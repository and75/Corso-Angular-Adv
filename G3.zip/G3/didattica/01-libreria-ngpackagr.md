# 01 — Creare una libreria nel workspace Angular

> **Tempo:** ~90 min (teoria + demo live `ng generate library`) · **Slide:** TBD · **Blocco:** G3 09:10–10:45

---

## Il problema

Dopo quattro moduli abbiamo costruito un'app catalogo che, riga dopo riga, ha accumulato una manciata di componenti che non sono affatto specifici del *catalogo prodotti*: la `ProductCard` multi-slot che abbiamo refactorato nel Lab 1 funziona benissimo come **scheda generica** con header/body/footer; il `Toast` del Lab 2 è una notifica visiva del tutto agnostica rispetto al dominio.

Poi, fuori dall'aula, arriva il messaggio che ognuno di noi si sente fare prima o poi:

> "Stiamo facendo una seconda app, l'area amministrativa. Vorremmo gli stessi bottoni, la stessa card, lo stesso toast. Possiamo riusare i tuoi componenti?"

A questo punto le strade sono tre, e una sola è quella giusta.

1. **Copia-incolla** — la classica "git clone, prendi `components/`, incolla". Funziona oggi. Domani qualcuno corregge un bug solo da una parte, e per i prossimi tre mesi i due Toast divergono lentamente come due fratelli che vivono in città diverse.
2. **Monorepo con percorsi relativi** (`import { ProductCard } from '../../app1/src/...'`) — funziona finché stai nello stesso filesystem. Quando l'app B vuole essere deployata da sola, ti accorgi che hai trasformato due progetti in un blob.
3. **Estrarre i componenti in una vera libreria npm**, con un nome, una versione, un contratto pubblico. È quella che ci interessa.

In questa scheda vediamo come Angular gestisce nativamente questa terza strada. Nella scheda 02 vedremo come la libreria si versiona e si pubblica; nel Lab 5 estrarremo davvero `ProductCard` e `Toast` da questa app.

---

## L'idea: il workspace multi-project

Una cosa che dal corso base potrebbe essere passata sotto silenzio: quando lanciamo `ng new product-catalog` non creiamo un *progetto* Angular — creiamo un **workspace** che, *al momento*, contiene un solo progetto (l'app). Lo si vede dal file `angular.json`:

```jsonc
{
  "projects": {
    "product-catalog": {           // ← un singolo progetto applicazione
      "projectType": "application",
      "root": "",
      "sourceRoot": "src",
      ...
    }
  }
}
```

Il workspace è quel contenitore in cui possono convivere **più progetti**: applicazioni *e* librerie. La cartella che li ospita è dichiarata in alto:

```jsonc
"newProjectRoot": "projects",
```

Vuol dire: "se da domani aggiungi altri progetti a questo workspace, mettili sotto `projects/`". Finché abbiamo una sola app, quella cartella non esiste nemmeno. Appena generiamo una libreria, nasce.

> **Metafora ricorrente.** Pensate al workspace come a un *condominio*. `product-catalog/` è l'appartamento storico al primo piano: c'era già quando avete preso le chiavi. `projects/` è il pianerottolo: vuoto finché non arrivano nuovi inquilini. La libreria che stiamo per generare sarà il primo nuovo inquilino, e accenderà il citofono comune (cioè il `tsconfig.json` di workspace) per farsi trovare dagli altri.

---

## `ng generate library` — la demo da non saltare

Diamo il comando in aula (su `product-catalog-finale/`, non sul seme):

```bash
ng generate library ui-kit --prefix=ui
```

Tre cose vanno guardate **insieme**, perché ognuna spiega l'altra:

1. **Cosa appare** sul filesystem.
2. **Cosa cambia** in `angular.json`.
3. **Cosa cambia** in `tsconfig.json`.

### 1. Cosa appare sul filesystem

```
product-catalog-finale/
├── projects/
│   └── ui-kit/
│       ├── ng-package.json          ← config build (ng-packagr)
│       ├── package.json             ← package npm "pubblicabile"
│       ├── tsconfig.lib.json        ← tsconfig di produzione
│       ├── tsconfig.lib.prod.json
│       ├── tsconfig.spec.json
│       ├── README.md
│       └── src/
│           ├── public-api.ts        ← ★ il "contratto pubblico"
│           └── lib/
│               ├── ui-kit.ts        ← un componente generato d'esempio
│               └── ui-kit.spec.ts
├── src/                              ← (immutato) sorgenti dell'app
├── angular.json                      ← modificato (vedi sotto)
├── tsconfig.json                     ← modificato (vedi sotto)
└── package.json                      ← invariato (ng-packagr arriva via devDep)
```

Il punto chiave: `projects/ui-kit/` è un *progetto a sé*, con il proprio `package.json`, il proprio `tsconfig`, il proprio README. Vive accanto all'app, ma non dipende da `src/`. Il workspace ne diventa solo l'ospite.

### 2. Cosa è cambiato in `angular.json`

L'oggetto `projects` ora ne contiene **due**:

```jsonc
{
  "projects": {
    "product-catalog": { /* invariato — la nostra app */ },

    "ui-kit": {                                       // ← nuovo
      "projectType": "library",                       // ← non "application"
      "root": "projects/ui-kit",
      "sourceRoot": "projects/ui-kit/src",
      "prefix": "ui",
      "architect": {
        "build": {
          "builder": "@angular/build:ng-packagr",     // ← ★ il builder cambia
          "options": {
            "tsConfig": "projects/ui-kit/tsconfig.lib.json",
            "project": "projects/ui-kit/ng-package.json"
          },
          "configurations": {
            "production": {
              "tsConfig": "projects/ui-kit/tsconfig.lib.prod.json"
            }
          }
        },
        "test": {
          "builder": "@angular/build:unit-test"
        }
      }
    }
  }
}
```

Notate due cose, perché in aula sono quelle che si dimenticano per prime.

- Il **builder di una libreria è diverso da quello di un'applicazione**. L'app usa `@angular/build:application` (bundler completo, produce HTML/CSS/JS pronti per il browser). La libreria usa `@angular/build:ng-packagr`, che produce un **pacchetto npm distribuibile**, non un sito da servire. Più sotto vediamo cosa cambia concretamente.
- Il `prefix: "ui"` è importante: tutti i componenti della libreria nasceranno con selector tipo `<ui-button>`, `<ui-card>`. Serve a evitare collisioni con i selettori dell'app (`<app-...>`) e con altre librerie installate.

### 3. Cosa è cambiato in `tsconfig.json` (di workspace)

Qui c'è la parte un po' magica:

```jsonc
{
  "compilerOptions": {
    ...
    "paths": {                                  // ← nuovo
      "@corso/ui-kit": [
        "./dist/ui-kit"
      ]
    }
  }
}
```

> **Nota.** Il path mapping di default che Angular CLI inserisce è `"ui-kit"` (il nome del progetto). Nel nostro corso lo cambieremo a mano in `"@corso/ui-kit"` (vedi scheda 02 e Lab 5) per allinearlo al nome scoped del pacchetto npm. È una modifica di una riga.

Cosa significa quel `paths`. Quando dall'app scriviamo:

```ts
import { ProductCardComponent } from '@corso/ui-kit';
```

TypeScript (e il builder Angular) non vanno a cercare in `node_modules/@corso/ui-kit` come farebbero con una libreria installata da npm: vanno a leggere `dist/ui-kit/` — cioè **l'output della build della libreria, dentro lo stesso workspace**. È un "ponte" che permette di sviluppare app e libreria fianco a fianco senza dover pubblicare ad ogni modifica.

**Perché questo e non l'import relativo (`../projects/ui-kit/src/...`)?** Perché vogliamo che l'app importi la libreria **esattamente come la importerà un domani che la libreria sarà su npm**. Lo stesso `import { ... } from '@corso/ui-kit'` deve funzionare:
- oggi, in workspace, contro `dist/ui-kit/` (artefatto locale);
- domani, contro `node_modules/@corso/ui-kit/` (pacchetto installato).

Se durante lo sviluppo importassimo `../projects/ui-kit/src/lib/...`, al primo `npm publish + npm install` la pagina nera: dovremmo cambiare tutti gli import. Path mapping = stesso import oggi e domani.

---

## La struttura di una libreria, dal vero

Apriamo `projects/ui-kit/src/lib/ui-kit.ts` (è il componente di esempio che la CLI ha generato):

```ts
import { Component } from '@angular/core';

@Component({
  selector: 'ui-ui-kit',           // ← prefisso "ui-" + nome
  standalone: true,
  template: `<p>ui-kit works!</p>`,
  styles: ``,
})
export class UiKitComponent {}
```

Nulla di esotico: un normale componente standalone. Quello che lo rende "libreria" non è il codice — è dove vive, *come viene buildato* e, soprattutto, **cosa di lui viene esportato**.

### `public-api.ts` — il contratto pubblico

Questo è il file più importante della libreria:

```ts
// projects/ui-kit/src/public-api.ts
export * from './lib/ui-kit';
```

Tutto ciò che è esportato qui dentro **è API pubblica** della libreria: lo vedrà chiunque scriva `import { ... } from '@corso/ui-kit'`. Tutto ciò che non è esportato qui dentro — anche se è `export class` nel suo file — *non esiste* per il consumer.

> **Metafora.** `public-api.ts` è la **vetrina del negozio**: i prodotti in vetrina sono comprabili; quelli nel retro no, anche se esistono. Quando nel Lab 5 estrarremo `ProductCard` e `Toast`, ogni componente che vorremo rendere consumabile dall'app dovrà passare di qui.

**Perché un singolo `public-api.ts` e non lasciare che ogni file esporti per sé?** Perché la libreria ha **una sola superficie pubblica**, e averla in un unico punto rende esplicito cosa promette di mantenere stabile. Quando, fra sei mesi, vi chiederete "se rinominiamo `ProductCardComponent` in `CardComponent` rompiamo qualcuno?", la risposta è in quel file. Se rimuovete una `export` da `public-api.ts`, state facendo un *breaking change*: la libreria perde un pezzo di API.

Lo stesso `package.json` della libreria lo dichiara:

```jsonc
// projects/ui-kit/package.json (estratto)
{
  "name": "ui-kit",
  "version": "0.0.1",
  "peerDependencies": {
    "@angular/common": "^21.0.0",
    "@angular/core": "^21.0.0"
  },
  "sideEffects": false
}
```

Lasciate da parte per ora `peerDependencies` e `sideEffects`: li affronteremo nella scheda 02 e nel Lab 5. Tenete in mente solo che `name` qui dentro è il nome npm che la libreria userà.

---

## `ng-packagr` — la build di una libreria

Quando lanciamo:

```bash
ng build ui-kit
```

non sta succedendo quello che succede con `ng build` sull'app. Niente HTML, niente CSS injection, niente lazy chunk, niente `index.html`. Sotto al cofano gira **ng-packagr**, e produce in `dist/ui-kit/`:

```
dist/ui-kit/
├── fesm2022/                       ← codice ES2022 in formato FESM (un singolo file flat per entry point)
│   └── corso-ui-kit.mjs
├── index.d.ts                      ← typings TypeScript
├── README.md
└── package.json                    ← package.json finalizzato per la pubblicazione
```

**Cos'è FESM (Flattened ES Module)?** È un singolo `.mjs` che raccoglie tutti i sorgenti della libreria già "appiattiti", pronto per essere consumato da un bundler (esbuild, webpack, Vite...). Non è codice "da eseguire in browser" — è codice "da consumare in build di un'altra app". È la differenza decisiva fra "io sono un'app" e "io sono una libreria":

| | App (`@angular/build:application`) | Libreria (`@angular/build:ng-packagr`) |
|---|---|---|
| Output | `index.html`, JS in chunk, CSS, asset | `*.mjs` FESM + `*.d.ts` + `package.json` |
| Per chi | il browser | un'altra build (npm consumer) |
| Treeshaking | finalizzato qui | lasciato al consumer |
| Code splitting / lazy chunk | sì | no, è un singolo modulo flat |
| AOT | runtime | template già pre-compilati |

**Perché un formato diverso e non "lo stesso bundle dell'app"?** Perché il consumer ha bisogno di **decidere lui** cosa includere. Se la libreria esporta 30 componenti e l'app ne usa 3, è il bundler dell'app che, partendo dal FESM, fa treeshaking. Se la libreria fosse già un bundle minified pronto, sarebbero 30 componenti dentro ogni build, e addio dimensioni.

> **`sideEffects: false`** in `package.json` della libreria è proprio il modo per dire al bundler dell'app: *"puoi tagliare via i componenti che il consumer non importa, non ho codice top-level con side effect"*. Senza quella riga, treeshaking compromesso.

---

## Cosa rende un componente "estraibile"

Prima di lanciarci nel Lab 5 e tirare fuori `ProductCard` e `Toast` dall'app, fissiamo un criterio. Un componente è "candidabile a libreria" se:

1. **Non importa codice del dominio dell'app.** `ProductCard` non deve sapere cos'è un `Product`: deve sapere di avere uno slot `header`, uno `body`, uno `footer`. Bene che nel Lab 1 l'abbiamo già refactorato così — di fatto l'abbiamo "estraibilificato" senza saperlo.
2. **Non inietta servizi specifici dell'app.** Niente `inject(CartService)`, niente `inject(ProductService)`. Va bene `inject(NotificationService)` *solo se* anche il servizio entra in libreria. Nel nostro caso il `Toast` userà un'interfaccia generica `Notifier` (o `inject()` di un token che l'app consumer fornisce) — lo vediamo nel Lab.
3. **Non dipende dal router della specifica app.** Un componente che fa `routerLink="/products/123"` non è riusabile, perché `/products` è una rotta della *nostra* app. Si parametrizza con `@Input() linkTo: string` oppure si emette un evento e si lascia decidere al consumer.
4. **Ha input/output chiari.** Niente metodi pubblici "da chiamare da fuori": tutto passa per `@Input()` (signal o classico) e `@Output()`. La superficie pubblica del componente è la sua firma TypeScript.
5. **Stili contenuti.** Niente classi globali Tailwind/CSS che esistono solo nell'app consumer: o lo stile sta dentro la component CSS, o si espone un `class` slot per la personalizzazione.

`ProductCard` (multi-slot, dopo Lab 1) e `Toast` (Lab 2 + `NotificationService` lasciato fuori) passano tutti e cinque i criteri. Nel Lab 5 li sposteremo davvero in `projects/ui-kit/`.

---

## Sviluppare app e libreria fianco a fianco

Una libreria non si pubblica ad ogni save. Il workflow tipico in workspace è:

```bash
# Terminale 1 — build incrementale della libreria
ng build ui-kit --watch

# Terminale 2 — dev server dell'app
ng serve
```

Il primo comando ricostruisce `dist/ui-kit/` ad ogni modifica della libreria. Il secondo è il consueto `ng serve`: grazie al path mapping in `tsconfig.json`, l'app legge dalla `dist/ui-kit/` che il watch tiene aggiornata. Modifico un componente in `projects/ui-kit/src/lib/...`, l'app si ricarica.

**Perché due terminali e non un solo comando?** Perché sono due build con due lifecycle diversi: la libreria produce un *artefatto* da consumare, l'app lo *consuma*. Tenerli separati permette anche di fermare il rebuild della libreria quando si sta lavorando solo sull'app — risparmio di CPU non banale su laptop in aula.

> Dopo il primo `ng build ui-kit` (anche senza `--watch`) la cartella `dist/ui-kit/` esiste e il path mapping risolve. Se in aula vedete `Cannot find module '@corso/ui-kit'`, novanta volte su cento è perché la build della libreria non è ancora stata lanciata.

---

## Errori comuni

### 1. Modificare la libreria e aspettarsi che l'app la veda subito senza rebuild

```bash
# ❌ Non basta
ng serve
# modifico projects/ui-kit/src/lib/product-card.ts
# ricarico la pagina → vedo ancora la versione vecchia
```

Il dev server dell'app guarda `dist/ui-kit/`, che non si aggiorna da solo. Serve sempre:

```bash
# ✅
ng build ui-kit --watch     # in un secondo terminale
```

### 2. Importare dalla libreria con path relativo

```ts
// ❌ Funziona ora, si rompe alla pubblicazione
import { ProductCardComponent } from '../../../projects/ui-kit/src/lib/product-card';

// ✅ Stesso import oggi (locale) e domani (da npm)
import { ProductCardComponent } from '@corso/ui-kit';
```

### 3. Esportare un componente ma dimenticarlo in `public-api.ts`

```ts
// projects/ui-kit/src/lib/product-card.ts
export class ProductCardComponent { ... }    // ← export TS, c'è
```

```ts
// projects/ui-kit/src/public-api.ts
export * from './lib/ui-kit';
// ❌ manca: export * from './lib/product-card';
```

Dall'app: `Module '"@corso/ui-kit"' has no exported member 'ProductCardComponent'`. La libreria *contiene* il componente, ma non lo *espone*. Tenete `public-api.ts` come "to-do list" della superficie pubblica.

### 4. Mettere dipendenze dell'app dentro la libreria

```ts
// projects/ui-kit/src/lib/product-card.ts
import { ProductService } from 'src/app/product.service';   // ❌
```

`src/app/...` è codice dell'app consumer, non della libreria. Anche se "compila" (perché il workspace lo vede), la libreria pubblicata su npm non avrà `src/app/`. Risultato: pacchetto rotto al primo `npm install`.

### 5. Selettori senza prefisso

```ts
@Component({ selector: 'card', ... })       // ❌ collide con qualsiasi cosa
@Component({ selector: 'ui-card', ... })    // ✅ prefisso della libreria
```

Lo `--prefix=ui` che abbiamo dato a `ng generate library` esiste apposta: i selettori della libreria diventano riconoscibili nel template e non litigano con i `<app-...>` dell'app.

---

## Schema riassuntivo

```
WORKSPACE: product-catalog-finale/
├── src/                              ← APP (projectType: application)
│   └── app/.../catalog.page.ts ──┐
│                                 │  import { ProductCard } from '@corso/ui-kit';
│                                 │
│  tsconfig.json: paths {         │   (TS risolve qui ↓)
│    "@corso/ui-kit":             ▼
│      "./dist/ui-kit"            ┌──────────────────────────────┐
│  }                              │  dist/ui-kit/                │
│                                 │   ├── fesm2022/*.mjs (FESM)  │
│                                 │   ├── index.d.ts (typings)   │
│                                 │   └── package.json           │
│                                 └─────────────▲────────────────┘
│                                               │
│                                  ng build ui-kit --watch
│                                               │
└── projects/ui-kit/                LIBRERIA (projectType: library)
    ├── ng-package.json             ← config ng-packagr
    ├── package.json                ← name, version, peerDeps
    └── src/
        ├── public-api.ts           ← ★ contratto pubblico (la "vetrina")
        └── lib/
            ├── product-card.ts     ← (Lab 5: spostato qui)
            └── toast.ts            ← (Lab 5: spostato qui)
```

| Concetto | Cosa è | Dove vive |
|---|---|---|
| Workspace | Contenitore di N progetti (app + librerie) | `angular.json` lo descrive |
| `projects/` | Cartella dei progetti aggiunti dopo l'app | `newProjectRoot` in `angular.json` |
| `public-api.ts` | API pubblica della libreria — la "vetrina" | `projects/<lib>/src/public-api.ts` |
| `ng-package.json` | Config di build per ng-packagr | `projects/<lib>/ng-package.json` |
| Path mapping | Ponte `@corso/ui-kit` → `dist/ui-kit/` durante lo sviluppo | `tsconfig.json` di workspace |
| FESM | Flattened ES Module — l'output di una build di libreria | `dist/<lib>/fesm2022/` |
| Builder libreria | `@angular/build:ng-packagr` (non `application`) | `angular.json`, `architect.build.builder` |

---

## Prossimo: [02 — Versioning, peerDependencies e publish con Verdaccio](./02-versioning-publish.md)
