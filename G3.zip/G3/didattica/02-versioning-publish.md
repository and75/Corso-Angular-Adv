# 02 — Versioning, peerDependencies e publish con Verdaccio

> **Tempo:** ~45 min · **Slide:** TBD · **Blocco:** G3 11:00–11:45

---

## Il problema

Nella scheda 01 abbiamo generato la libreria `ui-kit` e capito che `public-api.ts` è la sua vetrina. Finché viviamo dentro il workspace, l'app la importa via path mapping (`@corso/ui-kit` → `dist/ui-kit/`). Tutto bene.

Il momento di verità arriva quando proviamo a **portare la libreria fuori**: lo richiede l'app B, l'altro team, la pipeline CI, qualcuno che la vuole installare con `npm install`. Lì cambia tutto:

- Quale numero le diamo? E se domani la rilasciamo di nuovo, *come* si cambia?
- Cosa succede se la libreria dipende da `@angular/core` e l'app *anche*: ci ritroviamo Angular due volte?
- Dove la pubblichiamo, in aula, senza account npmjs e senza connessione?
- Cosa finisce, materialmente, nel pacchetto pubblicato?

Questa scheda risponde a quei quattro punti. Lo strumento di publish in aula è **Verdaccio** — un registry npm locale che si comporta come npmjs ma vive su `localhost`. La differenza con il publish "vero" si riduce a una manciata di parametri, e lo vedremo.

---

## `package.json` della libreria: nome e versione

Riapriamo `projects/ui-kit/package.json` — il file che ng-packagr usa come base per produrre `dist/ui-kit/package.json` (cioè il `package.json` *vero*, quello che finirà nel pacchetto):

```jsonc
{
  "name": "@corso/ui-kit",
  "version": "1.0.0",
  "peerDependencies": {
    "@angular/common": "^21.0.0",
    "@angular/core": "^21.0.0"
  },
  "sideEffects": false
}
```

Due cose che da qui escono.

**`name` con scope (`@corso/ui-kit`).** Lo scope è quel pezzo tra `@` e `/`. Nei progetti seri lo si usa quasi sempre: serve a evitare collisioni nel registry (`ui-kit` senza scope si chiama come duecento altre librerie sul pianeta) e a raggruppare i pacchetti di un'organizzazione. In npmjs.com lo scope corrisponde a un account o a un'organizzazione (`@anthropic`, `@angular`, `@nestjs`…); nel nostro Verdaccio "di aula" lo scope è solo una convenzione di nomi.

> **Metafora ricorrente.** Il registry npm è un *grande mercato comunale*. I pacchetti senza scope sono i banchi storici con un nome di una parola — chi arriva tardi non lo trova più libero. Gli scope sono *gallerie commerciali* private: dentro `@corso/` ci stiamo noi, dentro `@angular/` ci sta Angular, nessuno calpesta il nome di nessuno. Per questo nel corso useremo scope sempre.

**`version: "1.0.0"`.** Questa è la prima versione che pubblicheremo. Nel Lab 5 la bumperemo a `1.1.0` per dimostrare il rilascio di una nuova feature retro-compatibile — ma prima di fare *bump* dobbiamo capire le regole.

---

## semver — leggere e scrivere i tre numeri

Le versioni npm seguono **semver** (semantic versioning), tre numeri separati da punto:

```
1.4.7
│ │ └── PATCH  → bug fix, nessuna API cambiata
│ └──── MINOR  → nuova funzionalità, retro-compatibile (chi sta a 1.3.x può salire a 1.4.x senza toccare codice)
└────── MAJOR  → breaking change (qualcosa che prima funzionava ora non funziona o si chiama diverso)
```

La regola si legge in due tempi: **chi pubblica** decide se il diff è un patch/minor/major; **chi consuma** vede quel numero e sa cosa rischia ad aggiornare.

### Esempi concreti dalla nostra libreria

| Cambiamento alla `ui-kit` | Bump | Perché |
|---|---|---|
| Fix a un `style` di `Toast` che lasciava un bordo a 1px | `1.0.0` → `1.0.1` (patch) | Nessuna API cambia, comportamento sostanzialmente identico |
| Aggiunta di un nuovo `@Input() severity` opzionale a `Toast` | `1.0.0` → `1.1.0` (minor) | Chi non lo usa non se ne accorge, chi vuole può usarlo |
| Rinominato `ProductCardComponent` in `CardComponent` (così è davvero generico) | `1.0.0` → `2.0.0` (major) | Tutti gli `import { ProductCardComponent }` esistenti si rompono |
| Rimosso un `@Output() closed` da `Toast` | `1.0.0` → `2.0.0` (major) | Si rompe la `(closed)=...` in chi lo usa |

### I range nel `package.json` del consumer

Quando l'app B fa `npm install @corso/ui-kit`, nel suo `package.json` finisce qualcosa come:

```jsonc
"dependencies": {
  "@corso/ui-kit": "^1.0.0"
}
```

Quel `^` è il default di npm. Significa:

```
"^1.0.0"   →  qualunque versione 1.x.y compatibile (1.0.0, 1.1.0, 1.4.7…), MA non 2.0.0
"~1.0.0"   →  solo patch dello stesso minor (1.0.0, 1.0.1, 1.0.99), MA non 1.1.0
"1.0.0"    →  esattamente quella versione, nessun aggiornamento automatico
"latest"   →  qualunque cosa il registry chiami "ultima" — ⚠ pericoloso, non usatelo nei lockfile
```

> **Perché `^` di default e non `~`?** Perché il contratto semver dice che minor e patch sono *retro-compatibili*: se Angular cambia a `21.3.0` e abbiamo `^21.0.0`, è la promessa di npm e del manutentore che la nostra app non si rompe. Con `~` resteremmo bloccati ai bug fix e ci perderemmo le feature minor. La promessa, ovviamente, vale finché il manutentore rispetta semver — ma è il patto sociale di npm.

---

## `peerDependencies` — perché `@angular/*` non sta in `dependencies`

Riapriamo `package.json` della libreria e guardiamo questa riga:

```jsonc
"peerDependencies": {
  "@angular/common": "^21.0.0",
  "@angular/core": "^21.0.0"
}
```

Notate: **non** è `dependencies`. È `peerDependencies`. La differenza, sull'apparenza, è zero — entrambe dichiarano un pacchetto richiesto. Nella sostanza, è la differenza tra un'app che funziona e un'app che si pianta al primo `inject()`.

### Cosa succederebbe con `dependencies`

Se la libreria mettesse `@angular/core: "^21.0.0"` in `dependencies`:

```
app
├── node_modules/
│   ├── @angular/core/   ← versione installata dall'app (21.2.0)
│   └── @corso/ui-kit/
│       └── node_modules/
│           └── @angular/core/   ← ★ una SECONDA copia, installata dalla lib (21.0.4)
```

Due copie di Angular nello stesso runtime significano **due istanze di tutti i token di injection** (`HttpClient`, `Router`, `NgZone`...). I servizi che la libreria inietta non sono quelli dell'app. Nel browser si manifesta come:

- `NullInjectorError: No provider for HttpClient!` (la libreria ha la sua istanza di iniettore che non conosce i provider dell'app)
- componenti della libreria che non vedono il `Router` dell'app
- in casi sottili, `signal()` o `effect()` che funzionano "metà" perché il framework è duplicato

### Cosa cambia con `peerDependencies`

Con `peerDependencies` la libreria sta dicendo, letteralmente: *"ho bisogno di `@angular/core ^21.0.0`, ma **non installarmelo tu** — assumo che chi mi installa (l'app consumer) l'abbia già; io userò la **sua** istanza"*.

```
app
├── node_modules/
│   ├── @angular/core/    ← UNA istanza (quella dell'app)
│   └── @corso/ui-kit/    ← usa la stessa istanza, non porta la sua
```

Una sola istanza di Angular nel runtime. Tutti i token vivono nello stesso DI tree. È il modello che *deve* avere ogni libreria Angular pubblicata su npm — e ng-packagr lo applica per noi, automaticamente.

### "Automaticamente" come?

Quando lanciamo `ng build ui-kit`, ng-packagr legge `projects/ui-kit/package.json` (la nostra fonte) e produce `dist/ui-kit/package.json` (il pacchetto finale). In mezzo applica una serie di trasformazioni: una è proprio **promuovere `@angular/*` a `peerDependencies`** se nel sorgente fossero per errore in `dependencies`. Non vi fidate: andate a guardare `dist/ui-kit/package.json` dopo la build — quello è il `package.json` *vero*, l'altro è solo l'origine.

**Perché allora teniamo `peerDependencies` esplicito anche nel sorgente?** Per chiarezza dell'intento. Il sorgente *dichiara* il contratto; ng-packagr lo *applica*. Se un domani uno sviluppatore distratto mette `@angular/core` in `dependencies`, ng-packagr lo correggerà ma una review onesta dovrebbe pescarlo subito.

---

## Il flusso di publish: cosa finisce nel pacchetto

Da `product-catalog-finale/`:

```bash
# 1. Build della libreria — produce dist/ui-kit/
ng build ui-kit

# 2. Pubblicazione del CONTENUTO di dist/ui-kit/
cd dist/ui-kit
npm publish --registry http://localhost:4873
```

Tre cose vanno tenute in mente, perché in aula sbagliano tutti almeno una.

**1. Si pubblica `dist/ui-kit/`, non `projects/ui-kit/`.** Il sorgente non si pubblica mai; quello che va su npm è l'artefatto buildato da ng-packagr — FESM, typings, `package.json` finalizzato. Lo `cd dist/ui-kit && npm publish` è il modo canonico: `npm publish` pubblica la cartella corrente, e la cartella corrente *dev'essere* `dist/ui-kit`.

**2. `--registry http://localhost:4873`.** Senza questo, `npm publish` parla con npmjs.com (il default). In aula non vogliamo né possiamo arrivare lì: dirigiamo tutto verso il Verdaccio locale.

**3. Cosa finisce nel pacchetto:**

```
@corso/ui-kit-1.0.0.tgz
├── package.json           ← name, version, peerDependencies, "main": "fesm2022/...mjs"
├── README.md
├── index.d.ts
└── fesm2022/
    └── corso-ui-kit.mjs   ← codice della libreria (Flattened ES Module)
```

I sorgenti TS originali (`projects/ui-kit/src/lib/*.ts`) **non** ci sono. Gli `.spec.ts` non ci sono. Il `tsconfig.lib.json` non c'è. Resta solo ciò che serve a consumare la libreria: tipi (`.d.ts`), implementazione (`fesm2022/*.mjs`), metadati (`package.json`, `README.md`).

> Volete vedere *davvero* cosa finirà nel pacchetto prima di pubblicare? Da `dist/ui-kit/` lanciate `npm pack`. Crea il `.tgz` senza pubblicarlo: scompattatelo e date un'occhiata.

---

## Verdaccio — un registry npm sul portatile

Verdaccio è un registry npm completo che gira in locale. Si avvia con un comando:

```bash
npx verdaccio
```

Al primo avvio crea config e storage in `~/.config/verdaccio/` (su Windows: `%APPDATA%/verdaccio/`). Risponde su `http://localhost:4873` — apre anche una piccola UI web in cui si vedono i pacchetti pubblicati.

### Autenticazione: `npm adduser`

Verdaccio richiede un utente per pubblicare. Si crea così:

```bash
npm adduser --registry http://localhost:4873
# username: corso
# password: corso
# email: corso@example.com
```

`npm adduser` salva il token in `.npmrc` (di solito quello globale di utente, in `~/.npmrc`):

```ini
//localhost:4873/:_authToken=eyJhbGc...
```

Da quel momento, finché il token c'è, `npm publish --registry http://localhost:4873` funziona senza chiedere la password.

### Configurazioni alternative

Se ripetere `--registry http://localhost:4873` su ogni comando dà fastidio, c'è la via del `.npmrc` di progetto. In `product-catalog-finale/.npmrc`:

```ini
@corso:registry=http://localhost:4873
```

Cosa fa: dice a npm "*tutti* i pacchetti scope `@corso/...` vanno a `localhost:4873`". I pacchetti senza scope (`@angular/*`, `rxjs`, `tailwindcss`...) continuano ad andare su npmjs.com. È la configurazione che useremo nel Lab 5: scoped registry, una riga, indolore.

### Perché Verdaccio in aula e non npmjs.com

Tre motivi pratici:

1. **Niente account, niente connessione.** Funziona offline (i pacchetti pubblicati in aula restano sul vostro disco).
2. **Niente collisioni di nomi.** Su npmjs `@corso/ui-kit` potrebbe essere già preso o protetto; su Verdaccio del vostro portatile siete soli.
3. **Niente "unpublish è quasi impossibile".** Su npmjs.com una versione pubblicata, anche per errore, *non si tira giù davvero* (c'è una finestra di 72h, poi è bloccata). Su Verdaccio basta cancellare la cartella in `~/.config/verdaccio/storage/`. In aula stiamo facendo esperimenti: ci serve un cestino.

### Cosa cambia in produzione (npmjs o registry aziendale)

| Aspetto | Verdaccio (aula) | npmjs.com / registry aziendale |
|---|---|---|
| `--registry` | `http://localhost:4873` | omesso (default) o URL aziendale |
| Account | `npm adduser` locale, password libera | account verificato (npmjs) o SSO aziendale |
| Pacchetti scoped | pubblici di default | **`npm publish --access public`** se gratis su npmjs, altrimenti scope privati a pagamento |
| Unpublish | cestina la cartella | possibile entro 72h, poi bloccato |
| Latenza | locale | rete + CDN |

**Una sola riga importante**: per pubblicare *uno scope* su npmjs.com con un account free serve `--access public`:

```bash
npm publish --access public
```

Senza, npmjs assume che lo scope sia privato (=a pagamento) e blocca con `402 Payment Required`. In aula non capita perché Verdaccio non distingue pubblico/privato come fa npmjs.

---

## Consumare la libreria dal *vero* registry

Dopo `npm publish` (vedremo nel Lab 5), la libreria è installabile come qualunque altro pacchetto npm. Da un'altra app (o anche dalla nostra stessa, dopo aver pulito):

```bash
# Con .npmrc scoped: questo basta
npm install @corso/ui-kit

# Senza .npmrc: bisogna passare il registry
npm install @corso/ui-kit --registry http://localhost:4873
```

A questo punto in `app/package.json`:

```jsonc
"dependencies": {
  "@corso/ui-kit": "^1.0.0"
}
```

E gli `import` cambiano una sola cosa, e nemmeno quella per essere onesti — restano identici:

```ts
import { ProductCardComponent, ToastComponent } from '@corso/ui-kit';
```

> **Perché identici?** Perché abbiamo lavorato bene: in workspace, l'import passava da path mapping; da pacchetto installato, passa da `node_modules/@corso/ui-kit/`. Lo stesso simbolo `@corso/ui-kit` è risolto da due fonti diverse a seconda di chi arriva prima, ma il codice dell'app non se ne accorge. Questo è il dividendo del path mapping di cui abbiamo parlato nella scheda 01.

---

## Aggiornamenti: `npm version` e bump pulito

Quando, dopo il primo publish, aggiungiamo una feature (esempio Lab 5: nuovo `@Input() severity` sul `Toast`), il flusso è:

```bash
# Da projects/ui-kit/
cd projects/ui-kit
npm version minor      # 1.0.0 → 1.1.0  (modifica package.json e committa)

# Build + publish del nuovo artefatto
cd ../..
ng build ui-kit
cd dist/ui-kit
npm publish --registry http://localhost:4873
```

`npm version minor` fa tre cose in un colpo solo: aggiorna `version` nel `package.json`, fa un commit `1.1.0` (se sei in un repo git pulito) e crea il tag `v1.1.0`. Esistono `npm version patch` e `npm version major`. La parte automatica vale solo se il working tree git è pulito; se non lo è, npm si rifiuta per evitare di committare per sbaglio modifiche estranee.

> **Perché bumpare nel sorgente e non in `dist/ui-kit/package.json`?** Perché `dist/` è rigenerato ad ogni build: la versione che bumpo in `dist/` la sovrascrivo al `ng build` successivo. La fonte di verità della versione è `projects/ui-kit/package.json`, che ng-packagr copia in `dist/ui-kit/package.json` durante la build.

### dist-tags — pubblicare canary, beta, latest

Per default `npm publish` etichetta come `latest` la versione appena pubblicata. È quella che `npm install @corso/ui-kit` (senza specificare versione) installa. A volte vogliamo pubblicare una pre-release senza promuoverla a `latest`:

```bash
npm publish --tag beta --registry http://localhost:4873
# poi:
npm install @corso/ui-kit@beta
```

Chi continua a installare `@corso/ui-kit` senza tag, riceve ancora la `latest` precedente. È il modo pulito per testare in un'altra app senza disturbare gli utenti "normali". In aula non lo useremo, ma sapete che esiste.

### CHANGELOG — promessa, non documentazione

Una libreria che esce su un registry **deve** avere un CHANGELOG: il consumer ha bisogno di sapere cosa cambia da `1.0.0` a `1.1.0`. Va aggiornato *prima* di `npm version`, non dopo (così il commit di bump contiene anche il changelog). Formato consigliato: [Keep a Changelog](https://keepachangelog.com/) — sezioni `Added / Changed / Deprecated / Removed / Fixed / Security` per ogni versione. Nel Lab 5 ne mettiamo uno minimale.

---

## Errori comuni

### 1. Mettere `@angular/core` in `dependencies` della libreria

```jsonc
// projects/ui-kit/package.json
"dependencies": { "@angular/core": "^21.0.0" }    // ❌
```

L'app consumer si ritrova doppia istanza di Angular → `NullInjectorError` casuali. Va sempre in `peerDependencies`. ng-packagr correggerebbe, ma non fatevi notare in code review.

### 2. `npm publish` da `projects/ui-kit/` invece che da `dist/ui-kit/`

```bash
# ❌ pubblica i sorgenti TS, niente FESM, niente typings
cd projects/ui-kit && npm publish

# ✅
cd dist/ui-kit && npm publish
```

Verdaccio accetta entrambi, ma il pacchetto del primo caso è inservibile per chi lo installa.

### 3. Dimenticare `--registry` (o `.npmrc`)

```bash
npm publish    # ❌ se non c'è .npmrc, va su npmjs.com → 404 o 401
```

In aula, abituatevi a vedere il registry esplicito o usate `.npmrc` di progetto.

### 4. Bumpare a major per una nuova feature

```
1.0.0 → 2.0.0   per aver aggiunto un @Input() opzionale       ❌
1.0.0 → 1.1.0                                                  ✅
```

Una major è un *patto rotto*: dite ai consumer "preparatevi a cambiare codice". Usatela solo quando è vero.

### 5. Pubblicare due volte la stessa versione

```bash
npm publish    # ok, pubblica 1.0.0
# correggo un bug
npm publish    # ❌ "You cannot publish over the previously published versions"
```

Una versione, una volta. Per ripubblicare serve bumpare (patch). Anche in Verdaccio il comportamento è lo stesso — solo che cancellando la cartella in `storage/` "scordate" la pubblicazione precedente.

---

## Schema riassuntivo

```
SVILUPPO E PUBLISH
──────────────────

projects/ui-kit/                          ┌───────────────────────────────┐
├── package.json   ◄── version, peerDeps  │                               │
└── src/                                  │       ng build ui-kit         │
                                          │                               │
                                          └──────────────┬────────────────┘
                                                         ▼
                                  dist/ui-kit/                  ◄── ng-packagr
                                  ├── package.json (finalizzato)
                                  ├── index.d.ts
                                  └── fesm2022/corso-ui-kit.mjs
                                                         │
                                          cd dist/ui-kit │ npm publish --registry http://localhost:4873
                                                         ▼
                                      ┌──────────────────────────────┐
                                      │  VERDACCIO  (localhost:4873) │
                                      │   @corso/ui-kit@1.0.0  ✓     │
                                      └──────────────┬───────────────┘
                                                     │
                                       npm install @corso/ui-kit
                                                     ▼
                                  app B / app A
                                  node_modules/@corso/ui-kit/
                                  └── import { ProductCardComponent } from '@corso/ui-kit'
```

| Concetto | In una frase |
|---|---|
| `name: "@corso/ui-kit"` | Scope + nome del pacchetto npm |
| `version: "1.0.0"` | Versione semver corrente — fonte di verità in `projects/ui-kit/package.json` |
| MAJOR / MINOR / PATCH | Breaking / nuova feature retro-compatibile / bug fix |
| `^1.0.0` (default npm) | Accetto qualsiasi `1.x.y` ma non `2.x` |
| `peerDependencies` | Dichiaro la dipendenza, ma la installa il consumer (una sola istanza di Angular) |
| `--registry http://localhost:4873` | Punto a Verdaccio anziché npmjs |
| `.npmrc` scoped (`@corso:registry=...`) | Stesso effetto, in modo permanente per quello scope |
| `cd dist/ui-kit && npm publish` | L'unico modo *giusto* di pubblicare la libreria buildata |
| `npm version minor` | Bump pulito: aggiorna `package.json`, commit, tag git |
| `npm publish --tag beta` | Pubblica senza promuovere a `latest` |
| `npm publish --access public` (solo npmjs) | Permette di pubblicare scope free su npmjs.com |

---

## Prossimo: Lab 5 — Estrazione `ui-kit` + publish su Verdaccio
