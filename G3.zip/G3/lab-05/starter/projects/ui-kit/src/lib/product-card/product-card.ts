/**
 * LAB 5 — STARTER
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/lib/product-card/product-card.ts
 *
 * ProductCardComponent — versione "di libreria".
 * Si distingue dalla card che vive(va) nell'app per quello che NON ha:
 *   ✗ niente import del tipo `Product` del dominio dell'app
 *   ✗ niente inject(Router) — la card non decide dove portarvi
 *   ✗ niente riferimenti a percorsi assoluti dell'app
 *
 * Il contratto è invece tutto qui, esplicito, generico e riusabile:
 *   - un'interfaccia `ProductCardData` con il minimo che la card sa rendere;
 *   - un input richiesto di quel tipo;
 *   - due output che descrivono cosa è successo, non cosa farne.
 *
 * Scheda di riferimento: ../../../../Corso/G3/didattica/01-libreria-ngpackagr.md
 * (sezione "Cosa rende un componente estraibile")
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * Setup base (già pronto)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * Selettore       → 'ui-product-card' (prefisso `ui-` definito da --prefix=ui)
 * standalone      → true
 * templateUrl     → './product-card.html'
 * imports         → NgClass (per la classe condizionale "Esaurito")
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * TODO 2.2 — MEDIO
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * TODO 2.2.a — Esportare l'interfaccia `ProductCardData` con questi campi:
 *     id          : string | number   (chiave per la `detail` emessa)
 *     name        : string
 *     price       : number            (in EUR, importo grezzo)
 *     imageUrl    : string
 *     category?   : string            (opzionale — non tutti i domini la hanno)
 *     available?  : boolean           (opzionale — default: trattato come true)
 *
 * TODO 2.2.b — Dichiarare gli input/output della classe:
 *     - product : input richiesto di tipo ProductCardData
 *                 (firma: input.required<ProductCardData>())
 *     - detail  : output che emette l'id corrente (string | number)
 *     - addToCart : output che emette il ProductCardData corrente
 *
 *   Niente `inject(Router)`, niente `router.navigate(...)`. La navigazione
 *   è responsabilità del consumer (l'app).
 *
 * TODO 2.2.c — Calcolare il prezzo formattato come `computed()`:
 *   - usa Intl.NumberFormat con locale 'it-IT', style 'currency', currency 'EUR'
 *   - applica .format(this.product().price)
 *   - esposto al template come signal `formattedPrice`
 *
 * TODO 2.2.d — Esporre due metodi al template:
 *     onDetail() → emette this.product().id sull'output `detail`
 *     onAdd()    → emette this.product() sull'output `addToCart`
 *
 * ⚠ Suggerimento di stile: tieni la firma del componente piatta (proprietà
 *   pubbliche per input/output, due metodi privati per gli emit). Una libreria
 *   ben fatta è quella che si "scopre da sola" leggendo le sue 30 righe.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Component } from '@angular/core';
import { NgClass } from '@angular/common';

// TODO: aggiungere gli import necessari (input, output, computed)

// TODO 2.2.a: dichiarare ed esportare l'interfaccia ProductCardData

@Component({
  selector: 'ui-product-card',
  standalone: true,
  imports: [NgClass],
  templateUrl: './product-card.html',
})
export class ProductCardComponent {
  // TODO 2.2.b: input `product`, output `detail`, output `addToCart`

  // TODO 2.2.c: computed `formattedPrice`

  // TODO 2.2.d: onDetail() e onAdd()
}
