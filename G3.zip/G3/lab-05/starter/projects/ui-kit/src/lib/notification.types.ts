/**
 * LAB 5 — STARTER
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/lib/notification.types.ts
 *
 * Tipi condivisi fra il ToastComponent (che vive in libreria, presentational)
 * e il consumer dell'app (che ha il NotificationService e produce le
 * notifiche). Stare qui, in libreria, garantisce che il consumer importi
 * lo stesso `Notification` che il toast si aspetta — un unico contratto.
 *
 * TODO 2.1 — MEDIO (FACILE):
 *   Definire ed esportare l'interfaccia `Notification` con i 3 campi che il
 *   NotificationService dell'app già emette nel BehaviorSubject:
 *     - id: number              (chiave per il @for/track e per il dismiss)
 *     - type: union di 3 letterali ('success' | 'error' | 'info')
 *     - message: string         (testo mostrato a video dal toast)
 *
 *   ⚠ Niente classi, niente metodi — è puro contratto strutturale.
 *   Sarà il NotificationService dell'app a creare oggetti di questa forma.
 * ─────────────────────────────────────────────────────────────────────────────
 */

// TODO: dichiarare ed esportare l'interfaccia Notification
