/**
 * LAB 5 — STARTER
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/lib/toast/toast.ts
 *
 * ToastComponent — versione "di libreria", presentational al 100%.
 * Il vecchio Toast (Lab 2) era smart: iniettava NotificationService, si
 * sottoscriveva a notifications$, gestiva il DestroyRef. In libreria
 * non può fare niente di tutto questo: il NotificationService è codice
 * dell'app, non lo conosciamo qui.
 *
 * Modello: "dati dentro, eventi fuori":
 *   - INPUT  → items (array di Notification)
 *   - OUTPUT → dismiss (id da chiudere)
 *
 * Sarà il consumer (l'app) a:
 *   - iniettare NotificationService
 *   - convertire notifications$ in signal con toSignal()
 *   - passarne il valore a [items] e ascoltare (dismiss)
 *
 * Scheda di riferimento: ../../../../Corso/G3/didattica/01-libreria-ngpackagr.md
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * Setup base (già pronto)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * Selettore       → 'ui-toast'
 * standalone      → true
 * templateUrl     → './toast.html'
 * imports         → NgClass (per le varianti success/error/info)
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * TODO 2.3 — MEDIO
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * TODO 2.3.a — Importare il tipo `Notification` da '../notification.types'.
 *
 * TODO 2.3.b — Dichiarare:
 *     - items   : input richiesto di tipo Notification[]
 *                 (firma: input.required<Notification[]>())
 *     - dismiss : output<number>()
 *
 *   Niente inject(NotificationService).
 *   Niente DestroyRef, niente takeUntilDestroyed.
 *   Niente signal locale alimentato da Observable — qui non c'è Observable.
 *
 * TODO 2.3.c — Esporre un metodo `onDismiss(id: number)` che fa:
 *     this.dismiss.emit(id);
 *
 *   Il template chiamerà (click)="onDismiss(n.id)" sul bottone di chiusura.
 *
 * ⚠ Punto da non dimenticare a fine TODO: aggiornare `public-api.ts` per
 *   esportare ToastComponent (e l'interfaccia Notification dai types).
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Component } from '@angular/core';
import { NgClass } from '@angular/common';

// TODO 2.3.a: import di `input`, `output` da @angular/core e di `Notification` da '../notification.types'

@Component({
  selector: 'ui-toast',
  standalone: true,
  imports: [NgClass],
  templateUrl: './toast.html',
})
export class ToastComponent {
  // TODO 2.3.b: items (input.required<Notification[]>) + dismiss (output<number>)

  // TODO 2.3.c: onDismiss(id: number)
}
