/**
 * LAB 5 — STARTER
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/public-api.ts
 *
 * Il "contratto pubblico" della libreria @corso/ui-kit.
 * Tutto ciò che è esportato da qui è visibile a chi installa il pacchetto;
 * tutto ciò che NON è esportato qui non esiste, anche se è dichiarato
 * `export class` o `export interface` nel suo file.
 *
 * TODO 2.4 — MEDIO (FACILE):
 *   Aggiungere TRE righe di re-export, una per ciascun modulo della libreria:
 *     - i tipi di notifica (definiti in ./lib/notification.types)
 *     - il componente ProductCardComponent e l'interfaccia ProductCardData
 *       (definiti in ./lib/product-card/product-card)
 *     - il componente ToastComponent (definito in ./lib/toast/toast)
 *
 *   Forma di una riga: export * from '<path relativo senza estensione>';
 *
 *   ⚠ Tenere questo file allineato a mano è parte del lavoro: ogni volta che
 *   aggiungete un componente alla libreria, va dichiarato qui — altrimenti
 *   il consumer non lo vede.
 * ─────────────────────────────────────────────────────────────────────────────
 */

// TODO: qui i 3 export
