/**
 * LAB 5 — SOLUTION
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/lib/notification.types.ts
 *
 * Contratto strutturale (zero comportamento) condiviso fra:
 *   - il NotificationService dell'app (lo produce: BehaviorSubject<Notification[]>)
 *   - il ToastComponent della libreria (lo consuma: input.required<Notification[]>())
 *
 * Esportare il tipo dalla LIBRERIA è la scelta giusta: il toast lo richiede,
 * quindi è suo. L'app importerà `Notification` da '@corso/ui-kit' per essere
 * sicura di costruire oggetti con la shape che il toast riconosce.
 * ─────────────────────────────────────────────────────────────────────────────
 */

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}
