/**
 * LAB 5 — SOLUTION
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/lib/product-card/product-card.ts
 *
 * ProductCardComponent di libreria.
 * Differenze rispetto alla card del Lab 1 (che vive nell'app):
 *   ✗ niente import del `Product` dell'app   → si lavora su `ProductCardData`
 *   ✗ niente `inject(Router)`                → si emette `detail` come output
 *   ✗ niente `router.navigate(...)`          → il consumer decide cosa fare
 *
 * L'interfaccia `ProductCardData` è il contratto generico ricevuto in input.
 * Tutti i campi sono pensati per essere prodotti da uno specifico dominio
 * dell'app (qui `Product`, domani altro) tramite un mapping.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Component, computed, input, output } from '@angular/core';
import { NgClass } from '@angular/common';

export interface ProductCardData {
  id: string | number;
  name: string;
  price: number;
  imageUrl: string;
  category?: string;
  available?: boolean;
}

@Component({
  selector: 'ui-product-card',
  standalone: true,
  imports: [NgClass],
  templateUrl: './product-card.html',
})
export class ProductCardComponent {
  // Contratto del componente
  product   = input.required<ProductCardData>();
  detail    = output<string | number>();
  addToCart = output<ProductCardData>();

  // Prezzo formattato in EUR — calcolato qui per non duplicare la logica
  // nei consumer. L'i18n esplicito ('it-IT') è una scelta del corso;
  // in una libreria "vera" si parametrizzerebbe via InjectionToken.
  formattedPrice = computed(() =>
    new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' })
      .format(this.product().price)
  );

  // Emissioni esplicite: i bottoni nel template chiamano questi metodi,
  // non emettono inline. Tenere il template pulito è parte del contratto.
  onDetail(): void { this.detail.emit(this.product().id); }
  onAdd(): void    { this.addToCart.emit(this.product()); }
}
