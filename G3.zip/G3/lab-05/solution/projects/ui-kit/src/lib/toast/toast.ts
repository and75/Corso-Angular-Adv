/**
 * LAB 5 — SOLUTION
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/lib/toast/toast.ts
 *
 * ToastComponent di libreria — presentational al 100%.
 * Confronto con il Toast del Lab 2 (versione smart, nell'app):
 *   - via:    inject(NotificationService), DestroyRef, takeUntilDestroyed,
 *             signal locale alimentato dall'Observable.
 *   - resta:  rendering della lista + emit del dismiss.
 *
 * Il "ponte" verso il NotificationService dell'app vive nel consumer:
 *
 *   // in un componente "smart" dell'app:
 *   private notifications = inject(NotificationService);
 *   readonly toastItems = toSignal(this.notifications.notifications$, { initialValue: [] });
 *   onDismiss(id: number) { this.notifications.dismiss(id); }
 *
 *   <ui-toast [items]="toastItems()" (dismiss)="onDismiss($event)" />
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Component, input, output } from '@angular/core';
import { NgClass } from '@angular/common';
import { Notification } from '../notification.types';

@Component({
  selector: 'ui-toast',
  standalone: true,
  imports: [NgClass],
  templateUrl: './toast.html',
})
export class ToastComponent {
  items   = input.required<Notification[]>();
  dismiss = output<number>();

  onDismiss(id: number): void {
    this.dismiss.emit(id);
  }
}
