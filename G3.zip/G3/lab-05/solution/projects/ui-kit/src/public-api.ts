/**
 * LAB 5 — SOLUTION
 * ─────────────────────────────────────────────────────────────────────────────
 * File: projects/ui-kit/src/public-api.ts
 *
 * Contratto pubblico della libreria @corso/ui-kit.
 *
 * Regola operativa: ogni volta che si aggiunge un simbolo destinato al
 * consumer (componente, interfaccia, funzione) va dichiarato qui — è
 * l'unico file che `ng-packagr` "guarda" come entry point.
 *
 * Quello che è esportato:
 *   - Notification              → tipo condiviso col NotificationService dell'app
 *   - ProductCardComponent      → la card riusabile
 *   - ProductCardData           → contratto generico ricevuto in input dalla card
 *   - ToastComponent            → il toast presentational
 * ─────────────────────────────────────────────────────────────────────────────
 */
export * from './lib/notification.types';
export * from './lib/product-card/product-card';
export * from './lib/toast/toast';
