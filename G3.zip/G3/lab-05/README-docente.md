# Lab 5 — Estrazione `ui-kit` e publish su Verdaccio
## Guida per il Docente

---

## 1. Scopo Didattico

Il Lab 5 è il *capstone* operativo della parte "librerie" del corso. Lo studente:

- vede **da dentro** come `ng generate library` modifica `angular.json` e `tsconfig.json` (workspace multi-project diventa concreto);
- pratica il refactor "smart vs presentational": `ProductCard` perde l'`inject(Router)` e l'import del modello di dominio; `Toast` perde l'`inject(NotificationService)`. La libreria contiene solo componenti che potrebbe usare *un'altra app*;
- esegue un vero `npm publish` su un registry vero (anche se locale): il sapore del workflow di distribuzione npm si tocca con mano;
- riconosce, alla fine, che il path mapping `@corso/ui-kit` → `dist/ui-kit/` e l'import `from '@corso/ui-kit'` da `node_modules/` sono indistinguibili dal codice → la libreria si "stacca" senza riscrivere niente.

**Messaggio chiave da trasmettere all'inizio:**
> "Oggi spezziamo l'app in due. Il pezzo grosso — la nostra logica di catalogo — resta qui. Il pezzo riusabile — la card, il toast — esce dal workspace e vive di vita propria. A fine lab, l'app installa la libreria da un registry npm vero. È esattamente lo stesso flusso che usereste per pubblicare su npmjs o sull'Artifactory aziendale: lo facciamo localmente per controllare ogni passo."

---

## 2. Timing consigliato

**Slot orario: 11:45–13:00 (75 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo: aprire `dist/ui-kit/package.json` di una build di esempio per mostrare cosa significa "pacchetto pronto" | 5 min |
| TODO 1 | `ng generate library` + esplorazione `angular.json`/`tsconfig.json` + rinomina scope | 10 min |
| TODO 2 | Estrazione `ProductCard` e `Toast` — è il cuore del lab, qui si vede la "estraibilità" | 30 min |
| TODO 3 | Switch import dell'app + build/test | 15 min |
| TODO 4 | Publish su Verdaccio + install di ritorno + (se ce la fai) bump 1.1.0 | 15 min |
| **Totale** | | **~75 min** |

> Se la classe è lenta sul TODO 2 (mapping `Product` → `ProductCardData`), tagliare il bump `1.1.0` del TODO 4 e mostrarlo come demo a fine lezione: il publish base è non negoziabile, il bump è opzionale.

---

## 3. Contesto nella scaletta del giorno

Il lab arriva dopo la scheda 01 (libreria + ng-packagr) e la scheda 02 (semver + publish + Verdaccio). Le decisioni di scope sono già fissate (`@corso/ui-kit`, `ProductCard`+`Toast`, versioning `1.0.0`→`1.1.0`): in aula non si rinegozia nulla, si esegue. È il lab più "operativo" del modulo 5: massimo strumenti, minima teoria nuova.

---

## 4. Setup richiesto (verificare a inizio aula)

- Node 20+, `@angular/cli` 21 globale (`npm i -g @angular/cli`) — anche se nei comandi di verifica si usa `npx`.
- Tutti gli studenti devono avere `npx verdaccio` funzionante: testare prima della lezione, perché al primo avvio Verdaccio scarica e crea config (richiede ~30 secondi e una rete vagamente disponibile).
- `npm adduser --registry http://localhost:4873` va fatto una volta sola per macchina. Se la rete in aula è capricciosa, far passare lo step nei primi 5 minuti mentre si illustra l'intro.
- L'UI di Verdaccio (`http://localhost:4873`) è ottima da proiettare a metà lezione: vedere comparire `@corso/ui-kit@1.0.0` è il momento "è successo davvero" del lab.

---

## 5. Soluzione commentata — punti chiave

### 5.1 La rinomina dello scope a `@corso/ui-kit`

`ng generate library ui-kit` lascia `name: "ui-kit"` (senza scope) sia in `projects/ui-kit/package.json` sia in `tsconfig.json` (paths). Il lab chiede subito di rinominare in `@corso/ui-kit`. Il motivo da trasmettere:

> "Lo scope `@corso/` non è obbligatorio tecnicamente, ma in produzione lo scope è sempre lì: o è il nome dell'azienda o è il nome del team. Lo mettiamo subito perché vogliamo che gli `import` siano già nel formato che vedrete nei progetti reali."

**Due punti di sincronia da non perdere:**
- `tsconfig.json` (workspace): `"@corso/ui-kit": ["./dist/ui-kit"]` — il **nome dell'import** deve essere identico al `name` del `package.json`. Se disallineato, l'app importa qualcosa che non esiste.
- `projects/ui-kit/package.json`: `"name": "@corso/ui-kit"` — è da qui che `npm publish` prenderà il nome reale del pacchetto.

### 5.2 `ProductCardData` come "contratto generico"

Il cuore del Lab 5 è qui. Lo studente deve interiorizzare che la libreria non può importare `Product` dell'app, perché il `Product` dell'app è specifico del *catalogo prodotti*; un'altra app potrebbe avere un `Item`, un `Article`, qualunque cosa.

```ts
// SOLUTION — projects/ui-kit/src/lib/product-card/product-card.ts
export interface ProductCardData {
  id: string | number;
  name: string;
  price: number;
  imageUrl: string;
  category?: string;
  available?: boolean;
}
```

**Cosa dire agli studenti:**
> "`ProductCardData` non è `Product`. È il *minimo* che la card ha bisogno di sapere per rendere il suo HTML. È il contratto della card. Il giorno che un'altra app vorrà usare la card avrà un mapping `Item → ProductCardData` da fare, e starà bene così: la card non saprà mai che esistono i `Product`."

L'app fa il mapping nel componente contenitore con un metodo `toCardData(p: Product): ProductCardData`. Importante: gli studenti spesso provano a far implementare `ProductCardData` da `Product` (`class Product implements ProductCardData`). Funziona ma è anti-pattern qui: stringerebbe il `Product` al contratto della libreria, esattamente il contrario di quello che vogliamo.

### 5.3 `ProductCardComponent` — niente router, niente servizio

```ts
// SOLUTION — frammento essenziale
import { Component, computed, input, output } from '@angular/core';

@Component({ selector: 'ui-product-card', standalone: true, templateUrl: './product-card.html' })
export class ProductCardComponent {
  product = input.required<ProductCardData>();
  detail    = output<string | number>();
  addToCart = output<ProductCardData>();

  formattedPrice = computed(() =>
    new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' })
      .format(this.product().price)
  );

  onDetail(): void { this.detail.emit(this.product().id); }
  onAdd(): void    { this.addToCart.emit(this.product()); }
}
```

**Cosa dire:**
> "Notate cosa è sparito dalla versione dell'app: `inject(Router)` e `router.navigate(...)`. Sostituiti da un `output<string | number>()` che emette l'id. Chi vuole sapere `dove` portare l'utente è l'app, non la card. Questa è la regola d'oro del componente riusabile: **emette quello che è successo, non decide cosa farne**."

### 5.4 `ToastComponent` — presentational al 100%

```ts
// SOLUTION — frammento essenziale
import { Component, input, output } from '@angular/core';
import { Notification } from '../notification.types';

@Component({ selector: 'ui-toast', standalone: true, templateUrl: './toast.html' })
export class ToastComponent {
  items = input.required<Notification[]>();
  dismiss = output<number>();
}
```

Nessun `inject()`, nessun `BehaviorSubject`, nessun `DestroyRef`. È la dimostrazione più pura di "presentational". L'app fa il *bridge* via `toSignal`:

```ts
// SOLUTION — dove l'app usa il toast
private notifications = inject(NotificationService);
readonly toastItems = toSignal(this.notifications.notifications$, { initialValue: [] });
onDismiss(id: number) { this.notifications.dismiss(id); }
```

**Cosa dire:**
> "Il toast di prima era un *smart component*: sapeva del servizio, si sottoscriveva, gestiva il `DestroyRef`. Era giusto allora. Ma per uscire dall'app, doveva diventare *presentational*: dati dentro, eventi fuori, nient'altro. La logica reattiva non sparisce — sale di un piano, nell'app che monta il toast. È un pattern che vale per qualsiasi componente che vuoi distribuire."

### 5.5 `peerDependencies` — non lo facciamo "a mano"

ng-packagr applica le peer dependencies automaticamente in `dist/ui-kit/package.json`, ma il sorgente di `projects/ui-kit/package.json` *deve* già averle giuste, sia per chiarezza sia perché npm le legge da lì in caso di workspace npm con hoisting particolare.

```jsonc
// SOLUTION — projects/ui-kit/package.json
{
  "name": "@corso/ui-kit",
  "version": "1.0.0",
  "peerDependencies": {
    "@angular/common": "^21.0.0",
    "@angular/core": "^21.0.0"
  },
  "sideEffects": false
}
```

Trovare uno studente con `@angular/core` finito accidentalmente in `dependencies` è il caso più comune e va segnalato subito. Fare aprire `dist/ui-kit/package.json` dopo il primo `ng build ui-kit`: lì si vede il "vero" `package.json` del pacchetto.

### 5.6 Path mapping → `node_modules`: il momento "magico"

Il passaggio del TODO 4 in cui si **rimuove** `paths` dal `tsconfig.json` e si fa `npm install @corso/ui-kit` è il momento didatticamente più potente del lab. Vale la pena farlo in plenaria:

> "Cosa sta cambiando? Il TypeScript ora non risolve più `@corso/ui-kit` su `dist/ui-kit/`: lo risolve su `node_modules/@corso/ui-kit/`. Stessa stringa nell'import, sorgente diversa. **Il codice dell'app non se ne accorge**. Questo è il senso del path mapping: vi avete sviluppato per un mese contro un artefatto locale, e il giorno della release lo switch è una riga di `tsconfig`."

---

## 6. Errori comuni e come gestirli

### Errore 1: lo studente lascia `name: "ui-kit"` senza scope ma rinomina paths in `@corso/ui-kit`

**Sintomo:** `npm publish` pubblica `ui-kit` (senza scope) sul registry; ma l'app cerca `@corso/ui-kit` → `404 Not Found`.

**Fix:** allineare *sempre* tre punti: `projects/ui-kit/package.json#name`, `tsconfig.json#paths`, `dist/ui-kit/package.json#name` (dovrebbe seguire automaticamente).

### Errore 2: hanno cancellato `src/app/components/product-card/` ma lasciato un import vecchio

**Sintomo:** `Cannot find module '../../components/product-card/product-card'`.

**Fix:** `grep -r "components/product-card" src/` (o equivalente nell'editor): ogni occorrenza va sostituita con `from '@corso/ui-kit'` e con il nuovo nome `ProductCardComponent`.

### Errore 3: `Toast` non si aggiorna quando arriva una notifica

**Sintomo:** chiamare `notifications.success("hello")` non fa apparire nulla nel toast.

**Causa:** lo studente ha passato al toast un array statico (`[items]="notifications.value"` o simili). Il `toast` di libreria si fida dell'input — se l'input non cambia, non c'è change detection.

**Fix:** convertire `notifications$` in un signal con `toSignal(notifications$, { initialValue: [] })` e passarlo *chiamato*: `[items]="toastItems()"`. Il signal si aggiorna a ogni emissione dell'Observable; il toast vede il nuovo array; rerender.

### Errore 4: `@angular/core` finito in `dependencies` della libreria

**Sintomo:** dopo `npm install @corso/ui-kit`, runtime con `NullInjectorError` strani — di solito su servizi del router o dell'app.

**Causa:** npm ha installato una seconda copia di `@angular/core` dentro `node_modules/@corso/ui-kit/node_modules/`. Due istanze del framework → due DI tree → injection rotta.

**Fix:** rimuovere `@angular/core` (e `@angular/common`) da `dependencies` nel sorgente `projects/ui-kit/package.json`, lasciarli solo in `peerDependencies`. Rifare build + publish a `1.0.1`. Sull'app: `rm -rf node_modules` + `npm install`.

### Errore 5: `npm publish` dice "you cannot publish over the previously published versions"

**Sintomo:** lo studente ha già pubblicato `1.0.0`, ha modificato qualcosa, riprova a pubblicare.

**Fix:** *o* bumpare in `projects/ui-kit/package.json` (`1.0.0` → `1.0.1`) e rifare build + publish, *o* (solo in aula) cancellare a mano la cartella `%APPDATA%\verdaccio\storage\@corso\ui-kit\` (Windows) o `~/.config/verdaccio/storage/@corso/ui-kit/` (Mac/Linux). In produzione esiste solo la prima via.

### Errore 6: lo studente lancia `npm publish` dalla radice del workspace

**Sintomo:** Verdaccio pubblica… `product-catalog` (l'app!) come pacchetto.

**Causa:** `npm publish` opera sulla cartella corrente. Senza `cd dist/ui-kit`, "la cartella corrente" è la root del workspace.

**Fix:** insistere sulla sequenza `cd dist/ui-kit && npm publish`. Suggerire `npm pack` come dry-run: stampa cosa includerà il pacchetto, senza pubblicare.

### Errore 7: ha tolto il path mapping ma non ha ancora pubblicato

**Sintomo:** `npx ng build` dell'app fallisce con `Cannot find module '@corso/ui-kit'`.

**Causa:** path mapping rimosso, ma `node_modules/@corso/ui-kit/` non esiste ancora (publish/install non fatti).

**Fix:** sequenza obbligata: **prima** publish + install, **poi** rimozione del path mapping. Mai l'inverso.

---

## 7. Domande frequenti

**Q: posso pubblicare `dist/ui-kit/` su npmjs.com per davvero?**
A: tecnicamente sì (con `npm publish --access public` se lo scope `@corso` è tuo e free). In aula non lo faremo per ragioni di igiene del registry pubblico — lasciare pacchetti di test su npmjs è cattiva educazione.

**Q: il path mapping `@corso/ui-kit` → `dist/ui-kit/` resta o lo togliamo definitivamente?**
A: dopo l'install, lo togliamo. Tenere entrambi è ambiguo: TypeScript privilegia `paths` su `node_modules`, quindi staresti continuando a leggere dall'artefatto locale anche dopo l'install. Per pulizia: o sviluppi in workspace (path mapping presente, niente install), o consumi la libreria pubblicata (no path mapping, install presente). Non a metà.

**Q: nel template della card di libreria uso Tailwind. Se l'app consumer non ha Tailwind, si vede?**
A: no, le classi diventano stringhe inerti, il layout esce sgangherato. È una scelta del corso (le abbiamo lasciate per non riscrivere CSS), ma in un design system "vero" si usano CSS encapsulati nel componente o si distribuisce anche un foglio CSS. Punto da menzionare ma non da approfondire ora.

**Q: ng-packagr non c'è in `devDependencies` del workspace, lo devo aggiungere?**
A: `ng generate library` lo aggiunge automaticamente se serve. Se compare nei devDependencies dopo il TODO 1, è normale.

**Q: posso unificare `ProductCardData` e `Product` con un `type`?**
A: meglio di no, vedi 5.2. `ProductCardData` è il contratto della libreria; `Product` è il dominio dell'app. Tenerli separati è il punto del refactor.

**Q: perché `output()` funzionale e non `@Output()` con `EventEmitter`?**
A: è la sintassi moderna (Angular 17+, ora di fatto default). Equivalente semantico, più concisa, type-safe. Per coerenza con il resto del corso usiamo `input()`/`output()`/`computed()` ovunque.

---

## 8. Adattamenti

### Se il gruppo fatica sul TODO 2

Mostrare alla lavagna lo schema:

```
  App                                   Libreria (@corso/ui-kit)
  ─────                                 ──────────────────────
  Product { id, name, price, image,     ProductCardData {
    category, available, ...altro }       id, name, price, imageUrl,
                                          category?, available?
                                        }
       │
       │  toCardData(p) ───────────────►
                                          ◄── output<detail> ───┐
                                                                │ Router (dell'app)
       │ onDetail(id) → router.navigate ◄──────────────────────┘
```

> "L'app traduce *avanti* (`Product → ProductCardData`) e *indietro* (`detail → router.navigate`). La card vive nel suo mondo generico."

### Se il gruppo è avanzato

Far aggiungere alla libreria un secondo componente — es. una `<ui-empty-state>` riutilizzabile — ed esportarlo da `public-api.ts`. Bump a `1.1.0`, publish, install. Mostra che la libreria "vive" oltre l'estrazione iniziale.

### Cosa NON approfondire ora

- `InjectionToken` per configurare la libreria dal consumer (es. tema, traduzioni): è il pattern che useremmo se il `Toast` dovesse esporre stili configurabili dall'esterno. Fuori scope del lab di base.
- Multi-entry-point ng-packagr (`@corso/ui-kit/testing`): utile per separare codice di test, troppo per 75 minuti.
- `npm pack` e CI di publish (GitHub Actions, GitLab CI): cenno è ok, demo no.

---

## 9. Verifica binario A (lancia l'utente — FIX-001)

Da `Corso/progetto/product-catalog-finale/`:

```bash
npx ng build ui-kit                                                      # libreria
npx ng build && npx ng test                                              # app
cd dist/ui-kit && npm publish --registry http://localhost:4873 && cd ../..
npm install @corso/ui-kit                                                # con .npmrc scoped
npx ng build                                                              # ricontrolla dopo lo switch
```

Output da incollare in `REPORT.md`. Se uno qualunque fallisce → blocco `❌` e fix prima di chiudere lo STEP 03.
