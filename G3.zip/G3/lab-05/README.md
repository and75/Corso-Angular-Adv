# Lab 5 — Estrazione `ui-kit` e publish su Verdaccio
### Giornata 3 · Lab Guidato

---

## Obiettivo

Estrarre `ProductCard` e `Toast` dall'app dentro una libreria Angular (`@corso/ui-kit`),
buildarla con **ng-packagr**, pubblicarla su un registry npm locale (**Verdaccio**) e
consumarla dall'app come pacchetto installato. Al termine:

- esiste un nuovo progetto `projects/ui-kit/` nel workspace, con `public-api.ts` come superficie pubblica;
- l'app importa `ProductCardComponent` e `ToastComponent` da `@corso/ui-kit`, **non** più da percorsi relativi;
- la libreria è pubblicata sul Verdaccio locale alla versione `1.0.0` e installata da `node_modules`;
- `NotificationService` resta dell'app: il `Toast` di libreria è "presentational" (riceve la lista, emette il dismiss).

Aggancio: scheda [01 — Creare una libreria nel workspace](../didattica/01-libreria-ngpackagr.md) e
[02 — Versioning e publish](../didattica/02-versioning-publish.md).

---

## Novità rispetto ai lab precedenti

| Concetto | Dove | Cosa fa |
|---|---|---|
| Workspace multi-project | `angular.json` | accanto all'app convive un secondo progetto (libreria) |
| `public-api.ts` | `projects/ui-kit/src/` | dichiara cosa la libreria espone all'esterno |
| Path mapping | `tsconfig.json` | risolve `@corso/ui-kit` su `dist/ui-kit/` durante lo sviluppo |
| `peerDependencies` | `projects/ui-kit/package.json` | dichiara `@angular/*` senza portarsi dietro una seconda copia |
| ng-packagr | builder libreria | produce FESM + typings + `package.json` pubblicabile |
| Verdaccio | registry locale | publish/install reali senza account npmjs |
| Componente "presentational" | `ToastComponent` in libreria | riceve `items` come input, emette `dismiss` come output — niente servizi dell'app dentro |

---

## File creati / modificati in questo lab

> Il delta si applica a `Corso/progetto/product-catalog-finale/`. Il seme `product-catalog/` resta intatto.

### Nuovi (generati dalla CLI o aggiunti dal lab)

| File | Ruolo |
|---|---|
| `projects/ui-kit/` *(intera cartella)* | nuovo progetto libreria — generato da `ng generate library` |
| `projects/ui-kit/src/lib/notification.types.ts` | interfaccia generica `Notification` per il `Toast` di libreria |
| `projects/ui-kit/src/lib/product-card/product-card.ts` (+ `.html`) | `ProductCardComponent` parametrizzato su `ProductCardData` |
| `projects/ui-kit/src/lib/toast/toast.ts` (+ `.html`) | `ToastComponent` presentational |
| `.npmrc` *(workspace root)* | scoped registry `@corso:registry=http://localhost:4873` |

### Modificati

| File | Cosa cambia |
|---|---|
| `angular.json` | aggiunto progetto `ui-kit` (lo fa la CLI) — verificare `builder: "@angular/build:ng-packagr"` |
| `tsconfig.json` (workspace) | path mapping `@corso/ui-kit` → `dist/ui-kit/` (sostituisce il default `"ui-kit"`) |
| `projects/ui-kit/package.json` | rinominato `name` da `"ui-kit"` a `"@corso/ui-kit"`; `version` `1.0.0`; `peerDependencies` verificate |
| `projects/ui-kit/src/public-api.ts` | esporta `ProductCardComponent`, `ToastComponent` e le interfacce `ProductCardData`, `Notification` |
| File dell'app che usano `<app-product-card>` / `<app-toast>` | switch a `<ui-product-card>` / `<ui-toast>` con import da `@corso/ui-kit` |
| `src/app/components/product-card/`, `src/app/components/toast/` | **cancellati** — i sorgenti vivono in libreria |

---

## Scaffolding — comandi Angular CLI

Tutti i comandi da `product-catalog-finale/`. La CLI in aula è installata globalmente (`npm i -g @angular/cli`), quindi `ng` diretto.

| Cosa generi | Comando (forma estesa) | Alias breve |
|---|---|---|
| Libreria nel workspace | `ng generate library ui-kit --prefix=ui` | `ng g lib ui-kit --prefix=ui` |
| Componente dentro la libreria | `ng generate component lib/product-card --project=ui-kit --skip-tests` | `ng g c lib/product-card --project=ui-kit --skip-tests` |
| Componente dentro la libreria (Toast) | `ng generate component lib/toast --project=ui-kit --skip-tests` | `ng g c lib/toast --project=ui-kit --skip-tests` |

> **Note Angular 21.** I componenti vengono generati senza suffisso `.component.ts` (file `product-card.ts`, classe `ProductCard` di default) e sono `standalone: true`. Il lab rinomina la classe in `ProductCardComponent`/`ToastComponent` per esplicitare che sono unità di libreria: è una rinomina, non un vincolo della CLI. `--skip-tests` evita la generazione di `*.spec.ts` lato studente — i test della solution sono curati a parte.

> `--prefix=ui` definisce il prefisso dei selettori della libreria: i componenti nascono come `<ui-...>`, distinti dai `<app-...>` dell'app.

> Comandi di **verifica** (build/test) restano con `npx`: `npx ng build ui-kit`, `npx ng build`, `npx ng test`. Si appoggiano alla CLI locale del progetto e non vanno confusi con gli schematic di generazione.

---

## Setup di Verdaccio (una volta a inizio aula)

```bash
# Terminale dedicato — Verdaccio resta acceso per tutto il lab
npx verdaccio
# → in ascolto su http://localhost:4873
```

```bash
# Una volta sola: crea l'utente locale (qualunque user/password)
npm adduser --registry http://localhost:4873
```

Apri http://localhost:4873 nel browser: è la UI di Verdaccio (mostra i pacchetti pubblicati). Tienila a vista — sarà la "prova" visiva del publish del TODO 4.

---

## TODO da completare

### TODO 1 — FACILE: generare la libreria

- Da `product-catalog-finale/`, lancia `ng generate library ui-kit --prefix=ui`.
- Apri la cartella appena nata `projects/ui-kit/`: identifica `public-api.ts`, `ng-package.json`, `package.json`.
- Apri `angular.json` di workspace: dentro `projects` ora ci sono **due** voci; verifica che `ui-kit` abbia `"builder": "@angular/build:ng-packagr"`.
- Apri `tsconfig.json` di workspace: cerca la sezione `paths` aggiunta dalla CLI (`"ui-kit": ["./dist/ui-kit"]`). **Rinominala in `"@corso/ui-kit": ["./dist/ui-kit"]`** — allineiamo il path mapping al nome npm scoped che useremo.
- In `projects/ui-kit/package.json`, rinomina `"name": "ui-kit"` in `"name": "@corso/ui-kit"`. Imposta `"version": "1.0.0"`. Verifica che `@angular/common` e `@angular/core` siano in `peerDependencies` (non in `dependencies`).
- Cancella i file di esempio generati: `projects/ui-kit/src/lib/ui-kit.ts` e (se presente) `projects/ui-kit/src/lib/ui-kit.spec.ts`. Svuota `public-api.ts` (il prossimo TODO lo ricostruirà).

> Criterio di completamento del TODO 1: `npx ng build ui-kit` parte e produce `dist/ui-kit/` con `fesm2022/` e `*.d.ts` (anche se la libreria è ancora "vuota" — esporterà niente per ora; va bene).

---

### TODO 2 — MEDIO: estrarre `ProductCard` e `Toast` nella libreria

Genera lo scheletro dei due componenti dentro la libreria:

```bash
ng generate component lib/product-card --project=ui-kit --skip-tests
ng generate component lib/toast        --project=ui-kit --skip-tests
```

Lavora poi sui file dentro `starter/projects/ui-kit/src/lib/`:

**2.1 Interfaccia condivisa (`lib/notification.types.ts`)**
- Definisci `export interface Notification { id: number; type: 'success' | 'error' | 'info'; message: string; }`.
  È la stessa shape che `NotificationService` dell'app già usa: la liftiamo in libreria per condividerla con il consumer.

**2.2 `ProductCardComponent` (`lib/product-card/product-card.ts` + `.html`)**

- Selettore `ui-product-card`, `standalone: true`.
- Definisci ed `export interface ProductCardData { id: string | number; name: string; price: number; imageUrl: string; category?: string; available?: boolean; }`. È il **contratto generico** che la card riceve: niente più import del `Product` dell'app.
- Input richiesto: la card riceve un `ProductCardData` (firma: `product = input.required<ProductCardData>();`).
- Output:
  - `detail = output<string | number>();` — emette l'id quando l'utente vuole vedere il dettaglio.
  - `addToCart = output<ProductCardData>();` — emette il prodotto quando l'utente lo aggiunge al carrello.
  - **Niente** `inject(Router)` in libreria — la navigazione è responsabilità del consumer.
- `formattedPrice` come `computed()` con `Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' })`.
- Nel template: immagine, nome, eventuale categoria, prezzo formattato; bottoni "Dettagli" e "Aggiungi al carrello"; bandana "Esaurito" se `available === false`. Usa le classi Tailwind che usavi nel componente originale — la libreria assume Tailwind nel consumer (è scelta documentata in README).

**2.3 `ToastComponent` (`lib/toast/toast.ts` + `.html`)**

- Selettore `ui-toast`, `standalone: true`.
- Input richiesto: `items = input.required<Notification[]>();` (importa `Notification` da `../notification.types`).
- Output: `dismiss = output<number>();` — emette l'id da chiudere.
- **Niente** `inject(NotificationService)`. Niente `BehaviorSubject`. Il toast in libreria è "presentational": riceve la lista e basta. Sarà l'app a iniettare il servizio, leggere `notifications$` e passare la lista come input.
- Template `@for` sugli items con `track n.id`; classi diverse per `type` (`success`/`error`/`info`); bottone chiusura che chiama `dismiss.emit(n.id)`.

**2.4 `public-api.ts`**
- Esporta i due componenti e le due interfacce:
  ```ts
  // 4 righe in totale, una export per file
  export * from './lib/product-card/product-card';
  export * from './lib/toast/toast';
  export * from './lib/notification.types';
  ```
  Tutto ciò che non passa di qui non è parte dell'API pubblica.

> Criterio del TODO 2: `npx ng build ui-kit` verde. In `dist/ui-kit/index.d.ts` compaiono `ProductCardComponent`, `ToastComponent`, `ProductCardData`, `Notification`.

---

### TODO 3 — MEDIO: l'app consuma la libreria via path mapping

> Da qui in poi, in un **secondo terminale**, lascia in esecuzione:
> ```bash
> npx ng build ui-kit --watch
> ```
> Ad ogni save della libreria, `dist/ui-kit/` viene ricostruito e l'app lo vede.

**3.1 Mapping prodotto → `ProductCardData`**
- Dove l'app usava `<app-product-card [product]="p" (addToCart)="...">`, ora userà `<ui-product-card [product]="toCardData(p)" (detail)="onDetail($event)" (addToCart)="onAddToCart($event)">`.
- Nel componente contenitore, dichiara:
  ```ts
  toCardData(p: Product): ProductCardData {
    return { /* …mappa qui i campi di Product al contratto di libreria… */ };
  }
  ```
  Il punto chiave è che il dominio `Product` resta dell'app; la libreria non lo conosce.
- `onDetail(id: string | number)` chiama `this.router.navigate(['/products', id]);` — la navigazione torna nell'app, dove appartiene.
- `onAddToCart(card)` parla col `CartService` dell'app, eventualmente mappando indietro l'id sul `Product` reale.

**3.2 Wiring del `Toast`**
- Dove c'era `<app-toast />`, sostituisci con un wrapper inline che inietta `NotificationService` e converte `notifications$` in signal con `toSignal()`:
  ```ts
  // snippet 1-3 righe per la forma:
  private notifications = inject(NotificationService);
  readonly items = toSignal(this.notifications.notifications$, { initialValue: [] });
  onDismiss(id: number) { this.notifications.dismiss(id); }
  ```
  Nel template: `<ui-toast [items]="items()" (dismiss)="onDismiss($event)" />`.
- **Cancella** `src/app/components/product-card/` e `src/app/components/toast/`: i sorgenti vivono ora in libreria; lasciarli nel codice dell'app è un *bug didattico* (chi importa cosa?).

**3.3 Import e build**
- Tutti gli `import { ProductCard } from '../../components/product-card/...'` diventano `import { ProductCardComponent } from '@corso/ui-kit'`. Idem per `Toast`.
- Esegui:
  ```bash
  npx ng build && npx ng test
  ```
  Niente errori; tutti i test verdi.

> Criterio del TODO 3: `npx ng serve` mostra l'app funzionante; la card e il toast vengono dalla libreria; la navigazione `/products/:id` viene gestita dall'app.

---

### TODO 4 — DIFFICILE: publish su Verdaccio e install di ritorno

**4.1 `.npmrc` di workspace**
- Crea il file `.npmrc` alla radice di `product-catalog-finale/` con:
  ```ini
  @corso:registry=http://localhost:4873
  ```
  Effetto: ogni `npm install`/`npm publish` di pacchetti `@corso/...` userà Verdaccio; gli altri (`@angular/*`, `rxjs`...) continueranno ad andare su npmjs.

**4.2 Publish**
- Da `product-catalog-finale/`:
  ```bash
  npx ng build ui-kit              # rebuild una volta sola, completo
  cd dist/ui-kit
  npm publish                       # grazie a .npmrc va a Verdaccio
  ```
  Sulla UI di Verdaccio (http://localhost:4873) compare `@corso/ui-kit@1.0.0`.

**4.3 Install di ritorno e switch da path mapping a `node_modules`**
- Torna alla root del workspace: `cd ../..` (sei in `product-catalog-finale/`).
- **Rimuovi** dal `tsconfig.json` di workspace la voce `paths` per `@corso/ui-kit`: vogliamo che la risoluzione passi da `node_modules`, come per qualsiasi altra libreria installata.
- Installa il pacchetto:
  ```bash
  npm install @corso/ui-kit
  ```
  In `package.json` dell'app compare `"@corso/ui-kit": "^1.0.0"` dentro `dependencies`.
- Esegui di nuovo `npx ng build`: gli import `from '@corso/ui-kit'` ora vengono risolti da `node_modules/@corso/ui-kit/`, **non** più da `dist/ui-kit/`. L'app deve continuare a funzionare identicamente.

**4.4 (opzionale, se hai tempo) bump `1.0.0` → `1.1.0`**
- Aggiungi un piccolo `@Input() severity` opzionale al `Toast` (non rompe nessuno).
- Da `projects/ui-kit/`: `npm version minor` → la libreria passa a `1.1.0`.
- Rebuild + publish: `npx ng build ui-kit && cd dist/ui-kit && npm publish`.
- In aula: `npm install @corso/ui-kit` nell'app → vedi che la dipendenza salta a `^1.1.0` (perché `^` permette upgrade minor).

> Criterio del TODO 4: la lib è pubblicata su Verdaccio (UI lo conferma), `node_modules/@corso/ui-kit/` esiste, l'app funziona senza il path mapping. Punti bonus se hai fatto anche il bump.

---

## Se ti blocchi

| Sintomo | Causa probabile | Fix |
|---|---|---|
| `Cannot find module '@corso/ui-kit'` | mai lanciato `ng build ui-kit` o path mapping sbagliato in `tsconfig.json` | builda la libreria almeno una volta; controlla la riga `paths` |
| `NullInjectorError` strani dopo l'install | `@angular/core` finito in `dependencies` invece che `peerDependencies` | apri `dist/ui-kit/package.json` e verifica `peerDependencies`; correggi `projects/ui-kit/package.json` |
| `npm publish` dà 401/403 | utente Verdaccio mancante o `.npmrc` non punta al registry | `npm adduser --registry http://localhost:4873`; verifica `.npmrc` di workspace |
| `npm publish` dà `cannot publish over the previously published versions` | hai già pubblicato `1.0.0` | bumpa a `1.0.1` o cancella la cartella `~/.config/verdaccio/storage/@corso/ui-kit/` |
| App rotta dopo aver tolto i `components/product-card/` | qualche import residuo a un path relativo | grep `from '../../components/product-card'` / `from '../../components/toast'` e sostituisci con `'@corso/ui-kit'` |
| `Type 'Product' is not assignable to type 'ProductCardData'` | manca il mapping nel wrapper | implementa `toCardData()` nel componente che usa `<ui-product-card>` |
| Il toast non mostra nuove notifiche | la lista non è "live" — hai passato un array statico | usa `toSignal(notifications$, { initialValue: [] })` e passa il signal `()`-chiamato |

---

## Criteri di verifica

- [ ] `projects/ui-kit/` esiste con `public-api.ts` che esporta `ProductCardComponent`, `ToastComponent`, `ProductCardData`, `Notification`.
- [ ] `@angular/common` e `@angular/core` sono in `peerDependencies` della libreria, non in `dependencies`.
- [ ] `npx ng build ui-kit` produce `dist/ui-kit/fesm2022/` e `dist/ui-kit/index.d.ts`.
- [ ] L'app importa **esclusivamente** dalla libreria (`from '@corso/ui-kit'`); le cartelle `src/app/components/product-card/` e `src/app/components/toast/` sono state rimosse.
- [ ] La navigazione `/products/:id` parte dall'app, non dalla libreria (la card di libreria emette `detail` come output).
- [ ] `NotificationService` è ancora nell'app; il `Toast` di libreria è "presentational" (input `items`, output `dismiss`).
- [ ] `@corso/ui-kit@1.0.0` è visibile sulla UI di Verdaccio (`http://localhost:4873`).
- [ ] `npm install @corso/ui-kit` dall'app crea `node_modules/@corso/ui-kit/` e `package.json` mostra `"@corso/ui-kit": "^1.0.0"`.
- [ ] Dopo aver rimosso il path mapping da `tsconfig.json`, `npx ng build` resta verde.
- [ ] `npx ng test` passa.
