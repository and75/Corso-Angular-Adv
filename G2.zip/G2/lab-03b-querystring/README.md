# Lab 3b — Querystring: filtro + paginazione `AdminList`
### Giorno 2 · Lab guidato (~15 min) · Slot 12:35–12:50

---

## Obiettivo

Applicare il pattern della [Scheda 02 §Querystring — filtri e stato della vista](../didattica/02-children-loadchildren.md) per trasformare `AdminList` (creato nel [Lab 3a](../lab-03a-children-lazy/README.md)) da semplice elenco statico a lista **filtrabile e paginata via URL**:

1. Due signal `q` (search term) e `page` (pagina corrente) alimentati dall'Observable `route.queryParamMap`.
2. Un `computed` `pagedProducts` che applica filtro + slice in base a `q()` e `page()`.
3. Una `<input>` di ricerca che, ad ogni `(input)`, chiama `router.navigate(...)` con **`queryParamsHandling: 'merge'`**.
4. Pulsanti "← Indietro" / "Avanti →" che modificano solo `page`, sempre via `navigate` con merge.

Risultato visivo:

- `/admin/products` → tutti i prodotti, pagina 1.
- `/admin/products?q=mac` → filtrati per "mac", pagina 1.
- `/admin/products?q=mac&page=2` → filtrati per "mac", pagina 2.
- **Refresh** della pagina → stato preservato (la verità è l'URL, non un signal locale).
- **Back/Forward** del browser → funzionano: ogni navigazione è una entry nella history.

> **Stato di partenza:** hai completato il [Lab 3a](../lab-03a-children-lazy/README.md) — nel tuo `product-catalog/` esistono già `features/admin/admin.routes.ts`, `AdminLayout` e `AdminList` (versione base, senza filtri). In questo lab si modificano **solo** i due file `admin-list.ts` + `admin-list.html`.

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/features/admin/pages/admin-list/admin-list.ts` | Aggiunge `q`/`page` signal, sottoscrizione `queryParamMap`, `computed pagedProducts`, handler `onSearch`/`goToPage` | modificato |
| `src/app/features/admin/pages/admin-list/admin-list.html` | Sostituisce loop su `products()` con loop su `pagedProducts()`, aggiunge input search + paginazione | modificato |

Nessun nuovo componente, nessun nuovo servizio, nessuna nuova dipendenza npm.

---

## TODO 1 — MEDIO: `AdminList` con signal + queryParamMap (~10 min)

Modifica `features/admin/pages/admin-list/admin-list.ts` (parte dalla versione del Lab 3a).

### Cosa aggiungere alle iniezioni

Oltre al `ProductService` e `DestroyRef` già presenti dal Lab 3a, ti servono **anche**:

- `ActivatedRoute` — per leggere `queryParamMap` (Observable);
- `Router` — per le navigazioni `onSearch` / `goToPage`.

Entrambi via `inject()` come campi privati.

### Nuovi signal

Aggiungi due signal scrivibili `readonly` esposti al template:

- `q` di tipo `string`, valore iniziale `''`.
- `page` di tipo `number`, valore iniziale `1`.

E una **costante locale** `PAGE_SIZE = 3` (puoi tenerla `readonly` come campo della classe).

### Sottoscrizione a `queryParamMap`

Nel costruttore (oltre alla sottoscrizione esistente a `getProducts()`), aggiungi una **seconda** sottoscrizione a `route.queryParamMap` con `takeUntilDestroyed`. Nel callback:

- `this.q.set(params.get('q') ?? '')` — quando il param non c'è, default `''`.
- `this.page.set(Number(params.get('page') ?? '1'))` — il `Number()` converte la stringa, default `'1'`.

> Pattern signal + Observable: i signal `q`/`page` sono lo stato che il template legge; l'Observable `queryParamMap` è il publisher che li aggiorna. Ogni livello fa quello che sa fare meglio. **Non** usare `route.snapshot.queryParamMap`: è statico e non emette ai cambi di URL.

### Due `computed` (filtro + slice)

Aggiungi due derivazioni:

- `private filteredProducts = computed(() => ...)` — applica il filtro su `products()` confrontando `p.name.toLowerCase().includes(q().toLowerCase())`. Se `q()` è vuoto, ritorna `products()` intero (no filtro).
- `readonly pagedProducts = computed(() => ...)` — calcola `start = (page() - 1) * PAGE_SIZE` e ritorna `filteredProducts().slice(start, start + PAGE_SIZE)`.
- `readonly totalPages = computed(() => Math.max(1, Math.ceil(filteredProducts().length / PAGE_SIZE)))` — usato per disabilitare il pulsante "Avanti" e mostrare "Pagina X di Y".

### Handler `onSearch` e `goToPage`

Due metodi che chiamano `router.navigate([], { ... })`. Argomenti dell'oggetto opzioni:

- `relativeTo: this.route` — la navigazione è relativa alla rotta corrente (senza, parte dalla root).
- `queryParams: { ... }` — i nuovi param.
- `queryParamsHandling: 'merge'` — conserva i queryparam che NON stai modificando.

**Comportamenti specifici:**

- `onSearch(value: string)` → `queryParams: { q: value, page: 1 }`. Reset di `page` a 1 quando cambia la search: comportamento UX standard, evita di ritrovarsi in pagina 7 dopo aver scritto una nuova parola chiave.
- `goToPage(n: number)` → prima verifica `n < 1 || n > totalPages()` e in tal caso `return` (no-op). Poi `queryParams: { page: n }` — solo `page` cambia.

Riferimento: [Scheda 02 §"Querystring: filtri e stato della vista"](../didattica/02-children-loadchildren.md) e [§"Errori comuni — `snapshot` vs Observable"](../didattica/02-children-loadchildren.md).

---

## TODO 2 — FACILE: template con search + paginazione (~5 min)

Modifica `features/admin/pages/admin-list/admin-list.html`. Tre modifiche.

### 1. Aggiungi una `<input>` search sopra alla lista

Subito sotto l'`<header>` (che già contiene il titolo), inserisci un `<input type="text">` con:

- `[value]="q()"` — il signal è la **fonte di verità**, non un valore locale.
- `(input)="onSearch($any($event.target).value)"` — l'handler che hai scritto nel TS.
- `placeholder="Cerca prodotto…"`.
- Classi Tailwind a tuo gusto (suggerito: `w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500`).

> Il `$any($event.target)` è una scappatoia di tipi: senza, TypeScript si lamenta perché `event.target` ha tipo `EventTarget | null` (non `HTMLInputElement`). Per i lab va bene; in un'app reale puoi tipizzare meglio con un template variable `#input` e `input.value`.

### 2. Sostituisci `products()` con `pagedProducts()` nel loop

Il `@for (p of products(); track p.id)` diventa `@for (p of pagedProducts(); track p.id)`. Il template della singola riga (nome, categoria, prezzo, link "Modifica") resta identico al Lab 3a.

Adatta anche l'`@empty`: il messaggio "Nessun prodotto" può diventare `Nessun prodotto trovato per "{{ q() }}"` se vuoi essere più esplicito.

### 3. Aggiungi una barra paginazione sotto la lista

Un `<div class="flex justify-between items-center pt-4 border-t border-gray-100">` con tre elementi:

- `<button (click)="goToPage(page() - 1)" [disabled]="page() <= 1">← Indietro</button>`
- Uno `<span>` centrale: `Pagina {{ page() }} di {{ totalPages() }}`.
- `<button (click)="goToPage(page() + 1)" [disabled]="page() >= totalPages()">Avanti →</button>`

Classi suggerite per i pulsanti: `px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed`.

---

## Criteri di verifica

- [ ] `/admin/products` mostra i prodotti, pagina 1, contatore "Pagina 1 di N".
- [ ] Digitando "mac" nella search → URL diventa `/admin/products?q=mac&page=1` e la lista filtra in tempo reale.
- [ ] Cliccando "Avanti →" → URL `?q=mac&page=2`, lista aggiornata, `page` nel signal aggiornato.
- [ ] Cambiando solo `q` (cancella la search e riscrivi), `page` torna a 1 (reset esplicito in `onSearch`).
- [ ] Cliccando "Avanti" senza search attiva → `?page=2`, query `q` non aggiunto (resta omesso, non vuoto).
- [ ] **Refresh** dell'URL `/admin/products?q=mac&page=2` → ricarica con filtro e paginazione preservati.
- [ ] **Back/Forward** del browser dopo aver cambiato search/page → la lista segue le navigazioni della history.
- [ ] DevTools → Console pulita, nessun warning sui signal letti senza parentesi.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| Cambiando l'URL a mano da `/admin/products?q=mac` a `?q=ipad`, la lista non aggiorna | Stai leggendo `route.snapshot.queryParamMap` invece dell'Observable `queryParamMap.subscribe(...)` | TODO 1, sottoscrizione |
| Cambiando solo `q`, `page` sparisce dall'URL | Manca `queryParamsHandling: 'merge'` nel `router.navigate` | TODO 1, `onSearch`/`goToPage` |
| Cambiando search, resti nella stessa pagina (es. pagina 5 con filtro che ha 1 risultato) | Manca il reset esplicito `page: 1` dentro `onSearch` | TODO 1, `onSearch` |
| `totalPages` torna 0 quando la lista è vuota → divisioni strane | Manca il `Math.max(1, ...)` attorno al `Math.ceil` | TODO 1, `totalPages` computed |
| "Avanti →" non si disabilita all'ultima pagina | `[disabled]` legge `totalPages` senza `()` (legge la funzione, non il valore — sempre truthy) | TODO 2, paginazione |
| `Cannot read properties of undefined` su `event.target.value` | Manca `$any()` attorno a `$event.target` | TODO 2, input search |
| Il filtro è case-sensitive (cercando "MAC" non trova "MacBook") | Manca `.toLowerCase()` su uno dei due lati del confronto | TODO 1, `filteredProducts` computed |
| Refresh perde lo stato | Hai messo `q`/`page` come `signal` ma **non** li hai legati a `queryParamMap.subscribe(...)` — è la querystring che sopravvive al refresh, non il signal | TODO 1, sottoscrizione |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!

---

## Prossimo: [Lab 3c — Named outlet con cart preview](../lab-03c-named-outlet/README.md)
