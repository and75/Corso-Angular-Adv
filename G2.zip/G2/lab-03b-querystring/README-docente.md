# Lab 3b — Querystring filter + paginazione
## Guida per il Docente

---

## 1. Scopo Didattico

Secondo dei tre lab del Mod 3 (3a → **3b** → 3c). Applica la **seconda metà** della Scheda 02 (querystring, `queryParamMap` Observable, `queryParamsHandling: 'merge'`). Il pattern è probabilmente il più riusato dei tre nella vita reale: filtri/paginazione/ordinamento via URL sono ovunque nelle dashboard B2B.

Tre messaggi chiave:

1. **L'URL è la fonte di verità.** Se la search box ha "mac" e la pagina è 2, deve esserci `?q=mac&page=2` in URL — altrimenti refresh/back/share rompono.
2. **`snapshot` vs Observable**: `route.snapshot.queryParamMap` è statico (vale alla prima visita); `route.queryParamMap` è reattivo (emette ad ogni cambio URL). Si usa l'Observable.
3. **`queryParamsHandling: 'merge'` esiste perché senza, ogni `navigate` cancella la querystring intera.** È il default sbagliato di Angular.

---

## 2. Timing Consigliato

**Slot orario: 12:35–12:50 (15 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo del risultato (digitare in search → URL cambia in tempo reale → refresh preserva) | 1 min |
| TODO 1 | AdminList TS: signal q/page + queryParamMap subscription + computed pagedProducts + onSearch/goToPage | 10 min |
| TODO 2 | Template: input search + sostituzione products()→pagedProducts() + paginazione | 4 min |
| **Totale** | | **~15 min** |

> Se la classe è in difficoltà, fai prima il template (TODO 2, 4 min) e poi il TS (TODO 1) — vedono subito che "manca qualcosa" e la cosa motiva la subscription a `queryParamMap`. Per classi più mature, l'ordine TS→template è più coerente con il flusso del dato.

---

## 3. Contesto nella Scaletta

- **Lab 3a** (12:15–12:35): ha creato `AdminList` come elenco base.
- **Lab 3b** (questo): aggiunge querystring sopra `AdminList`.
- **Lab 3c** (12:50–13:00): named outlet `panel` con cart preview.

Aggancio col resto del corso:

- Il pattern signal + Observable verrà rivisto in **Mod 4** (interceptor): l'interceptor mappa `HttpErrorResponse` su `NotificationService.error(...)` — stesso schema "RxJS in mezzo, signal/effetto in uscita".
- Le query `?q=`/`?page=` qui sono client-side. Tematica per il refresher: in un'app reale spesso il filtro va sul backend (`GET /api/products?q=...&page=...&size=...`) — la struttura del codice cambia poco: cambia chi fa lo `slice`.

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 Pattern signal + Observable insieme

```typescript
readonly q    = signal('');
readonly page = signal(1);

constructor() {
  this.route.queryParamMap
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(params => {
      this.q.set(params.get('q') ?? '');
      this.page.set(Number(params.get('page') ?? '1'));
    });
}
```

**Cosa dire:**
> "Mix consapevole: i signal `q` e `page` sono lo stato che il template legge (`q()`, `page()`); l'Observable `queryParamMap` è il publisher che li aggiorna. Funziona perché ogni livello fa quello che sa fare meglio: signal per la UI, Observable per gli stream del router. Non serve `computed` qui — `q`/`page` sono valori *ricevuti*, non *derivati*. Per il filtro effettivo invece sì: `pagedProducts = computed(...)`."

### 4.2 `snapshot` vs Observable — l'errore numero 1

```typescript
// ❌ NO — statico, non emette ai cambi URL
const q = this.route.snapshot.queryParamMap.get('q');

// ✅ SÌ — emette ad ogni cambio URL
this.route.queryParamMap.subscribe(params => this.q.set(params.get('q') ?? ''));
```

**Cosa dire:**
> "`snapshot` è statico — vale al momento in cui il componente è stato istanziato. Funziona alla prima visita perché il componente è appena nato. Ma cambiando l'URL dopo (con `router.navigate`, con back/forward del browser, con un link), `snapshot` non si aggiorna: lo stesso componente resta vivo e legge ancora il valore vecchio. L'Observable invece emette ad ogni cambio. È la differenza tra fotografia e telecamera."

### 4.3 `queryParamsHandling: 'merge'`

```typescript
this.router.navigate([], {
  relativeTo: this.route,
  queryParams: { q: value, page: 1 },     // reset page al cambio search
  queryParamsHandling: 'merge',
});
```

**Cosa dire:**
> "Senza `merge`, ogni `navigate` con queryParams **sostituisce** la querystring intera. Se l'utente cambia solo `q`, perde `page` (e qualsiasi altro queryparam — `sort`, `view`, ecc.). Con `merge`, aggiornate solo i campi che passate e tenete gli altri. Notate che qui scrivo `page: 1` esplicitamente: quando l'utente cambia la ricerca, voglio resettare la pagina — comportamento UX standard. Senza quella riga, l'utente cerca 'mac' e si ritrova in pagina 7 perché era lì."

### 4.4 `relativeTo: this.route` nel `navigate`

```typescript
this.router.navigate([], { relativeTo: this.route, queryParams: { ... } });
```

**Cosa dire:**
> "Il primo argomento `[]` è il segmento di path — qui vuoto, vogliamo restare sulla rotta corrente. Per dirgli che il `[]` è relativo alla rotta del componente (e non alla root), serve `relativeTo: this.route`. Senza, `[]` cambia path a `/` e l'utente finisce sulla home. Errore facile da fare e che TypeScript non segnala."

### 4.5 Due computed: `filteredProducts` (privato) e `pagedProducts` (pubblico)

```typescript
private readonly filteredProducts = computed(() => {
  const term = this.q().toLowerCase();
  if (!term) return this.products();
  return this.products().filter(p => p.name.toLowerCase().includes(term));
});

readonly pagedProducts = computed(() => {
  const start = (this.page() - 1) * this.PAGE_SIZE;
  return this.filteredProducts().slice(start, start + this.PAGE_SIZE);
});

readonly totalPages = computed(() =>
  Math.max(1, Math.ceil(this.filteredProducts().length / this.PAGE_SIZE))
);
```

**Cosa dire:**
> "Due `computed` separati anziché uno per due motivi: (1) `totalPages` deve calcolarsi sui prodotti **filtrati ma non paginati** — se calcolo `totalPages` su `pagedProducts` ottengo 1 sempre; (2) avere `filteredProducts` come step intermedio rende il debug più facile (basta loggare quel signal). Il `private` su `filteredProducts` perché il template non ne ha bisogno: serve solo a `pagedProducts` e `totalPages` interni."

### 4.6 `Math.max(1, ...)` su `totalPages`

```typescript
readonly totalPages = computed(() =>
  Math.max(1, Math.ceil(this.filteredProducts().length / this.PAGE_SIZE))
);
```

**Cosa dire:**
> "Quando il filtro non trova niente, `length` è 0 e `Math.ceil(0/3)` è 0 — `totalPages` sarebbe 0. Il template mostrerebbe 'Pagina 1 di 0' (assurdo) e il pulsante 'Avanti' resterebbe attivo con `page >= 0` falso. Il `Math.max(1, ...)` forza il minimo a 1. Una riga, salva tre bug visuali."

---

## 5. Errori comuni degli studenti

### ❌ Errore 1: `route.snapshot.queryParamMap` invece dell'Observable
**Sintomo:** filtri funzionano alla prima visita, ma cambiando URL la lista non aggiorna.
**Causa:** `snapshot` è statico.
**Fix:** `this.route.queryParamMap.subscribe(...)` con `takeUntilDestroyed`.

### ❌ Errore 2: Manca `queryParamsHandling: 'merge'`
**Sintomo:** cambiando solo la search box, `page` sparisce dall'URL.
**Fix:** aggiungere `queryParamsHandling: 'merge'` al `router.navigate`.

### ❌ Errore 3: Manca `relativeTo: this.route`
**Sintomo:** cambiando la search, l'utente finisce in `/` invece di restare su `/admin/products`.
**Fix:** aggiungere `relativeTo: this.route` al `router.navigate`.

### ❌ Errore 4: Manca reset di `page` in `onSearch`
**Sintomo:** l'utente cerca "mac" mentre è in pagina 7 e si ritrova in pagina 7 di un filtro che ha 2 risultati.
**Fix:** in `onSearch`, passare esplicitamente `page: 1` insieme a `q`.

### ❌ Errore 5: Filtro case-sensitive
**Sintomo:** cercando "MAC" non si trova "MacBook".
**Fix:** `.toLowerCase()` su entrambi i lati del confronto.

### ❌ Errore 6: Signal letti senza parentesi nel template
**Sintomo:** `{{ q }}` mostra `() => readonly Signal<string>` invece del valore; `[disabled]="page <= 1"` sempre falso (la funzione signal è truthy).
**Fix:** `{{ q() }}`, `[disabled]="page() <= 1"`.

### ❌ Errore 7: `totalPages` a 0 (filtro vuoto)
**Sintomo:** "Pagina 1 di 0", pulsante "Avanti" attivo.
**Fix:** `Math.max(1, Math.ceil(...))`.

### ❌ Errore 8: `(input)="onSearch($event.target.value)"` senza `$any`
**Sintomo:** errore TypeScript `Property 'value' does not exist on type 'EventTarget'`.
**Fix:** `$any($event.target).value`, oppure template variable `#searchInput` + `searchInput.value`.

---

## 6. Domande frequenti

**Q: `queryParamMap` vs `queryParams` — quando uso uno o l'altro?**
A: `queryParamMap` è un `ParamMap` con metodo `get(key)` — più sicuro perché ritorna `string | null`. `queryParams` è un oggetto `{ [k: string]: any }` — più immediato ma più "stringly typed". Preferisci `queryParamMap` per la robustezza dei tipi.

**Q: Posso evitare il signal locale `q` e leggere direttamente dall'Observable?**
A: Sì, con `toSignal(route.queryParamMap)` poi un `computed` che estrae il `get('q')`. È più conciso ma introduce un Observable→Signal in più. Per il lab la doppia subscribe esplicita è più chiara: si vede *dove* arriva il valore.

**Q: Perché il filtro è client-side qui? Nel mondo reale sarebbe sul backend, no?**
A: Esatto. Qui abbiamo l'intero array già in memoria (il `ProductService` ritorna tutto). In un'app reale faresti `GET /api/products?q=mac&page=2&size=20` e il backend ti tornerebbe già paginato. Il pattern Angular è quasi identico: cambia solo che dentro `goToPage` rifai la GET invece di fare lo `slice` locale. La query string nell'URL resta la fonte di verità.

**Q: `queryParamMap` emette anche al primo caricamento (initial)?**
A: Sì — `ActivatedRoute.queryParamMap` è un `BehaviorSubject` mascherato: emette subito il valore corrente al subscribe. Quindi non devi gestire "primo caricamento" separatamente: la sottoscrizione popola `q`/`page` subito alla creazione del componente.

---

## 7. Adattamenti

### Classe veloce (resta tempo):
- TODO bonus: aggiungere un ordinamento `?sort=price|name`. Discutere il pattern: un terzo signal `sort`, un terzo `set` dentro la subscribe, un terzo `<select>` nel template, sempre `queryParamsHandling: 'merge'`. È un buon esercizio per consolidare il pattern senza introdurre nuove API.
- Mostrare in DevTools che cambiando URL a mano (`?q=mac&page=2` direttamente nella barra) la lista risponde.

### Classe lenta:
- Tagliare il `Math.max(1, ...)` su `totalPages` — accettare il bug visivo "Pagina 1 di 0" come compromesso, è fuori scope.
- Saltare la conversione esplicita `Number(...)`: lasciare `q.set(params.get('page'))` e accettare che `page` sia stringa. Tanto al template arriva via `{{}}` interpolation, "1" o `1` sembrano uguali. Ma il calcolo `(page - 1) * PAGE_SIZE` rompe — quindi: meglio tenerlo, è 1 riga.

### Cosa NON approfondire:
- `toSignal` (Angular 17+) — è un'API solo nominata; ci ritorneremo se serve in M4.
- `withRouterConfig({ paramsInheritanceStrategy: 'always' })` — fuori scope, complica il modello mentale dei queryParam vs paramMap.

---

## 8. Verifica NAP (binario A)

Stato di partenza: `product-catalog-finale/` con la solution di Lab 3a già applicata. Applicare i delta:

```bash
cp -r Corso/G2/lab-03b-querystring/solution/src/app/. Corso/progetto/product-catalog-finale/src/app/

cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test
```

**Verifica funzionale suggerita (manuale):**
- `/admin/products` → tutti i prodotti, "Pagina 1 di N".
- Digitare "mac" → URL `?q=mac&page=1`, lista filtrata in tempo reale.
- "Avanti →" → URL `?q=mac&page=2`.
- Cancellare search e digitare "ipad" → URL `?q=ipad&page=1` (page resettato a 1).
- Refresh dell'URL `?q=ipad&page=1` → stato preservato.
- Back del browser → torna a `?q=mac&page=2`. Forward → `?q=ipad&page=1`.

> **Stato di partenza del Lab 3c:** la `solution/` di questo lab applicata a `product-catalog-finale/`. Lab 3c aggiungerà il named outlet `panel` con cart preview.
