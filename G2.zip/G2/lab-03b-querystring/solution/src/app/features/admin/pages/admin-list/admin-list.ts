// features/admin/pages/admin-list/admin-list.ts — SOLUTION Lab 3b G2
// Delta rispetto al Lab 3a: aggiunte querystring, computed di filtro/paginazione,
// handler di navigazione con queryParamsHandling: 'merge'.

import { Component, DestroyRef, inject, signal, computed } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CurrencyPipe } from '@angular/common';
import { ProductService } from '../../../../services/product';
import { Product } from '../../../../product.model';

@Component({
  selector: 'app-admin-list',
  standalone: true,
  imports: [RouterLink, CurrencyPipe],
  templateUrl: './admin-list.html',
})
export class AdminList {

  private route      = inject(ActivatedRoute);   // ✅ TODO 1 — nuovo
  private router     = inject(Router);           // ✅ TODO 1 — nuovo
  private svc        = inject(ProductService);
  private destroyRef = inject(DestroyRef);

  readonly products = signal<Product[]>([]);

  // ✅ TODO 1 — signal alimentati da queryParamMap
  readonly q    = signal('');
  readonly page = signal(1);

  readonly PAGE_SIZE = 3;

  // ✅ TODO 1 — computed privato: filtro per nome (case-insensitive)
  private readonly filteredProducts = computed(() => {
    const term = this.q().toLowerCase();
    if (!term) return this.products();
    return this.products().filter(p => p.name.toLowerCase().includes(term));
  });

  // ✅ TODO 1 — computed pubblico: pagina corrente della lista filtrata
  readonly pagedProducts = computed(() => {
    const start = (this.page() - 1) * this.PAGE_SIZE;
    return this.filteredProducts().slice(start, start + this.PAGE_SIZE);
  });

  // ✅ TODO 1 — Math.max(1, ...) evita "Pagina 1 di 0" quando il filtro è vuoto
  readonly totalPages = computed(() =>
    Math.max(1, Math.ceil(this.filteredProducts().length / this.PAGE_SIZE))
  );

  constructor() {
    // (Lab 3a) carico i prodotti una sola volta
    this.svc.getProducts()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(list => this.products.set(list));

    // ✅ TODO 1 — aggancio reattivo alla querystring (rispetta back/forward del browser)
    this.route.queryParamMap
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(p => {
        this.q.set(p.get('q') ?? '');
        this.page.set(Number(p.get('page') ?? '1'));
      });
  }

  // ✅ TODO 1 — cambia search → reset page a 1 + merge per conservare altri queryParam
  onSearch(value: string): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { q: value, page: 1 },
      queryParamsHandling: 'merge',
    });
  }

  // ✅ TODO 1 — naviga di pagina, ignora valori fuori range
  goToPage(n: number): void {
    if (n < 1 || n > this.totalPages()) return;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { page: n },
      queryParamsHandling: 'merge',
    });
  }
}
