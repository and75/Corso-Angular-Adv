/**
 * features/admin/pages/admin-list/admin-list.ts — STARTER Lab 3b G2
 *
 * Stato di partenza: SOLUTION del Lab 3a (lista base, niente querystring).
 * Obiettivo: aggiungere search + paginazione via queryParams (TODO 1).
 *
 * Vedi Scheda 02 G2 §"Querystring: filtri e stato della vista" e Lab 3b README §TODO 1.
 */

import { Component, DestroyRef, inject, signal } from '@angular/core';
// TODO 1 — Aggiungi i nuovi import qui sopra:
//   - `computed` da '@angular/core'                              per filteredProducts, pagedProducts, totalPages
//   - `ActivatedRoute`, `Router` da '@angular/router'             per leggere la querystring e navigare
//   (RouterLink resta nel decoratore, già importato)
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CurrencyPipe } from '@angular/common';
import { ProductService } from '../../../../services/product';
import { Product } from '../../../../product.model';

@Component({
  selector: 'app-admin-list',
  standalone: true,
  imports: [RouterLink, CurrencyPipe],
  templateUrl: './admin-list.html',
})
export class AdminList {

  private svc        = inject(ProductService);
  private destroyRef = inject(DestroyRef);

  // TODO 1 — Aggiungi qui due nuovi inject:
  //   private route  = inject(ActivatedRoute);
  //   private router = inject(Router);

  readonly products = signal<Product[]>([]);

  // TODO 1 — Aggiungi qui i due nuovi signal esposti al template:
  //   readonly q    = signal('');
  //   readonly page = signal(1);
  //
  // E la costante di paginazione (campo privato readonly):
  //   readonly PAGE_SIZE = 3;

  /*
   * TODO 1 — Aggiungi qui i 3 computed:
   *
   *   Privato (usato sia da pagedProducts sia da totalPages):
   *     private readonly filteredProducts = computed(() => {
   *       const term = this.q().toLowerCase();
   *       if (!term) return this.products();
   *       return this.products().filter(p => p.name.toLowerCase().includes(term));
   *     });
   *
   *   Esposto al template (lista mostrata):
   *     readonly pagedProducts = computed(() => {
   *       const start = (this.page() - 1) * this.PAGE_SIZE;
   *       return this.filteredProducts().slice(start, start + this.PAGE_SIZE);
   *     });
   *
   *   Esposto al template (paginazione):
   *     readonly totalPages = computed(() =>
   *       Math.max(1, Math.ceil(this.filteredProducts().length / this.PAGE_SIZE))
   *     );
   *
   *   ⚠️ Il Math.max(1, ...) evita "Pagina 1 di 0" quando il filtro non trova nulla.
   */

  constructor() {
    // (Lab 3a) carico i prodotti una sola volta
    this.svc.getProducts()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(list => this.products.set(list));

    /*
     * TODO 1 — Aggiungi una SECONDA sottoscrizione, a route.queryParamMap:
     *
     *   this.route.queryParamMap
     *     .pipe(takeUntilDestroyed(this.destroyRef))
     *     .subscribe(params => {
     *       this.q.set(params.get('q') ?? '');
     *       this.page.set(Number(params.get('page') ?? '1'));
     *     });
     *
     *   ⚠️ NON usare route.snapshot.queryParamMap — è statico, non emette ai cambi URL.
     *      Usa l'Observable queryParamMap, che è reattivo (back/forward, refresh, navigate).
     */
  }

  /*
   * TODO 1 — Aggiungi i due handler invocati dal template:
   *
   *   onSearch(value: string): void {
   *     this.router.navigate([], {
   *       relativeTo: this.route,
   *       queryParams: { q: value, page: 1 },     // reset page a 1: UX standard al cambio search
   *       queryParamsHandling: 'merge',           // conserva altri queryParam (sort, view, ecc.)
   *     });
   *   }
   *
   *   goToPage(n: number): void {
   *     if (n < 1 || n > this.totalPages()) return;   // no-op se fuori range
   *     this.router.navigate([], {
   *       relativeTo: this.route,
   *       queryParams: { page: n },
   *       queryParamsHandling: 'merge',
   *     });
   *   }
   *
   *   ⚠️ `relativeTo: this.route` è obbligatorio: senza, il navigate('[]') va alla root.
   *   ⚠️ `queryParamsHandling: 'merge'` è OBBLIGATORIO: senza, ogni navigate cancella tutta la querystring.
   */
}
