// product-form.page.ts — STARTER mini-lab G2
// Stato di partenza: il form del seme è invariato, agganciare i 2 nuovi validatori
// (cross-field + async) e i relativi messaggi di errore.

import { Component, inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ProductService } from '../../services/product';
import { ProductCategory } from '../../product.model';
import { forbiddenWordsValidator } from '../../validators/product.validators';
// TODO 1: aggiungi qui sopra l'import del nuovo cross-field validator
//         (il nome è quello che hai definito nel TODO 1 di validators).
// TODO 2: aggiungi qui sopra l'import del nuovo async validator
//         (il nome è quello che hai definito nel TODO 2 di validators).

@Component({
  selector: 'app-product-form-page',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './product-form.page.html',
})
export class ProductFormPage implements OnInit {

  private fb             = inject(FormBuilder);
  private productService = inject(ProductService);

  productForm!: FormGroup;
  successMessage = '';
  errorMessage   = '';
  isLoading      = false;

  categories = Object.values(ProductCategory);

  ngOnInit(): void {
    this.initForm();
  }

  /**
   * TODO 1 + TODO 2 — Agganciare i due nuovi validatori al form:
   *
   *   TODO 2 (sul campo "name"):
   *     L'array di controllo di "name" oggi ha 2 elementi: [valore, sync].
   *     Aggiungi il TERZO slot [async] con il tuo uniqueProductNameValidator,
   *     che riceve this.productService come argomento.
   *
   *   TODO 1 (a livello di FormGroup):
   *     fb.group accetta DUE argomenti: la mappa dei controlli (1°) e un
   *     oggetto opzioni (2°). Aggiungi il secondo argomento:
   *       { validators: [detailedDescriptionIfAvailable(30)] }
   *     Il validator scatta ad ogni cambio di un qualsiasi controllo del gruppo
   *     e legge available + description insieme.
   */
  private initForm(): void {
    this.productForm = this.fb.group({
      name:        ['', [Validators.required, Validators.minLength(3)]],
      price:       [null, [Validators.required, Validators.min(1)]],
      category:    ['', [Validators.required]],
      description: ['', [
        Validators.required,
        Validators.minLength(10),
        forbiddenWordsValidator(['sconto', 'gratis', 'offerta', 'promo']),
      ]],
      available:   [true],
    });
  }

  isInvalid(fieldName: string): boolean {
    const control = this.productForm.get(fieldName);
    return !!(control && control.invalid && control.touched);
  }

  /**
   * TODO 2 — [TEMPLATE side] Non serve modifica qui in getFieldError:
   *   il messaggio per "nameTaken" lo gestiremo direttamente nel template
   *   (è specifico e usa il payload dell'errore). Il messaggio cross-field
   *   "detailedDescriptionRequired" è sul gruppo, anch'esso gestito a template.
   */
  getFieldError(fieldName: string): string {
    const control = this.productForm.get(fieldName);
    if (!control) return '';
    if (control.hasError('required'))  return 'Campo obbligatorio.';
    if (control.hasError('minlength')) {
      const err = control.getError('minlength');
      return `Minimo ${err.requiredLength} caratteri.`;
    }
    if (control.hasError('min')) {
      const err = control.getError('min');
      return `Il valore minimo è ${err.min}.`;
    }
    if (control.hasError('forbiddenWord')) {
      const err = control.getError('forbiddenWord');
      return `La descrizione non può contenere la parola "${err.word}".`;
    }
    return '';
  }

  onSubmit(): void {
    if (this.productForm.invalid) {
      this.productForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.successMessage = '';
    this.errorMessage   = '';

    this.productService.addProduct(this.productForm.value).subscribe({
      next: () => {
        this.successMessage = 'Prodotto aggiunto con successo!';
        this.productForm.reset({ available: true });
        this.isLoading = false;
      },
      error: () => {
        this.errorMessage = 'Errore durante il salvataggio. Riprova.';
        this.isLoading = false;
      },
    });
  }
}
