// product.validators.ts — STARTER mini-lab G2
// Stato di partenza: il forbiddenWordsValidator del seme è invariato.
// Vanno aggiunte DUE nuove funzioni esportate (TODO 1 e TODO 2).

import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
// TODO 2: aggiungi qui sopra gli import necessari per l'AsyncValidatorFn:
//          - AsyncValidatorFn dal @angular/forms (lo trovi nello stesso modulo
//            di ValidatorFn ma sotto un nome diverso che inizia per Async…);
//          - Observable, of, timer da 'rxjs';
//          - map, switchMap, catchError da 'rxjs/operators';
//          - ProductService dal servizio del seme ('../services/product').

/**
 * forbiddenWordsValidator (invariato dal seme — NON toccare).
 * Restituisce un ValidatorFn che controlla che il valore del controllo
 * non contenga nessuna delle parole vietate.
 */
export function forbiddenWordsValidator(forbidden: string[]): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = (control.value ?? '').toLowerCase() as string;
    if (!value) return null;
    const found = forbidden.find(word => value.includes(word.toLowerCase()));
    if (!found) return null;
    return { forbiddenWord: { word: found } };
  };
}

/**
 * TODO 1 — [FACILE] Cross-field validator: "se Disponibile → descrizione dettagliata".
 *
 *   Esportare una funzione `detailedDescriptionIfAvailable(minLen: number): ValidatorFn`
 *   (factory). La funzione restituita riceve l'AbstractControl del FORMGROUP, non
 *   di un singolo controllo: questo è ciò che le permette di leggere PIÙ campi insieme.
 *
 *   Logica:
 *     - leggi available  = group.get('available')?.value as boolean
 *     - leggi description = (group.get('description')?.value ?? '') as string
 *     - se available === true E description.length < minLen → ritorna
 *         { detailedDescriptionRequired: { minLen, actualLen: description.length } }
 *     - altrimenti → ritorna null (gruppo valido rispetto a questa regola)
 *
 *   ATTENZIONE: questo validator NON va messo sul controllo "description";
 *   se lo fai, riceve solo description.value e non vede available. Va messo
 *   come secondo argomento di fb.group(controls, { validators: [...] }) in
 *   product-form.page.ts (TODO 1 lato componente).
 *
 *   Vedi Scheda 01 di G2 §"Pattern 2 — Cross-field validator (sul FormGroup)".
 */


/**
 * TODO 2 — [MEDIO] Async validator: "nome prodotto univoco" via HTTP.
 *
 *   Esportare una funzione `uniqueProductNameValidator(productService: ProductService): AsyncValidatorFn`
 *   (factory). La funzione restituita riceve l'AbstractControl del SINGOLO controllo
 *   "name" e deve ritornare un Observable<ValidationErrors | null>.
 *
 *   Pattern canonico (vedi Scheda 01 di G2 §"Pattern 3 — Async validator"):
 *
 *     1. Legge name = (control.value ?? '').trim() — se vuoto, ritorna of(null)
 *        (la regola "required" la gestisce un altro validator).
 *
 *     2. Ritorna timer(400).pipe(...) — il timer(400) fa da DEBOUNCE:
 *        - se l'utente continua a digitare, switchMap annulla la pipe corrente
 *          e ne crea una nuova; di fatto la chiamata HTTP parte solo dopo
 *          ~400 ms di "silenzio".
 *
 *     3. Dentro pipe:
 *        - switchMap(() => productService.getProducts())   ← chiamata HTTP
 *        - map(products => products.some(p =>
 *            p.name.toLowerCase() === name.toLowerCase())
 *            ? { nameTaken: { name } } : null)             ← matching case-insensitive
 *        - catchError(() => of(null))                      ← rete offline → non bloccare
 *
 *   ATTENZIONE: questo validator va come TERZO argomento dell'array di controllo
 *   del campo "name" in product-form.page.ts:
 *     name: [valore, sync[], async[]]
 *                              ↑ terzo slot, è qui che va.
 *
 *   Senza timer/debounce, partirebbe una HTTP a ogni keystroke. Senza catchError,
 *   un network error lascerebbe il controllo in "pending" per sempre.
 */
