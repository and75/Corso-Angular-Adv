# Mini-lab — Validatori cross-field + async sul product-form
## Guida per il Docente

---

## 1. Scopo Didattico

Mini-lab breve (30 min) che applica i due pattern non banali della Scheda 01 di G2:
**cross-field** (validator sul `FormGroup`) e **async** (validator HTTP). Il taglio è
"consolidamento ripasso" — non si introduce nessun concetto nuovo, si mette in pratica.

Tre punti che vale la pena trasmettere a voce mentre i corsisti lavorano:

1. **Niente nuovi campi del form** — il refactor tocca solo i validator. È la differenza
   tra "estendere il modello dati" (un lab più lungo, in M3) e "aggiungere regole" (oggi).
2. **Il validator cross-field vive sul gruppo**, non sul controllo. Discutete a voce il
   perché: leggere `address` mentre si valida `email` significa che il validator deve
   "vedere" entrambi → solo il `FormGroup` ha la visibilità di tutti i figli.
3. **L'async validator è un Observable**, non una Promise: si integra naturalmente con
   `debounceTime`/`switchMap`/`catchError` — pattern che ritroveranno in Mod 3
   (`route.paramMap` reattivo) e Mod 4 (interceptor).

---

## 2. Timing Consigliato

**Slot orario: 10:00–10:30 (30 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo del risultato (provo nome esistente + descrizione corta su prodotto Disponibile) | 3 min |
| TODO 1 | Cross-field `detailedDescriptionIfAvailable` (validator + agganciato a `fb.group`) + messaggio nel template | 10 min |
| Recap di mezzo | Verifica visiva del cross-field | 2 min |
| TODO 2 | `uniqueProductNameValidator` async (validator + agganciato al `name` slot 3) + UI pending/nameTaken | 12 min |
| Verifica + Q&A | Criteri visivi soddisfatti, niente errori console | 3 min |
| **Totale** | | **~30 min** |

> Se a metà tempi un quarto della classe è in panne sul TODO 1, fai tu in proiezione il
> cross-field e dai più tempo al TODO 2 (l'async è il pattern che ricorderanno di più).

---

## 3. Contesto nella Scaletta

Mini-lab fuori numerazione (come `mini-lab-direttive` del corso base). Arriva subito dopo
la Scheda 01 di G2 (recap, 09:10–10:00) e precede il pranzo (13:00). Non ci sono lab
successivi nel pomeriggio del giorno 2 fino al Mod 3 (Lab 3, 12:00).

Aggancio col resto del corso:
- Il `product-form` resterà toccato anche in **Mod 3**: verrà spostato in area admin lazy
  (`admin/products/:id/edit`). I validatori che aggiungiamo qui sopravvivono al move.
- Il pattern async + `switchMap` torna in **Mod 4** (interceptor con retry + auth refresh)
  e in **Mod 3** (`paramMap.pipe(switchMap(...))`).

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 Cross-field sul FormGroup

```typescript
this.productForm = this.fb.group({
  name:        [...],
  // …
  available:   [true],
}, {
  validators: [detailedDescriptionIfAvailable(30)],   // ← secondo argomento
});
```

**Cosa dire:**
> "Notate che `fb.group(controls, opts)` accetta DUE argomenti. Il primo è la mappa dei
> controlli; il secondo è un oggetto di opzioni — qui ci interessa `validators` (array).
> Il validator riceve l'INTERO `AbstractControl` del gruppo, non un singolo controllo:
> potete fare `group.get('available')?.value` e `group.get('description')?.value` insieme.
> L'errore vive sul gruppo, non sui figli."

### 4.2 Cast esplicito sui valori del FormGroup

```typescript
const available   = group.get('available')?.value as boolean;
const description = (group.get('description')?.value ?? '') as string;
```

**Cosa dire:**
> "I typed forms di Angular 14+ tipizzerebbero i singoli controlli, ma quando leggete
> via `group.get('chiave')?.value` ricevete `unknown`. Cast esplicito + fallback a stringa
> vuota per `description` (per evitare `null.length` se non ancora toccato)."

### 4.3 Pattern async canonico

```typescript
return timer(400).pipe(
  switchMap(() => productService.getProducts()),
  map(products => /* check */),
  catchError(() => of(null)),
);
```

**Cosa dire:**
> "Quattro operatori, ognuno con un ruolo preciso:
>   - `timer(400)` debounce manuale — aspetta 400 ms prima di partire. Se il valore
>     cambia prima, lo `switchMap` cancella la pipe corrente e ne crea una nuova.
>   - `switchMap` annulla la chiamata precedente — se l'utente digita 'iP', poi 'iPh',
>     parte solo l'ultima HTTP, le precedenti vengono ignorate.
>   - `map` trasforma la risposta in `{ chiave: payload } | null`.
>   - `catchError(() => of(null))` evita di bloccare l'utente se l'API è offline. Scelta
>     di design 'fail-open': qui preferiamo non far passare un nome valido errato
>     piuttosto che bloccare il form. Discutete con la classe quando NON si fa così
>     (es. validazione fiscale di IVA: fail-closed è più sicuro)."

### 4.4 Async validator come terzo slot di array

```typescript
name: [
  '',
  [Validators.required, Validators.minLength(3)],         // sync[]
  [uniqueProductNameValidator(this.productService)],      // async[]
],
```

**Cosa dire:**
> "L'array del controllo è `[valore, sync, async]`. Sono **tre slot ordinali**. Se ne
> dimenticate uno, Angular non si arrabbia ma il vostro validator non funziona — è
> l'errore più frequente quando lo si vede per la prima volta."

### 4.5 UI: pending + errore async

```html
@if (productForm.get('name')?.pending) {
  <p class="mt-1 text-xs text-gray-500">Verifico disponibilità…</p>
} @else if (!isInvalid('name')) {
  <!-- nessun errore — ok -->
} @else if (productForm.get('name')?.hasError('nameTaken')) {
  <p class="mt-1 text-xs text-red-500">
    Il nome "{{ productForm.get('name')?.getError('nameTaken').name }}" è già usato.
  </p>
} @else {
  <p class="mt-1 text-xs text-red-500">{{ getFieldError('name') }}</p>
}
```

**Cosa dire:**
> "L'`@if/@else if` gestisce tre stati visivi distinti: in verifica → messaggio neutro;
> errore async specifico → messaggio mirato; altrimenti fall-through al `getFieldError`
> esistente per gli errori sync. Senza il primo ramo, durante la verifica vedreste
> brevemente 'nome già usato' (perché l'ultimo stato valido è ancora `nameTaken` mentre
> la prossima chiamata è in volo) → flash visivo poco professionale."

---

## 5. Errori comuni degli studenti

### ❌ Errore 1: cross-field messo sul controllo
**Sintomo:** TypeScript compila, ma il validator non scatta mai (oppure scatta vedendo
solo `description.value` come stringa).
**Causa:** `description: ['', [...validators, detailedDescriptionIfAvailable(30)]]` →
il validator riceve il singolo control, non il gruppo, e `group.get('available')` è
undefined.
**Fix:** mettere il validator come 2° argomento di `fb.group(...)`.

### ❌ Errore 2: async validator nello slot sync
**Sintomo:** TypeScript dà errore tipo, oppure il validator non scatta in `pending`.
**Causa:** mettere `uniqueProductNameValidator(...)` come secondo elemento del controllo
(slot sync) invece che terzo (slot async).
**Fix:** rispettare l'ordine `[valore, sync, async]`.

### ❌ Errore 3: niente `timer`/`debounce` → bombardamento server
**Sintomo:** una chiamata HTTP per ogni keystroke (visibile nel Network tab).
**Causa:** l'AsyncValidatorFn chiama direttamente `productService.getProducts()`.
**Fix:** `timer(400).pipe(switchMap(...))` o `productService.getProducts().pipe(debounceTime(400))`
(il primo è preferibile perché annulla anche la HTTP precedente con switchMap).

### ❌ Errore 4: niente catchError → utente bloccato offline
**Sintomo:** se la rete cade, il form resta `pending` per sempre.
**Causa:** l'Observable dell'async validator emette `error` invece di completare → il
controllo resta `pending`.
**Fix:** `catchError(() => of(null))` (fail-open) o `catchError(() => of({ networkError: true }))`
(fail-closed). Discutere a voce.

### ❌ Errore 5: messaggio cross-field mostrato sempre
**Sintomo:** `detailedDescriptionRequired` appare appena la pagina si apre.
**Causa:** dimenticato il controllo `&& productForm.touched` nel template.
**Fix:** `@if (form.hasError('detailedDescriptionRequired') && form.touched)`.

---

## 6. Domande frequenti

**Q: Posso mettere il cross-field validator come `Validators.required` su un campo virtuale?**
A: No, non ha senso semantico. I cross-field validator esistono proprio per esprimere
regole che attraversano più campi. È il loro mestiere.

**Q: `AsyncValidatorFn` accetta anche Promise?**
A: Sì, ma in Angular gli Observable sono più potenti (cancellabili con `switchMap`,
componibili in pipe). Usate Observable a meno che non abbiate una Promise di partenza
(es. da `fetch()` raw).

**Q: Lo stato `pending` viene anche propagato sul `FormGroup`?**
A: Sì — se un controllo figlio è `pending`, anche il gruppo è `pending`. Se disabilitate
il bottone "Salva" con `[disabled]="form.invalid || form.pending"` evitate submit mentre
la verifica HTTP è in corso.

**Q: Il cross-field validator può ritornare errori su più campi insieme?**
A: Tecnicamente sì (ritornando un oggetto con più chiavi), ma per UX si preferisce
chiavi distinte e messaggio unico sul gruppo. Per errori "su un campo specifico" usate
`group.get('x')?.setErrors({...})` dentro al validator — pattern raro.

---

## 7. Adattamenti

### Classe veloce (resta tempo):
- Chiedere: "come fareste in modo che la validazione async sia disabilitata in modalità
  EDIT (quando il prodotto già esiste con quel nome)?" → soluzione: passare l'id corrente
  alla factory e ignorare il match se `p.id === currentId`.

### Classe lenta:
- Fare il TODO 1 (cross-field, 10 min) ed eventualmente saltare il TODO 2 — l'async
  validator richiede `Observable`, `pipe`, `switchMap` insieme; se la classe ha
  difficoltà su uno di questi, è meglio rivedere la Scheda 02 di Mod 0.

### Cosa NON approfondire:
- Animazione del "pending" (skeleton loader, spinner): UX, non Angular.
- Typed forms al 100% — i typed forms con cross-field richiedono lavoro extra che esce
  dai 30 min.

---

## 8. Verifica NAP (binario A)

A fine lab, applicare i file di `solution/` sopra a `product-catalog-finale/` (sopra ai
delta cumulativi Lab 0+1+2 già applicati):

```bash
cp -r Corso/G2/mini-lab-form/solution/src/app/. Corso/progetto/product-catalog-finale/src/app/

cd Corso/progetto/product-catalog-finale
npx ng build           # atteso: Application bundle generation complete
npx ng test            # atteso: tutti i Test Files passed
```

Il seme `Corso/progetto/product-catalog/` resta intatto.
