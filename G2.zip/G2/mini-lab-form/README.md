# Mini-lab — Validatori cross-field + async sul product-form
### Giorno 2 · Mini-lab guidato (30 min)

---

## Obiettivo

Consolidare i pattern della Scheda 01 di G2 sul form esistente `product-form`:
1. Aggiungere un validatore **cross-field** (sul `FormGroup`) che impone una descrizione dettagliata quando il prodotto è marcato come "Disponibile".
2. Aggiungere un validatore **async** che verifica via `ProductService` che il nome del prodotto non sia già usato.

Risultato visivo: provando a salvare un prodotto "disponibile" con descrizione corta vedi il messaggio cross-field; mentre scrivi un nome già esistente vedi prima "verifico…" poi "nome già usato".

---

## File modificati / creati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/validators/product.validators.ts` | Aggiunge 2 validatori (`detailedDescriptionIfAvailable`, `uniqueProductNameValidator`) | modificato |
| `src/app/pages/product-form/product-form.page.ts` | Aggancia i nuovi validatori al `fb.group` + messaggi errore | modificato |
| `src/app/pages/product-form/product-form.page.html` | Mostra "verifico…" sul name + errore form-level | modificato |

> Il resto del progetto è invariato. Niente nuove dipendenze npm.

---

## Setup veloce

Da una shell sola (è il nuovo `npm start` che lancia json-server + ng serve insieme):

```bash
cd Corso/progetto/product-catalog
npm start
```

Apri `http://localhost:4200/products/new` (è la route protetta dall'`authGuard`: serve essere "loggati" — clicca prima "Login" e usa la finta auth del seme).

---

## TODO 1 — FACILE: cross-field "se Disponibile, descrizione dettagliata"

Regola: quando l'utente spunta `available = true`, la descrizione deve essere ≥ **30 caratteri** (non 10 come oggi). Quando `available = false`, basta il minimo standard.

Apri `src/app/validators/product.validators.ts` e aggiungi accanto a `forbiddenWordsValidator` un nuovo validator a livello di `FormGroup`. Vedi i TODO nel file `starter/` per la struttura.

Poi aggancialo al `product-form` come **secondo argomento** di `fb.group(..., { validators })`. Vedi TODO nel file `starter/`.

Infine, nel template, mostra il messaggio d'errore — l'errore vive sul **FormGroup**, non sui singoli controlli:

```html
@if (productForm.hasError('detailedDescriptionRequired') && productForm.touched) {
  <p class="mt-1 text-xs text-red-500">
    I prodotti "Disponibile" richiedono almeno 30 caratteri di descrizione.
  </p>
}
```

---

## TODO 2 — MEDIO: async "nome prodotto univoco"

Regola: mentre l'utente digita il nome, dopo una pausa di ~400 ms si chiede a `ProductService.getProducts()` se esiste già un prodotto con lo stesso nome (case-insensitive). Se sì, errore `nameTaken`.

Apri `validators/product.validators.ts` e aggiungi `uniqueProductNameValidator`. Vedi i TODO nel file `starter/` per il pattern `timer→switchMap→map→catchError`.

Poi aggancialo al campo `name` come **terzo argomento** dell'array `[value, sync[], async[]]`. Vedi TODO nel file `starter/`.

Nel template aggiungi:
- Stato "in verifica" durante la chiamata HTTP (`productForm.get('name')?.pending`)
- Messaggio dedicato per l'errore `nameTaken`

---

## Criteri di verifica

- [ ] In `validators/product.validators.ts` ci sono **3 funzioni esportate**: `forbiddenWordsValidator` (esistente), `detailedDescriptionIfAvailable` (TODO 1), `uniqueProductNameValidator` (TODO 2).
- [ ] Il `productForm` ha l'opzione `{ validators: [...] }` come secondo argomento di `fb.group(...)`.
- [ ] Il campo `name` ha il terzo slot popolato con `[uniqueProductNameValidator(this.productService)]`.
- [ ] Aprire la pagina, inserire un nome **già presente** (es. "MacBook Pro 14\"") fa apparire prima "verifico…" poi un messaggio di errore.
- [ ] Spuntando "Disponibile" e lasciando una descrizione corta (es. 15 caratteri), al primo `submit` appare il messaggio cross-field.
- [ ] Togliendo la spunta "Disponibile" il messaggio cross-field sparisce (la descrizione corta torna accettabile).
- [ ] `ng serve` non lancia errori, console del browser pulita.
- [ ] **Verifica formale (binario A):** dopo aver applicato la `solution/` a `product-catalog-finale/`, `npx ng build` + `npx ng test` passano.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| L'errore "nameTaken" appare ad ogni keystroke (server bombardato) | Manca `timer(400)` o `debounceTime(400)` nella pipe | TODO 2 |
| L'errore "detailedDescriptionRequired" appare sul controllo "description" | Hai messo il validator sul campo invece che sul `fb.group` | TODO 1 |
| `nameTaken` appare anche durante la verifica (flash brutto) | Manca il controllo `!form.get('name')?.pending` nel template | TODO 2 (template) |
| `console.error` su offline mode → il form si blocca | Manca `catchError(() => of(null))` nell'async validator (decidere se fail-open o fail-closed) | TODO 2 |
| Type error sul cross-field `group.get('available')?.value` | Tipo `unknown` su `value` → cast esplicito `as boolean` | TODO 1 |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!
