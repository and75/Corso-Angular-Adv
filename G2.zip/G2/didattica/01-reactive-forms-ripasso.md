# 01 — Reactive Forms (ripasso veloce)

> **Tempo:** ~50 min · **Slide:** TBD · **Blocco:** G2 Sessione 1 · 09:10–10:00 (Mod 2)
> **Prerequisito:** [Scheda 05 G1 — Reactive Forms base + ng-content](../../G1/didattica/05-reactive-forms-ngcontent.md). Qui non rifacciamo i Reactive Forms da capo: prendiamo per assodato lo scheletro del base e ci concentriamo sui *tre* tipi di validator non banali che il base ha solo accennato.

---

## Il problema

Nel corso base avete imparato a comporre un Reactive Form: `FormBuilder.group({...})`, `[formGroup]` nel template, `Validators.required` e `Validators.email` agganciati al singolo controllo, e l'errore mostrato solo quando il campo è `invalid && touched`. È il modello mentale che la Scheda 05 di G1 vi ha lasciato — e che ritrovate nel seme dentro [`pages/checkout/checkout.page.ts`](../../progetto/product-catalog/src/app/pages/checkout/checkout.page.ts): un `fb.group` di quattro controlli, ciascuno con la sua lista di sync validators built-in, niente di più.

Quella forma copre il 70% dei casi reali. Vi capiterà però — e nel resto della giornata vi capiterà tre volte — di trovarvi davanti a regole che il modello "validator built-in sul singolo controllo" non riesce a esprimere. Una regola che dipende da *più campi insieme* ("se la quantità supera 5, l'indirizzo dev'essere dettagliato"), una regola che dipende da una *risposta del server* ("questo nome prodotto è già usato?"), e — già vista in fondo al base ma da rispolverare — una regola che vorreste scrivere voi una volta sola e parametrizzare ovunque ("queste tre parole promozionali sono vietate").

Nei prossimi 50 minuti chiudiamo questi tre buchi. Non per esibizione: ci servono direttamente da Mod 3 in poi. Il [`product-form`](../../progetto/product-catalog/src/app/pages/product-form/product-form.page.ts) verrà spostato in area admin lazy come `admin/products/:id/edit` (Mod 3) e dovrà validare campi in funzione di altri campi; il backend mock risponderà con conflitti che vogliamo intercettare in maniera centralizzata via `errorInterceptor` (Mod 4); e qualche controllo del form farà chiamate HTTP che in SSR (Mod 6) andranno trattate come browser-only. I tre pattern che vediamo ora sono la base su cui tutto il resto si appoggia.

---

## Il magazziniere che controlla il modulo

Prima di entrare nel codice, vi do una metafora che ci accompagna per tutta la scheda. Pensate al form come a un *modulo di consegna ordine* compilato a mano che arriva al magazzino. Dietro lo sportello c'è un magazziniere il cui mestiere è uno solo: controllare che il modulo sia compilato bene prima di farlo passare al reparto spedizioni.

Il magazziniere lavora a *tre livelli di attenzione*, e sono esattamente i tre livelli del sistema dei validator in Angular.

1. **L'occhio sul singolo campo.** Guarda riga per riga: il nome è scritto? L'email ha la chiocciola? L'indirizzo è almeno di 10 caratteri? Sono regole locali, una per ciascuna riga, indipendenti l'una dall'altra. *Questo è il validator sul `FormControl`* — `Validators.required`, `Validators.email`, il vostro `forbiddenWordsValidator`.
2. **L'occhio sul modulo intero.** Ogni tanto si stacca dal singolo campo e *legge il modulo nel suo insieme* per regole che nessun singolo campo può conoscere: "se hai scritto 'consegna serale', devi anche avermi dato un numero di citofono", "se la quantità è alta, l'indirizzo va dettagliato". Sono regole *trasversali*. *Questo è il cross-field validator sul `FormGroup`*.
3. **La telefonata al sistema centrale.** Per alcuni dati il magazziniere da solo non basta: deve alzare la cornetta e chiamare il sistema centrale che gli risponde dopo qualche secondo ("questo codice cliente è già registrato? questo SKU esiste?"). Mentre aspetta la risposta, il modulo è in uno stato intermedio: né accettato né rifiutato. *Questo è l'async validator*.

Tenete in testa queste tre figure mentre attraversiamo il codice. Quando vi chiederete *"dove va questo controllo?"*, la risposta è sempre una delle tre: sul singolo campo, sul gruppo, o "richiede una telefonata". Il resto è sintassi.

---

## Recap rapido (5 min — quello che il base vi ha già lasciato)

Lo scheletro lo conoscete. Vale la pena rileggerlo dal vero, perché lo riprenderemo come *base di partenza* per i tre pattern nuovi. Aprite [`checkout.page.ts`](../../progetto/product-catalog/src/app/pages/checkout/checkout.page.ts) del seme:

```typescript
// pages/checkout/checkout.page.ts — codice reale del seme
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [ReactiveFormsModule, /* … */],
  templateUrl: './checkout.page.html',
})
export class CheckoutPage implements OnInit {
  private fb = inject(FormBuilder);
  checkoutForm!: FormGroup;

  ngOnInit(): void {
    this.checkoutForm = this.fb.group({
      customerName: ['', Validators.required],
      email:        ['', [Validators.required, Validators.email]],
      address:      ['', [Validators.required, Validators.minLength(10)]],
      notes:        [''],
    });
  }
}
```

Quattro controlli, ciascuno è il classico array `[valoreIniziale, sync-validators]`. Quando il sync validator è uno solo lo passate diretto (`Validators.required`); quando ne avete più di uno li mettete in un array (`[Validators.required, Validators.email]`). Nel template è tutto altrettanto familiare:

```html
<form [formGroup]="checkoutForm" (ngSubmit)="onSubmit()">
  <input formControlName="customerName" />
  @if (isInvalid('customerName')) { <small>Campo obbligatorio.</small> }
  <!-- … -->
</form>
```

Le tre cose che date per scontate — e che vi serviranno ancora più chiare oggi:

- `[formGroup]` + `formControlName` + `(ngSubmit)` come triangolo di base.
- Lo stato del controllo non è binario: `valid`/`invalid`, `touched`/`untouched`, `dirty`/`pristine`. La regola d'oro per non aggredire l'utente è mostrare l'errore *solo* quando è `invalid && touched` — ovvero quando ha sbagliato *e* ha già interagito.
- `markAllAsTouched()` in `onSubmit` per forzare la visibilità degli errori al primo invio, perché se l'utente clicca "Invia" senza aver toccato nulla, `touched` è ancora `false` e i messaggi resterebbero nascosti.

Se sentite il bisogno di un richiamo più disteso prima di andare avanti, tornate a [Scheda 05 G1](../../G1/didattica/05-reactive-forms-ngcontent.md). Da qui in poi diamo per acquisito tutto questo.

---

## Il validator personalizzato: la regola scritta a mano

Cominciamo dal livello *campo singolo* della nostra metafora, perché è il punto in cui il base si è fermato e da cui partiamo. I `Validators.*` di Angular coprono i casi comuni (required, email, min/max, pattern), ma prima o poi vi capita una regola di dominio che nessun built-in conosce. Nel seme c'è già un esempio reale: la descrizione di un prodotto non deve contenere certe parole promozionali ("sconto", "gratis", "offerta", "promo"). Aprite [`validators/product.validators.ts`](../../progetto/product-catalog/src/app/validators/product.validators.ts):

```typescript
// validators/product.validators.ts — codice reale del seme
export function forbiddenWordsValidator(forbidden: string[]): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = (control.value ?? '').toLowerCase() as string;
    if (!value) return null;   // lasciamo agire Validators.required

    const found = forbidden.find(word => value.includes(word.toLowerCase()));
    if (!found) return null;
    return { forbiddenWord: { word: found } };
  };
}
```

Soffermatevi un momento sulla forma: `forbiddenWordsValidator` *non è* un validator. È una **factory di validator** — una funzione che, *chiamata* con la lista di parole vietate, *ritorna* il validator vero e proprio. È un pattern che vale la pena assimilare perché lo riuserete in tutti e tre i livelli del magazziniere: ogni volta che un validator ha bisogno di *parametri di configurazione* (la soglia di quantità, la lunghezza minima, il servizio HTTP da consultare), il modo idiomatico in Angular è incapsulare quei parametri in una factory esterna che ritorna la funzione interna.

L'aggancio al controllo è banale — la factory viene *invocata* nella definizione del form:

```typescript
description: ['', [
  Validators.required,
  Validators.minLength(10),
  forbiddenWordsValidator(['sconto', 'gratis', 'offerta', 'promo']),
]],
```

Tre dettagli da fissare prima di andare oltre.

Il primo è la **forma dell'errore**: un oggetto `{ chiave: payload }`. La *chiave* (`forbiddenWord`) è ciò che il template userà per intercettare l'errore — `control.hasError('forbiddenWord')`. Il *payload* (`{ word: found }`) è il contesto che vi serve per scrivere un messaggio specifico — `control.getError('forbiddenWord').word` vi dà la parola che ha fatto scattare l'errore, così il template può dire *"la parola «sconto» non è ammessa"* invece di un generico *"errore"*. Guardate `getFieldError` in [`product-form.page.ts`](../../progetto/product-catalog/src/app/pages/product-form/product-form.page.ts) per vedere il pattern in azione.

Il secondo è la **convenzione del campo vuoto**: se il controllo non ha valore, il vostro validator deve ritornare `null` (cioè "tutto a posto"). Non perché sia indulgente, ma perché *delegate* l'obbligatorietà a `Validators.required`, che è il job di un altro validator. Se metteste l'errore "campo obbligatorio" dentro a `forbiddenWordsValidator`, l'utente vedrebbe due messaggi sovrapposti per lo stesso problema. Una regola, un mestiere.

Il terzo è la firma. `ValidatorFn` è il tipo di una funzione `(control: AbstractControl) => ValidationErrors | null`. Il nome del tipo dice tutto: una funzione che riceve un controllo e ritorna *errori o niente*. Da qui in poi tutte le firme che vediamo sono varianti di questa stessa idea — cambiano `control` (può diventare un `FormGroup`) e cambia il ritorno (può diventare un `Observable<ValidationErrors | null>`), ma il modello mentale è lo stesso.

---

## Cross-field: quando il controllo richiede l'intero modulo

Vi capiterà presto di scontrarvi con regole che *non hanno senso* sul singolo campo. "La password di conferma deve coincidere con quella sopra". "La data di fine non può essere precedente alla data di inizio". "Se la quantità supera 5, l'indirizzo va dettagliato (almeno 20 caratteri)". Il magazziniere, qui, smette di guardare la singola riga: deve *leggere il modulo intero* per esprimersi.

Tradotto in Angular: il validator non vive più sul `FormControl`, vive sul `FormGroup`. Tecnicamente la firma è identica — riceve un `AbstractControl` e ritorna `ValidationErrors | null` — ma quel `AbstractControl` *adesso è il gruppo*, e da lì potete chiamare `group.get('quantity')`, `group.get('address')`, e confrontare i valori. Anticipazione del mini-lab che farete subito dopo questa scheda:

```typescript
// validators/product.validators.ts — pattern del mini-lab
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Sul FormGroup: se "quantity" supera la soglia,
 * "address" deve essere lungo almeno minAddressLen.
 */
export function detailedAddressIfHighQuantity(
  qtyThreshold: number,
  minAddressLen: number,
): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const qty     = group.get('quantity')?.value as number ?? 0;
    const address = (group.get('address')?.value ?? '') as string;

    if (qty > qtyThreshold && address.length < minAddressLen) {
      return { detailedAddressRequired: { qty, minAddressLen, actualLen: address.length } };
    }
    return null;
  };
}
```

Stessa factory di prima — parametrizziamo soglia e lunghezza minima — ma il corpo del validator interpreta il proprio argomento come *il gruppo*, non come *il singolo controllo*. Notate che usiamo l'optional chaining `group.get('quantity')?.value` invece di assumere che il campo esista sempre: se in futuro qualcuno aggiunge o toglie controlli dinamicamente con `addControl`/`removeControl`, il validator non crasha — semplicemente si comporta come se il campo non ci fosse.

L'aggancio al `FormBuilder` cambia rispetto a prima: il validator del gruppo si dichiara come **secondo argomento di `fb.group(...)`**, dentro a un oggetto opzioni:

```typescript
this.checkoutForm = this.fb.group({
  customerName: ['', Validators.required],
  email:        ['', [Validators.required, Validators.email]],
  address:      ['', [Validators.required, Validators.minLength(10)]],
  quantity:     [1,  [Validators.required, Validators.min(1)]],
  notes:        [''],
}, {
  // ← validator a livello di GRUPPO, secondo argomento di fb.group
  validators: [detailedAddressIfHighQuantity(5, 20)],
});
```

E qui arriva il dettaglio che fa la differenza nei template — *e che brucia in produzione se ve lo dimenticate*: l'errore non vive sui singoli controlli `quantity` e `address`. Vive sul **FormGroup intero**. Significa che nel template non scrivete `quantity.hasError(...)` ma `checkoutForm.hasError(...)`:

```html
<form [formGroup]="checkoutForm" (ngSubmit)="onSubmit()">
  <!-- … input … -->

  @if (checkoutForm.hasError('detailedAddressRequired') && checkoutForm.touched) {
    <small class="text-red-600">
      Per ordini sopra 5 articoli l'indirizzo deve essere di almeno 20 caratteri.
    </small>
  }
</form>
```

È coerente con la metafora del magazziniere: la regola "modulo intero" produce un'osservazione "sul modulo intero", non su un campo specifico. E vi indicherei di renderlo *visibile* nel template — un messaggio collettivo, sopra o sotto la sezione interessata — perché un utente che vede l'errore solo su `address` si chiederebbe *"perché solo ora? era a posto un attimo fa"*. Il vero motivo è che ha cambiato `quantity`, e lo capisce solo se glielo dite.

Una terza cosa è utile sapere: il cross-field gira **ad ogni cambio di un qualsiasi controllo del gruppo**. Non aspetta che cambi `quantity` o `address` in particolare. Per regole semplici è esattamente quello che volete; per regole costose (es. che fanno calcoli pesanti) avete sempre la possibilità di rientrare dentro al validator e ottimizzare. Nel 99% dei casi non vi serve.

### Perché cross-field e non un sync validator su uno dei due campi?

Vi capiterà di chiedervi, ed è una domanda onesta: *"non potrei mettere `detailedAddressIfHighQuantity` come validator di `address`, e leggermi `quantity` con `control.parent`?"*. Tecnicamente sì — il `parent` di un controllo è il gruppo, e da lì potreste leggere `quantity`. È *sintatticamente* corretto e non c'è nessun warning runtime. Però:

- L'errore vive su `address`, ma la *causa* potrebbe essere `quantity`. Un utente che corregge `address` non capisce perché l'errore non scompare se non riduce `quantity`. Confonde.
- Il validator non si attiva quando cambia `quantity` da solo (cambia un *altro* controllo, non il vostro): Angular non ricalcola la validità di `address` se non lo tocca l'utente.
- È fragile: rinominare o spostare il controllo padre rompe il validator silenziosamente.

La regola di pollice: *se il validator ha bisogno di guardare più di un controllo, vive sul gruppo*. Punto.

---

## Async: quando il magazziniere alza la cornetta

Veniamo al terzo livello — il più ricco, quello dove RxJS rientra in gioco. Alcune regole il magazziniere *non può verificarle da solo*: deve chiamare il sistema centrale e aspettare una risposta. "Questo nome prodotto è già usato?" è il caso canonico — solo il backend sa chi c'è già nel database; il client può solo *chiedere*.

Angular tratta questo caso con un tipo apposito, `AsyncValidatorFn`, che è quasi-identico al `ValidatorFn` sync con due sole differenze: ritorna un **`Observable<ValidationErrors | null>`** (o una `Promise`), e si aggancia nello **slot async del controllo** (un terzo argomento dell'array che fin qui ne aveva due). Anteprima del mini-lab:

```typescript
// validators/product.validators.ts — pattern del mini-lab
import { AbstractControl, AsyncValidatorFn, ValidationErrors } from '@angular/forms';
import { Observable, of, timer } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { ProductService } from '../services/product';

export function uniqueProductNameValidator(
  productService: ProductService,
): AsyncValidatorFn {
  return (control: AbstractControl): Observable<ValidationErrors | null> => {
    const name = (control.value ?? '').trim();
    if (!name) return of(null);                            // vuoto → required pensa al resto

    return timer(400).pipe(                                // debounce: aspetto 400 ms prima di chiamare
      switchMap(() => productService.getProducts()),       // chiamata HTTP vera
      map(products => products.some(p => p.name.toLowerCase() === name.toLowerCase())
        ? { nameTaken: { name } }
        : null),
      catchError(() => of(null)),                          // errore di rete → non blocchiamo
    );
  };
}
```

C'è molto da raccontare in poche righe. Il `timer(400)` non è ornamentale: è il *debounce manuale*. Se non lo metteste, Angular invocherebbe il validator ad ogni tasto premuto, e il vostro `ProductService.getProducts()` partirebbe una volta per "M", una per "Ma", una per "Mac", una per "Mac ". Quaranta chiamate per scrivere "Macbook Pro". Con `timer(400)`, l'utente deve smettere di scrivere per 400 millisecondi prima che la chiamata parta — e se nel frattempo digita di nuovo, lo `switchMap` *cancella* la chiamata precedente e ne avvia una nuova. È il pattern canonico di RxJS per "debounce + cancellazione della richiesta superata".

Il `catchError(() => of(null))` è una scelta di design che vale la pena esplicitare in aula. Stiamo dicendo: *se la rete è giù, considero il campo valido*. È la convenzione "*fail open*". L'alternativa — "*fail closed*", restituire un errore se la chiamata fallisce — bloccherebbe l'utente per un problema che non ha causato lui. Non è una scelta universale: in un form di registrazione bancaria probabilmente vorrete fail closed. Nel nostro caso didattico — un form di catalogo prodotti — fail open è ragionevole, e soprattutto è un'opportunità per discutere in aula che *questa è una decisione*, non un dettaglio.

L'aggancio al `FormBuilder` è il punto in cui la sintassi vi sorprende la prima volta. L'array di definizione del controllo finora era `[valoreIniziale, sync-validators]`. Per gli async, c'è un **terzo slot**:

```typescript
private fb             = inject(FormBuilder);
private productService = inject(ProductService);

this.productForm = this.fb.group({
  name: [
    '',                                                  // 1° slot: valore iniziale
    [Validators.required, Validators.minLength(3)],      // 2° slot: sync validators
    [uniqueProductNameValidator(this.productService)],   // 3° slot: async validators (← nuovo)
  ],
  // … altri controlli …
});
```

Tre cose vi raccomando di portare a casa.

La prima è lo **stato `pending`**. Mentre la chiamata HTTP è in volo, il controllo non è né `valid` né `invalid`: è `pending`. È uno stato che esisteva anche prima ma che non avevate motivo di guardare. Per gli async validator diventa cruciale, perché è il momento in cui il form *non sa ancora* cosa pensare — e l'utente, se non glielo dite, non capisce perché il bottone "Invia" è ancora disabilitato. Il template tipico è:

```html
<input formControlName="name" />

@if (productForm.get('name')?.pending) {
  <small class="text-gray-500">Verifico disponibilità…</small>
}

@if (!productForm.get('name')?.pending && productForm.get('name')?.hasError('nameTaken')) {
  <small class="text-red-600">
    Il nome "{{ productForm.get('name')?.getError('nameTaken').name }}" è già usato.
  </small>
}
```

Notate la doppia condizione del secondo `@if`: prima controllate che *non* sia pending, *poi* controllate l'errore. Senza il `!pending`, ogni volta che l'utente cambia il nome vedreste un flash rosso mentre la chiamata è in volo — l'errore precedente che riappare un attimo prima che il nuovo `null` lo sostituisca. Brutto, e visivamente confonde. Mettere `!pending` davanti è gratis e fa la differenza.

La seconda cosa è una conseguenza implicita di tutto questo: **gli async validator non sono "veri" controlli di sicurezza**. Sono UX. Verificate che il nome sia disponibile come *cortesia* per l'utente, perché altrimenti scoprirebbe il conflitto solo al `POST` finale. Ma il vero controllo lo fa il server al momento del salvataggio — l'unique constraint sul database, il check transazionale del backend. Se vi affidaste solo al client, due utenti che provano a registrare lo stesso nome contemporaneamente lo otterrebbero entrambi (race condition: il client di A dice "libero", il client di B dice "libero", poi entrambi fanno `POST` e uno dei due rompe). L'async validator non sostituisce il server, lo *anticipa*.

La terza è la firma. `AsyncValidatorFn` ritorna `Observable<ValidationErrors | null>` (o `Promise`). Se avete usato gli interceptor di Mod 4 — o se ci arrivate dalla Scheda 02 G1 sugli Observable — la firma vi è familiare. È un Observable normale, e si compone con `pipe`, `switchMap`, `catchError` come tutti gli altri.

### Perché Observable e non `async/await`?

La domanda è ragionevole, soprattutto se venite dal mondo TypeScript "moderno" dove `await` è la norma. La risposta è in due punti.

Tecnicamente, Angular accetta entrambe le forme — potete ritornare una `Promise<ValidationErrors | null>` invece di un Observable, e il framework la gestisce. Ma la `Promise` non ha la *cancellazione*: se l'utente continua a digitare, la chiamata HTTP precedente parte lo stesso e arriva la sua risposta (in ritardo, ignorata, ma a costo di banda e di un round trip). Con `switchMap`, la richiesta vecchia viene *annullata* a livello di `XMLHttpRequest`. In un form a digitazione veloce su rete lenta, è la differenza tra 3 chiamate utili e 30 chiamate sprecate.

Praticamente, gli operatori RxJS (`debounceTime`, `distinctUntilChanged`, `switchMap`, `catchError`) sono *esattamente* gli strumenti pensati per questo tipo di flusso. Riscriverli con `Promise` significa reinventare il debounce con `setTimeout`, gestire la cancellazione a mano, e perdere la composizione dichiarativa. Tutto fattibile, ma è remare contro la corrente del framework.

---

## valueChanges — reagire ai cambiamenti del form

Un'ultima cosa che il base ha solo nominato e che diventa importante da qui in poi: ogni `FormControl` (e ogni `FormGroup`) espone un `valueChanges: Observable<T>` che emette ad *ogni* modifica del valore. È quello che vi serve quando un campo dipende da un altro in modo **non vincolante** — cioè non per validare, ma per ricalcolare qualcosa.

Esempio classico nel `product-form`: la categoria selezionata cambia il prezzo suggerito; o un campo "totale" si ricalcola quando cambia la quantità o l'unità. Pattern tipico:

```typescript
ngOnInit(): void {
  // … inizializzazione form …

  this.productForm.get('category')!.valueChanges
    .pipe(
      debounceTime(150),
      distinctUntilChanged(),
      takeUntilDestroyed(this.destroyRef),   // ← cruciale
    )
    .subscribe(category => {
      // ricalcolo del prezzo suggerito, filtro dipendente, ecc.
    });
}
```

Tre cose da fissare in ordine di importanza. La prima — quella che brucia in produzione e che è probabilmente il *bug numero uno* con i form reattivi — è che `valueChanges` è un Observable **infinito**: non completa mai da solo. Senza `takeUntilDestroyed(this.destroyRef)`, ogni volta che il componente viene smontato e rimontato (navigazione fra rotte, switch admin/lista, qualunque cosa rifaccia il render del form) ne nasce un nuovo subscription che non muore. Dopo cinque navigazioni avete cinque listener attivi, ciascuno con la sua closure che tiene viva la sua copia del componente. È un memory leak garantito.

La seconda è `debounceTime(150)`. Senza, ogni tasto premuto in un `<input>` text triggera il subscribe. Per la maggior parte degli `valueChanges` *non vi serve* la frequenza piena dei tasti — vi serve sapere il valore "quando si stabilizza". 150 ms è un valore ragionevole.

La terza è `distinctUntilChanged()`. Per le `<select>` o i radio button, vi capita che lo stesso valore venga "reimpostato": l'utente clicca due volte la stessa opzione, o il framework rilancia un `setValue` con il valore corrente. Senza `distinctUntilChanged`, il subscribe parte comunque; con, parte solo se il valore *è veramente cambiato*.

Tornerete su questo pattern in dettaglio nella Scheda 10 G1 (Parte B) sui side effect controllati — è lo stesso problema lì, applicato a un contesto diverso. Per i form, ricordatevi le tre righe sopra come una *unità*: difficilmente vi serve una senza le altre due.

---

## Errori comuni

I quattro che mi vedo ripetere in aula, in ordine di gravità decrescente.

**Cross-field validator messo su un singolo controllo.** Già discusso nella sezione "Perché cross-field e non un sync validator". L'errore si manifesta come un validator che "non si attiva quando dovrebbe": l'utente cambia `quantity` e l'errore su `address` non scatta, perché Angular non ricalcola la validità dei controlli che l'utente *non ha toccato*. Il fix è uno: spostarlo al livello giusto.

```typescript
// ❌ Compila ma il validator non vede quantity
address: ['', [Validators.required, detailedAddressIfHighQuantity(5, 20)]]

// ✅ Il validator vive sul gruppo, perché ha bisogno del gruppo
fb.group({...}, { validators: [detailedAddressIfHighQuantity(5, 20)] })
```

**Async validator messo nello slot dei sync.** L'array di definizione del controllo ha tre slot: valore iniziale, sync validators, async validators. Mettere un async nel secondo slot non dà errore in compilazione — TypeScript non distingue le due forme — ma a runtime Angular non gestisce il flusso `Observable`/`pending` come dovrebbe, e il template si comporta in modo strano: lo stato non passa mai per `pending`, l'errore non appare, o appare quando non dovrebbe.

```typescript
// ❌ Compila ma non funziona come ti aspetti
name: ['', [Validators.required, uniqueProductNameValidator(svc)]]

// ✅ Slot async = TERZO elemento dell'array
name: ['', [Validators.required], [uniqueProductNameValidator(svc)]]
```

**Mostrare l'errore async senza considerare il pending.** Già detto a metà scheda ma vale la pena di rimarcarlo qui fra gli errori comuni perché è quello che vi farà tornare il designer a chiedere *"perché il messaggio rosso flasha?"*.

```html
<!-- ❌ "nome già preso" lampeggia anche mentre la chiamata è in volo -->
@if (form.get('name')?.invalid) { <small>Nome già preso.</small> }

<!-- ✅ Aspetto che l'async finisca prima di leggere l'errore -->
@if (!form.get('name')?.pending && form.get('name')?.hasError('nameTaken')) {
  <small>Nome già preso.</small>
}
```

**`valueChanges.subscribe(...)` senza `takeUntilDestroyed`.** È *il* memory leak più diffuso con i form reattivi. La cosa terribile è che non vi sbatte in faccia un errore: il form funziona, il componente si smonta visivamente — ma in memoria, dietro le quinte, restano cinque, dieci, venti subscription appese ad altrettante copie del componente smontato. In dev non lo vedete; in prod, dopo un'ora di navigazione, la pagina rallenta visibilmente. Tornerete sul perché succede esattamente nella Scheda 10 G1; per oggi, la regola pratica è: *qualsiasi `subscribe()` su `valueChanges` (o su `route.params`, `route.queryParamMap`, etc.) vuole il `takeUntilDestroyed(this.destroyRef)` nel pipe*. Senza eccezioni.

---

## Cheat-sheet finale

| Cosa serve | Dove va | Esempio |
|---|---|---|
| Validator sync built-in | 2° elemento del controllo | `['', Validators.required]` |
| Validator sync custom | idem | `['', [Validators.required, forbiddenWordsValidator([...])]]` |
| Validator async | 3° elemento del controllo | `['', [Validators.required], [uniqueProductName(svc)]]` |
| Validator cross-field | opzioni di `fb.group(..., { validators })` | `fb.group({...}, { validators: [crossField(...)] })` |
| Stato pending | `control.pending` | `@if (form.get('x')?.pending) { ... }` |
| Reagire ai cambiamenti | `control.valueChanges` + `takeUntilDestroyed` | vedi sezione `valueChanges` |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`pages/checkout/checkout.page.ts`](../../progetto/product-catalog/src/app/pages/checkout/checkout.page.ts) | `FormBuilder.group()` con built-in (`required`, `email`, `minLength`), `markAllAsTouched`, `onSubmit` |
| [`pages/product-form/product-form.page.ts`](../../progetto/product-catalog/src/app/pages/product-form/product-form.page.ts) | Uso del `forbiddenWordsValidator` + `getFieldError` per messaggi mirati per chiave d'errore |
| [`validators/product.validators.ts`](../../progetto/product-catalog/src/app/validators/product.validators.ts) | Factory `ValidatorFn` — base da cui estenderemo nel mini-lab |

---

## Il filo end-to-end

Riallacciamo la metafora a una storia unica. Un utente compila un form di prodotto. Il magazziniere (Angular) lavora a tre livelli contemporaneamente: *guarda ogni campo* (i sync validator del singolo controllo dicono "nome troppo corto", "descrizione contiene 'sconto'"), *guarda il modulo intero* ogni volta che qualcosa cambia (il cross-field dice "quantità alta richiede indirizzo dettagliato"), e *alza la cornetta* quando vede un campo che richiede verifica remota (l'async chiede al backend "questo nome è libero?"). Mentre la cornetta è alzata, lo stato del controllo è `pending` — né valido né invalido — e il template lo dice all'utente con un *"Verifico disponibilità…"*. Quando la risposta arriva, lo stato si stabilizza e il bottone "Invia" diventa cliccabile.

Quando l'utente preme "Invia" e l'errore è ancora lì — perché ha ignorato i messaggi — `markAllAsTouched()` rende visibili tutti gli errori che fino a quel momento erano nascosti dal `touched: false`. Se invece il form passa, il `POST` parte verso `json-server` — e da Mod 4 in poi, un *altro casello* (l'interceptor) entra in scena: aggiunge il token, intercetta il 409 di conflitto, mostra il toast. Ma questa è la prossima storia.

---

## Prossimo: [Mini-lab — Validatori async + cross-field sul product-form](../mini-lab-form/README.md)
