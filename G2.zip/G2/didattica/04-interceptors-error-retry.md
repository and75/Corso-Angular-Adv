# 04 — Interceptors HTTP: error handling centralizzato e retry

> **Tempo:** ~45 min · **Slide:** TBD · **Blocco:** G2 Sessione 4 · 14:00–14:45 (Mod 4a)
> **Prerequisito:** [Scheda 02 G1 — Observable e RxJS Base](../../G1/didattica/02-observable-rxjs.md) (operatori `catchError`, `tap`, `retry`). Questa scheda prende quei pattern, li tira *fuori* dai servizi e li mette in un punto solo.

---

## Il problema

Nel corso base avete imparato a usare `catchError` direttamente nei servizi: la chiamata HTTP si fa con `http.get(...).pipe(catchError(err => ...))`, e nel `catchError` decidete cosa restituire al componente. Nella scheda 02 di G1 abbiamo costruito quel pattern; nei lab di Mod 1 lo abbiamo replicato in `ProductService.getProducts()` e `ProductService.getProductById()`. Funziona, è la prima cosa che si scrive.

Tornate per un attimo a guardare [`services/product.ts`](../../progetto/product-catalog/src/app/services/product.ts) del seme, e provate a leggere con occhio nuovo i tre metodi che parlano col backend:

```typescript
getProducts(): Observable<Product[]> {
  return this.http.get<Product[]>(this.API_URL).pipe(
    catchError(err => {
      console.error('Errore caricamento prodotti:', err);
      return throwError(() => new Error('Impossibile caricare i prodotti.'));
    })
  );
}

getProductById(id: string): Observable<Product> {
  return this.http.get<Product>(`${this.API_URL}/${id}`).pipe(
    catchError(() => throwError(() => new Error(`Prodotto ${id} non trovato.`)))
  );
}

addProduct(product: Omit<Product, 'id'>): Observable<Product> {
  return this.http.post<Product>(this.API_URL, product);    // nessun catchError
}
```

Cosa stride? Tre cose, ed è interessante che siano tutte vere insieme, non in alternativa. Primo: il `catchError` *si ripete* — due chiamate, due copie quasi identiche, con un messaggio diverso scritto a mano. Secondo: la terza chiamata — `addProduct` — non ha catchError per niente. Asimmetria silenziosa: nessuno se ne accorge finché non rompe in produzione. Terzo, e più sottile: quel `console.error` non serve a nessuno. L'utente finale non lo vede; il componente che voleva avvisarlo deve sottoscrivere `error` a parte e reinventare la sua UI del toast. Tutto questo lavoro è duplicato in ogni servizio, e si moltiplica per ogni metodo HTTP.

Vi capiterà di chiedervi: *e se aggiungessimo retry per i 503 momentanei?* La risposta è "sì, ma dove?". Mettendolo dentro a `getProducts` lo dimenticherete in `getProductById`. Mettendolo in entrambi lo riscrivete due volte. E per ogni nuovo servizio domani (`OrderService`, `UserService`) si ricomincia daccapo. Il problema non è scrivere un `catchError` o un `retry`: il problema è che quei pattern sono **cross-cutting** — vivono in mezzo a tutte le chiamate — ma li stiamo scrivendo *dentro* a ciascuna singolarmente. Vanno spostati fuori.

Da Angular 15 esiste la primitiva nativa che permette di farlo: gli **HTTP interceptor funzionali**. Da Angular 17 sono il modo idiomatico — le vecchie classi che implementavano `HttpInterceptor` con `HTTP_INTERCEPTORS` esistono ancora per retrocompatibilità, ma in un progetto del 2026 sono semplicemente storia.

---

## Dal `catchError` per-servizio al casello

Cambiate scenario per un attimo. Immaginate l'autostrada con la fila dei caselli all'entrata di una grande città. Ogni macchina che entra li attraversa **in ordine**: il primo controlla il biglietto, il secondo registra l'ingresso nel log centrale, il terzo — se è il caso — fa girare la macchina e la rimanda indietro. La macchina non sa che i caselli esistono; ogni casello non sa cosa fa quello prima o quello dopo. Ognuno ha un solo mestiere semplice, e nessuna macchina può saltare la fila.

È esattamente quello che vogliamo per le chiamate HTTP. Un HTTP interceptor è un casello sulla strada che porta da `HttpClient` al server (e indietro). Ogni richiesta in andata e ogni risposta in ritorno lo attraversa. La firma in Angular 21 è una funzione pura:

```typescript
import { HttpInterceptorFn } from '@angular/common/http';

export const loggingInterceptor: HttpInterceptorFn = (req, next) => {
  // il casello legge la macchina che passa
  console.log('[HTTP] →', req.method, req.url);
  // e la riconsegna al casello successivo (next), così la fila prosegue
  return next(req);
};
```

`req` è la macchina, `next` è il prossimo casello (o, se siete l'ultimo, l'`HttpClient` vero che fa la chiamata di rete). `next(req)` restituisce un `Observable<HttpEvent>`: se non lo restituite, la macchina resta ferma al casello — la chiamata HTTP non parte mai. È l'errore numero uno di chi inizia.

Tre proprietà di questo casello vale la pena fissarle adesso, perché torneranno in tutto il resto della scheda. **È bidirezionale**: modificate `req` *prima* di chiamare `next` se volete agire sulla richiesta (aggiungere headers, cambiare URL); usate `pipe(catchError, tap, retry, …)` sul risultato di `next(req)` se volete agire sulla risposta. **È funzionale**, non class-based — niente DI nel costruttore, niente provide multi:true, niente boilerplate. E `inject()` **funziona dentro**: anche se siete in una funzione, l'interceptor viene invocato in *injection context* da `HttpClient`, quindi `inject(Router)`, `inject(NotificationService)`, `inject(AuthService)` funzionano in cima al body. È esattamente questo dettaglio — che la documentazione ufficiale tende a dare per scontato — a renderli pratici da usare nel mondo reale.

---

## Registrarli: la fila dei caselli

In Angular 21 si dichiarano in `provideHttpClient` con `withInterceptors([...])`. L'array è la *fila* dei caselli, e l'ordine conta.

```typescript
// app.config.ts
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { loggingInterceptor } from './interceptors/logging.interceptor';
import { errorInterceptor }   from './interceptors/error.interceptor';
// (scheda 05) import { authInterceptor } from './interceptors/auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(
      withInterceptors([
        loggingInterceptor,   // ① logga in andata, riconsegna in ritorno
        // authInterceptor,   // ② (scheda 05) aggiunge il Bearer in andata
        errorInterceptor,     // ③ in ritorno: catch, retry, toast
      ]),
    ),
  ],
};
```

L'ordine fa una cosa *asimmetrica* fra andata e ritorno, e qui ci si inciampa la prima volta. In **andata** (request) l'array si percorre dall'alto in basso: prima `logging`, poi `auth`, poi `error`. Quando `errorInterceptor` chiama `next(req)`, la richiesta esce davvero verso la rete. In **ritorno** (response/error) i `pipe` si srotolano dall'interno verso l'esterno — *a partire da chi ha chiamato `next` per ultimo*. Quindi se `error` ha messo un `catchError` sul suo `next(req)`, lo vede *prima* di chiunque a monte.

Vi capiterà di scoprire questo dettaglio nel modo doloroso: invertendo l'ordine fra auth ed error, vi accorgerete che il **retry parte senza Bearer**. La sequenza è esattamente questa — in andata invertita `errorInterceptor` vede la richiesta nuda, `authInterceptor` aggiunge il Bearer, la rete fallisce con 503. In ritorno, il `pipe` di `errorInterceptor` si srotola per primo e fa `retry`: la richiesta che ritenta è quella che `errorInterceptor` ha visto *in andata*, cioè quella senza il Bearer. Sintomo subdolissimo: la prima chiamata di una sessione fresca riesce, il retry no. Tenete questo "auth prima, error dopo" come regola: torneremo a sbatterci contro in scheda 05.

---

## Clonare la richiesta — il primo riflesso

`HttpRequest` è **immutabile**. Per cambiarla si fa `req.clone()` passando le modifiche; il metodo restituisce una *nuova* `HttpRequest` con le modifiche applicate. L'originale resta intatta.

```typescript
const cloned = req.clone({
  setHeaders: { 'X-Client-Version': '21.2.0' },  // aggiunge/sovrascrive headers
  url: req.url.replace('http://', 'https://'),   // riscrive l'URL
});
return next(cloned);   // ⚠️ passare il clone, non l'originale
```

Il passaggio cruciale — quello che brucia i pomeriggi — è "passare il clone a `next`". Se distrazione → `return next(req)`, la richiesta originale prosegue come se non aveste mai fatto il `clone`. Sintomo: i vostri headers non arrivano al server, e non capite perché. È invisibile a colpo d'occhio perché il codice "sembra giusto"; lo vedete solo aprendo Network in DevTools e accorgendovi che l'header non c'è.

Useremo davvero `clone` in scheda 05 per il Bearer (`setHeaders: { Authorization: 'Bearer ' + token }`). Qui basta che vi resti in testa la regola: la richiesta è immutabile, si rimpiazza con il suo clone.

---

## Error interceptor — il "perché" di oggi

Eccoci al casello che giustifica il modulo. L'idea: invece di ripetere `catchError` in ogni metodo del servizio, lo facciamo *una volta sola* in un interceptor che vede passare tutte le risposte. Quando ne arriva una in errore, mappiamo lo status a un messaggio leggibile e lo spingiamo nel `NotificationService` — quello che il Lab 2 di Mod 1 ha messo in piedi proprio per centralizzare i toast.

```typescript
// interceptors/error.interceptor.ts
import { inject } from '@angular/core';
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { NotificationService } from '../services/notification.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  // ① inject in cima al body — qui c'è injection context perché HttpClient
  //    ha invocato il casello "ufficialmente"; dentro al catchError no.
  const notifications = inject(NotificationService);

  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      const message = mapStatusToMessage(err);
      notifications.error(message);
      // ⚠️ Rilanciare SEMPRE: a valle c'è chi voleva sapere com'è andata.
      return throwError(() => err);
    }),
  );
};

function mapStatusToMessage(err: HttpErrorResponse): string {
  if (err.status === 0)   return 'Server non raggiungibile. Controlla la connessione.';
  if (err.status === 404) return 'Risorsa non trovata.';
  if (err.status === 409) return 'Conflitto: la risorsa è già stata modificata.';
  if (err.status >= 500)  return 'Errore del server. Riprova tra qualche istante.';
  return 'Si è verificato un errore. Riprova.';
}
```

Vi indicherei tre dettagli, perché sono i tre "perché" che giustificano *questa* forma e non altre. Il primo è il `throwError(() => err)` finale. Se al posto del rethrow metteste `return of(null)` o `return EMPTY` — tentazione comune perché "ho già notificato l'utente, mi basta" — il toast comparirebbe correttamente, ma il componente che era in stato `isLoading = true` in attesa della risposta non saprebbe mai che la chiamata è fallita. Lo spinner gira in eterno. *Centralizzare la notifica* dell'errore non significa *sopprimerlo*: il componente decide ancora cosa fare in proprio (mostrare uno stato di errore, riprovare, mostrare un fallback). L'interceptor gli evita di reinventare la UI del messaggio — non di sapere com'è andata.

Il secondo è l'`inject` invece del costruttore. Siete dentro a una funzione, non a una classe. Le dipendenze (`NotificationService`, e in scheda 05 anche `AuthService` e `Router`) si prendono con `inject()` chiamato in cima al body, e basta. È quello che permette di scrivere interceptor che parlano col resto dell'app senza dover dichiarare provider esoterici. Attenzione però: `inject()` *deve* stare in cima al body — chiamato dentro al `catchError` o al `pipe` perde il contesto e Angular vi sbatte fuori con un errore esplicito.

Il terzo è dove vive `mapStatusToMessage`. È esattamente quel codice che oggi è duplicato dentro ai vari `catchError` di `ProductService`, scritto in modo leggermente diverso ogni volta. Mettendolo qui, quando domani aggiungete un `OrderService` o un `UserService`, il pattern di notifica è già pronto: non scrivete nemmeno una riga in più.

Una conseguenza pratica e liberatoria: dopo aver registrato `errorInterceptor`, i `catchError` "difensivi" dentro a `ProductService` diventano puro rumore — dicono "trasforma un errore in un altro errore che il componente non userà". Si possono togliere, e il servizio torna a fare un solo mestiere:

```typescript
// product.ts dopo il giro di interceptor (Lab 4)
getProducts(): Observable<Product[]> {
  return this.http.get<Product[]>(this.API_URL);   // niente catchError qui
}
```

L'asimmetria fra `getProducts` (con catchError) e `addProduct` (senza) sparisce per costruzione. Se domani `addProduct` fallisce, il toast esce uguale a quello di `getProducts`.

---

## Retry mirato

`retry` è uno degli operatori più *facili da abusare*. Spiegato in due righe: prende un Observable che ha fallito, lo risottoscrive per ritentare; se il retry riesce, il risultato finale è "successo dopo N tentativi". La forma in Angular 21:

```typescript
import { retry, timer, throwError } from 'rxjs';

return next(req).pipe(
  retry({ count: 2, delay: 500 }),    // ritenta fino a 2 volte con 500 ms di pausa
  catchError(err => { /* ... */ }),
);
```

La domanda interessante non è "come si scrive": è **quando lo metto e quando no**. Vi indico tre regole, perché sono quelle che rifate sempre e da cui dipende se il vostro retry è una rete di sicurezza o un problema in più.

Solo su richieste **idempotenti**. GET sì; POST e PUT, no, di default. Una `POST /orders` ritentata dopo una rete instabile può creare due ordini se il primo è arrivato al server e la *risposta* si è persa per strada — il server non sa che state ritentando per quel motivo. Se proprio servisse, va affiancata da una idempotency key lato server. Il default del lab: ritento solo se `req.method === 'GET'`.

Solo su errori **ritentabili**. Un 503 e un 504 sono candidati credibili: il server era momentaneamente sotto. Un 401 o un 403 no: il retry non cambia il fatto che il token è scaduto o che non avete i permessi. Un 404 nemmeno: la risorsa non esiste, riprovare non la fa nascere. Il filtro non è il `delay` — il filtro che conta è *se* ritentare.

E **mai infinito**. `retry({ count: 2 })` perché due tentativi extra coprono il 95 % dei picchi di rete. Senza `count`, rischiate un loop che intasa l'utente e il server, e che resta invisibile lato client — la pagina sembra solo lenta.

Implementazione tipica, dentro all'`errorInterceptor`:

```typescript
return next(req).pipe(
  // ① retry: solo GET, solo per errori 5xx/0 (rete giù).
  retry({
    count: 2,
    delay: (err: HttpErrorResponse) => {
      const ritentabile = req.method === 'GET' && (err.status === 0 || err.status >= 500);
      if (!ritentabile) {
        // ⚠️ throwError DENTRO al delay: spegne il retry e fa proseguire l'errore al catchError.
        return throwError(() => err);
      }
      return timer(500);   // delay vero
    },
  }),
  // ② catchError dopo retry: arriva qui solo se tutti i tentativi sono falliti.
  catchError((err: HttpErrorResponse) => {
    notifications.error(mapStatusToMessage(err));
    return throwError(() => err);
  }),
);
```

Il dettaglio non ovvio — quello che alla lavagna disegnerei sempre — è il `delay` come **funzione**, non come numero. Quando passate una funzione, `retry` la invoca con l'errore corrente, e voi decidete cosa restituire: un `Observable` che ritenta (tipicamente `timer(500)`), oppure un `throwError(() => err)` per arrendersi. È così che si fa il "retry condizionato" senza scrivere un proprio operatore custom — e il `throwError` dentro al `delay` non è un `throw` sincrono, è un Observable che emette un errore, ed è proprio per questo che `retry` lo interpreta come "non ritentare". Spiegare la differenza fra `throw` e `throwError(() => err)` agli studenti che vengono dal Promise/async è metà del lavoro su RxJS in questo punto.

---

## Quando però terreste il `catchError` nel servizio

Lo studente esperto, lette le pagine sopra, può legittimamente chiedere: *"se l'interceptor centralizza tutto, devo ancora scrivere catchError nei miei servizi?"*. La risposta onesta non è "*butta tutto via*". È una **divisione dei compiti**:

| Caso | Dove va la gestione |
|---|---|
| Toast generico al fallire di una HTTP qualsiasi | nell'`errorInterceptor` (è cross-cutting, non specifico) |
| Retry sulle GET con backoff | nell'`errorInterceptor` (è policy, non logica di dominio) |
| Logging centralizzato (Sentry, Datadog) | nell'`errorInterceptor` (un solo posto) |
| Trasformazione di un 404 → `Observable<null>` per il componente | nel `catchError` *del servizio* (è semantica di dominio: "se il prodotto non c'è, restituisci null") |
| Mappatura `HttpErrorResponse` → un tipo dominio (`UserNotFoundError`) | nel `catchError` *del servizio* (è incapsulamento del backend) |
| Fallback su cache locale al primo fallimento | nel servizio (l'interceptor non sa che esiste una cache) |

In sintesi: il `catchError` resta utile *quando esprime la semantica del dominio* — "questa risorsa quando non c'è, non è un errore, è null". Quando invece esprime la stessa policy che vale per tutte le chiamate (toast, retry, log) sale al casello. Non è "interceptor sì, servizio no": è "ognuno dove gli compete". Lo scoprirete sul vostro codice rifattorizzando: ogni `catchError` nei servizi che resta dopo aver introdotto l'interceptor è quasi sempre uno che *davvero* aveva senso lasciare lì.

---

## Errori comuni

### 1. Dimenticare `return` davanti a `next(req)`

```typescript
export const x: HttpInterceptorFn = (req, next) => {
  next(req);   // ❌ nessun return → l'Observable risultante è undefined
};
```

TypeScript se ne accorge (il tipo di ritorno è `Observable<HttpEvent>`), ma in mezzo a una `pipe` complessa con più rami è facile farsi sfuggire un branch. Sintomo: nessuna chiamata HTTP parte mai, nessun errore in console.

### 2. Clonare ma non passare il clone

```typescript
const cloned = req.clone({ setHeaders: { 'X-Tenant': 't1' } });
return next(req);   // ❌ passato l'originale → headers non aggiunti
```

Fix: `return next(cloned)`. Il clone è un *nuovo* oggetto: se non lo usate, è come non averlo creato.

### 3. Catturare l'errore senza rilanciare

```typescript
catchError(err => { notifications.error('...'); return of(null); })   // ❌
```

Il toast esce, ma il componente che attendeva la risposta resta in `isLoading = true` per sempre. Fix: `return throwError(() => err)` *sempre*, dopo aver notificato.

### 4. Retry su tutto

```typescript
retry({ count: 3, delay: 1000 })   // ❌ ritenta anche POST e anche 4xx
```

Sintomi: ordini doppi (POST ritentati), schermate che impiegano 5 secondi per dirvi "non autorizzato" (401 ritentato 3 volte). Fix: `delay` come funzione che filtra su `req.method` e `err.status`.

### 5. Cambiare l'ordine in `withInterceptors`

```typescript
withInterceptors([errorInterceptor, authInterceptor])   // ❌ in scheda 05
```

Il retry dell'`errorInterceptor` ripartirà *senza* Bearer. Sintomo classico: prima chiamata OK, retry KO. Fix: auth **prima** di error nell'array.

### 6. `inject()` dentro `catchError`

```typescript
catchError(err => {
  const router = inject(Router);   // ❌ "inject() can only be used within an injection context"
  ...
})
```

`inject` va in cima al body dell'interceptor, prima della `pipe`. Le dipendenze restano catturate nella closure.

### 7. Classe e `HTTP_INTERCEPTORS`

Esistono ancora classi che implementano `HttpInterceptor` e il `provide: HTTP_INTERCEPTORS, multi: true`. Funzionano, ma in un progetto Angular 21 sono storia: `inject()` è più semplice, `withInterceptors` è esplicito, e l'unica ragione per usare il vecchio modo è codice ereditato che ancora non avete migrato. In aula citateli e basta.

---

## Schema riassuntivo

```
Componente                         "Autostrada" HttpClient
──────────                         ─────────────────────────────
http.get<Product[]>(URL)
  .subscribe({...})  ─────────►   ┌─────────────────────────────┐
                                  │ logging   (req log)         │ ①
                                  ├─────────────────────────────┤
                                  │ auth      (scheda 05)        │ ②
                                  │   req.clone(+Bearer)         │
                                  ├─────────────────────────────┤
                                  │ error     (retry + catch)    │ ③
                                  │   retry({count,delay(req,e)})│
                                  │   catchError → notify        │
                                  └─────────────────────────────┘
                                            │
                                            ▼
                                     rete + json-server
                                            │
                                  ◄─── HttpResponse / HttpErrorResponse
                                  risale i pipe in ordine inverso:
                                  ③ retry?   no →   catch → toast → rethrow
                                  ② passa
                                  ① passa
                                  componente: error callback
```

| Voce | Sintassi chiave |
|---|---|
| Firma interceptor | `export const fn: HttpInterceptorFn = (req, next) => next(req)` |
| Registrazione | `provideHttpClient(withInterceptors([a, b, c]))` |
| Clonare la req | `req.clone({ setHeaders: { … }, url: … })` |
| Dipendenze | `const x = inject(MyService);` in cima al body |
| Catch + rethrow | `catchError(e => { notify(e); return throwError(() => e); })` |
| Retry mirato | `retry({ count: 2, delay: (e) => filtra ? timer(500) : throwError(() => e) })` |
| Tap di debug | `tap({ next: ev => log('ok', ev), error: e => log('ko', e) })` |

### File reali nel seme da citare in aula

| File | Cosa mostra | Note |
|---|---|---|
| [`src/app/services/product.ts`](../../progetto/product-catalog/src/app/services/product.ts) | `catchError` duplicato in `getProducts`/`getProductById`, assente in `addProduct` | È il "prima" che giustifica l'interceptor: tre metodi, tre comportamenti diversi sull'errore. |
| [`src/app/app.config.ts`](../../progetto/product-catalog/src/app/app.config.ts) | `provideHttpClient()` "nudo" | Diventerà `provideHttpClient(withInterceptors([...]))` nel Lab 4. |
| `src/app/services/notification.service.ts` (solo in `product-catalog-finale/` dopo Lab 2) | `success(msg)` / `error(msg)` + `BehaviorSubject` dei toast (vedi Scheda 11 G1) | È il consumer dell'`errorInterceptor`: il toast esce in alto a destra, nessuno scrive HTML d'errore nei componenti. |

---

## Prossimo: [05 — Autenticazione token-based via interceptor](./05-auth-jwt-refresh.md)
