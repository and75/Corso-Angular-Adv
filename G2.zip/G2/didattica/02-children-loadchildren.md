# 02 — Feature areas, children routing, `loadChildren`

> **Tempo:** ~45 min · **Slide:** TBD · **Blocco:** G2 Sessione 2 · 10:45–11:30 (Mod 3a)
> **Prerequisito:** [Scheda 04 G1 — Routing SPA con `provideRouter`](../../G1/didattica/04-routing-spa.md). Qui non rifacciamo il routing da zero: lo *estendiamo* dalla forma "flat" a quella "per aree", che è la forma con cui vive il 99% delle app Angular reali oltre le tre rotte.

---

## Il problema

Nella Scheda 04 G1 avete imparato il routing standalone moderno: `provideRouter(routes)` in `app.config.ts`, un `<router-outlet />` in `app.html`, e un array piatto di `Routes` dove ogni rotta cita o un `component` (eager) o un `loadComponent` (lazy del singolo componente). È lo stato attuale del seme — aprite [`app.routes.ts`](../../progetto/product-catalog/src/app/app.routes.ts) e contate: sette rotte, tutte allo stesso livello, tre delle quali lazy via `loadComponent`. La forma è chiara e funziona benissimo *finché le rotte sono una manciata*.

Vi capiterà presto di trovarvi al bivio. L'area `/admin` cresce: dalla pagina "monolitica" `Admin` del seme volete passare a una sezione vera — lista prodotti dell'admin, edit prodotto, gestione utenti, log, settings. Cinque rotte invece di una, tutte protette da `authGuard`, tutte con una sidebar comune, tutte logicamente parenti fra loro. Provate a immaginarle dentro l'`app.routes.ts` attuale: cinque entry con il `canActivate: [authGuard]` ripetuto cinque volte, nessun layout condiviso (la sidebar la dovreste replicare in ogni pagina), e cinque chunk lazy separati — uno per pagina — quando in realtà vorreste *tutta l'area* in un chunk solo, caricato la prima volta che l'utente entra in admin.

Il routing flat, a quel punto, ha smesso di aiutarvi. Vi serve un modo per *organizzare* le rotte per dominio, dedicarci una porta d'ingresso comune con la sua guardia, e tenere la planimetria del settore *in tasca al portiere* finché qualcuno non bussa. Da Angular 14 — con `provideRouter` e i functional guard — la primitiva idiomatica per farlo è una sola: **`loadChildren`**, accoppiata a una *feature area* organizzata in una cartella dedicata. È il salto che facciamo oggi, e che si porta dietro tre concetti intrecciati: la feature area come unità di codice, il `loadChildren` come meccanismo di caricamento, e il children routing come modello di composizione.

---

## Dall'appartamento open-space al palazzo con piani

Prima del codice, vi do la metafora che ci accompagna. Pensate al routing flat del seme come a un grande **appartamento open-space**: ingresso, e da lì tutte le stanze direttamente visibili — soggiorno, cucina, camera, bagno. Niente porte, niente corridoi. Per app piccole è perfetto — meno cerimoniale, tutto sotto gli occhi.

Quando l'app cresce in un'area specifica, l'open-space inizia a darvi fastidio. La parte "admin" vorrebbe essere un *piano dedicato del palazzo*: con una porta blindata all'ingresso (il guardiano controlla chi entra), un *bancone reception* con una piantina del piano (il layout component con la sidebar), e dietro al bancone una serie di stanze in cui l'utente passa via via (le children routes). E un dettaglio importante: la **planimetria di quel piano** — il file che dice *"questo piano ha queste stanze, e ognuna porta a queste sottostanze"* — non viene caricata fino al momento in cui qualcuno preme il pulsante dell'ascensore per il piano admin.

Tre figure di questa scena tornano sempre, ed è utile fissarle subito.

1. La **porta blindata con il guardiano** è la rotta padre con `canActivate`. Una sola guardia che protegge *tutto* il piano: niente da ripetere su ogni stanza.
2. Il **bancone reception con la planimetria del piano** è il *layout component* — un component Angular normale, ma con dentro un suo `<router-outlet />` distinto da quello del piano terra. Lì il portiere ti orienta, e lì cambiano i contenuti man mano che ti sposti.
3. La **planimetria del piano in tasca al portiere** è il file `admin.routes.ts` con `export default` — un `Routes[]` che il `loadChildren` scarica *quando serve*, non prima.

Con questa scena in testa, il codice diventa esecuzione di un'idea. Andiamo.

---

## `loadComponent` vs `loadChildren` — la divisione dei compiti

Conoscete già `loadComponent` dal seme: lo trovate su tre rotte di `app.routes.ts` — `checkout`, `products/new`, `products/:id`. La sua firma è semplice: una funzione che ritorna una `Promise<Type<Component>>`, e Angular tratta quella promise come il componente da montare quando la rotta matcha. È il *lazy del singolo componente*.

`loadChildren` ha la stessa idea — caricamento differito — ma a un livello di granularità più grosso: non un componente, un *array di rotte*. Il file che caricate non esporta più una classe componente, esporta un `Routes` con `export default`. E quel `Routes` può contenere a sua volta `component`, `loadComponent`, perfino altri `loadChildren` annidati.

| | `loadComponent` | `loadChildren` |
|---|---|---|
| Cosa carica | Un **singolo componente** standalone | Un **array di `Routes`** (e tutti i componenti citati al suo interno) |
| Chunk risultante | Uno per componente | Uno per *area*, di solito |
| Quando lo scegliete | Pagina singola raggiunta da una rotta isolata | Settore con più rotte coordinate (admin, settings, dashboard) |
| Forma del file caricato | `export class XPage { ... }` | `const adminRoutes: Routes = [...]; export default adminRoutes;` |

La regola pratica del corso — quella che vi indicherei di stamparvi in testa — è geometrica: *se avete almeno due rotte logicamente parenti, passate a `loadChildren` con una feature area; sotto le due rotte, `loadComponent` resta più diretto*. Non è una regola morale: `loadComponent` non è "peggio". È una questione di organizzazione — `loadComponent` per la stanza isolata, `loadChildren` per il piano.

C'è una seconda dimensione, meno ovvia, che vale la pena nominare. `loadChildren` *cambia anche la composizione*: porta con sé la possibilità di un *layout component* sopra le children, di un `canActivate` a livello di area, di rotte fra loro relative. Sono cose che con tre `loadComponent` indipendenti non avete — o le avete a costo di ripetervi tre volte. Quando vi chiederete *"qui mi basta `loadComponent` ripetuto o mi serve una feature area?"*, la domanda da farsi è: *queste tre rotte vorrebbero condividere qualcosa* (una guardia, un layout, un prefisso semantico) *o stanno bene ciascuna per conto suo?* Se la risposta è la prima, è ora di un'area.

---

## La feature area: una cartella, una planimetria

L'area in Angular è una **convenzione organizzativa**: nessun decoratore, nessuna API. È *come scegliete di sistemare i file* in una cartella dedicata, di solito sotto `features/`. La struttura target del Lab 3 — quella che costruirete fra poco — è questa:

```
src/app/features/admin/
├── admin.routes.ts          ← default export Routes (è ciò che loadChildren carica)
├── admin-layout.ts          ← AdminLayout: shell con sidebar + <router-outlet />
├── admin-layout.html
└── pages/
    ├── admin-list.ts        ← lista prodotti dell'area admin (con filtri querystring)
    ├── admin-list.html
    └── product-form-page.ts ← riuso o wrapper di pages/product-form esistente
```

Non c'è niente di magico in `features/admin/`. Avreste potuto chiamarla `modules/admin/`, `areas/admin/`, `admin/` direttamente. Quello che conta è che *tutto ciò che riguarda l'admin viva in un solo posto*, che il file di rotte si chiami in modo prevedibile (`admin.routes.ts`), e che dall'esterno il resto dell'app non sappia nulla dei dettagli interni — vi parli solo attraverso il `loadChildren`. È *l'incapsulamento per cartella*, l'unico tipo di incapsulamento che Angular vi offre nativamente a questo livello.

### La planimetria del piano: `admin.routes.ts`

Questo è il cuore di tutto. Il file di rotte dell'area è un normale `Routes`, con due caratteristiche specifiche: il **default export** (richiesto dal `loadChildren`) e una **rotta padre vuota** che fa da contenitore al layout e alle children.

```typescript
// src/app/features/admin/admin.routes.ts — pattern del Lab 3
import { Routes } from '@angular/router';
import { AdminLayout } from './admin-layout';
import { AdminList } from './pages/admin-list';
import { authGuard } from '../../auth-guard';
import { ProductFormPage } from '../../pages/product-form/product-form.page';

const adminRoutes: Routes = [
  {
    path: '',                         // ← rotta padre RELATIVA al prefisso del loadChildren
    component: AdminLayout,           // ← bancone reception con <router-outlet /> dietro
    canActivate: [authGuard],         // ← guardia all'ingresso del PIANO, vale per tutte le stanze
    children: [
      { path: '',                   pathMatch: 'full', redirectTo: 'products' },
      { path: 'products',           component: AdminList },
      { path: 'products/:id/edit',  component: ProductFormPage },
      // … altre stanze del piano …
    ],
  },
];

export default adminRoutes;          // ← obbligatorio per loadChildren
```

Tre dettagli sono critici e meritano un paragrafo ciascuno.

L'**`export default`** non è una scelta stilistica: è la firma stessa di `loadChildren`. Quando scrivete `loadChildren: () => import('./admin.routes').then(m => m.default)`, state dicendo ad Angular *"prendi il default export di quel modulo, è il mio `Routes`"*. Senza il `default`, ottenete un errore a runtime al primo navigate sull'area — un `Cannot read properties of undefined` che è il classico sintomo della rotta caricata ma vuota. Si può aggirare esportando con un nome (`export const adminRoutes`) e leggendolo via `.then(m => m.adminRoutes)`, ma la convenzione del 2026 è il `default`, ed è quella che vi rende uno stile coerente con tutta la documentazione e la community.

Il **`path: ''` della rotta padre** è il punto in cui la planimetria del piano si aggancia all'edificio. È *relativo* al prefisso usato dal `loadChildren`: se nel router principale scrivete `{ path: 'admin', loadChildren: ... }`, allora dentro `admin.routes.ts` il `path: ''` corrisponde a `/admin` *esatto*. Da lì in giù i children si compongono per concatenazione: `path: 'products'` qui sotto diventa `/admin/products` nell'URL finale. È esattamente come gli URL relativi in HTML — la base la sceglie chi vi monta, voi descrivete la parte interna.

Il **`canActivate` sulla rotta padre** è la guardia all'ingresso del piano, non sulle singole stanze. Angular eredita automaticamente i guard del padre su tutti i `children`: una sola riga di `canActivate: [authGuard]` protegge l'intero sottoalbero. È il primo *guadagno organizzativo* concreto che la feature area vi porta, e da solo basterebbe a giustificarla. Confrontatelo con la situazione attuale del seme, dove `authGuard` è ripetuto su `path: 'admin'` e su `path: 'products/new'` — due punti separati che potrebbero benissimo divergere in futuro per dimenticanza.

### L'aggancio nel router principale

Nel file principale `app.routes.ts` la rotta `admin` cambia natura: da rotta eager con un componente diventa rotta lazy che delega tutto alla planimetria del piano.

```typescript
// src/app/app.routes.ts — modifica del Lab 3
export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home',  component: HomePage },
  { path: 'login', component: Login },

  // ✅ La rotta admin diventa lazy: il piano si carica solo al primo accesso
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then(m => m.default),
  },

  // … resto invariato (checkout, products/new, products/:id) …
];
```

Notate cosa è *sparito*: il `canActivate: [authGuard]` non è più qui, perché vive *dentro* `admin.routes.ts`. Anche `component: Admin` è andato — la pagina monolitica è stata smontata in layout + children. Quello che resta nel router principale è una sola riga che dice *"per `/admin` e tutto ciò che ci sta sotto, chiedi alla planimetria della feature"*. È l'inversione di responsabilità che cercavate.

Proviamo a raccontare cosa succede a runtime quando l'utente naviga `/admin/products?q=mac`. Il router del piano terra matcha il prefisso `/admin` e *scarica il chunk lazy* di `admin.routes.ts` — la prima volta, perché poi resta in cache. Quel chunk gli ritorna il `Routes` con la rotta padre `path: ''`. Angular vede il `canActivate: [authGuard]` e chiama la guardia: se l'utente non è loggato, redirect a `/login`; se passa, monta `AdminLayout`. Dentro `AdminLayout` c'è un `<router-outlet />` — il router prosegue il match guardando le `children`, trova `path: 'products'` che corrisponde al segmento rimasto, e monta `AdminList` dentro l'outlet del layout. Il `?q=mac` resta disponibile per `AdminList` via `route.queryParamMap`.

Tutto questo accade senza che il router principale sappia niente delle stanze interne del piano admin. Esattamente l'incapsulamento che cercavate.

---

## Children routing: il bancone reception e la stanza dietro

La rotta padre con `component: AdminLayout` + `children: [...]` è il pattern centrale di tutto il routing avanzato Angular. Il *layout component* è un component normalissimo — `@Component`, `templateUrl`, niente di speciale — ma il suo template contiene *due* cose: la struttura comune del piano (sidebar, breadcrumb, header dell'area) e **un `<router-outlet />` interno** dove Angular monta le children.

```html
<!-- src/app/features/admin/admin-layout.html — anteprima del Lab 3 -->
<div class="grid grid-cols-[200px_1fr] min-h-[calc(100vh-64px)]">

  <!-- Sidebar del piano admin -->
  <aside class="bg-gray-50 border-r p-4">
    <h2 class="font-bold text-sm uppercase text-gray-500 mb-4">Admin</h2>
    <nav class="flex flex-col gap-2">
      <a routerLink="products"  routerLinkActive="bg-teal-100">Prodotti</a>
      <a routerLink="users"     routerLinkActive="bg-teal-100">Utenti</a>
      <a routerLink="settings"  routerLinkActive="bg-teal-100">Impostazioni</a>
    </nav>
  </aside>

  <!-- ← qui dentro Angular monta le stanze del piano -->
  <main class="p-6">
    <router-outlet />
  </main>

</div>
```

Tre cose meritano di essere fissate qui — e sono le tre che, se le saltate, vi torneranno indietro come bug.

Il `<router-outlet />` dentro al layout è **un'altra cosa** rispetto a quello in `app.html`. Sono due outlet distinti, a due livelli diversi della gerarchia. Il primo (in `app.html`) è il *piano terra* — dentro ci finiscono le rotte di primo livello, incluso `AdminLayout` quando navigate `/admin`. Il secondo (in `admin-layout.html`) è il *bancone del piano admin* — dentro ci finiscono le children. Angular li gestisce in cascata: quando navigate `/admin/products`, mette `AdminLayout` nel primo outlet e *poi* mette `AdminList` nel secondo. Se il secondo outlet vi sfugge dal layout, il primo continua a funzionare — vedete la sidebar — ma le children non hanno dove andare e *non vedete niente al posto del contenuto*. Sintomo classico: "il layout admin si vede ma le pagine interne no". Il fix è uno.

I `routerLink` nel layout sono **relativi** alla rotta padre. Scrivete `routerLink="products"` senza slash iniziale, e Angular naviga a `/admin/products`. Se invece scriveste `routerLink="/products"` (con slash), Angular interpreterebbe il path come *assoluto* — uscireste dal piano admin e finireste su una rotta `/products` di primo livello, che probabilmente non esiste. È una distinzione sottile che il base aveva nominato ma che qui diventa critica: dentro a una feature area, *quasi tutti i `routerLink` sono relativi*. Vi indicherei di prenderla come regola di default, e di passare ad assoluti solo quando *davvero* vi serve uscire dall'area (es. tornare alla home dal layout admin).

`routerLinkActive` continua a funzionare uguale: si attiva quando il link corrente *fa parte* dell'URL attivo. Non c'è niente di speciale per le aree — è una buona notizia, perché se fosse stato diverso ve lo avrei dovuto raccontare.

### Le rotte relative dentro alle children

```typescript
children: [
  { path: '',                   pathMatch: 'full', redirectTo: 'products' },
  { path: 'products',           component: AdminList },
  { path: 'products/:id/edit',  component: ProductFormPage },
],
```

Tre dettagli pratici, in ordine di importanza decrescente.

Il `redirectTo: 'products'` *senza* slash iniziale è la forma corretta. Risolve il problema di *cosa mostrare quando l'utente naviga `/admin` esatto* — senza il redirect, il layout apparirebbe ma il `<router-outlet />` interno resterebbe vuoto, perché nessuna children matcha la stringa vuota. Con `pathMatch: 'full'` dite ad Angular che il redirect deve scattare *solo* quando il path è esattamente vuoto (senza, scatterebbe per qualunque path che inizia con la stringa vuota, cioè tutti — un loop infinito). Lo slash mancante è cruciale: con `/products` redirigereste a un path *assoluto*, uscendo dall'area; senza, redirigete *all'interno*, a `/admin/products`. Il dettaglio dei dettagli — ma vi capiterà di rincorrere il bug per dieci minuti se ve lo dimenticate.

I `path` delle children sono **relativi** al padre — `'products'` qui dentro significa `/admin/products` quando appare nell'URL. È la stessa logica dei `routerLink`: il padre fissa il prefisso, voi descrivete il segmento. Mai aggiungere uno slash iniziale a un path interno: lo slash trasformerebbe il path in assoluto e Angular vi darebbe un errore in compilazione (o, peggio, un match silenziosamente sbagliato).

Le guard sul padre si applicano a *tutto il sottoalbero*. Niente da ripetere sui children. È l'altro guadagno organizzativo dell'area, e diventa palpabile quando aggiungete una sesta children: zero riga di guard in più.

---

## Querystring: il foglietto degli appunti attaccato al modulo

Andiamo all'ultimo concetto della scheda — e probabilmente quello in cui vi imbatterete più spesso nei lab successivi. C'è una distinzione semantica che il routing avanzato vi obbliga a fare in modo netto: ci sono dati che identificano *cosa state guardando*, e dati che descrivono *come lo state guardando*.

Riprendo la metafora del piano. Il **parametro di rotta** (`:id` in `products/:id/edit`) è l'**indirizzo della stanza**: senza, la stanza non esiste — `/admin/products/edit` da solo non porta da nessuna parte, manca l'id del prodotto. È *identità*. La **querystring** (`?q=mac&page=2`) è invece il *foglietto di appunti che vi attaccate al modulo che state compilando*: filtri di ricerca, paginazione, ordinamento. Lo stato della *vista*. Se togliete il foglietto, la stanza esiste comunque — solo, la lista non è filtrata. La stessa rotta `/admin/products`, con o senza `?q=mac`, è la stessa stanza vista in due modi.

Questa distinzione è semantica, non sintattica — Angular non vi impedisce di mettere un id in querystring o un filtro come param di rotta. Ma le convenzioni di tutta la community web (e di Angular nella sua documentazione) seguono la regola sopra, ed è quella che vi indicherei di adottare senza esitazione: *identità nella rotta, stato della vista in querystring*. Vi capiterà di vedere codebase che la violano, e quasi sempre quei codebase hanno bug sottili di refresh, di link condivisibili che non funzionano, di back del browser che si comporta in modo strano.

### Leggere la querystring in modo reattivo

```typescript
// admin-list.ts — pattern del Lab 3
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-admin-list',
  standalone: true,
  templateUrl: './admin-list.html',
})
export class AdminList {
  private route      = inject(ActivatedRoute);
  private router     = inject(Router);
  private destroyRef = inject(DestroyRef);

  readonly q    = signal('');
  readonly page = signal(1);

  constructor() {
    // queryParamMap è un Observable: emette al primo render + ad ogni cambio querystring
    this.route.queryParamMap
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        this.q.set(params.get('q') ?? '');
        this.page.set(Number(params.get('page') ?? '1'));
      });
  }

  onSearch(value: string): void {
    // queryParamsHandling: 'merge' → conserva gli ALTRI param (es. page),
    // aggiornando solo quello passato. Senza, il navigate li azzererebbe.
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { q: value, page: 1 },   // reset page quando cambia la ricerca
      queryParamsHandling: 'merge',
    });
  }

  nextPage(): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { page: this.page() + 1 },
      queryParamsHandling: 'merge',
    });
  }
}
```

Una cosa per volta. `route.queryParamMap` è un **Observable** — emette ogni volta che la querystring cambia, e *anche al primo render* con i valori iniziali. È il pattern reattivo: ogni cambio dell'URL si traduce in un'emissione, che alimenta i due signal locali (`q` e `page`), che a loro volta guidano il template. L'URL diventa la *fonte di verità* dello stato vista — l'utente cambia la ricerca, l'URL cambia, l'Observable emette, i signal si aggiornano, il template si ridisegna. Da fuori sembra magico; in realtà è una catena di causa-effetto lineare.

Il `takeUntilDestroyed(this.destroyRef)` è lo stesso pattern che avete visto nella [Scheda 01](./01-reactive-forms-ripasso.md) per `valueChanges`: `queryParamMap` è un Observable infinito, non completa mai da solo, e senza la cleanup automatica al destroy del componente avete un memory leak garantito alla seconda navigazione. La regola è la stessa: *qualsiasi `.subscribe()` su un Observable infinito vuole `takeUntilDestroyed` nel pipe, senza eccezioni*.

`router.navigate([], { queryParams: ..., queryParamsHandling: 'merge' })` è la forma idiomatica per aggiornare la querystring *senza cambiare il path*. L'array vuoto `[]` significa *"resta dove sei"*; `queryParams` cambia i parametri passati; `queryParamsHandling: 'merge'` è il dettaglio che fa la differenza. Senza, ogni `navigate` *azzera* la querystring precedente — l'utente cambia la ricerca e perde la pagina, cambia la pagina e perde la ricerca. Con `merge`, vengono toccati solo i parametri che passate; gli altri restano dove sono.

I **vantaggi pratici** di tenere lo stato della vista in URL sono concreti e vale la pena nominarli in aula: l'utente può **bookmarkare** una ricerca specifica e ritrovarla domani, può **condividere il link** con un collega che vedrà esattamente la stessa vista, il **back del browser** ripristina lo stato precedente (la ricerca, la pagina, il sort), e il **refresh** non perde il contesto. Sono tutti effetti gratuiti del fatto che lo stato è nell'URL — replicare gli stessi comportamenti con uno stato interno (signal, BehaviorSubject) richiederebbe codice esplicito e di solito non viene fatto.

### Param di rotta vs querystring — i due ruoli affiancati

| | Param di rotta (`:id`) | Querystring (`?q=...&page=2`) |
|---|---|---|
| Esempio | `/admin/products/3/edit` | `/admin/products?q=mac&page=2` |
| Cosa rappresenta | *Identità* della risorsa | *Stato* della vista |
| Senza il valore | La rotta non matcha (404) | La rotta matcha lo stesso |
| Lettura reattiva | `route.paramMap` | `route.queryParamMap` |
| Si combinano? | Sì: `/products/3/edit?from=list` è perfettamente lecito | |

L'ultima riga merita un commento. Spesso la stessa pagina ha *entrambi*: il param di rotta identifica la risorsa (il prodotto 3), la querystring porta lo stato vista (da quale lista ci siete arrivati, che ordine c'era nella lista, etc.). Non si escludono — si combinano per ruoli diversi. La distinzione "identità/stato vista" è quella che vi guida nel decidere *dove* mettere ogni dato.

---

## La gerarchia di rotte, vista dall'alto

```
ROOT (app.routes.ts)                                   app.html
├── '' → redirect a 'home'                             <router-outlet />   ← OUTLET ROOT
├── 'home'        → HomePage                                  │
├── 'login'       → Login                                     │
├── 'admin'       → loadChildren(admin.routes)               │ /admin → AdminLayout
│                                                             │
├── 'checkout'    → loadComponent(CheckoutPage)              ▼ admin-layout.html
├── 'products/new'                                       AdminLayout (sidebar + )
├── 'products/:id'                                            <router-outlet />  ← OUTLET INTERNO
                                                                    │
                                                                    │  /admin/products → AdminList
                                                                    │  /admin/products/:id/edit → ProductFormPage
                                                                    │  /admin/users    → …
                                                                    ▼
                                                              [contenuto della children attiva]
```

Lo schema è una mappa fisica del palazzo a piani. Il piano terra è il root component, l'ascensore è la navigazione, il piano admin è la feature area, e dentro il piano admin il bancone reception (layout) ha la sua propria area servizi (outlet interno) dove i contenuti cambiano. Ogni livello di annidamento aggiunge un outlet: con due livelli si fanno *quasi tutte* le app reali, con tre si copre il resto. Tre è già un segnale che forse l'architettura sta diventando troppo profonda.

---

## Errori comuni

I cinque che mi vedo ripetere in aula, in ordine di gravità decrescente.

**`loadChildren` senza `export default`**. È l'errore numero uno, perché TypeScript non vi avvisa in compilazione — il `then(m => m.default)` accetta che `m.default` sia `undefined`, e Angular si rompe solo a runtime al primo navigate. Il sintomo è un `Cannot read properties of undefined` cripticissimo che non vi dice dove guardare.

```typescript
// admin.routes.ts
export const adminRoutes: Routes = [ ... ];    // ❌ niente default export

// app.routes.ts — esplode al primo navigate /admin
{ path: 'admin', loadChildren: () => import('./features/admin/admin.routes').then(m => m.default) }

// ✅ fix
export default adminRoutes;
```

**`<router-outlet />` interno dimenticato nel layout**. Il layout appare correttamente (sidebar visibile, header visibile), ma il contenuto delle children non c'è. È un errore che dura cinque secondi perché lo vedete subito, ma succede sempre quando state riadattando un componente esistente come layout.

```html
<!-- admin-layout.html -->
<aside>…</aside>
<main>Welcome admin</main>    <!-- ❌ niente outlet, le children non hanno dove andare -->
```

**`redirectTo` assoluto invece che relativo nelle children**. Il classico errore "sembra funzionare ma sei finito altrove". `/admin` esatto vi porta a `/products` di primo livello invece che a `/admin/products`. Se `/products` non esiste, 404; se esiste, *ancora peggio* — pensate di essere nell'admin e siete fuori.

```typescript
// ❌ assoluto: esce dall'area admin
{ path: '', pathMatch: 'full', redirectTo: '/products' }

// ✅ relativo: resta in /admin/products
{ path: '', pathMatch: 'full', redirectTo: 'products' }
```

**`routerLink` assoluto dove dovrebbe essere relativo**. Compila e *spesso* funziona, ma rende il layout fragile: se domani spostate l'area da `/admin` a `/admin-panel`, tutti i `routerLink="/admin/products"` vanno aggiornati a mano, mentre quelli relativi (`routerLink="products"`) si adattano automaticamente.

```html
<!-- ❌ Funziona oggi, fragile a refactor del prefisso -->
<a routerLink="/admin/products">Prodotti</a>

<!-- ✅ Relativo: il prefisso lo sceglie il routing, non il link -->
<a routerLink="products">Prodotti</a>
```

**`route.snapshot.queryParamMap` dove vi serve reattivo**. Lo stesso problema che il base aveva nominato per `paramMap`: lo `snapshot` vi dà *solo il valore al primo render*. Se l'utente cambia la querystring (con un `navigate` interno, o cliccando un link di paginazione), lo snapshot non si aggiorna e i vostri signal restano fermi al primo valore. Sembra un dettaglio, ma è la causa di un bug ricorrente in produzione: "i filtri non si aggiornano quando navigo tra pagine".

```typescript
// ❌ Solo la prima visita
const q = this.route.snapshot.queryParamMap.get('q');

// ✅ Reattivo
this.route.queryParamMap.subscribe(p => this.q.set(p.get('q') ?? ''));
```

**`navigate` senza `queryParamsHandling: 'merge'`**. Già discusso. L'utente cambia la ricerca e `page` sparisce dall'URL — il classico effetto collaterale silenzioso. Se l'app è semplice non lo notate; in un admin con filtri multipli, lo notate al primo bug report.

---

## Dove l'avanzato lo estende (Mod 4 — Interceptor)

L'`authGuard` che protegge l'area `/admin` oggi è, lo dicono i suoi stessi commenti, una scenografia: legge `localStorage.getItem('token')` e basta. È il placeholder didattico del corso base. Nella [Scheda 04](./04-interceptors-error-retry.md) e [Scheda 05](./05-auth-jwt-refresh.md) trasformiamo quella scenografia in qualcosa di più strutturato — `authInterceptor` che aggancia il token JWT a ogni richiesta HTTP dell'area protetta, `errorInterceptor` che intercetta il 401 e redirige a `/login` (con tanto di toast via `NotificationService`), refresh token con `switchMap`. Il routing per area che costruite oggi è la **fondazione** su cui quegli interceptor si poggiano: senza una guard a livello di area, l'utente accederebbe alle viste; senza viste organizzate per area, gli interceptor non saprebbero quali richieste arricchire o intercettare diversamente.

---

## Cheat-sheet finale

| Voce | Sintassi chiave |
|---|---|
| Default export del file di rotte | `export default adminRoutes;` |
| Aggancio lazy nel router padre | `loadChildren: () => import('./.../admin.routes').then(m => m.default)` |
| Layout con outlet interno | `component: AdminLayout` (con `<router-outlet />` dentro) + `children: [...]` |
| Guard a livello di area | `canActivate: [authGuard]` sulla rotta padre (vale per tutti i children) |
| Redirect children relativo | `{ path: '', pathMatch: 'full', redirectTo: 'products' }` (senza `/`) |
| `routerLink` relativo | `<a routerLink="products">` (senza `/`) |
| Leggere querystring reattivo | `route.queryParamMap.subscribe(p => ...)` con `takeUntilDestroyed` |
| Navigare conservando altri queryParam | `router.navigate([], { queryParams: {...}, queryParamsHandling: 'merge' })` |
| Param di rotta vs querystring | `:id` = identità · `?q=` = stato vista |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/app.routes.ts`](../../progetto/product-catalog/src/app/app.routes.ts) | Routing flat con `loadComponent` (3 rotte) — il "prima" del Lab 3 |
| [`src/app/auth-guard.ts`](../../progetto/product-catalog/src/app/auth-guard.ts) | `CanActivateFn` functional con `inject(Router)` — passerà a livello di area senza modifiche |
| [`src/app/pages/admin/admin.page.ts`](../../progetto/product-catalog/src/app/pages/admin/admin.page.ts) | La pagina admin "monolitica" attuale — diventerà l'`AdminLayout` con sidebar nel Lab 3 |

---

## Il filo end-to-end

Riallacciamo la metafora a una storia unica. L'utente clicca "Admin" nell'header dell'app. Il router vede la rotta `/admin`, va a cercare la sua definizione, e trova un `loadChildren` — *"la planimetria del piano è in tasca al portiere, va a prenderla"*. Il chunk lazy di `admin.routes.ts` viene scaricato (la prima volta, poi resta in cache), e Angular ottiene il `Routes` dell'area. La rotta padre ha un `canActivate`: la guardia controlla `localStorage` — token presente, passa. Angular monta `AdminLayout` nell'outlet del piano terra. Il layout appare con la sua sidebar e il suo `<router-outlet />` interno vuoto. Il router prosegue il match: il segmento `products` corrisponde a una children, monta `AdminList` nell'outlet del layout. La querystring `?q=mac` arriva ad `AdminList` via `queryParamMap`, che alimenta i signal `q` e `page`, che guidano il template a renderizzare i risultati filtrati.

L'utente cambia la ricerca: `navigate([], { queryParams: { q: 'pro' }, queryParamsHandling: 'merge' })`. L'URL cambia, l'Observable emette di nuovo, i signal si aggiornano, il template si ridisegna. Tutto questo *senza ricostruire il layout* — il bancone reception resta dove sta, cambia solo quello che c'è dietro. È la differenza tra un'app SPA fluida e un classico refresh — ed è esattamente quello che il routing per aree vi dà gratis.

Nella [Scheda 03](./03-outlet-annidati-named.md) prendiamo l'idea di outlet e la spingiamo a un livello in più: *due outlet attivi allo stesso tempo, sulla stessa pagina, indirizzabili indipendentemente nell'URL*. Sono i **named outlet**, e sono il pezzo che vi serve per pannelli laterali, modali bookmarkabili, anteprime affiancate.

---

## Prossimo: [03 — Outlet annidati + named outlet](./03-outlet-annidati-named.md)
