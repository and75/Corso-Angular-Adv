# 05 — Autenticazione token-based via interceptor

> **Tempo:** ~45 min · **Slide:** TBD · **Blocco:** G2 Sessione 4 · 14:45–15:30 (Mod 4b)
> **Prerequisito:** [Scheda 04 — Interceptors HTTP](./04-interceptors-error-retry.md). Qui aggiungiamo un *secondo* interceptor — fratello di quello degli errori — che si occupa dell'auth. Stesso meccanismo, contenuto diverso.

---

## Il problema

Nella scheda 04 abbiamo costruito l'`errorInterceptor`: un casello che vede passare ogni risposta HTTP e centralizza errori, retry e toast. Lo abbiamo fatto perché *quei* concern erano cross-cutting: vivevano in mezzo a tutte le chiamate, e tenerli dentro ai singoli servizi era una battaglia persa.

L'autenticazione è esattamente lo stesso tipo di problema. Tornate per un attimo a guardare il seme. Aprite [`auth-guard.ts`](../../progetto/product-catalog/src/app/auth-guard.ts) e [`pages/login/login.page.ts`](../../progetto/product-catalog/src/app/pages/login/login.page.ts) — sono il setup didattico del corso base, e raccontano una storia coerente ma di pura scenografia:

```typescript
// auth-guard.ts — il placeholder del corso base
const token = localStorage.getItem('token');
if (token) return true;
return router.createUrlTree(['/login']);

// login.page.ts — lo "stamp" del token
localStorage.setItem('token', 'demo-token');
this.router.navigate(['/admin']);
```

Funziona come dimostrazione: cliccate "Accedi", `'demo-token'` finisce in `localStorage`, la guard lo vede e vi lascia entrare. Vi capiterà di provarlo in aula nei primi 30 secondi e di scoprire — divertiti — che basta aprire DevTools, scrivere `localStorage.setItem('token','qualsiasi-cosa')`, ricaricare, e siete "admin". È un placeholder che mostra il *meccanismo* del routing, non l'auth.

Tre buchi se la guardiamo con gli occhi della scheda 04:

1. **Chiunque entra**, scrivendo a mano nello storage. La guard è soddisfatta. È un sistema di sicurezza che fa sicurezza con un suggerimento gentile.
2. **Le chiamate HTTP partono nude**: non c'è nessun `Authorization` da nessuna parte. Se il backend volesse sapere chi sta facendo la `POST /products`, non lo saprebbe — e il giro `localStorage.token → guard → navigate` non glielo direbbe mai.
3. **Non c'è differenza fra utenti**: `admin@…` e `user@…` hanno lo stesso accesso, perché non c'è il concetto di ruolo. L'area `/admin` la apre chiunque sia "loggato". Le guard rinforzano la *presenza*, non l'*identità*.

Oggi chiudiamo tutti e tre i buchi, ma con un trucco didattico esplicito che vale la pena dichiarare subito: non avendo un IdP reale, **simuliamo** l'auth interamente lato Angular su `json-server`. Il punto importante — che ripeterò di proposito alla fine, ed è probabilmente la cosa che vorrete portare a casa da questa scheda — è che *il codice Angular* che scriviamo è lo stesso che scrivereste con un backend vero. Cambia solo da dove arriva il token.

---

## Anatomia di un JWT vero (in due minuti)

Vi serve un modello mentale di che cos'è un JWT prima di costruirne uno finto. Dal 2015 i JSON Web Token sono diventati il default per le SPA: una stringa nella forma `header.payload.signature`, dove le tre parti sono base64url-encoded e separate da un punto:

```
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjMiLCJyb2xlIjoiYWRtaW4iLCJleHAiOjE3MzM4NDAwMDB9.k8wQ...
└─────── header ─────┘└──────────────── payload (claims) ────────────────┘└── signature ──┘
```

L'**header** dice quale algoritmo si è usato per firmare (`{"alg":"HS256"}`). Il **payload** contiene i *claims* — le affermazioni del server su di voi. I claims standard hanno nomi di tre lettere: `sub` (subject, l'id utente), `exp` (expiry, scadenza), `iat` (issued at). Si aggiungono claims custom: `role`, `tenant`, `email`. La **signature** è la firma HMAC/RSA del concat `header.payload` calcolata con una chiave che *solo il server conosce*. È ciò che impedisce a un client di modificare il payload — cambiare `role: "user"` in `role: "admin"` — e farsi accettare lo stesso.

La cosa più importante per la nostra storia: **il payload è leggibile da chiunque abbia il token**. Non è cifrato, è codificato. Fate `atob('eyJzdWIi...')` in console e vi torna il payload in chiaro. Quindi vale la pena ricordare due cose insieme: ✅ il client *può* leggere `role` ed `exp` dal payload per decidere cosa mostrare (es. "mostra il bottone admin solo se role === 'admin'"); ❌ il client non deve mai *fidarsi* del token oltre la UI: chi protegge le risorse è il server, che ricalcola la firma a ogni chiamata.

Tenete questo modello in testa: nei prossimi paragrafi useremo una versione di JWT *senza la firma* — solo `payload` codificato in base64. Tutto il resto resta.

---

## Perché qui un token finto e non un JWT vero

Vi capiterà di chiedervi, e ragionevolmente, *"ma perché non installiamo un IdP, o almeno un middleware che firmi JWT veri?"*. È la domanda giusta, e merita una risposta esplicita.

Il backend del progetto Product Catalog è `json-server` v0.17, scelto nel corso base perché lascia lo studente concentrato sull'Angular senza dover stare dietro a un Express. Non sa firmare niente — è una persistenza REST automatica su `db.json`. Sopra ci avevamo provato a montare `json-server-auth` (che firmava JWT veri); per come è scritto, è incompatibile con Node ≥20 e con le versioni recenti di `path-to-regexp`, e nessun downgrade ragionevole sblocca la cosa. Le alternative concrete erano:

- **Scriverci un piccolo Express** con `jsonwebtoken` che firma con una chiave statica. Realistico ma sposta 10 minuti del corso a configurare un server che non c'entra niente con Angular, e ogni minuto di setup-fragile è un minuto sottratto al modulo.
- **Usare un IdP reale tipo Keycloak o Auth0.** Stesso problema all'ennesima potenza: tira via mezza giornata, e l'aula non avrebbe i tempi per entrare nel modello mentale di interceptor + guard, che è il punto.
- **Simulare interamente lato Angular** generando un token finto `btoa(JSON.stringify({sub, role, exp}))`. Niente firma, password in chiaro nel `db.json` (è dev). Tutto il *resto* del codice Angular — `AuthService` con `login()` e `logout()`, `authInterceptor` che mette il Bearer, `errorInterceptor` che gestisce il 401, `authGuard` e `roleGuard` — resta identico parola per parola a quello che scrivereste in produzione.

Abbiamo scelto la terza, ed è la scelta giusta perché il **valore didattico** del modulo non è "come si firma un JWT" (è la parte del backend, ce ne sono mille tutorial). È **come Angular reagisce a un token** che gli viene dato. Quel codice — quello che porterete al lavoro — non cambia in funzione di chi firma il token. Si avverte esplicitamente la classe, lo si scrive a caratteri cubitali nel README del Lab 4, e si va avanti.

> **In produzione**: HTTPS obbligatorio, password mai in `db.json`, JWT firmati lato server (HS256 con secret robusto o RS256 con coppia di chiavi), refresh in cookie `HttpOnly` quando possibile, scadenze brevi per l'access token. Niente di tutto questo nel lab. Tutto il resto del codice Angular sì.

---

## Il braccialetto del festival

La metafora che vi tornerà utile per tutto il resto della scheda. Andate al festival, vi presentate alla biglietteria, mostrate il documento, pagate: vi danno un **braccialetto** colorato. Sul braccialetto c'è scritto chi siete (nome, ticket id) e di che colore è (general, vip, staff). Da quel momento:

- A ogni stand mostrate il polso. Lo stand controlla che il braccialetto sia vero (firma) e del colore giusto per quel servizio (ruolo).
- Se lo perdete tornate alla biglietteria a rifare il giro (logout → login).
- Se è scaduto, lo stand vi respinge (401) e vi rimanda alla biglietteria.
- Se avete il braccialetto general e provate a entrare nel backstage (vip-only), lo stand vi respinge (403).

Tre attori, da identificare uno a uno con il codice che andremo a scrivere. La **biglietteria** è l'`AuthService.login()`: confronta le credenziali e vi restituisce il braccialetto. Il **braccialetto stesso** è il token: piccolo, opaco, sta in tasca (`localStorage`), ve lo dà la biglietteria e voi lo riportate ovunque. Il **buttafuori che lo controlla a ogni stand** è il `authInterceptor`: davanti a ogni richiesta HTTP vi pesca dal polso il token e lo mette nell'header `Authorization`. Voi — il componente — non ve ne accorgete nemmeno.

Le due **guard** del routing sono la versione "navigazione" della stessa idea: l'`authGuard` vi lascia passare il tornello d'ingresso solo se avete il braccialetto; il `roleGuard('admin')` vi lascia passare il tornello del backstage solo se il braccialetto è del colore richiesto. Vedrete: tutta la scheda tornerà a chiamare in causa la biglietteria, il braccialetto, i buttafuori e i tornelli. Non è solo immagine — è il filo che tiene insieme il modello.

---

## La biglietteria — `AuthService`

Lo scheletro che useremo nel Lab 4. Il service è il pezzo più articolato del modulo — tiene insieme HTTP simulata, signal di stato, persistenza e ripristino al boot — ma è anche il più lineare se gli date le tre minute di lettura che merita.

```typescript
// services/auth.ts — anteprima Lab 4
import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface User { id: number; email: string; name: string; role: 'admin' | 'user'; }
interface TokenPayload { sub: number; role: User['role']; exp: number; }

const STORAGE_KEY = 'pc.token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);

  // la cella del foglio di calcolo: chi è loggato in questo momento
  private _user = signal<User | null>(null);
  readonly currentUser     = this._user.asReadonly();
  readonly isAuthenticated = computed(() => this._user() !== null);

  constructor() {
    this.restoreFromStorage();   // ⬅️ se al boot il braccialetto in tasca è ancora buono, lo rimetto
  }

  async login(email: string, password: string): Promise<User> {
    // 1) chiedo a json-server l'utente con quella email
    const found = await firstValueFrom(
      this.http.get<User[]>('http://localhost:3000/users', { params: { email } }),
    );
    const candidate = found[0] as (User & { password: string }) | undefined;

    // 2) confronto pwd lato client — è la parte simulata: in produzione lo fa il server
    if (!candidate || candidate.password !== password) {
      throw new Error('Credenziali non valide');
    }

    // 3) la biglietteria stampa il braccialetto: token finto con sub/role/exp
    const payload: TokenPayload = {
      sub: candidate.id,
      role: candidate.role,
      exp: Date.now() + 60 * 60 * 1000,   // 1 ora
    };
    const token = btoa(JSON.stringify(payload));

    // 4) braccialetto in tasca + aggiorno la cella
    localStorage.setItem(STORAGE_KEY, token);
    const { password: _, ...user } = candidate;
    this._user.set(user);
    return user;
  }

  logout(): void {
    localStorage.removeItem(STORAGE_KEY);
    this._user.set(null);
  }

  /** Letto dall'interceptor a ogni chiamata. Null se scaduto / assente / manomesso. */
  getToken(): string | null {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const payload = this.decode(raw);
    if (!payload || payload.exp < Date.now()) {
      localStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return raw;
  }

  private restoreFromStorage(): void {
    const raw = localStorage.getItem(STORAGE_KEY);
    const payload = raw ? this.decode(raw) : null;
    if (!payload || payload.exp < Date.now()) {
      localStorage.removeItem(STORAGE_KEY);
      return;
    }
    // allo F5 il payload ha solo sub/role/exp: per popolare email/name pesco
    // l'utente intero dal backend. È una scelta — discussa fra un attimo.
    this.http.get<User>(`http://localhost:3000/users/${payload.sub}`)
      .subscribe(user => this._user.set(user));
  }

  private decode(raw: string): TokenPayload | null {
    try { return JSON.parse(atob(raw)) as TokenPayload; }
    catch { return null; }   // qualcuno ha scritto a mano in localStorage: fail silently
  }
}
```

Vi indicherei quattro dettagli, perché non sono ovvi e sono quelli che la documentazione tende a dare per scontati. Il primo: **lo stato è un `signal`, non un `BehaviorSubject`**. È coerente col `ProductService` del seme e con quanto abbiamo visto nella scheda 12 di G1 — i signal sono il modo idiomatico Angular 21 per lo stato sincrono condiviso. `isAuthenticated` può essere un `computed` derivato da `_user`, e nel template potete scrivere `@if (auth.isAuthenticated())` direttamente, senza `async pipe`, senza subscribe, senza `takeUntilDestroyed`. La cella del foglio di calcolo, esattamente.

Il secondo: **`getToken()` valida ogni volta**. Sareste tentati di scrivere `getToken() { return localStorage.getItem(STORAGE_KEY); }` perché "tanto se il token è scaduto risponderà 401 il server". Vero, ma con l'auth simulata il server non risponderà *mai* 401, quindi un token scaduto resterebbe attivo all'infinito. E anche in produzione, validare client-side prima dell'invio significa risparmiare una request già condannata. La distruzione del token mal formato dentro `getToken` è un effetto collaterale voluto: rimette il sistema in uno stato coerente al primo accesso successivo, senza che nessuno chieda.

Il terzo: **`restoreFromStorage` rifa una GET**. Quando ricaricate la pagina, il signal `_user` parte a `null`. Il payload del token ha `sub` e `role`, ma non `name` né `email`. Per l'header dell'app ("Ciao Admin Demo") vi serve l'utente intero. La scelta del lab è chiamare `GET /users/<id>` al boot e ripopolare. È *una* scelta — l'alternativa è salvare l'oggetto utente intero in `localStorage` accanto al token, e ripristinarlo senza chiamata di rete. Il trade-off è fra una request in più al boot (versione GET) e un riferimento utente "fresco" dal backend (se qualcuno modifica `name` lato `db.json`, il nostro signal lo riflette). In produzione spesso si fa la versione "tutto in storage" per ridurre il time-to-interactive; in aula scegliamo la GET perché è una riga in più ma è più "vera". Sentitevi liberi di cambiarla se nel vostro contesto pesa di più l'altra direzione.

Il quarto: **`btoa(JSON.stringify(...))` non è un JWT**. Non c'è la firma, e questo lo sapete già. Quello che vale la pena notare: se domani il backend diventasse reale, dovreste decodificare un vero JWT — ma `atob` su `header.payload.signature` darebbe errore al primo `.`. La forma corretta in produzione è `JSON.parse(atob(token.split('.')[1]))` per leggere il payload (la firma è verificata lato server, non lato client). Cambia 4 righe, non l'architettura.

---

## Il buttafuori dello stand — `authInterceptor`

Il secondo casello — l'`authInterceptor` — è la parte più piccola del giro, ed è la parte che paga di più rispetto al codice scritto. Anatomia:

```typescript
// interceptors/auth.interceptor.ts — anteprima Lab 4
import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from '../services/auth';

const API_HOST   = 'http://localhost:3000';
const LOGIN_PATH = '/users';   // la GET di login NON deve avere il Bearer

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth  = inject(AuthService);
  const token = auth.getToken();

  // ① solo richieste verso la nostra API; risorse esterne (CDN, mappe, …) restano nude
  const isOurApi = req.url.startsWith(API_HOST);

  // ② la chiamata di login NON deve portare il Bearer (escluderebbe il caso "nuovo accesso")
  const isLoginCall = req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET';

  if (!token || !isOurApi || isLoginCall) {
    return next(req);
  }

  // il buttafuori pesca il braccialetto dal polso e lo aggiunge al biglietto
  const cloned = req.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
  });
  return next(cloned);
};
```

I tre filtri non sono difensivi a caso: ognuno previene un problema specifico, e vale la pena vederli uno per uno. **`isOurApi`** evita di sparare il Bearer a CDN, Google Maps, GitHub APIs, qualsiasi cosa che non sia il vostro backend. Mandare un token interno a un servizio esterno è un piccolo leak che nessuno si accorge finché non viene loggato dal terzo, e a quel punto è tardi. **`isLoginCall`** è l'escamotage che impedisce il loop sottile: la chiamata di login parte *prima* che ci sia un token (caso 1, ovvio), ma anche durante una sessione attiva qualcuno potrebbe rifare login per cambiare account (caso 2, meno ovvio). Se mettessimo il Bearer anche lì, sul `json-server` non succede niente; in un backend reale potreste ricevere un 409 "sessione già attiva" o un comportamento ancora più strano. Meglio escluderla esplicitamente. **`!token`** copre il primo render: l'app parte, l'interceptor è già attivo, ma `AuthService.currentUser()` è ancora `null` e non c'è nulla da iniettare. La GET pubblica dei prodotti deve poter partire lo stesso.

Per registrarlo, ci uniamo alla catena della scheda 04:

```typescript
// app.config.ts
provideHttpClient(
  withInterceptors([
    authInterceptor,    // ① aggiunge il Bearer in andata
    errorInterceptor,   // ② vede la risposta — se è 401, manda al logout
  ]),
)
```

L'ordine è quello: **auth prima di error**. Vi ricordate dalla scheda 04 perché — se invertissimo, il `retry({ count: 2 })` dell'`errorInterceptor` ripartirebbe *senza* Bearer (perché in andata l'`authInterceptor`, che ora viene dopo, non lo vedrebbe sul retry). Sintomo classico: la prima chiamata di una sessione fresca riesce, il retry no. È il bug più subdolo del modulo, e lo trovate scritto in ogni esempio canonico Angular della community proprio per questo.

---

## Lo stand chiuso — il 401 nel `errorInterceptor`

L'`errorInterceptor` della scheda 04 si arricchisce di un caso speciale. Quando una qualsiasi chiamata torna `401 Unauthorized`, significa "il braccialetto non è più buono, vai alla biglietteria":

```typescript
// estratto: il pezzo del 401 dentro errorInterceptor
catchError((err: HttpErrorResponse) => {
  if (err.status === 401) {
    inject(AuthService).logout();
    inject(Router).navigate(['/login'], {
      queryParams: { returnUrl: location.pathname },
    });
  } else {
    notifications.error(mapStatusToMessage(err));
  }
  return throwError(() => err);
})
```

Due "perché" giustificano questa forma. Il **`returnUrl`**: dopo il login, vorrete riportare l'utente esattamente dove stava prima di essere sloggato — è una piccola cortesia che fa la differenza fra un'app che "funziona" e un'app che si usa volentieri. Lo passiamo come query string; la `LoginPage` lo legge dopo `subscribe(login)` e fa `router.navigateByUrl(returnUrl)` se presente. Senza, l'utente sbarca su `/` e perde tutto il contesto del giro che stava facendo.

E `logout()` **prima** del redirect, non solo redirect. Se vi limitaste a `router.navigate(['/login'])` senza svuotare il token, la guard del prossimo refresh vi rivedrebbe "loggato" (il token c'è ancora) e vi rimanderebbe al dashboard, che farebbe la stessa chiamata, che riprenderebbe 401: ping-pong infinito invisibile. La regola pratica da memorizzare: **401 → svuoto, poi vado a `/login`**.

Una nota didattica importante che vi farà respirare in aula: **con un'auth simulata, il 401 non arriva mai dal server**. `json-server` risponde 200 a tutto. Per dimostrare il flusso in aula, il docente lo simula manomettendo il token in DevTools (sostituirlo con una stringa nonsense → al refresh `AuthService.decode` ritorna null → la prossima request senza Bearer atterra sul controllo lato server… che però accetta tutto). Insomma, dovrete *raccontare* il 401 più che vederlo. Lo segnaliamo qui per evitare che vi chiediate "perché non vedo mai il toast 401?".

---

## Refresh token: solo teoria, e per buoni motivi

Il pattern del refresh token va capito perché in produzione lo incontrate ovunque, ma nel Lab 4 non lo implementiamo. Vi spiego entrambe le cose.

In produzione il server emette **due** token al login. L'**access token** ha vita breve (10–15 minuti) e viene rispedito a ogni chiamata. Il **refresh token** ha vita lunga (giorni o settimane), va al server *solo* a un endpoint dedicato (`POST /auth/refresh`), e tipicamente vive in un cookie `HttpOnly` (non leggibile da JavaScript, mitiga gli XSS). Quando l'access scade, il client chiama `/auth/refresh` con il refresh, ottiene un nuovo access, riprova la chiamata fallita. Il dettaglio scomodo: se mentre il refresh è in volo arrivano altre cinque chiamate, tutte vedono il 401, e tutte chiamano il refresh? No — vanno **messe in coda** finché il refresh non risponde, e solo dopo si ritentano tutte col nuovo token. Questa coda è l'elemento che rende il refresh un esercizio di un giorno intero — non di un lab di un'ora.

Perché qui non lo facciamo:

- L'access token finto del lab dura un'ora, abbastanza per i 65 minuti del Lab 4 senza che la scadenza si veda.
- Non c'è un endpoint `/refresh` su `json-server` da cui rigenerare niente. Avremmo dovuto scriverlo dentro `AuthService` come "decodifica il vecchio token e rifirmane uno nuovo", che è una falsa lezione: in produzione il rinnovo dipende dal *server* che si fida solo del refresh in suo possesso, mai del client.
- Il valore del modulo è il **pattern** (interceptor + coda + retry), non il copione di un caso particolare. Una volta visto come si aggancia il Bearer e si gestisce il 401, fare un refresh in coda è un'estensione meccanica — una manciata di righe nell'`errorInterceptor` che intercetta il 401, fa partire il refresh, e ritenta. Lo aggiungerete il giorno in cui vi capiterà.

In aula vale la pena disegnare alla lavagna i tre attori (access, refresh, coda) e dire "questa è la to-do list del giorno in cui vi capiterà; il setup interceptor del Lab 4 è già fatto, vi serve solo aggiungere il pezzo di coda". Tanto basta a chiudere il discorso senza farne un altro modulo.

---

## Autenticazione vs autorizzazione: il `roleGuard`

Fino a qui ho usato "autenticato" e "autorizzato" quasi come sinonimi, ed è una pigrizia da correggere. **Autenticazione** è "chi sei" — il login. **Autorizzazione** è "cosa puoi fare" — siete admin? siete stagione VIP? avete pagato il backstage? In un'app con ruoli, le due cose si compongono: prima vi vedo entrare (auth), poi vi lascio fare solo le cose del vostro colore (autz). Sono questioni diverse risolte da meccanismi diversi, anche se in aula spesso si dice "guard" per entrambi.

In Angular il pattern idiomatico è una **factory di guard**: una funzione che riceve un parametro (il ruolo richiesto) e *restituisce* una `CanActivateFn`. La factory vi permette di scrivere `roleGuard('admin')` su una rotta, `roleGuard('marketing')` su un'altra, `roleGuard('staff')` su una terza — tutte la stessa funzione, parametri diversi, senza un guard distinto per ogni ruolo.

```typescript
// guards/role.guard.ts — anteprima Lab 4
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService, type User } from '../services/auth';
import { NotificationService } from '../services/notification.service';

export function roleGuard(required: User['role']): CanActivateFn {
  return (_route, _state) => {
    const auth   = inject(AuthService);
    const router = inject(Router);
    const notify = inject(NotificationService);

    const user = auth.currentUser();
    if (user?.role === required) return true;

    notify.error('Accesso negato: serve il ruolo "' + required + '".');
    return router.createUrlTree(['/']);
  };
}
```

E nella `admin.routes.ts` del Lab 3 si compone con la guard di autenticazione che già c'è:

```typescript
// features/admin/admin.routes.ts — diff Lab 4
{
  path: '',
  component: AdminLayout,
  canActivate: [authGuard, roleGuard('admin')],   // ⬅️ era solo [authGuard]
  children: [ /* … */ ],
}
```

Tre dettagli vi torneranno utili. **L'ordine in `canActivate` è AND, non OR**: tutte le guard devono ritornare `true` perché l'utente passi. Mettere `authGuard` prima fa sì che, se non siete loggati, `roleGuard` non venga nemmeno valutato — risparmiate l'iniezione di `AuthService.currentUser()` e, soprattutto, evitate il toast spurio "accesso negato" mentre l'utente non aveva nemmeno il braccialetto. È l'ordine "auth prima, autz dopo" che ritroverete in ogni codebase Angular ben strutturata.

**`roleGuard` legge il signal, non il token**. Sareste tentati: "ma il token ha già `role` nel payload, perché non leggerlo direttamente da `localStorage`?". Perché il signal è la *fonte di verità in memoria*, e `AuthService.restoreFromStorage()` lo popola al boot. Decodificare il token in due posti (`AuthService` e `roleGuard`) significa avere due algoritmi che possono divergere il giorno in cui cambierete la forma del payload. Una fonte sola, un decoder solo: regola da tenere stretta.

**Senza ruolo → redirect, non `false`**. Restituire `false` lascia l'utente sulla rotta corrente, e dal suo punto di vista "non è successo niente" (ha cliccato un link e la pagina non è cambiata). Restituire un `UrlTree` (`createUrlTree(['/'])`) lo riporta a una pagina sensata, e la spiegazione del rifiuto viaggia sul toast. È la differenza fra "blocco silenzioso" e "rifiuto comunicato": la seconda è quasi sempre quella che volete.

---

## Il film — il flusso end-to-end

Riavvolgiamo, in prosa, come lo racconterei a voce.

L'utente atterra su `/login` con il braccialetto inesistente. Compila il form e clicca. `LoginPage` chiama `AuthService.login(email, pwd)`, che fa una `GET /users?email=...` al `json-server`, riceve l'utente, confronta la password lato client, costruisce il braccialetto (`btoa(JSON.stringify({sub, role, exp}))`), lo mette in `localStorage.pc.token` e popola il signal `currentUser`. La page legge dalla query l'eventuale `returnUrl` e ci naviga; se non c'è, va su `/admin` o sul dashboard di default.

Da quel momento, ogni chiamata `HttpClient.get/post/...` attraversa l'`authInterceptor` che, se la richiesta va al backend e non è la chiamata di login, ci appende `Authorization: Bearer <token>`. Il backend (qui finto) accetta sempre; in produzione, è qui che il server validerebbe la firma e l'`exp` del token, e risponderebbe 401 se qualcosa non torna.

Quando l'utente clicca `/admin`, il router valuta nell'ordine `authGuard` (c'è il braccialetto? sì, signal popolato) e `roleGuard('admin')` (il colore è `admin`? il signal dice sì). Entra. Se fosse stato un utente `user`, il `roleGuard` avrebbe spinto un toast "Accesso negato" e fatto redirect a `/`.

In una sessione lunga, prima o poi qualcosa torna `401` — in produzione il token è scaduto, l'account è stato disabilitato, qualcuno ha invalidato la sessione dall'altro lato. L'`errorInterceptor` lo intercetta, chiama `auth.logout()` (svuota `localStorage.pc.token` e azzera il signal), e naviga a `/login?returnUrl=/admin/products/42`. Il `LoginPage` lo riprende, e dopo il prossimo login vi riporta esattamente lì. Nessun componente ha scritto una riga di questa logica: tutto vive negli interceptor + nel signal di `AuthService`.

L'utente fa F5. `AuthService` parte, il costruttore chiama `restoreFromStorage`: trova il token, lo decodifica, verifica `exp`, ricarica l'utente da `GET /users/<id>` e ripopola il signal. La sessione è sopravvissuta al refresh, l'app si è ridipinta sullo stato corretto, la guard non si è accorta di niente. Il braccialetto era in tasca, e la biglietteria al boot lo riconosce.

---

## Errori comuni

### 1. Mettere il Bearer alla chiamata di login

Senza il check `isLoginCall`: il login da sloggato funziona (nessun token), ma il login da utente già loggato che cambia account fa partire la GET con `Bearer <vecchio token>`. Su `json-server` invisibile; su backend reali un 409 "sessione già attiva". Fix: aggiungere il check come nel pattern.

### 2. Leggere il token nel costruttore del service

```typescript
constructor() {
  const token = localStorage.getItem('pc.token');
  this._user.set(token ? JSON.parse(atob(token)) : null);   // ❌
}
```

Due bug nello stesso pezzo: `JSON.parse(atob(token))` vi dà il *payload* (`{sub, role, exp}`), non l'utente intero (manca `email`, `name`). E non c'è validazione di `exp`. Fix: una funzione `restoreFromStorage()` che decodifica, valida la scadenza, e popola via `GET /users/<id>`.

### 3. `logout` solo navigando

```typescript
catchError((err) => {
  if (err.status === 401) router.navigate(['/login']);   // ❌ niente auth.logout() prima
  return throwError(() => err);
})
```

Senza `auth.logout()` il token resta in `localStorage`. Loop infinito. Fix: prima `logout()`, poi `navigate`.

### 4. `roleGuard` come `CanActivateFn` diretta

```typescript
export const adminGuard: CanActivateFn = (route, state) => {
  return inject(AuthService).currentUser()?.role === 'admin';   // ❌
};
```

Funziona, ma se domani arriva un'area `/marketing` con ruolo `'marketing'`, scrivete `marketingGuard` clone con un parametro hardcoded. Fix: factory `roleGuard(role): CanActivateFn`, una sola funzione parametrica.

### 5. Decodificare il JWT manualmente in due posti

`authInterceptor` e `roleGuard` che fanno entrambi `JSON.parse(atob(...))` invece di chiedere a `AuthService.getToken()` / `AuthService.currentUser()`. Il giorno in cui cambia la forma del payload, dovete cambiare due posti. Fix: tutto centralizzato in `AuthService`, gli altri lo chiedono via interfaccia.

### 6. Salvare il refresh token in `localStorage`

Il giorno in cui userete il refresh, **non mettetelo in `localStorage`**: è leggibile da qualsiasi script XSS-iniettato e gli si dà accesso "lungo" a tutta la sessione. Va in cookie `HttpOnly` lato server, oppure — se proprio non è possibile — nello storage solo del tab corrente con piena consapevolezza. È un consiglio fuori scope per il lab ma vale la pena dirlo: gli studenti se lo trovano davanti il giorno dopo.

---

## Schema riassuntivo

```
LOGIN                                CHIAMATA HTTP qualsiasi                     401 / refresh
─────                                ────────────────────────                     ──────────────
LoginPage                            componente.http.get(...)                    componente.subscribe
  ↓ form valid                                ↓                                          ↑ error
AuthService.login(email, pwd)        authInterceptor                              errorInterceptor
  ↓ GET /users?email=...               ↓ getToken() valido?                         ↓ status === 401
  ↓ check pwd lato client                ↓ stesso host? non /login?                 ↓ auth.logout()
  ↓ btoa({sub,role,exp})                 ↓ sì → req.clone(+Bearer)                  ↓ router.navigate(
  ↓ localStorage.pc.token                                                              ['/login'],
  ↓ _user.set(user)                  errorInterceptor                                 { queryParams:
  ↓ router.navigate(returnUrl)         ↓ retry GET ritentabili                          { returnUrl }})
                                       ↓ catch → notify → rethrow
ROUTING /admin                       BOOT (F5)
──────────────                       ─────────
canActivate: [                       AuthService.constructor
  authGuard,        // c'è token?      ↓ restoreFromStorage()
  roleGuard('admin')// role giusto?    ↓ atob → check exp
]                                      ↓ GET /users/<id> → _user.set
```

| Voce | Sintassi chiave |
|---|---|
| Token finto | `btoa(JSON.stringify({sub, role, exp}))` |
| Decode | `JSON.parse(atob(raw))` (try/catch obbligatorio) |
| Storage | `localStorage.setItem('pc.token', token)` |
| Stato in memoria | `signal<User\|null>(null)` + `computed(() => !!user())` |
| Auth interceptor | `req.clone({ setHeaders: { Authorization: 'Bearer '+token } })` |
| 401 in error interceptor | `auth.logout(); router.navigate(['/login'], { queryParams: { returnUrl } })` |
| Role guard factory | `function roleGuard(role): CanActivateFn { return () => …; }` |
| Composizione | `canActivate: [authGuard, roleGuard('admin')]` |
| Ordine interceptor | `withInterceptors([authInterceptor, errorInterceptor])` |

### File reali nel seme da citare in aula

| File | Cosa mostra oggi | Cosa cambia nel Lab 4 |
|---|---|---|
| [`src/app/auth-guard.ts`](../../progetto/product-catalog/src/app/auth-guard.ts) | `localStorage.getItem('token')` placeholder | usa `AuthService.isAuthenticated()` (signal-aware) e la chiave diventa `pc.token` |
| [`src/app/pages/login/login.page.ts`](../../progetto/product-catalog/src/app/pages/login/login.page.ts) | `localStorage.setItem('token','demo-token')` → navigate | form template-driven invariato → `AuthService.login(email, pwd)` → eventuale `returnUrl` |
| [`src/app/features/admin/admin.routes.ts`](../../progetto/product-catalog/src/app/features/admin/admin.routes.ts) | `canActivate: [authGuard]` | `canActivate: [authGuard, roleGuard('admin')]` |
| `src/app/services/auth.ts` (nuovo nel Lab 4) | — | biglietteria + decoder + restore al boot |
| `src/app/interceptors/auth.interceptor.ts` (nuovo nel Lab 4) | — | il buttafuori che aggiunge il Bearer escludendo CDN e GET di login |
| `db.json` collection `users` (seedata nello STEP 00 NAP) | `admin@overnet.it / demo123 / role: admin` e `user@overnet.it / demo123 / role: user` | password in chiaro — è dev |

---

## Prossimo: [Lab 4 — Auth + error interceptor + role guard](../lab-04/README.md)
