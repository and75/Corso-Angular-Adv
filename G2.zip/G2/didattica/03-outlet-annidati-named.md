# 03 — Outlet annidati e named outlet

> **Tempo:** ~45 min · **Slide:** TBD · **Blocco:** G2 Sessione 2 · 11:30–12:15 (Mod 3b)
> **Prerequisito:** [Scheda 02 — Feature area + `loadChildren`](./02-children-loadchildren.md). Qui prendiamo l'idea di outlet e la spingiamo a un livello in più — due outlet attivi sulla stessa pagina, indirizzabili indipendentemente nell'URL.

---

## Il problema

Nella [Scheda 02](./02-children-loadchildren.md) abbiamo costruito il palazzo: piano terra, piano admin con la sua porta blindata, bancone reception con la planimetria interna, e dentro il bancone un *outlet annidato* dove cambiano le stanze (lista, edit, log). Le stanze sono sequenziali — vi spostate da una all'altra, e nell'URL un solo segmento per volta dice *"sono qui adesso"*. È il modello *"un contenuto principale per volta"*, e copre la quasi totalità delle navigazioni di un'app.

Vi capiterà però di volere qualcosa che quel modello da solo non vi dà. Volete un **pannello laterale** che resti aperto mentre l'utente continua a navigare il contenuto principale — un'anteprima carrello sulla destra che persiste mentre l'utente passa da `/admin/products` a `/admin/products/3/edit`. Volete che lo stato del pannello (aperto o chiuso, con dentro *cosa*) viva **nell'URL** — perché l'utente possa ricaricare la pagina e ritrovare il pannello dov'era, condividere il link a un collega col pannello già aperto, premere "back" per chiudere il pannello senza perdere la lista sottostante. Volete, in altre parole, **due viste contemporanee sincronizzate con l'URL ma indipendenti l'una dall'altra**.

Da Angular 4 la primitiva per questo si chiama **named outlet**, e da Angular 14 — con il routing standalone — vive esattamente nella stessa forma di tutti gli altri outlet, solo con un nome esplicito. È poco usata, scoperta tardi nella maggior parte dei progetti, e quando arriva il momento giusto cambia letteralmente il modo in cui pensate il routing. Oggi è quel momento.

Restano in cima alla scheda due domande pratiche che ci portiamo dietro:

1. **Quanti livelli di outlet annidati posso fare?** E come si compone l'URL quando ne ho tanti?
2. **Posso avere due outlet** *paralleli* **sulla stessa pagina, ciascuno con il suo proprio indirizzo URL?**

La risposta alla prima è "tutti quelli che vi servono, ma due-tre sono già il massimo *sano*". La seconda è esattamente il named outlet. Andiamo con ordine.

---

## Dal palazzo allo split-screen

Nella scheda 02 vi avevo dato la metafora del palazzo: piano terra, piano admin, bancone reception con il suo outlet interno. Dovete tenerla in mente perché oggi la estendiamo lateralmente.

Pensate al modello che vi siete fatti finora come a **un televisore che mostra un canale per volta**. Ogni canale è una rotta — `/home`, `/admin/products`, `/admin/users` — e quando cambiate canale, lo schermo cambia. Gli outlet annidati sono lo *schermo dentro lo schermo* di chi guarda un canale che ha al suo interno una scena complessa: navigate dentro `/admin/products/3/edit`, e *dentro* la cornice del piano admin cambiano i dettagli. Sempre un canale per volta, però. Sempre una destinazione per volta nell'URL.

I named outlet sono lo **split-screen sincronizzato con l'URL**. Da una parte il programma principale — che è quello che state cambiando navigando — dall'altra una *finestra parallela* che mostra qualcos'altro: il telegiornale, le quotazioni di borsa, l'anteprima del carrello. La finestra parallela non è un sotto-livello del programma principale: è *un secondo flusso autonomo*. E il dettaglio che cambia tutto: l'URL li riflette entrambi. La parte principale dell'URL dice *"stai guardando questo programma"*, e una sintassi specifica fra parentesi — `(panel:cart)` — dice *"e nella finestra di destra c'è il pannello carrello"*. Cambiate canale: la finestra resta. Chiudete la finestra: il canale resta. Aprite un link condiviso da un collega: entrambi sono dove erano quando il collega ve l'ha mandato.

L'esempio concreto del Lab 3 è una di quelle situazioni in cui il named outlet sembra la cosa più naturale del mondo. Navigando `/admin/products(panel:cart)` vedete contemporaneamente la lista dell'admin (outlet primary) **e** il cart preview a destra (outlet `panel`). L'utente naviga ai dettagli di un prodotto — l'URL diventa `/admin/products/3/edit(panel:cart)` — la lista cambia con i dettagli, ma il pannello carrello resta dov'era. Chiude il pannello: l'URL diventa `/admin/products/3/edit`, e basta. Tutto coerente, tutto indirizzabile, tutto bookmarkabile.

Una distinzione che vale la pena di fissare subito, perché in aula confonde sempre:

> **Punto chiave:** *"annidato"* e *"named"* non sono la stessa cosa. **Annidato** è la posizione *fisica* dell'outlet (è dentro a un layout, a un livello in più della gerarchia). **Named** è il *nome esplicito* dell'outlet, che permette di montarne più di uno *allo stesso livello* in parallelo. Potete avere un outlet annidato che è anche named, ma sono due dimensioni indipendenti.

---

## Outlet annidati — il riepilogo dalla scheda 02

Per chiudere la prima domanda — quanti livelli di annidamento — ricapitoliamo quello che la scheda 02 vi ha già lasciato. Il routing children montato sul layout produce automaticamente un outlet *al livello successivo*:

```
ROOT app.html                          ← OUTLET ROOT (primary, livello 0)
  └─ AdminLayout (admin-layout.html)   ← rotta '/admin' montata qui
       └─ OUTLET INTERNO (primary)     ← livello 1, dentro AdminLayout
            └─ AdminList o ProductFormPage  ← children del piano admin
```

Non c'è limite teorico al numero di livelli. Se dentro `AdminList` ci foste *un altro* layout interno con altre children, avreste un outlet di livello 2; e così via. *Praticamente* però, ogni livello in più rende il routing più difficile da seguire — sia per chi legge il codice, sia per chi naviga (back/forward diventano meno prevedibili). Due livelli coprono il 95% delle app reali; tre livelli sono un segnale di "forse questa parte vuole essere un'app a sé".

Quello che è importante notare per quanto segue: ogni outlet annidato finora è ancora un **primary outlet**. L'URL ne riflette il path con i segmenti separati da slash — `/admin/products/3/edit` corrisponde a tre livelli logici, ma sintatticamente è un solo percorso. *Niente parentesi*, niente sintassi speciale. È il modello "un canale per volta", che si annida in profondità senza mai diventare "due canali contemporanei".

Il named outlet è la frattura: aggiunge la dimensione *parallela* a quella già esistente *annidata*.

---

## Named outlet — un secondo schermo a fianco del primo

### Dichiararlo nel template

Tutto comincia con un nome. Un `<router-outlet />` senza attributo `name` è il **primary** — ce ne può essere uno solo per livello, ed è quello con cui avete lavorato finora. Un `<router-outlet name="panel" />` è un **named outlet**, e ne potete avere quanti volete *allo stesso livello*, ciascuno con un nome unico:

```html
<!-- src/app/app.html — anteprima del Lab 3 -->
<app-header />

<main class="flex">
  <router-outlet />                       <!-- ← outlet PRIMARY (senza name) -->
</main>

<!-- Pannello laterale: outlet NAMED -->
<aside class="fixed right-0 top-16 w-80 bg-white shadow-xl hidden has-[*]:block">
  <router-outlet name="panel" />          <!-- ← outlet NAMED -->
</aside>

<app-footer />
```

Il nome `"panel"` è la chiave che collegherete alla rotta corrispondente. Sceglietelo *semanticamente*: `"panel"` se è un pannello generico, `"detail"` se è una vista di dettaglio sempre presente accanto a un master, `"chat"` se è una chat persistente. Non chiamatelo `"outlet2"` — vi sarà incomprensibile fra tre mesi.

L'utility Tailwind `hidden has-[*]:block` sull'`<aside>` è una scelta di UX, non un obbligo del routing. Un outlet vuoto (cioè non popolato dalla rotta) *non renderizza niente* di per sé, ma il suo contenitore — l'`<aside>` esterno — resta nel DOM e occuperebbe spazio se non lo nascondeste. Senza quel `hidden has-[*]:block` vedreste un pannello vuoto seduto sulla destra dello schermo. Con, il pannello sparisce visivamente quando non è popolato. Il trucco è il selettore CSS `:has()`: la utility chiede *"l'aside ha figli? se sì `block`, altrimenti `hidden`"*. Quando la rotta del named outlet non è attiva, Angular non emette markup dentro al `<router-outlet>` → l'aside resta `hidden`. Zero JavaScript, zero signal da tenere in sincrono con lo stato del router. L'alternativa naive — un `@if` legato a un signal locale come `isPanelOpen()` — funziona, ma replica nello stato del componente un'informazione che è già nell'URL: tedioso da mantenere allineato. Decisione UX, ripetiamo: *se il pannello è importante anche da vuoto* (magari per offrire un'azione "apri carrello"), allora questa utility non vi serve.

### Dichiararlo nelle rotte

Il pezzo che la prima volta sembra magia è la dichiarazione della rotta named. Va affianco alle altre rotte — *non dentro a un blocco speciale*, *non sotto al `children`* — ma con una chiave in più che la qualifica:

```typescript
// src/app/app.routes.ts — anteprima del Lab 3
export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home',  component: HomePage },

  { path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then(m => m.default) },

  // ✅ Rotta del named outlet "panel" → cart preview
  {
    path: 'cart',
    outlet: 'panel',                                  // ← la chiave che la distingue dal primary
    component: CartPreviewPanel,                      // wrapper attorno a CartSummary
  },

  // … resto delle rotte primary …
];
```

La proprietà `outlet: 'panel'` dice ad Angular: *"questa rotta non vive nello schermo principale, vive nel secondo schermo chiamato `panel`"*. Senza, la rotta verrebbe trattata come primary e finirebbe nell'outlet senza nome — il che significherebbe *sostituire* la lista admin con il cart preview, non *affiancarla*. È l'errore più frequente di chi prova i named outlet per la prima volta.

C'è una sottigliezza importante sul *dove* dichiarate la rotta named. Nel codice sopra l'abbiamo messa in `app.routes.ts`, accanto a `home` e al `loadChildren` di admin. Questo significa che il pannello è disponibile *a livello root* — vive in parallelo a qualunque rotta primary dell'app, sia `/home`, `/admin/products`, `/checkout`. È quasi sempre quello che volete per un cart preview o un profilo utente. Se invece il pannello dovesse essere disponibile *solo* dentro a una specifica area — diciamo solo dentro `/admin/...` — allora la rotta named andrebbe dichiarata dentro `admin.routes.ts` come children del layout admin. Il *livello* a cui dichiarate la rotta named determina *dove nell'app* il pannello esiste. Tenetelo a mente, perché è il sintomo dell'errore #4 più sotto.

### La forma dell'URL: la sintassi delle parentesi

L'URL con un named outlet attivo ha una forma specifica con le parentesi tonde:

```
/admin/products(panel:cart)
└──────┬──────┘└─────┬─────┘
   primary       named outlet "panel"
   /admin/products    rotta "cart" montata nell'outlet "panel"
```

Con i querystring:

```
/admin/products(panel:cart)?q=mac&page=2
```

L'ordine è importante e a volte sorprende: prima i segmenti di rotta (compresi i named outlet fra parentesi), poi `?` e i queryParam. È così che `DefaultUrlSerializer` di Angular serializza la `UrlTree`: la querystring vive *fuori* dall'albero dei segmenti. Se la guardate al contrario nella barra indirizzi e vi sembra sbagliato, no — è la forma canonica.

Tre dettagli che confondono in aula la prima volta, e che vale la pena guardare in faccia subito.

L'URL ha **una sola querystring**, e vale per *tutta la pagina*, non per singolo outlet. Non c'è modo nativo di avere `?q=mac` sull'outlet primary e `?id=42` sull'outlet panel — Angular gestisce queryParam globali al livello di pagina. Se vi serve passare parametri al pannello, li mettete o nel path della rotta named (`{ outlets: { panel: ['cart', '42'] } }`) oppure li leggete da un servizio condiviso. Il 99% delle volte la seconda strada è più pulita.

Le **parentesi tonde non sono URL-encoded**: Angular le tratta come *sintassi speciale*, non come parentesi letterali del path. Se le vedete encoded in qualche tool di logging o copia-incolla, è il tool che le tratta a modo suo — il browser e Angular si capiscono bene anche così.

E infine: **senza la parte fra parentesi, l'URL non è "rotto"**. Semplicemente non ha il named outlet attivo. È esattamente la differenza fra "pannello aperto" e "pannello chiuso": stesso URL principale, stesso contenuto della lista, solo che il pannello c'è oppure non c'è. È quello che vi permette di chiudere il pannello *senza perdere niente del resto*.

---

## Navigare verso il named outlet

### Dal template, con `routerLink`

Aprire e chiudere un named outlet via `routerLink` ha una sintassi che la prima volta sembra esoterica:

```html
<!-- Apri il cart preview, MANTENENDO la rotta primary corrente -->
<a [routerLink]="[{ outlets: { panel: ['cart'] } }]">
  Apri carrello
</a>

<!-- Chiudi il cart preview (l'outlet "panel" diventa null) -->
<a [routerLink]="[{ outlets: { panel: null } }]">
  Chiudi carrello
</a>
```

Tre cose da fissare in fila.

L'argomento di `routerLink` è **un array**, sempre — anche quando contiene un solo elemento. Dentro all'array c'è un *oggetto* con la proprietà `outlets`, e dentro a `outlets` ci sono le chiavi degli outlet che volete controllare. Potete controllarne più di uno nella stessa navigazione: `{ outlets: { panel: ['cart'], detail: ['user', '42'] } }` aprirebbe entrambi insieme. La sintassi è verbosa ma esprime esattamente la struttura: una mappa da nome-outlet a path-da-montare.

**`null` come valore chiude l'outlet** — lo "smonta" e fa sparire la sezione `(panel:...)` dall'URL. È la differenza importante con `undefined`, che non funziona allo stesso modo (vedi errori comuni più sotto). `null` è esplicito e leggibile come *"voglio che questo outlet non sia attivo"*.

L'outlet primary si controlla con la chiave `primary` (`outlets: { primary: ['home'] }`), oppure — quando state solo cambiando il primary — con la forma classica `routerLink="/home"` che già conoscete. Le due forme sono equivalenti per il primary; per i named, *non* esiste la forma classica, dovete sempre passare per l'oggetto `outlets`.

### Da TypeScript, con `Router.navigate`

La stessa logica, lato componente:

```typescript
private router = inject(Router);

openCartPanel(): void {
  this.router.navigate([{ outlets: { panel: ['cart'] } }], {
    relativeTo: this.route,        // opzionale: navigazione relativa
  });
}

closeCartPanel(): void {
  this.router.navigate([{ outlets: { panel: null } }]);
}
```

Pattern tipico del Lab 3: l'`Header` (o la `HomePage`) ha un bottone "Cart preview" che chiama `openCartPanel()`; il `CartPreviewPanel` stesso ha una `×` in alto a destra che chiama `closeCartPanel()`. Il fatto che il componente *si chiuda da solo*, senza passare attraverso il padre, è un dettaglio di disaccoppiamento che vale la pena nominare in aula: il pannello non sa chi l'ha aperto e non gli interessa: sa solo che, quando vuole chiudersi, *parla con il router*. Lo stesso pannello potrebbe essere aperto da contesti diversi senza modifiche.

---

## L'esempio guida del Lab 3 — Cart preview

Il seme ha già un componente `components/cart-summary/` — il riepilogo del carrello, usato oggi *in-page* dentro alla `HomePage`. Nel Lab 3 lo riusiamo come contenuto del named outlet, *senza modificarlo*. Lo incapsuliamo in un `CartPreviewPanel` che gli aggiunge l'header e la `×`:

```typescript
// src/app/components/cart-preview-panel/cart-preview-panel.ts — anteprima del Lab 3
import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../../services/product';
import { CartSummary } from '../cart-summary/cart-summary';

@Component({
  selector: 'app-cart-preview-panel',
  standalone: true,
  imports: [CartSummary],
  template: `
    <header class="flex justify-between items-center p-4 border-b">
      <h2 class="font-bold">Anteprima carrello</h2>
      <button (click)="close()" class="text-gray-400 hover:text-gray-700">✕</button>
    </header>

    <div class="p-4">
      <app-cart-summary
        [cartItems]="productService.cartItems()"
        (clearCart)="productService.clearCart()"
        (removeItem)="productService.removeFromCart($event)"
      />
    </div>
  `,
})
export class CartPreviewPanel {
  productService = inject(ProductService);
  private router = inject(Router);

  close(): void {
    this.router.navigate([{ outlets: { panel: null } }]);
  }
}
```

Tre cose interessanti emergono qui, ed è utile esplicitarle.

Il **riuso totale** di `CartSummary` esistente: zero duplicazione, zero divergenza di codice. Il pannello laterale è semplicemente una *nuova cornice* attorno a un componente già esistente del seme. È il tipo di organizzazione che dà valore agli investimenti del corso base — gli atomi UI sono pronti, montarli in contesti nuovi è quasi sempre solo *composizione*.

Il **close gestito dal componente stesso**, non dal padre. È un pattern di disaccoppiamento che dovete *desiderare* in queste situazioni: il pannello sa qual è la sua interazione con il router e si gestisce da solo. L'alternativa — emettere un `(close)` al padre, che chiama il router — funzionerebbe ma vi costringerebbe a sapere "chi è il padre" del pannello, e con i named outlet questa risposta è meno chiara del solito (è la rotta che lo monta, non un componente esplicito).

I **dati arrivano dal `ProductService` singleton**, non da props. È una conseguenza di come funzionano i named outlet: la rotta named monta il componente *da sola*, senza un input binding da un padre che gli passi i dati. Il componente, da solo, sa dove andare a prendere lo stato. Per stati globali (carrello, utente loggato, tema) è perfetto; per stati locali sarebbe un problema, ma per locale non avete bisogno di un named outlet — vi basta un `<app-...>` normale.

---

## La gerarchia target del Lab 3

```
URL: /admin/products(panel:cart)?q=mac&page=2
                    └─ named outlet attivo
ROOT app.html
├─ OUTLET ROOT (primary)        ←  /admin/products → AdminLayout
│   │
│   AdminLayout
│   └─ OUTLET INTERNO (primary) ←  children: AdminList
│       │
│       AdminList               ←  legge ?q=mac&page=2 da queryParamMap
│
└─ OUTLET NAMED "panel"         ←  (panel:cart) → CartPreviewPanel
    │
    CartPreviewPanel
    └─ <app-cart-summary>       ←  riuso del componente esistente del seme
```

Tre outlet attivi contemporaneamente, distribuiti su due dimensioni: l'**annidamento** (ROOT primary → INTERNO primary) e il **parallelo** (ROOT primary + NAMED `panel`). È il quadro completo del routing avanzato Angular — da qui in poi non ci sono concetti nuovi, ci sono solo composizioni più ricche di questi pochi pezzi.

---

## Quando usare i named outlet (e quando no)

Vi capiterà, una volta scoperti, di volerli usare ovunque. Resistere a quell'impulso è il segreto di un'app sana. Il named outlet è una primitiva *pesante* — modifica la forma dell'URL, complica la gestione di apertura/chiusura, e fa apparire quella sintassi delle parentesi che la prima volta confonde tutti. Il prezzo si paga: assicuratevi di star comprando qualcosa.

La regola del corso è una sola, e vi indicherei di non scordarla: **usate i named outlet solo se volete che lo stato del pannello sia nell'URL**. Cioè: bookmark, link condivisibili, back/forward del browser. Se non vi serve nessuno di questi, *non usate i named outlet* — usate un `signal` locale per `isOpen`, e basta.

### Sì, quando

- **Pannelli laterali persistenti**: il cart preview che vi accompagna mentre navigate il catalogo. L'utente vuole poter condividere il link "ecco quello che ho nel carrello mentre guardavo questo prodotto" — l'URL deve riflettere entrambi.
- **Modali bookmarkabili**: una modale che mostra il dettaglio di una notifica, aperta da un click su una lista. Volete che il `?notification=42` sopravviva al refresh, e che il back del browser la chiuda invece di tornare alla pagina precedente.
- **Master/detail paralleli**: il caso (raro) in cui il detail non è children del master ma è una vista *parallela* che il master deve poter aprire/chiudere senza spostarsi.

### No, quando

- **Detail di una risorsa selezionata in una lista**: questo è children routing, non named outlet. Il detail *appartiene* al master, il pattern è `/products/:id` come children — non un secondo schermo parallelo.
- **Tab di una stessa pagina**: anche queste sono children, con `redirectTo` su una tab di default. Il named outlet sarebbe overkill — non avete due *flussi* paralleli, avete uno stesso flusso con sezioni interne.
- **Pannelli puramente UI**: menu hamburger, dropdown, tooltip persistenti. Non hanno motivo di stare nell'URL — un `signal` locale per `isOpen` è la scelta corretta. Mettere nell'URL `(menu:open)` complicherebbe tutto senza dare niente in cambio.

La domanda di controllo da farsi: *"se l'utente fa F5, voglio che il pannello sia ancora aperto?"* Se sì, named outlet. Se no, `signal` locale.

---

## Errori comuni

I cinque che mi vedo ripetere in aula, in ordine di gravità decrescente.

**Dimenticare `outlet: 'panel'` nella rotta**. È l'errore numero uno, e ha un sintomo memorabile: aprite il pannello, e *la lista admin sparisce e viene sostituita dal cart preview*. Senza la proprietà `outlet`, Angular considera la rotta come primary e la monta nell'outlet senza nome — sostituendo quello che c'era.

```typescript
// ❌ La rotta finisce nel primary → la lista sparisce, il pannello prende il suo posto
{ path: 'cart', component: CartPreviewPanel }

// ✅ outlet esplicito: la rotta vive nel named outlet
{ path: 'cart', outlet: 'panel', component: CartPreviewPanel }
```

**Sintassi `routerLink` sbagliata**. La forma corretta è *array → oggetto → outlets*. Le varianti che sembrano ragionevoli ma non funzionano:

```html
<!-- ❌ Stringa: Angular la interpreta come path primary letterale -->
<a routerLink="(panel:cart)">Apri</a>

<!-- ❌ Oggetto sciolto fuori dall'array -->
<a [routerLink]="{ outlets: { panel: ['cart'] } }">Apri</a>

<!-- ✅ Array che contiene l'oggetto outlets -->
<a [routerLink]="[{ outlets: { panel: ['cart'] } }]">Apri</a>
```

**Chiudere con `undefined` invece di `null`**. È un errore subdolo: `undefined` non rimuove l'outlet, e l'URL conserva la sezione `(panel:cart)` anche se il template *sembra* aver chiuso il pannello.

```typescript
// ❌ undefined non rimuove l'outlet
this.router.navigate([{ outlets: { panel: undefined } }]);

// ✅ null lo smonta esplicitamente
this.router.navigate([{ outlets: { panel: null } }]);
```

**Dichiarare l'outlet a un livello e la rotta a un altro**. Confusione tipica: mettete `<router-outlet name="panel" />` in `app.html` (vivace su tutta l'app), ma dichiarate la rotta named dentro a `admin.routes.ts` (visibile solo dentro l'area admin). Risultato: la rotta non viene mai matchata, il pannello resta vuoto, nessun errore — solo silenzio. Il fix è coerentizzare il livello: o entrambi a livello root, o entrambi dentro all'area.

**Non gestire la chiusura → URL "sporco"**. L'utente apre il cart preview, naviga via, il componente del pannello viene smontato a video (perché magari la nuova rotta primary non è compatibile col layout che ospitava il pannello), ma il segmento `(panel:cart)` resta nell'URL. Sintomo: ricaricando la pagina, il pannello *si riapre da solo* anche se l'utente "credeva di averlo chiuso". Il fix nei casi semplici è chiamare `router.navigate([{ outlets: { panel: null } }])` quando navigate via dal contesto in cui il pannello ha senso; nei casi più complessi, ascoltare `router.events` e azzerare l'outlet quando il primary cambia — soluzione sofisticata, raramente necessaria.

---

## Cheat-sheet finale

| Voce | Sintassi chiave |
|---|---|
| Outlet primary (default) | `<router-outlet />` |
| Outlet primary annidato | `<router-outlet />` dentro a un layout component |
| Outlet named | `<router-outlet name="panel" />` |
| Rotta named | `{ path: 'cart', outlet: 'panel', component: ... }` |
| `routerLink` named (apri) | `[routerLink]="[{ outlets: { panel: ['cart'] } }]"` |
| `routerLink` named (chiudi) | `[routerLink]="[{ outlets: { panel: null } }]"` |
| `navigate` named (TS) | `router.navigate([{ outlets: { panel: ['cart'] } }])` |
| Forma URL | `/primary-path(panel:cart)` |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/app.html`](../../progetto/product-catalog/src/app/app.html) | Outlet root attuale: `<router-outlet />` dentro al `<main>` — qui aggiungeremo nel Lab 3 il secondo `<router-outlet name="panel" />` |
| [`src/app/components/cart-summary/cart-summary.ts`](../../progetto/product-catalog/src/app/components/cart-summary/cart-summary.ts) + [`.html`](../../progetto/product-catalog/src/app/components/cart-summary/cart-summary.html) | Componente esistente che verrà incapsulato nel `CartPreviewPanel` del named outlet |
| [`src/app/services/product.ts`](../../progetto/product-catalog/src/app/services/product.ts) | `cartItems = signal<CartItem[]>([])` — fonte dati del pannello, condivisa via singleton |

---

## Il filo end-to-end

Riallacciamo la metafora dello split-screen. L'utente naviga `/admin/products?q=mac` — siamo nello scenario di chiusura della [scheda 02](./02-children-loadchildren.md): il piano admin è caricato, il bancone reception è montato, la lista filtrata appare. Adesso clicca "Apri carrello" nell'header. Il `routerLink` `[{ outlets: { panel: ['cart'] } }]` invia al router *un'istruzione che non tocca il primary*: l'URL diventa `/admin/products(panel:cart)?q=mac`. Angular interpreta la nuova sezione fra parentesi, trova la rotta con `outlet: 'panel'`, e monta `CartPreviewPanel` nell'outlet `name="panel"` di `app.html`. La lista non si è mossa, la sidebar admin neppure — il pannello appare *a fianco*.

L'utente naviga ai dettagli del prodotto 3: l'URL diventa `/admin/products/3/edit(panel:cart)`. Il router aggiorna l'outlet primary annidato (`AdminList` lascia il posto a `ProductFormPage`) ma *non tocca* il named outlet — la sezione `(panel:cart)` rimane, il pannello rimane visibile. L'utente preme `×` sul pannello: `router.navigate([{ outlets: { panel: null } }])`. L'URL torna a `/admin/products/3/edit`, il pannello sparisce, la pagina principale resta. L'utente fa F5: la pagina si ricarica esattamente nello stato in cui era — perché *tutto lo stato di vista era nell'URL*.

Da Mod 4 in poi, gli interceptor che vediamo nella [Scheda 04](./04-interceptors-error-retry.md) si aggiungeranno *senza toccare* nessuna di queste rotte: si infilano fra `HttpClient` e la rete, non hanno niente a che vedere con il routing. Il piano admin con i named outlet di oggi resta la nostra base — domani gli aggiungiamo solo dei caselli sull'autostrada delle chiamate.

---

## Prossimo: [Lab 3a — Children + lazy area](../lab-03a-children-lazy/README.md)

> Il Mod 3 chiude con tre mini-lab: **3a** (children + lazy), **3b** (querystring filter/paginazione), **3c** (named outlet con cart preview). Si applicano in sequenza sul `product-catalog-finale/`.
