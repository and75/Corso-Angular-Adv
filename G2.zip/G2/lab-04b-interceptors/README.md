# Lab 4b — Interceptors: `authInterceptor` + `errorInterceptor` + registrazione
### Giorno 2 · Lab guidato (~30 min) · Slot 16:20–16:50

---

## Obiettivo

Costruire i due interceptor funzionali della [Scheda 04 — Interceptors, error, retry](../didattica/04-interceptors-error-retry.md) appoggiandoli all'`AuthService` consegnato dal [Lab 4a](../lab-04a-auth-guards/README.md), e registrarli in `app.config.ts`:

1. **`authInterceptor`** — clona ogni richiesta verso il nostro backend aggiungendo `Authorization: Bearer <token>`. Esclude la GET di login (`/users?email=…`) per design.
2. **`errorInterceptor`** — pipe centralizzato sopra `next(req)`: `retry` mirato sui GET ritentabili (`status === 0 || status >= 500`), `catchError` finale che intercetta i 401 (`auth.logout()` + redirect a `/login?returnUrl=…`) e gli altri errori (toast via `NotificationService`), con `throwError(() => err)` sempre rilanciato.
3. **Registrazione** — `provideHttpClient(withInterceptors([authInterceptor, errorInterceptor]))` in `app.config.ts`. L'ordine è motivato: invertirlo significa che il retry parte senza Bearer.

Risultato visibile (in DevTools → Network):

- Login `admin@overnet.it / demo123` → la `GET /products` parte con `Authorization: Bearer eyJ…`. La GET di login (`/users?email=…`) parte **senza** Bearer.
- Spegni `json-server` e ricarica la lista prodotti → vedi 3 GET in Network (1 + 2 retry) spaziati ~500 ms, poi un toast "Server non raggiungibile".
- Forza un 401 a mano (in DevTools → Application → Local Storage, sostituisci `pc.token` con `"invalido"` ma valido in base64: `btoa(JSON.stringify({sub:1,role:'admin',exp:Date.now()+3600000}))` poi rompi a mano il sub) → il backend torna 401, vai su `/login?returnUrl=/admin`, `pc.token` sparisce.
- POST con payload sbagliato → toast con messaggio mappato, **niente retry** (è un POST + 4xx).

> **Cosa non si fa qui:** AuthService, login, guards. Quelli sono il [Lab 4a](../lab-04a-auth-guards/README.md). Lo stato di partenza di questo lab è esattamente la `solution/` del 4a applicata a `product-catalog-finale/`.

---

## Stato di partenza

| Punto | Stato |
|---|---|
| `product-catalog-finale/` | Dopo Lab 4a: `AuthService` + login funzionante + `authGuard` + `roleGuard('admin')` su `/admin` |
| `services/auth.ts` | Esiste, espone `getToken(): string \| null` e `logout(): void`. Sono i due metodi che gli interceptor consumano |
| `services/notification.service.ts` | Esiste dal seme (Mod 1), espone `error(message: string): void` |
| `db.json` collection `users` | Già seedato dal Lab 4a |
| `app.config.ts` | Ancora con `provideHttpClient()` nudo — niente interceptor registrati |
| `src/app/interceptors/` | **Cartella vuota** — la creiamo noi con i due file |

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/interceptors/auth.interceptor.ts` | Aggiunge `Authorization: Bearer <token>` alle chiamate al nostro backend, esclusa la GET di login | **nuovo** |
| `src/app/interceptors/error.interceptor.ts` | Retry mirato sui GET 0/5xx + 401 → logout+redirect + altri → toast | **nuovo** |
| `src/app/app.config.ts` | Registrazione `provideHttpClient(withInterceptors([authInterceptor, errorInterceptor]))` | modificato |

> Non si tocca nient'altro. Niente `services/`, niente `pages/`, niente `features/`: tutto il cablaggio è già fatto dal Lab 4a.

---

## Scaffolding — comandi Angular CLI

Due artefatti nuovi: entrambi sono interceptor funzionali.

```bash
cd Corso/progetto/product-catalog-finale

# authInterceptor
ng generate interceptor interceptors/auth --functional --skip-tests
# alias breve:
ng g interceptor interceptors/auth --functional --skip-tests

# errorInterceptor
ng generate interceptor interceptors/error --functional --skip-tests
# alias breve:
ng g interceptor interceptors/error --functional --skip-tests
```

Note Angular 21:
- `ng g interceptor interceptors/auth --functional` genera `src/app/interceptors/auth-interceptor.ts` (senza suffisso `.interceptor.ts`). Lo schematic restituisce uno scheletro `HttpInterceptorFn` pronto, da riempire.
- **Attenzione al nome del file:** lo schematic di Angular 21 usa di default `auth-interceptor.ts`. Per coerenza con la Scheda 04 e con la `solution/` (`auth.interceptor.ts`), **rinominalo a mano** a `auth.interceptor.ts` subito dopo la generazione. Stesso per `error.interceptor.ts`.
- `--skip-tests` evita di generare `*.spec.ts`.

> `ng` diretto perché in aula la CLI è installata globalmente.

---

## TODO 1 — FACILE: `authInterceptor` (~8 min)

Crea **`src/app/interceptors/auth.interceptor.ts`** (vedi Scaffolding). È il file più corto del lab e quello con la densità di "perché" più alta.

### Tipi e costanti

Importa `inject` da `'@angular/core'` e `HttpInterceptorFn` da `'@angular/common/http'`. Importa `AuthService` da `'../services/auth'`.

Definisci due costanti a livello di **modulo** (fuori dalla function):

- `API_HOST = 'http://localhost:3000'` — origine del nostro backend.
- `LOGIN_PATH = '/users'` — la GET di login va a `/users?email=…`.

Le tieni fuori dalla function (non dentro) per due motivi: (1) sono costanti, non c'è motivo di ricalcolarle a ogni request; (2) leggere `req.url.startsWith(API_HOST + LOGIN_PATH)` racconta cosa sta succedendo molto meglio di una stringa magica inline.

### Corpo della function

Firma: `export const authInterceptor: HttpInterceptorFn = (req, next) => { … }`.

Tre passi:

1. **Recupera il token.** In cima al body chiama `inject(AuthService).getToken()`. `inject()` qui funziona perché l'interceptor è invocato in un *injection context* da `HttpClient`. ⚠️ Non spostarlo dentro `next(req).pipe(...)`: lì non c'è injection context.

2. **Tre filtri di passaggio intatto.** Costruisci due booleani:
   - `isOurApi = req.url.startsWith(API_HOST)` — la richiesta va al nostro backend? Se no, niente Bearer (non vogliamo regalare il token a CDN/mappe/IdP terzi).
   - `isLoginCall = req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET'` — è la GET di login? Allora deve partire **senza** Bearer per design (vedi Scheda 05 §"Il buttafuori dello stand").

   Se `!token || !isOurApi || isLoginCall` → `return next(req)`.

3. **Altrimenti clona e passa il clone.** `req.clone({ setHeaders: { Authorization: 'Bearer ' + token } })`, poi `return next(cloned)`.

> **Errore numero uno** (vedi Scheda 04 §"Errori comuni — 2"): clonare e poi passare `req` originale a `next`. `req.clone()` ritorna un nuovo oggetto immutabile: se non lo usi, è come se non l'avessi fatto.

Riferimento: [Scheda 04 §"Pattern 1 — clonare la richiesta"](../didattica/04-interceptors-error-retry.md) + [Scheda 05 §"Il buttafuori dello stand — authInterceptor"](../didattica/05-auth-jwt-refresh.md).

---

## TODO 2 — MEDIO: `errorInterceptor` (~15 min)

Crea **`src/app/interceptors/error.interceptor.ts`**. Tre responsabilità in un solo file: ritentare i GET ritentabili, gestire il 401, notificare gli altri errori.

### Imports

- da `'@angular/core'`: `inject`;
- da `'@angular/common/http'`: `HttpInterceptorFn`, `HttpErrorResponse`;
- da `'@angular/router'`: `Router`;
- da `'rxjs'`: `catchError`, `retry`, `throwError`, `timer`;
- da `'../services/auth'`: `AuthService`;
- da `'../services/notification.service'`: `NotificationService`.

### Corpo della function

In cima al body inietta le **tre** dipendenze:

```typescript
const auth          = inject(AuthService);
const router        = inject(Router);
const notifications = inject(NotificationService);
```

⚠️ Le tre `inject()` restano catturate nella **closure** degli operatori — non chiamarle dentro `catchError`/`retry`, lì non c'è injection context.

Poi `return next(req).pipe(retry({…}), catchError((err) => {…}))`. L'**ordine** `retry` prima di `catchError` è obbligatorio: se inverti, il `catchError` cattura il primo errore, lo "gestisce" da solo, e il `retry` non vede mai nulla da ritentare.

### Il `retry` con `delay` funzione

Firma: `retry({ count: 2, delay: (err: HttpErrorResponse) => Observable })`.

Il `delay` non è un numero — è una **funzione** che riceve l'errore e ritorna un Observable. La logica:

- definisci `isRetriable = req.method === 'GET' && (err.status === 0 || err.status >= 500)`;
- se ritentabile → ritorna `timer(500)` (Observable che emette dopo 500 ms → `retry` ritenta);
- se non ritentabile → ritorna `throwError(() => err)` (Observable che emette un errore → `retry` si arrende e passa la palla al `catchError`).

Tre regole della Scheda 04 §"Pattern 3 — retry mirato": **idempotenza** (solo GET, mai POST/PUT/DELETE), **ritentabilità** (solo 0/5xx, mai 4xx — riprovare un 404 non lo trasforma in 200), **mai infinito** (`count: 2`, totale 3 tentativi).

> Il `throwError(() => err)` *dentro* il `delay` non è un `throw` JS classico. È un Observable che emette un errore — è la convenzione che `retry` usa per "non ritentare". La differenza fra `throw` (sincrono, scoppia) e `throwError(() => err)` (Observable che emette `error`) è importante: nel `delay`, solo il secondo funziona.

### Il `catchError` finale

```typescript
catchError((err: HttpErrorResponse) => {
  if (err.status === 401) {
    // logout PRIMA del navigate — vedi nota sotto
    auth.logout();
    router.navigate(['/login'], { queryParams: { returnUrl: location.pathname } });
  } else {
    notifications.error(mapStatusToMessage(err));
  }
  return throwError(() => err);   // sempre rilanciare
})
```

Due "perché" cruciali:

- **`auth.logout()` PRIMA del navigate.** Se navigi a `/login` senza prima fare logout, il prossimo render rilegge il token ancora in `localStorage`, `authGuard` decide "sei loggato", `restoreFromStorage` rimette il signal a non-null, e a `/admin` parte un'altra GET che ritorna 401: loop. Vedi `README-docente` §3.
- **`return throwError(() => err)` obbligatorio.** Lo studente è tentato di mettere `return EMPTY` perché "ho già notificato". È l'errore più subdolo del lab: il componente che ha fatto `http.get(...).subscribe(...)` aspetta una risposta, e senza rethrow non riceve né `next` né `error`. Il suo `isLoading` resta `true` per sempre. Vedi Scheda 04 §"Errori comuni — 3. Niente rethrow".

### `mapStatusToMessage(err)` — helper privato al file

Funzione helper (sotto la `export const errorInterceptor`) che mappa status code → messaggio:

- `0` → `'Server non raggiungibile. Controlla la connessione.'`
- `404` → `'Risorsa non trovata.'`
- `409` → `'Conflitto: la risorsa è già stata modificata.'`
- `>= 500` → `'Errore del server. Riprova tra qualche istante.'`
- *default* → `'Si è verificato un errore. Riprova.'`

> Perché `location.pathname` e non `Router.url` per `returnUrl`? `Router.url` viene aggiornato all'inizio di una navigation, quindi durante il `catchError` non sempre coincide con la rotta che il browser sta mostrando. `location.pathname` è la verità del browser, sempre.

Riferimento: [Scheda 04 §"Pattern 2 — error interceptor"](../didattica/04-interceptors-error-retry.md) + [§"Pattern 3 — retry mirato"](../didattica/04-interceptors-error-retry.md) + [Scheda 05 §"Lo stand chiuso — il 401"](../didattica/05-auth-jwt-refresh.md).

---

## TODO 3 — FACILE: registrazione in `app.config.ts` (~3 min)

Modifica **`src/app/app.config.ts`**. Due cambiamenti:

1. **Import esteso** di `withInterceptors` da `'@angular/common/http'` (è già importato `provideHttpClient`).
2. **Import dei due interceptor** appena scritti:
   ```typescript
   import { authInterceptor }  from './interceptors/auth.interceptor';
   import { errorInterceptor } from './interceptors/error.interceptor';
   ```
3. **Sostituisci** il `provideHttpClient()` nudo con la versione che registra i due interceptor in catena, **in quest'ordine**: `authInterceptor`, `errorInterceptor`.

L'**ordine** non è simmetrico. In andata, l'array si percorre dall'alto in basso (auth aggiunge il Bearer prima che error veda la richiesta). In ritorno, il `pipe` di RxJS si srotola dall'interno verso l'esterno (il `retry` di error è in coda — corretto). Conseguenza pratica: con l'ordine giusto, il retry parte *includendo* il Bearer. Invertendo (`[errorInterceptor, authInterceptor]`), il retry parte *senza* Bearer e tutti i 401 ritentati restano 401.

Vedi Scheda 04 §"Errori comuni — 5. Cambiare l'ordine in withInterceptors".

---

## Criteri di verifica

### Funzionali (manuali, in DevTools)

- [ ] Login `admin@overnet.it / demo123` → atterri su `/admin`, Network mostra `Authorization: Bearer eyJ…` sulle GET a `localhost:3000/products`. La GET a `localhost:3000/users?email=…` (login) parte **senza** `Authorization`.
- [ ] Spegni `json-server` (`Ctrl+C` sulla finestra `npm start`) e ricarica la lista prodotti: in Network vedi **3 chiamate** (1 originale + 2 retry) spaziate ~500 ms, poi un toast "Server non raggiungibile. Controlla la connessione.".
- [ ] Tenta un `POST` (es. crea un prodotto con campo mancante, se l'UI lo permette) che dia 4xx: **niente retry**, una sola chiamata in Network, toast con messaggio mappato.
- [ ] Forza un 401: in DevTools → Application → Local Storage, sostituisci `pc.token` con `btoa(JSON.stringify({sub:9999,role:'admin',exp:Date.now()+3600000}))` (utente che non esiste). Ricarica `/admin`: la GET `/users/9999` torna 404 (intercettato dal toast), ma se vai su `/admin/products` con una rotta che richiede ruolo admin il flusso è coerente. Per un 401 vero serve un backend che lo emetta: in mancanza, demo via console con `inject(HttpClient).get('http://localhost:3000/fake-401').subscribe()` non basta (json-server non emette 401). **Variante didattica:** stoppare `json-server` mid-request → status 0 e retry visibile.
- [ ] In DevTools console, esegui `localStorage.removeItem('pc.token')` e poi clicca un link che fa una chiamata HTTP autenticata — la chiamata parte senza Bearer (corretto: nessun token → niente clone) e tu vedi la lista prodotti pubblica funzionare. Se l'endpoint richiedesse auth, vedresti il 401 + redirect.

### Formali (binario A — solution applicata a `product-catalog-finale/`)

```bash
cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test --watch=false
```

Zero errori, tutti i test verdi.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| Login OK ma `Authorization` non compare in Network sulle GET a `/products` | Manca `withInterceptors([authInterceptor, ...])` in `app.config.ts`, oppure stai cercando l'header sulla chiamata di login (esclusa per design) | TODO 1 (filtri) + TODO 3 (`app.config.ts`) |
| La GET di login parte CON Bearer (cambio account → 401 in scenari reali) | Manca il check `isLoginCall`, oppure stai usando `===` invece di `startsWith` (l'URL ha `?email=…`) | TODO 1, secondo filtro |
| `inject() can only be used within an injection context` | Stai chiamando `inject()` **dentro** `catchError`/`retry`, non in cima al body dell'interceptor | TODO 2, cima del body |
| Il `retry` ritenta ogni POST in fail | Il `delay` del retry non filtra `req.method` | TODO 2, `isRetriable` |
| I 4xx aspettano 1.5 s prima del toast (3 tentativi inutili) | Il `delay` ritenta anche per status 4xx — il ramo "non ritentabile" deve ritornare `throwError(() => err)`, non un timer | TODO 2, ramo non ritentabile |
| Loop di redirect tra `/login` e `/admin` dopo un 401 | Manca `auth.logout()` PRIMA di `router.navigate(['/login'])` | TODO 2, ramo 401 |
| Lo spinner del componente resta acceso quando arriva un errore | Nel `catchError` hai messo `return EMPTY` (o niente return) invece di `return throwError(() => err)` | TODO 2, fine catchError |
| Toast con messaggio "Si è verificato un errore" anche per i 404 | `mapStatusToMessage` non gestisce 404 (sta cadendo nel default) | TODO 2, helper |
| Tutte le chiamate a CDN/font esterni hanno Bearer (e i CORS si lamentano) | Manca il check `isOurApi` | TODO 1, primo filtro |
| Errori di compilazione "cannot find module '../services/notification.service'" | Il percorso è `services/notification.service` (`.service.ts`) — è il file del seme (Mod 1), non rinominato | TODO 2, imports |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!

---

## Conclusione del Mod 4

Con la registrazione di questi due interceptor in `app.config.ts` chiudi il modulo Mod 4. La **biglietteria** (Lab 4a) ha consegnato il braccialetto (token + signal); il **buttafuori** (`authInterceptor`) lo controlla all'ingresso di ogni request; il **servizio reclami** (`errorInterceptor`) gestisce centralmente cosa succede quando qualcosa va male. L'`AuthService` resta l'unica fonte di verità sull'identità — interceptor e guard sono solo consumer.

> Il prossimo passo del corso (Mod 5) sposta il focus dalla pipe HTTP alle librerie riutilizzabili (`ng-packagr`). Tutto quello che hai scritto qui — interceptor + guard + service — è perfettamente "estraibile" in una lib aziendale.
