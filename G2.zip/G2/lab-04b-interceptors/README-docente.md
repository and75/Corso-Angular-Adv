# Lab 4b — Interceptors: Bearer + error + retry
## Guida per il Docente

---

## 1. Scopo Didattico

Secondo dei due lab del Mod 4 (4a → 4b). Applica la **Scheda 04** (interceptors + error + retry) e chiude la **Scheda 05** (slot 401/logout). L'angolazione è: "consuma la biglietteria del 4a — il pattern Angular per i cross-cutting concerns HTTP è esattamente questo".

Tre messaggi chiave:

1. **Cross-cutting concerns fuori dai servizi.** Senza interceptor, ogni `ProductService`/`OrderService` duplicherebbe `catchError`, retry, header Authorization. Con due interceptor in `app.config.ts`, tutta l'app si comporta in modo coerente — e i servizi tornano a parlare solo di dominio.
2. **L'ordine in `withInterceptors([…])` non è simmetrico.** L'array si percorre dall'alto in basso in andata e dall'interno all'esterno in ritorno (è una `pipe` RxJS). Conseguenza: `[authInterceptor, errorInterceptor]` significa "Bearer aggiunto *prima* che error veda la req, retry *dopo* il catchError di auth". Invertito, il retry parte senza Bearer.
3. **`retry` con `delay` funzione è il punto che confonde sempre.** Non è un numero ("aspetta tot ms"), è una funzione `(err) => Observable` che decide *se* ritentare ritornando un timer, o *non* ritentare ritornando `throwError(() => err)`. Si disegna alla lavagna.

---

## 2. Timing Consigliato

**Slot orario: 16:20–16:50 (30 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Recap Lab 4a (`AuthService.getToken()` + `logout()`) + demo del bug "Bearer assente in Network" | 3 min |
| TODO 1 | `authInterceptor` (3 filtri + clone) | 8 min |
| TODO 2 | `errorInterceptor` (retry + 401 + toast + mapStatusToMessage) | 14 min |
| TODO 3 | Registrazione `withInterceptors([auth, error])` in `app.config.ts` | 3 min |
| Recap | Demo Network: Bearer su `/products`, niente su login, 3 retry quando spegni `json-server` | 2 min |
| **Totale** | | **~30 min** |

> Se l'aula è veloce, lasciare 3 minuti finali per la demo "ordine invertito": cambiare a `[errorInterceptor, authInterceptor]`, rifare login, mostrare in Network che il retry parte senza `Authorization`. Riallineare l'ordine. È un'esperienza didattica forte.
>
> Se sforate, il candidato a essere ridotto è il `mapStatusToMessage`: si può lasciare un solo ramo (es. `default → 'Errore generico'`) e raccontare la mappatura alla lavagna. Il pattern resta intatto.

---

## 3. Contesto nella Scaletta

- **Mod 4 teoria** (14:00–15:30): Scheda 04 (interceptors + error + retry) e Scheda 05 (auth + JWT + refresh).
- **Lab 4a** (15:45–16:20): `AuthService` + login + guards. Il prerequisito di questo lab.
- **Lab 4b** (questo, 16:20–16:50): interceptor consumer di `AuthService`.

Aggancio col resto del corso:

- Il `NotificationService` (Mod 1) torna utile qui: l'`errorInterceptor` lo usa come consumer per i toast. È lo stesso pattern del Lab 2b — un service global che riceve eventi da fonti disparate.
- Il `ProductService` del seme (Mod 0) ha un `catchError` inline in tre metodi. **Cosa NON facciamo nel Lab 4b**: rifattorizzare il `ProductService` per togliere i `catchError`. È una variazione possibile (vedi §7); per il timing dello slot resta come compito a casa o discussione di chiusura.
- L'`app.config.ts` toccato qui sarà il punto di partenza di Mod 5 (`ng-packagr`): mostrare come gli interceptor *non* finiscano nella lib, ma restino nell'app — sono troppo legati a infrastruttura specifica (URL del backend, `NotificationService` concreto).

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 Costanti `API_HOST` / `LOGIN_PATH` fuori dalla function

```typescript
const API_HOST   = 'http://localhost:3000';
const LOGIN_PATH = '/users';

export const authInterceptor: HttpInterceptorFn = (req, next) => { … };
```

**Cosa dire:**
> "Le costanti vivono fuori. Tre motivi: (1) sono costanti, non c'è motivo di ricalcolarle a ogni request; (2) `req.url.startsWith(API_HOST + LOGIN_PATH)` racconta cosa sta succedendo molto meglio di `req.url.startsWith('http://localhost:3000/users')` inline; (3) il giorno in cui il backend si sposta su `https://api.example.com`, cambiamo una stringa. In produzione le porteremmo in `environment.ts` — qui le teniamo inline per non scollegare ancora di più dal seme."

### 4.2 I tre filtri dell'`authInterceptor`

```typescript
const isOurApi    = req.url.startsWith(API_HOST);
const isLoginCall = req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET';

if (!token || !isOurApi || isLoginCall) {
  return next(req);
}
```

**Cosa dire:**
> "Tre check, motivati uno per uno. `!token` è il caso 'sloggato' — niente Bearer da aggiungere, passa intatto. `!isOurApi` è il caso 'CDN/font/Google Maps' — non vogliamo regalare il nostro token a chi non lo richiede e non lo aspetta. `isLoginCall` è il caso più subdolo: la GET di login deve partire *senza* Bearer per design. Su `json-server` non si vede nulla; su un IdP reale, un cambio di account fallirebbe perché l'IdP rifiuta una login authenticated. È il classico bug che si trova solo in QA."

### 4.3 `req.clone({ setHeaders })` e il pattern immutabile

```typescript
const cloned = req.clone({
  setHeaders: { Authorization: `Bearer ${token}` },
});
return next(cloned);
```

**Cosa dire:**
> "`HttpRequest` è *immutabile*. Non puoi fare `req.headers.set('Authorization', …)`. La clone è il pattern: ti restituisce un nuovo oggetto con il delta applicato. Errore numero uno in aula: clonare e poi passare `req` originale a `next`. Il clone esiste, è in memoria, ma `next` riceve l'originale senza header. Sintomo: nessun errore di compilazione, nessun errore runtime, il Bearer semplicemente non appare in Network."

### 4.4 `retry` con `delay` funzione

```typescript
retry({
  count: 2,
  delay: (err: HttpErrorResponse) => {
    const isRetriable = req.method === 'GET' && (err.status === 0 || err.status >= 500);
    return isRetriable ? timer(500) : throwError(() => err);
  },
}),
```

**Cosa dire:**
> "Tre cose da fissare. Primo: il `delay` non è un numero. È una funzione che riceve l'errore e ritorna un Observable. Secondo: 'ritentare' significa ritornare un Observable che emette (`timer(500)` emette `0` dopo 500 ms → `retry` riprende e rifa la request). 'Non ritentare' significa ritornare un Observable che emette un errore (`throwError(() => err)` → `retry` si arrende e passa al `catchError`). Terzo: tre regole sull'ammissibilità del retry — idempotenza (solo GET), ritentabilità (solo 0/5xx, mai 4xx — riprovare un 404 non lo trasforma in 200), mai infinito (`count: 2`, totale 3 tentativi)."

Disegnare alla lavagna:

```
  next(req) ──► (errore HTTP) ──► retry({ delay: fn(err) → Observable })
                                            │
                                            ├─ fn ritorna timer(500) ► riprovi
                                            │
                                            └─ fn ritorna throwError(() => err) ► retry si arrende
                                                                                    │
                                                                                    ▼
                                                                              catchError
```

### 4.5 `auth.logout()` PRIMA del `router.navigate` sul 401

```typescript
if (err.status === 401) {
  auth.logout();                                                       // ⚠️ PRIMA
  router.navigate(['/login'], {
    queryParams: { returnUrl: location.pathname },
  });
}
```

**Cosa dire:**
> "L'ordine è critico. Se navighi a `/login` senza prima fare logout, il prossimo render *rilegge* il token ancora in `localStorage`, `authGuard` decide 'sei loggato', `restoreFromStorage` rimette il signal a non-null, e l'app prova ad andare di nuovo su `/admin` — dove la chiamata HTTP ritorna 401, l'interceptor naviga di nuovo a `/login`, e ripeti all'infinito. È il loop più visto in aula. Fix: `auth.logout()` prima."

### 4.6 `return throwError(() => err)` sempre, anche dopo il toast

```typescript
return throwError(() => err);
```

**Cosa dire:**
> "Lo studente è tentato di scrivere `return EMPTY` perché 'ho già notificato, il giro è finito'. È l'errore più subdolo del lab. Il componente che ha fatto `http.get(...).subscribe({ next, error })` aspetta una risposta — `next` o `error`. Con `EMPTY` non arriva nessuna delle due, e l'`isLoading` del componente resta `true` per sempre. Si vede solo in produzione, dove gli spinner cominciano a non spegnersi più dopo errori. Demo in vivo: togliere il `throwError`, fare una request che fallisce con 500, lo spinner gira all'infinito."

### 4.7 `location.pathname` vs `Router.url` per il `returnUrl`

```typescript
queryParams: { returnUrl: location.pathname }
```

**Cosa dire:**
> "Scelta pragmatica. `Router.url` viene aggiornato all'inizio di una navigation, quindi se il 401 arriva durante un `resolve`/durante una guard, `Router.url` ancora punta alla pagina precedente. `location.pathname` è la verità del browser, sempre. Costo: perdi le query string. Per il lab va bene; in app più complesse vale la pena combinare `location.pathname + location.search`."

### 4.8 L'ordine `[authInterceptor, errorInterceptor]` in `withInterceptors`

```typescript
provideHttpClient(
  withInterceptors([
    authInterceptor,    // ① andata: prima di error. Il Bearer è già sulla req quando error la vede
    errorInterceptor,   // ② ritorno: il pipe si srotola dall'interno — il retry di error è in coda
  ]),
),
```

**Cosa dire:**
> "L'ordine non è simmetrico, ed è qui che la maggior parte degli studenti si confonde. In andata, l'array si percorre dall'alto in basso: `auth` prima di `error`. In ritorno, il `pipe` RxJS si srotola dall'interno verso l'esterno: il `retry` di `error` è in coda. Conseguenza pratica: con l'ordine giusto, quando il retry parte la richiesta ha *già* il Bearer aggiunto da `auth`. Invertendo, il retry parte senza Bearer e i 401 ritentati restano 401. È il bug 'silente' più costoso del modulo."

Demo opzionale (se resta tempo): invertire a `[errorInterceptor, authInterceptor]`, mostrare in Network che il `Authorization` manca nei tentativi 2 e 3.

---

## 5. Errori comuni degli studenti

### ❌ Errore 1: Bearer aggiunto alla GET di login
**Sintomo:** funziona su `json-server` (nessun controllo), ma in QA con backend reale il login da loggato (cambio account) fallisce.
**Causa:** manca il check `isLoginCall`.
**Fix:** aggiungere `isLoginCall = req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET'` nei filtri.

### ❌ Errore 2: `req.clone()` ignorato
```typescript
const cloned = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
return next(req);   // ❌ passa l'originale
```
**Sintomo:** il Bearer non appare mai in Network. Nessun errore di compilazione né runtime.
**Fix:** `return next(cloned)`.

### ❌ Errore 3: `inject()` dentro `catchError`
```typescript
catchError((err) => {
  const router = inject(Router);   // ❌ no injection context
  …
})
```
**Sintomo:** `Error: inject() can only be used within an injection context`.
**Fix:** spostare le tre `inject()` in cima al body dell'interceptor; sono catturate nella closure degli operatori.

### ❌ Errore 4: Loop di redirect dopo 401
```typescript
catchError((err) => {
  if (err.status === 401) {
    inject(Router).navigate(['/login']);   // ❌ manca auth.logout() prima
  }
  return throwError(() => err);
})
```
**Sintomo:** dopo un 401 l'utente sembra autenticato (`pc.token` ancora in `localStorage`), `authGuard` lo rimanda su `/admin`, parte un'altra GET, 401, redirect, loop.
**Fix:** `auth.logout()` *prima* di `router.navigate`.

### ❌ Errore 5: `return EMPTY` nel catchError
```typescript
catchError((err) => {
  notifications.error(…);
  return EMPTY;   // ❌ il componente non riceve né next né error
})
```
**Sintomo:** spinner del componente che non si spegne più dopo errori.
**Fix:** `return throwError(() => err)`.

### ❌ Errore 6: `retry` con `delay: 500` (numero)
```typescript
retry({ count: 2, delay: 500 })   // ❌ ritenta tutto, sempre, ovunque
```
**Sintomo:** in `json-server` (permissivo) → 3 POST identici nel DB invece di 1. Anche 4xx aspettano 1.5 s prima di mostrare il toast.
**Fix:** `delay` come funzione che filtra su `req.method === 'GET'` e su `err.status` ritentabile.

### ❌ Errore 7: `throw err` invece di `throwError(() => err)` nel `delay`
```typescript
delay: (err) => {
  if (req.method !== 'GET') throw err;   // ❌ throw sincrono dentro la callback di delay
  return timer(500);
}
```
**Sintomo:** comportamento erratico. Il `throw` può fermare il flusso ma non passa pulitamente al `catchError` — RxJS si aspetta un Observable di errore.
**Fix:** `return throwError(() => err)` invece di `throw err`.

### ❌ Errore 8: Ordine invertito in `withInterceptors`
```typescript
withInterceptors([errorInterceptor, authInterceptor])   // ❌
```
**Sintomo:** funziona per le request fresche, ma i retry partono senza Bearer e i 401 ritentati restano 401.
**Fix:** `[authInterceptor, errorInterceptor]`.

### ❌ Errore 9: `Authorization` su CDN/font esterni
**Sintomo:** errori CORS su `fonts.googleapis.com`, `cdn.example.com`, etc. La console del browser è piena di rosso.
**Causa:** manca il check `isOurApi`.
**Fix:** primo filtro `req.url.startsWith(API_HOST)`.

### ❌ Errore 10: `===` invece di `startsWith` nei filtri
```typescript
const isLoginCall = req.url === API_HOST + LOGIN_PATH;   // ❌ ignora ?email=…
```
**Sintomo:** la GET di login parte con Bearer (e in backend reali fallisce).
**Fix:** `startsWith` — l'URL di login include la query string.

---

## 6. Domande frequenti

**Q: Perché due interceptor invece di uno solo?**
A: Separation of concerns. `authInterceptor` ha una responsabilità (aggiungere il Bearer in andata) ed è testabile in isolamento. `errorInterceptor` ne ha tre (retry + 401 + toast) ma sono tutte legate al *ritorno*. Mescolandoli avresti una function di 80 righe con una doppia identità. Inoltre, in app reali si compone diversamente: ad es. solo `authInterceptor` in un microfrontend pubblico, entrambi nel dashboard admin.

**Q: Posso usare un `HttpInterceptor` class-based come si faceva prima di Angular 15?**
A: Tecnicamente sì (Angular continua a supportarli con `withInterceptorsFromDi`), ma il modello idiomatico Angular 21 è funzionale: niente decoratori, niente registrazione con `HTTP_INTERCEPTORS`, niente `multi: true`. La forma funzionale è più snella, più facile da testare (chiamala come una funzione qualsiasi), e si compone meglio con `inject()` rispetto al `constructor(private auth: AuthService)` di una classe. Vedi Scheda 04 §"L'evoluzione: da class-based a functional".

**Q: Il `retry` del Mod 4 ritenta anche durante la modale del login? Cioè se l'utente sta digitando la password e il server è momentaneamente fuori, ritento la POST?**
A: No, per due motivi. Primo: `req.method === 'GET'` esclude esplicitamente i POST/PUT/DELETE. Secondo: nella nostra app non c'è una POST di login (è una GET su `/users?email=…`). Quindi la regola "solo GET ritentabili" protegge automaticamente. In un'app con `POST /api/login`, il retry verrebbe escluso a meno di whitelist esplicita — di solito non si fa, perché un retry su login significa due tentativi di autenticazione e qualche backend li conta come "brute force".

**Q: Perché `count: 2` (3 tentativi totali) e non `count: 5`?**
A: Trade-off UX-vs-resilienza. 3 tentativi a 500 ms l'uno sono ~1.5 s di latenza percepita prima dell'errore. `count: 5` sarebbe ~2.5 s — troppo per un'UI moderna. La regola pratica: tot tentativi che, sommati ai delay, restano sotto i 2 s. In API critiche (es. salvataggio importante) vale la pena salire a `count: 3` con `delay: timer(exp(i) * 500)` (backoff esponenziale) — ma è una variazione, non il default.

**Q: Posso registrare l'`errorInterceptor` solo per certe rotte?**
A: Non nativamente: `withInterceptors` è globale. Per scoping per-route, Angular 21 introduce `HttpContext` (`req.context.set(SKIP_RETRY, true)`) come "tag" che l'interceptor può leggere per saltare la sua logica. È un'estensione naturale del Lab 4b, fuori scope per il timing.

**Q: `mapStatusToMessage` non è anti-pattern? Sembra un cattivo `switch`.**
A: È un classico mapping a tabella, e in italiano "non-traduzione". Va bene per il volume di error code del lab (5 casi). Sopra i 10, vale la pena estrarlo in una mappa statica `const MESSAGES: Record<number, string> = {…}` con un fallback. Sopra i 20, hai probabilmente un problema di design del backend (status overloaded come business logic) — vai a parlare col team backend.

---

## 7. Adattamenti

### Classe veloce (resta tempo):
- **Demo "ordine invertito" (3 min).** Cambiare a `[errorInterceptor, authInterceptor]`, rifare login, mostrare in Network che i tentativi 2/3 del retry non hanno `Authorization`. Ribaltare.
- **Rifattorizzazione `ProductService` (5 min).** Aprire `services/product.ts`, mostrare i tre `catchError` inline, cancellarli. Mostrare che la lista prodotti continua a funzionare e che gli errori finiscono nel toast. È il pagamento del Lab 4b — finalmente puoi togliere boilerplate.
- **Test unit dell'`authInterceptor` (8 min).** Esempio canonico di testing di una `HttpInterceptorFn`: `HttpTestingController`, mock di `AuthService.getToken()`, expect del header su una request. Funziona bene anche con `runInInjectionContext`.

### Classe lenta:
- **Saltare il `retry` (5 min risparmiati).** Lasciare solo il `catchError` con i due rami (401 + toast). Spiegare il retry alla lavagna usando il diagramma sopra. Costo: la verifica funzionale "spegni `json-server` → 3 tentativi" non funziona, ma il pattern di base è chiaro.
- **Saltare `mapStatusToMessage` (3 min risparmiati).** Mostrare un singolo `notifications.error('Errore: ' + err.message)`. Funziona. Costo: i messaggi sono meno gentili (`http error 500 OK`) ma il pattern interceptor è intatto.

### Cosa NON approfondire:
- **`HttpContext`** per scoping per-request: estensione futura.
- **Backoff esponenziale** nel retry: variazione produzione, fuori scope didattico.
- **Refresh token flow** (401 → POST /refresh → retry originale): teoria nella Scheda 05, mai implementato — il backend simulato non emette refresh.
- **SSR-safety degli interceptor**: gli interceptor girano anche server-side. Va menzionato (è uno dei "perché interceptor e non ErrorService" della Scheda 04) ma non implementato fino al Mod 6.

---

## 8. Verifica NAP (binario A)

Stato di partenza: `product-catalog-finale/` con la `solution/` del Lab 4a già applicata (`AuthService`, login, `authGuard`, `roleGuard`, db.json seedato). Applicare i delta:

```bash
cp -r Corso/G2/lab-04b-interceptors/solution/src/app/. Corso/progetto/product-catalog-finale/src/app/

cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test
```

**Verifica funzionale suggerita (manuale):**
- `npm start` (json-server + ng serve).
- Login `admin@overnet.it / demo123`. In DevTools → Network: la GET `/users?email=…` (login) parte **senza** `Authorization`; le successive GET `/products` partono **con** `Authorization: Bearer eyJ…`.
- Spegnere `json-server` (Ctrl+C sulla finestra `npm start`) e ricaricare la lista prodotti. In Network: 3 GET spaziate ~500 ms, poi un toast "Server non raggiungibile. Controlla la connessione.".
- Riavviare `json-server`. Funziona di nuovo.
- Da DevTools console: `localStorage.setItem('pc.token', 'rotto')` poi `location.reload()`. `restoreFromStorage` (Lab 4a) decodifica fallisce, `pc.token` viene rimosso, header torna anonimo. Niente errori in console grazie al `try/catch` di `decode()`.

> **Modulo Mod 4 chiuso.** Lab 4a + Lab 4b consegnano la pipeline completa: auth simulata + interceptor + guards. Il prossimo modulo (Mod 5 — `ng-packagr`) prenderà spunto da questi file per discutere cosa entra in una library e cosa no.

---

## 9. Note sul testing

Il `npx ng test` di `product-catalog-finale/` non testa specificatamente gli interceptor del Lab 4b. I test del seme (smoke su `app.config`, `auth-guard.spec.ts` minimale) continuano a passare anche con la nuova registrazione di `withInterceptors` perché non istanziano `HttpClient`.

> Estensione opzionale (15' in più): scrivere il test del `authInterceptor` con `HttpTestingController` e `runInInjectionContext`. Vale come esempio canonico di testing functional interceptor in Angular 21. Mock di `AuthService.getToken()` su due scenari (token presente → header settato; token null → request intatta).
