/**
 * interceptors/auth.interceptor.ts — STARTER Lab 4b G2
 *
 * Functional HTTP interceptor (Angular 21): aggiunge l'header
 * `Authorization: Bearer <token>` alle richieste dirette al nostro backend,
 * escludendo la GET di login (che parte SENZA token per design).
 *
 * Vedi Scheda 04 G2 §"Pattern 1 — clonare la richiesta".
 * Vedi Scheda 05 G2 §"Il buttafuori dello stand — authInterceptor" per la motivazione dei 3 filtri.
 *
 * Stato di partenza: la `solution/` di Lab 4a applicata a product-catalog-finale.
 *   - `AuthService` esiste a `services/auth.ts` ed espone `getToken(): string | null`.
 */

import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from '../services/auth';

/*
 * TODO 1 — Costanti a livello di modulo (fuori dalla function).
 *
 *   Definisci due const:
 *     - API_HOST   = 'http://localhost:3000'    ← origine del nostro backend
 *     - LOGIN_PATH = '/users'                    ← la GET di login va a /users?email=...
 *
 *   Perché fuori dalla function? Sono costanti (no ricalcolo a ogni request) e leggere
 *   `req.url.startsWith(API_HOST + LOGIN_PATH)` racconta cosa sta succedendo molto meglio
 *   di una stringa magica inline.
 */

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  /*
   * TODO 1 — Recupera il token tramite AuthService.
   *
   *   Forma:
   *     const auth  = inject(AuthService);
   *     const token = auth.getToken();
   *
   *   ⚠️ `inject()` qui in cima funziona perché l'interceptor è invocato in un
   *      injection context da HttpClient. NON spostarlo dentro pipe/catchError di un
   *      eventuale altro interceptor: lì non c'è injection context.
   */

  /*
   * TODO 1 — Tre filtri che, se ALMENO UNO è vero, fanno passare la req intatta:
   *
   *     1) `!token`           — non siamo loggati, niente Bearer da aggiungere.
   *     2) `!isOurApi`        — la richiesta va a un servizio terzo (CDN, font, mappe, …).
   *                              Non vogliamo regalare il nostro token a chi non lo richiede.
   *        Espressione: `req.url.startsWith(API_HOST)`.
   *     3) `isLoginCall`      — la chiamata di login NON deve portare il Bearer (per design).
   *        Espressione: `req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET'`.
   *        Nota su `startsWith` (vs `===`): l'URL di login include `?email=...`, quindi
   *        l'uguaglianza diretta NON match-erebbe. `startsWith` copre il prefisso.
   *
   *   Se la combinazione blocca il flusso main:  `return next(req);`  e via.
   */

  /*
   * TODO 1 — Clona la richiesta aggiungendo il Bearer.
   *
   *   Forma:
   *     const cloned = req.clone({
   *       setHeaders: { Authorization: `Bearer ${token}` },
   *     });
   *     return next(cloned);
   *
   *   ⚠️ Errore numero uno (vedi Scheda 04 §"Errori comuni — 2"): clonare e poi passare
   *      `req` (originale) a `next`. `req.clone()` ritorna un nuovo oggetto immutabile:
   *      se non lo usi, è come non averlo fatto. Nessun errore di compilazione, nessun
   *      errore runtime, il Bearer semplicemente non appare in Network.
   */

  /* eslint-disable-next-line @typescript-eslint/no-unused-expressions */
  null;   // placeholder per il compilatore — sostituire con la logica sopra
  throw new Error('TODO 1 — authInterceptor non implementato');
};
