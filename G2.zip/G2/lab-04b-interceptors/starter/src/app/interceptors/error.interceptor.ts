/**
 * interceptors/error.interceptor.ts — STARTER Lab 4b G2
 *
 * Functional HTTP interceptor (Angular 21): gestione centralizzata degli errori HTTP.
 *
 *   Responsabilità:
 *     1) Retry MIRATO sui GET ritentabili (status 0 o 5xx).
 *     2) 401 → logout + redirect a /login?returnUrl=...
 *     3) Altri errori → toast via NotificationService.
 *     4) Sempre `throwError(() => err)` finale: l'errore deve risalire al componente.
 *
 * Vedi Scheda 04 G2 §"Pattern 2 — error interceptor" e §"Pattern 3 — retry mirato".
 * Vedi Scheda 05 G2 §"Lo stand chiuso — il 401" per il flusso logout/redirect.
 *
 * Stato di partenza: la `solution/` di Lab 4a applicata a product-catalog-finale.
 *   - `AuthService.logout()` esiste a `services/auth.ts`.
 *   - `NotificationService.error(message)` esiste a `services/notification.service.ts`.
 */

import { inject } from '@angular/core';
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, retry, throwError, timer } from 'rxjs';
import { AuthService } from '../services/auth';
import { NotificationService } from '../services/notification.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  /*
   * TODO 2 — Inietta le TRE dipendenze in cima al body.
   *
   *     const auth          = inject(AuthService);
   *     const router        = inject(Router);
   *     const notifications = inject(NotificationService);
   *
   *   ⚠️ `inject()` NON va chiamato dentro `catchError`/`retry`: lì non c'è injection context.
   *      Le tre const restano catturate nella closure degli operatori (è il motivo per cui
   *      possiamo dichiararle qui e usarle giù).
   *
   *   Vedi Scheda 04 §"Pattern 2" — il "perché" del `inject()` qui dentro.
   */

  /*
   * TODO 2 — Applica gli operatori a `next(req)` in QUESTO ordine:
   *
   *     return next(req).pipe(
   *       retry({ count: 2, delay: (err) => Observable }),
   *       catchError((err: HttpErrorResponse) => { ... }),
   *     );
   *
   *   ⚠️ L'ordine conta: `retry` DEVE venire PRIMA di `catchError`. Altrimenti
   *   il `catchError` cattura il primo errore, lo "gestisce", e `retry` non vede
   *   mai nulla da ritentare.
   */

  /*
   * TODO 2 — `retry({ count: 2, delay: (err) => Observable })`.
   *
   *   Il `delay` è una FUNZIONE che riceve l'errore e decide:
   *     - ritentare → ritorna `timer(500)` (Observable che emette dopo 500 ms).
   *     - arrendersi → ritorna `throwError(() => err)` (Observable di errore: il retry
   *                     si arrende, l'errore passa al catchError a valle).
   *
   *   ⚠️ NON `throw err` (sincrono). Dentro il `delay` serve un OBSERVABLE di errore.
   *      `throwError(() => err)` è la convenzione corretta.
   *
   *   Filtro "ritentabile":
   *     const isRetriable =
   *       req.method === 'GET' &&
   *       (err.status === 0 || err.status >= 500);
   *
   *   Solo GET (idempotente, safe da ripetere) e solo errori di rete o server momentaneo
   *   (0 = browser non ci ha parlato; 5xx = server in difficoltà). 4xx NO — il retry non
   *   trasforma un 404 in 200, e ripetere un 401 non lo fa scomparire.
   *
   *   Tre regole della Scheda 04 §"Pattern 3 — retry mirato":
   *     • idempotenza   → solo GET
   *     • ritentabilità → solo 0/5xx
   *     • mai infinito  → count: 2 (= 3 tentativi totali, ~1.5 s di latenza percepita)
   */

  /*
   * TODO 2 — `catchError((err: HttpErrorResponse) => ...)`.
   *
   *   Forma:
   *     if (err.status === 401) {
   *       auth.logout();                              ← ⚠️ PRIMA del navigate, altrimenti loop
   *       router.navigate(['/login'], {
   *         queryParams: { returnUrl: location.pathname },
   *       });
   *     } else {
   *       notifications.error(mapStatusToMessage(err));
   *     }
   *     return throwError(() => err);                  ← ⚠️ SEMPRE rilanciare
   *
   *   ⚠️ Loop di redirect: dimenticare `auth.logout()` PRIMA del navigate. Senza, la
   *      guard del prossimo refresh rivede `pc.token` in localStorage (ancora non rimosso),
   *      `authGuard` redirige su `/admin`, la chiamata ritenta, 401 di nuovo, loop.
   *      Vedi README docente §5 errore 4.
   *
   *   ⚠️ Errore "spinner che gira a vuoto": sostituire `throwError(() => err)` con
   *      `return EMPTY`. Il componente che ha fatto subscribe non riceve né next né
   *      error, il suo `isLoading` resta a true per sempre. Vedi Scheda 04 §"Errori
   *      comuni — 3".
   *
   *   ⚠️ Perché `location.pathname` e non `Router.url`? `Router.url` viene aggiornato
   *      all'inizio della navigation, quindi durante il `catchError` non sempre
   *      coincide con la rotta che il browser sta mostrando. `location.pathname` è la
   *      verità del browser, sempre.
   */

  /*
   * TODO 2 — `mapStatusToMessage(err: HttpErrorResponse): string`.
   *
   *   Helper privato al file (sotto la `export const`, oppure inline nel catchError).
   *   Mappa status code → messaggio italiano:
   *
   *     - err.status === 0   → 'Server non raggiungibile. Controlla la connessione.'
   *     - err.status === 404 → 'Risorsa non trovata.'
   *     - err.status === 409 → 'Conflitto: la risorsa è già stata modificata.'
   *     - err.status >= 500  → 'Errore del server. Riprova tra qualche istante.'
   *     - default            → 'Si è verificato un errore. Riprova.'
   */

  /* eslint-disable-next-line @typescript-eslint/no-unused-expressions */
  null;   // placeholder per il compilatore — sostituire con la pipe sopra
  throw new Error('TODO 2 — errorInterceptor non implementato');
};
