/**
 * app.config.ts — STARTER Lab 4b G2
 *
 * Modifica: registrare gli interceptor funzionali nel provideHttpClient.
 *
 * Vedi Scheda 04 G2 §"Registrarli: la fila dei caselli".
 *
 * Stato di partenza: identico al seme — `provideHttpClient()` nudo, senza interceptor.
 * (Il Lab 4a non tocca questo file: cambia solo `auth-guard.ts`, `login.page.ts`,
 *  `admin.routes.ts` e introduce `services/auth.ts` + `guards/role.guard.ts`.)
 */

import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';

import { routes } from './app.routes';

/*
 * TODO 3 — Estendi l'import di `@angular/common/http` con `withInterceptors`:
 *
 *     import { provideHttpClient, withInterceptors } from '@angular/common/http';
 *
 *   E aggiungi i due import dei nuovi interceptor:
 *
 *     import { authInterceptor }  from './interceptors/auth.interceptor';
 *     import { errorInterceptor } from './interceptors/error.interceptor';
 */

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),

    /*
     * TODO 3 — Sostituisci il `provideHttpClient()` nudo qui sotto con la versione
     *           che registra i due interceptor in catena:
     *
     *     provideHttpClient(
     *       withInterceptors([
     *         authInterceptor,    ← ① aggiunge il Bearer in andata
     *         errorInterceptor,   ← ② vede la risposta — retry + 401/logout + toast
     *       ]),
     *     ),
     *
     *   ⚠️ L'ordine NON è simmetrico. In andata l'array si percorre dall'alto in basso
     *      (auth → error → rete); in ritorno il `pipe` RxJS si srotola dall'interno
     *      verso l'esterno. Conseguenza pratica: il `retry` di errorInterceptor parte
     *      DOPO che authInterceptor ha aggiunto il Bearer in andata — quindi i tentativi
     *      ritentati includono il token. Invertendo l'ordine, i retry partono SENZA Bearer
     *      e i 401 ritentati restano 401.
     *
     *   Vedi Scheda 04 §"Errori comuni — 5. Cambiare l'ordine in withInterceptors".
     */
    provideHttpClient()
  ]
};
