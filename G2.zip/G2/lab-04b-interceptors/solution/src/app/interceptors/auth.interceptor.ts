// auth.interceptor.ts — SOLUZIONE Lab 4b G2
// Aggiunge `Authorization: Bearer <token>` alle chiamate al nostro backend,
// escludendo la GET di login (che parte SENZA Bearer per design).

import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from '../services/auth';

const API_HOST   = 'http://localhost:3000';
const LOGIN_PATH = '/users';   // la GET di login va a /users?email=... — niente Bearer per lei.

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth  = inject(AuthService);
  const token = auth.getToken();

  // Tre filtri: se almeno uno è vero, la req passa intatta.
  const isOurApi    = req.url.startsWith(API_HOST);
  const isLoginCall = req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET';

  if (!token || !isOurApi || isLoginCall) {
    return next(req);
  }

  // Clone immutabile con il Bearer aggiunto.
  // ⚠️ Errore tipico: clonare e poi passare `req` originale a `next`. Il clone esiste
  //    in memoria ma `next` non lo vedrebbe. Sempre `next(cloned)`.
  const cloned = req.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
  });
  return next(cloned);
};
