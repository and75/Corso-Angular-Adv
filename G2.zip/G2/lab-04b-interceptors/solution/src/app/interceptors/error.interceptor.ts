// error.interceptor.ts — SOLUZIONE Lab 4b G2
// Retry mirato sui GET ritentabili, 401 → logout + redirect, altri errori → toast.

import { inject } from '@angular/core';
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, retry, throwError, timer } from 'rxjs';
import { AuthService } from '../services/auth';
import { NotificationService } from '../services/notification.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const auth          = inject(AuthService);
  const router        = inject(Router);
  const notifications = inject(NotificationService);

  return next(req).pipe(
    // ① Retry: solo GET ritentabili (errori 0/5xx). 4xx no — riprovare non li sistema.
    //    `delay` è una FUNZIONE che riceve l'errore e ritorna un Observable:
    //      • timer(500)              → ritenta dopo 500 ms
    //      • throwError(() => err)   → si arrende, l'errore passa al catchError
    retry({
      count: 2,
      delay: (err: HttpErrorResponse) => {
        const isRetriable =
          req.method === 'GET' &&
          (err.status === 0 || err.status >= 500);
        return isRetriable ? timer(500) : throwError(() => err);
      },
    }),
    // ② Catch finale: arriva qui se il retry si è arreso o se l'errore non era ritentabile.
    catchError((err: HttpErrorResponse) => {
      if (err.status === 401) {
        // ⚠️ ORDINE: logout PRIMA del navigate. Senza, il prossimo render rilegge
        //    `pc.token` in localStorage e `authGuard` rimanda su /admin → loop di 401.
        auth.logout();
        router.navigate(['/login'], {
          queryParams: { returnUrl: location.pathname },
        });
      } else {
        notifications.error(mapStatusToMessage(err));
      }
      // ⚠️ Sempre rilanciare: chi ha fatto subscribe deve potersi accorgere dell'errore.
      //    Senza, l'isLoading dei componenti resta a true per sempre.
      return throwError(() => err);
    }),
  );
};

function mapStatusToMessage(err: HttpErrorResponse): string {
  if (err.status === 0)   return 'Server non raggiungibile. Controlla la connessione.';
  if (err.status === 404) return 'Risorsa non trovata.';
  if (err.status === 409) return 'Conflitto: la risorsa è già stata modificata.';
  if (err.status >= 500)  return 'Errore del server. Riprova tra qualche istante.';
  return 'Si è verificato un errore. Riprova.';
}
