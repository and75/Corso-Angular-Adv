/**
 * services/auth.ts — STARTER Lab 4a G2
 *
 * Nuovo service: "biglietteria" che simula l'autenticazione contro json-server.
 * Vive con `providedIn: 'root'` (singleton globale). Lo stato corrente è un signal,
 * la persistenza è in localStorage, il token è finto ma con la stessa forma di un JWT
 * (header omesso, payload + scadenza, niente firma).
 *
 * Vedi Scheda 05 G2 §"La biglietteria — AuthService" e Lab 4a README §TODO 1.
 */

import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

/*
 * TODO 1 — Tipi del dominio (da esportare/dichiarare qui sopra).
 *
 *   1) `User` (interface esportata): shape dell'utente in `db.json` SENZA la password.
 *      Campi: id (number), email (string), name (string), role ('admin' | 'user').
 *
 *   2) `TokenPayload` (interface, può restare privata al modulo): shape del payload
 *      del nostro token finto. Campi: sub (number, ovvero l'id utente),
 *      role (User['role']), exp (number, ms epoch).
 *
 *   3) `STORAGE_KEY = 'pc.token'`: costante locale al modulo, chiave usata in localStorage.
 *
 *   4) `ONE_HOUR_MS = 60 * 60 * 1000`: utile per il calcolo dell'exp del token (1 ora).
 *
 *   Note: la password è in chiaro in `db.json` perché simuliamo l'auth lato Angular —
 *   nei tipi pubblici NON deve apparire (vedi `currentUser` più avanti).
 */

@Injectable({ providedIn: 'root' })
export class AuthService {

  private http = inject(HttpClient);

  /*
   * TODO 1 — Stato interno e API read-only.
   *
   *   Crea un signal privato:
   *     private _user = signal<User | null>(null);
   *
   *   Esponi pubblicamente:
   *     - `readonly currentUser = this._user.asReadonly()`        ← read-only per i consumer
   *     - `readonly isAuthenticated = computed(() => this._user() !== null)`  ← derivato booleano
   */

  constructor() {
    /*
     * TODO 1 — Chiama qui `restoreFromStorage()` (definito sotto).
     *
     *   Al boot dell'app il signal `_user` parte a null: questa chiamata lo ripopola
     *   se in localStorage c'è un token ancora valido. Senza, ogni F5 azzera la sessione.
     */
  }

  /*
   * TODO 1 — `async login(email: string, password: string): Promise<User>`
   *
   *   Passi:
   *     1) GET http://localhost:3000/users con params {email}, attendendo l'array di risultati.
   *        Suggerimento: firstValueFrom(this.http.get<Array<User & { password: string }>>(...))
   *
   *     2) Prendi l'elemento [0] dell'array. Se manca, O se la password non coincide:
   *        throw new Error('Credenziali non valide').
   *        ⚠️ Controlla PRIMA che candidate esista, POI confronta la password
   *           (altrimenti NPE su candidate.password).
   *
   *     3) Costruisci il payload:
   *          { sub: candidate.id, role: candidate.role, exp: Date.now() + ONE_HOUR_MS }
   *
   *     4) const token = btoa(JSON.stringify(payload));
   *
   *     5) localStorage.setItem(STORAGE_KEY, token);
   *
   *     6) Rimuovi la password dall'utente e aggiorna il signal:
   *          const { password: _pwd, ...safeUser } = candidate;
   *          this._user.set(safeUser);
   *
   *     7) return safeUser;
   *
   *   ⚠️ Errori tipici:
   *     - Salvare l'utente intero (con password) nel signal: NO.
   *     - Dimenticare il btoa() prima del setItem: NO (finirebbe JSON in chiaro in localStorage).
   *     - Fare console.error sul catch: NO, è un errore atteso (gestito dalla LoginPage).
   */

  /*
   * TODO 1 — `logout(): void`
   *
   *   Due righe:
   *     - localStorage.removeItem(STORAGE_KEY);
   *     - this._user.set(null);
   *
   *   Non chiamare router.navigate qui: il logout è un'azione di stato; la navigazione
   *   è responsabilità di chi lo chiama (LoginPage, errorInterceptor sul 401 nel Lab 4b).
   */

  /*
   * TODO 1 — `getToken(): string | null`
   *
   *   Usato dall'authInterceptor del Lab 4b (importante: la firma è 'pubblica').
   *
   *   Logica:
   *     1) raw = localStorage.getItem(STORAGE_KEY); se null → return null.
   *     2) payload = this.decode(raw); se null OPPURE payload.exp < Date.now():
   *          - localStorage.removeItem(STORAGE_KEY)
   *          - return null
   *     3) Altrimenti return raw (l'interceptor non ha bisogno del payload).
   *
   *   ⚠️ Perché validare lato client?
   *      - Risparmio una request già condannata.
   *      - Con auth simulata, json-server non risponde 401 mai. Senza la validazione
   *        client-side, un token scaduto resterebbe attivo indefinitamente.
   */

  /*
   * TODO 1 — `private restoreFromStorage(): void`
   *
   *   Chiamato dal costruttore. Logica:
   *     1) raw = localStorage.getItem(STORAGE_KEY); se null → return.
   *     2) payload = this.decode(raw); se null O exp < Date.now():
   *          localStorage.removeItem(STORAGE_KEY); return.
   *     3) GET http://localhost:3000/users/<payload.sub>:
   *          - next: rimuovi password e fai this._user.set(safeUser).
   *          - error: localStorage.removeItem(STORAGE_KEY); this._user.set(null).
   *
   *   Nota TS: per togliere la password:
   *     const { password: _pwd, ...safeUser } = user as User & { password: string };
   *     this._user.set(safeUser);
   *
   *   (Alternativa progettuale non richiesta: salvare l'oggetto user completo accanto
   *    al token e ripristinare senza HTTP. Vantaggio: zero request. Svantaggio: dati staleable.
   *    Discusso nel README docente.)
   */

  /*
   * TODO 1 — `private decode(raw: string): TokenPayload | null`
   *
   *   Forma idiomatica:
   *
   *     try {
   *       return JSON.parse(atob(raw)) as TokenPayload;
   *     } catch {
   *       return null;
   *     }
   *
   *   ⚠️ Il try/catch NON è cosmetico: se l'utente sostituisce 'pc.token' in DevTools
   *      con una stringa non base64, atob lancia InvalidCharacterError. Senza catch,
   *      il primo render dopo F5 esplode.
   */
}
