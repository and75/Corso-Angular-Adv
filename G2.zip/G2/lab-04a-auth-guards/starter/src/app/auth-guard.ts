/**
 * auth-guard.ts — STARTER Lab 4a G2
 *
 * Modifica: sostituire la lettura "nuda" da localStorage con AuthService.isAuthenticated().
 *
 * Vedi Scheda 05 G2 §"Il flusso end-to-end" (l'authGuard è il "tornello d'ingresso";
 * il roleGuard del TODO 3 è il "tornello del backstage").
 */

import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';

/*
 * TODO 2 — Importa AuthService:
 *
 *   import { AuthService } from './services/auth';
 */

export const authGuard: CanActivateFn = (_route, state) => {
  const router = inject(Router);

  /*
   * TODO 2 — Sostituisci la lettura placeholder qui sotto con:
   *
   *   const auth = inject(AuthService);
   *   if (auth.isAuthenticated()) return true;
   *   return router.createUrlTree(['/login'], {
   *     queryParams: { returnUrl: state.url },
   *   });
   *
   *   Note:
   *     - `state.url` è l'URL completa che l'utente stava cercando di raggiungere.
   *       La passiamo come `returnUrl` per riportarcelo dopo il login.
   *     - `isAuthenticated()` legge un signal: la guard reagisce sempre allo stato
   *       corrente, non a un valore stantio cachato.
   *     - `createUrlTree([...], { queryParams })`: una guard deve RITORNARE un valore
   *       (true | UrlTree | Observable<...>), non innescare un side effect (no router.navigate).
   */

  // ⚠️ Placeholder del seme — da rimuovere nel TODO 2
  const token = localStorage.getItem('token');
  if (token) return true;
  return router.createUrlTree(['/login']);
};
