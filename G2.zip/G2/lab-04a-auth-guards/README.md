# Lab 4a — Auth: `AuthService` + Login + `authGuard` + `roleGuard`
### Giorno 2 · Lab guidato (~35 min) · Slot 15:45–16:20

---

## Obiettivo

Applicare i pattern della [Scheda 05 — Auth, JWT, refresh](../didattica/05-auth-jwt-refresh.md) costruendo un sistema di autenticazione simulato lato Angular sopra a `json-server`:

1. **`AuthService`** — singleton che incapsula login, logout, ripristino al boot, decoder e validazione del token finto. Stato esposto via signal (`currentUser`, `isAuthenticated`).
2. **Login + `authGuard`** — il form di login esistente viene collegato a `AuthService.login()`; `auth-guard.ts` passa dalla lettura placeholder di `localStorage` a `isAuthenticated()` del service.
3. **`roleGuard` factory** — guard parametrica `roleGuard(required): CanActivateFn` per l'autorizzazione su base ruolo. Composta con `authGuard` sull'area `/admin`.

Risultato visibile:

- `admin@overnet.it / demo123` → entra in `/admin`, nel `localStorage` compare `pc.token`.
- `user@overnet.it / demo123` → entra nell'app ma `/admin` mostra toast "Accesso negato" e redirige a `/`.
- Logout → `pc.token` sparisce, refresh di `/admin` redirige a `/login?returnUrl=/admin`.
- Manomettendo `pc.token` in DevTools con una stringa qualsiasi → al refresh `AuthService` lo scarta silenziosamente (try/catch su `atob`).

> **Avvertenza didattica.** L'auth di questo lab è **simulata interamente lato Angular**: password in chiaro nel `db.json`, token finto senza firma, niente IdP. È uno strumento per studiare il pattern Angular (service + signal + guard + storage), non un design di sicurezza. Il codice Angular qui scritto **non cambia** quando in produzione il backend diventa reale: cambia solo `AuthService.login()`, che parlerà con un vero `/api/login` invece di `GET /users?email=…`. Vedi Scheda 05 §"Perché qui un token finto e non un JWT vero".

> **Cosa non si fa qui:** interceptor HTTP (Bearer su ogni request, gestione 401, retry). Quelli sono il [Lab 4b](../lab-04b-interceptors/README.md). Lo stato di partenza del Lab 4b è esattamente la `solution/` di questo lab.

---

## Stato di partenza

| Punto | Stato |
|---|---|
| `product-catalog-finale/` | Dopo Lab 3c (admin feature area + named outlet cart preview) |
| `auth-guard.ts` esistente | Legge `localStorage.getItem('token')` (placeholder). Lo sostituiremo con `AuthService.isAuthenticated()` |
| `pages/login/login.page.{ts,html}` | Form template-driven esistente. Il template **non cambia**, cambia solo `onSubmit` |
| `services/auth.ts` | **Non esiste** — lo creiamo nel TODO 1 |
| `guards/role.guard.ts` | **Non esiste** — lo creiamo nel TODO 3 |
| `db.json` collection `users` | Non esiste — la aggiungiamo nel Setup |

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `db.json` | Aggiunge collection `users` con 2 utenti seed (admin + user) | modificato |
| `src/app/services/auth.ts` | Biglietteria: login GET /users + token finto + signal currentUser + restoreFromStorage | **nuovo** |
| `src/app/pages/login/login.page.ts` | Form esistente collegato al nuovo `AuthService.login()` | modificato |
| `src/app/auth-guard.ts` | Usa `AuthService.isAuthenticated()` invece del placeholder localStorage | modificato |
| `src/app/guards/role.guard.ts` | Factory `roleGuard(role): CanActivateFn` | **nuovo** |
| `src/app/features/admin/admin.routes.ts` | Composizione `canActivate: [authGuard, roleGuard('admin')]` | modificato |

> Il **template** `login.page.html` *non* viene toccato: il form template-driven del seme funziona già com'è. Cambia solo `onSubmit` lato TypeScript.

---

## Scaffolding — comandi Angular CLI

Due artefatti nuovi: un service e una guard funzionale (factory).

```bash
cd Corso/progetto/product-catalog-finale

# AuthService
ng generate service services/auth --skip-tests
# alias breve:
ng g s services/auth --skip-tests

# roleGuard (functional guard)
ng generate guard guards/role --functional --skip-tests
# alias breve:
ng g g guards/role --functional --skip-tests
```

Note Angular 21:
- `ng g s services/auth` genera `src/app/services/auth.ts` (no suffisso `.service.ts` in Angular 21). Classe `AuthService` (la CLI somma "Service" al nome del path).
- `ng g g guards/role --functional` genera una `CanActivateFn`. La sceglieremo come scope di guard (`CanActivate`) interattivamente: rispondi `CanActivate` quando la CLI lo chiede, oppure passa `--implements=CanActivate` per evitare il prompt.
- Per il roleGuard riscrivi **comunque** il file: lo schematic genera una guard "semplice" (`export const roleGuard: CanActivateFn = ...`), ma noi vogliamo una **factory** che ritorna una `CanActivateFn`. Cambia la firma.
- `--skip-tests` evita di generare `*.spec.ts`.

> `ng` diretto perché in aula la CLI è installata globalmente.

---

## Setup — seed `users` in `db.json` (~3 min)

Apri `Corso/progetto/product-catalog-finale/db.json` e **aggiungi** (o sostituisci se vuota) la collection `users` con due utenti seed:

```json
"users": [
  { "id": 1, "email": "admin@overnet.it", "password": "demo123", "name": "Admin Demo", "role": "admin" },
  { "id": 2, "email": "user@overnet.it",  "password": "demo123", "name": "User Demo",  "role": "user"  }
]
```

> Password in chiaro: è dev. In produzione mai — verrebbero hashate con bcrypt/argon2 lato server e mai esposte via REST.

Avvia API + dev server:

```bash
cd Corso/progetto/product-catalog-finale
npm start         # avvia json-server (porta 3000) + ng serve (porta 4200) insieme
```

Sanity check dell'API:

```bash
curl "http://localhost:3000/users?email=admin@overnet.it"
# atteso: [{ "id": 1, "email": "admin@overnet.it", "password": "demo123", "name": "Admin Demo", "role": "admin" }]
```

Se vedi un array vuoto, il seed non è stato applicato — ricontrolla `db.json`.

---

## TODO 1 — FACILE: `services/auth.ts` (~15 min)

Crea **`src/app/services/auth.ts`** (vedi sezione Scaffolding). È il file più grande del lab ma è anche il più lineare: una classe `@Injectable({ providedIn: 'root' })` che incapsula login, logout, stato corrente, e ripristino da `localStorage` al boot.

### Tipi del dominio (export)

- `interface User` — id (number), email (string), name (string), role (`'admin' | 'user'`). **Niente password** nel tipo pubblico.
- `interface TokenPayload` (puoi tenerlo privato al modulo) — `sub` (number, l'id), `role` (User['role']), `exp` (number, ms epoch).
- `const STORAGE_KEY = 'pc.token'` — chiave usata in `localStorage`.

### Stato del service

- `private _user = signal<User | null>(null)` — stato interno.
- `readonly currentUser = this._user.asReadonly()` — read-only per i consumer (header, guard, roleGuard).
- `readonly isAuthenticated = computed(() => this._user() !== null)` — derivato booleano.

### API pubblica

- **`async login(email, password): Promise<User>`** — passi:
  1. `firstValueFrom(this.http.get<...>('http://localhost:3000/users', { params: { email } }))`. Importa `firstValueFrom` da `rxjs`.
  2. Risultato è un array (json-server filtra in `?email=`). Prendi `[0]`. Se manca o se `password` non combacia → `throw new Error('Credenziali non valide')`.
  3. Costruisci payload `{ sub: candidate.id, role: candidate.role, exp: Date.now() + 60*60*1000 }`.
  4. `const token = btoa(JSON.stringify(payload))`.
  5. `localStorage.setItem(STORAGE_KEY, token)`.
  6. Rimuovi `password` dall'utente (`const { password: _pwd, ...safeUser } = candidate`) e fai `this._user.set(safeUser)`.
  7. Ritorna `safeUser`.

- **`logout(): void`** — due righe: `localStorage.removeItem(STORAGE_KEY)` + `this._user.set(null)`. Niente `router.navigate` qui: il logout è un'azione di stato, la navigazione la fa chi lo chiama.

- **`getToken(): string | null`** — usato dall'interceptor del Lab 4b:
  1. Legge raw da `localStorage`. Se null → `return null`.
  2. Chiama `private decode(raw)` (sotto). Se decode fallisce o `payload.exp < Date.now()` → rimuovi la chiave e `return null`.
  3. Altrimenti ritorna la stringa raw (l'interceptor non ha bisogno del payload).

- **`private restoreFromStorage(): void`** — chiamato dal costruttore:
  1. Legge raw. Se null → return.
  2. Decodifica. Se invalido o scaduto → rimuovi la chiave + return.
  3. `GET http://localhost:3000/users/<payload.sub>` con `.subscribe(...)` → `this._user.set(safeUser)`. In `error`: rimuovi la chiave + `_user.set(null)`.

- **`private decode(raw: string): TokenPayload | null`** — `try { return JSON.parse(atob(raw)) as TokenPayload; } catch { return null; }`. Il try/catch è obbligatorio: se l'utente sostituisce `pc.token` in DevTools con una stringa non base64, `atob` lancia `InvalidCharacterError`.

### Costruttore

Una sola riga: `this.restoreFromStorage()`. Senza, ogni F5 azzera la sessione.

Riferimento: [Scheda 05 §"La biglietteria — AuthService"](../didattica/05-auth-jwt-refresh.md) (codice completo + i 4 perché).

---

## TODO 2 — MEDIO: Login + `authGuard` (~10 min)

### `src/app/pages/login/login.page.ts`

Il form **template-driven** del seme (`#f="ngForm"`, `[(ngModel)]`) resta com'è. Cambia solo `onSubmit`:

- inietta `ActivatedRoute`, `AuthService`, `NotificationService` (oltre a `Router` già presente);
- import: `import { AuthService } from '../../services/auth';` e `import { NotificationService } from '../../services/notification.service';`;
- in `onSubmit(isValid)` chiama `await this.auth.login(email, password)`;
- al successo: legge `route.snapshot.queryParamMap.get('returnUrl')` e fa `router.navigateByUrl(returnUrl ?? '/admin')`. Usa `snapshot` perché la login page si visita una volta sola — la subscription a `queryParamMap` sarebbe overhead inutile. Usa `navigateByUrl` (non `navigate([...])`) perché `returnUrl` è già una URL completa (es. `/admin/products?q=mac`);
- al fallimento (catch): `this.notifications.error('Credenziali non valide')` e basta — il form resta visibile, l'utente può ritentare. Non fare `console.error`: l'errore è atteso, non eccezionale.

Imports nuovi necessari nel decoratore: nessuno (`FormsModule` e `RouterLink` sono già).

### `src/app/auth-guard.ts`

Il placeholder del seme legge `localStorage.getItem('token')`. Sostituisci la logica con:

- import `AuthService` da `'./services/auth'`;
- inject di `AuthService` e `Router`;
- se `auth.isAuthenticated()` è `true` → ritorna `true`;
- altrimenti → ritorna `router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } })`. L'oggetto `UrlTree` è preferibile a `router.navigate()` dentro una guard: lascia ad Angular il controllo della navigazione e dell'ordine relativo agli altri eventi di routing.

Due cose da non scordare: usare `state.url` per `returnUrl` (è quello che la guard riceve come secondo argomento), e tipizzare la guard come `CanActivateFn` (Angular 21 idiomatic).

Riferimento: [Scheda 05 §"Lo stand chiuso — il 401"](../didattica/05-auth-jwt-refresh.md) (per `returnUrl`) e [§"Il flusso end-to-end"](../didattica/05-auth-jwt-refresh.md) (per il giro completo).

---

## TODO 3 — MEDIO: `guards/role.guard.ts` + composizione (~10 min)

### `src/app/guards/role.guard.ts`

Crea il file come **factory** — una funzione che riceve il ruolo richiesto e **ritorna** una `CanActivateFn`. La firma è `export function roleGuard(required: User['role']): CanActivateFn`.

La `CanActivateFn` ritornata, una volta invocata da Angular:

- inietta `AuthService`, `Router`, `NotificationService`;
- legge `auth.currentUser()` (il signal letto come funzione);
- se `user?.role === required` → ritorna `true`;
- altrimenti → chiama `notify.error('Accesso negato: serve il ruolo "X".')` e ritorna `router.createUrlTree(['/'])` per dirottare alla home.

Non scrivere `export const roleGuard: CanActivateFn = ...` come si farebbe per una guard semplice: qui serve la **factory** perché vogliamo poter scrivere `roleGuard('admin')` con argomenti diversi sulle stesse routes.

Imports necessari: `inject` da `'@angular/core'`, `CanActivateFn`/`Router` da `'@angular/router'`, `AuthService` + `type User` da `'../services/auth'`, `NotificationService` da `'../services/notification.service'`.

### `src/app/features/admin/admin.routes.ts`

Componi le due guard sulla rotta padre:

- aggiungi import `import { roleGuard } from '../../guards/role.guard';`;
- sostituisci `canActivate: [authGuard]` (dal Lab 3a) con `canActivate: [authGuard, roleGuard('admin')]`.

L'ordine `[authGuard, roleGuard]` è motivato nella [Scheda 05 §"Autenticazione vs autorizzazione"](../didattica/05-auth-jwt-refresh.md): Angular valuta in AND, e se l'utente non è loggato non vogliamo nemmeno mostrargli il toast "accesso negato" — vogliamo mandarlo a `/login`.

---

## Criteri di verifica

### Funzionali (manuali, in DevTools)

- [ ] Login `admin@overnet.it / demo123` → atterri su `/admin`, in `localStorage` c'è la chiave `pc.token` con un valore base64. Verifica con `atob('<token>')` da console: ottieni `{"sub":1,"role":"admin","exp":...}`.
- [ ] In header dell'app appare il nome dell'utente loggato (se il componente header consuma `currentUser` — questo è seme/Lab 4a successivo).
- [ ] Click su "Logout" (o `auth.logout()` da console) → la chiave sparisce, refresh di `/admin` ti porta su `/login?returnUrl=/admin`. Dopo nuovo login, atterri di nuovo su `/admin`.
- [ ] Login `user@overnet.it / demo123` → entri nell'app ma `/admin` mostra un toast "Accesso negato" e ti redirige su `/`.
- [ ] In DevTools → Application → Local Storage → modifica `pc.token` con `"ciao"` e ricarica. L'header non mostra più l'utente, niente errori in console, `pc.token` sparisce dallo storage.
- [ ] Credenziali sbagliate al login → toast "Credenziali non valide", resti sulla pagina di login.
- [ ] Refresh con `pc.token` valido → l'utente resta loggato (`restoreFromStorage` fa il suo dovere).

### Formali (binario A — solution applicata a `product-catalog-finale/`)

```bash
cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test --watch=false
```

Zero errori, tutti i test verdi.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| Login OK ma al refresh perdi l'utente loggato | `restoreFromStorage` non c'è o non popola il signal | TODO 1, costruttore + `restoreFromStorage` |
| `/admin` non parte mai, redirect immediato a `/login` anche dopo login | `auth-guard.ts` non legge `AuthService.isAuthenticated()`, oppure il signal è ancora `null` perché `restoreFromStorage` non è stato chiamato | TODO 2 (`auth-guard`) + TODO 1 (costruttore) |
| Toast "Accesso negato" appare anche per admin | `roleGuard` confronta `role` con stringa hardcoded sbagliata, oppure `currentUser()` ritorna `null` perché `restoreFromStorage` è ancora in volo (race al boot) | TODO 3 / TODO 1 |
| `inject() can only be used within an injection context` nel roleGuard | Stai chiamando `inject()` **fuori** dalla `CanActivateFn` ritornata, nella body della factory | TODO 3 |
| `cannot read properties of null` su `candidate.password` nel login | Nel `login()` confronti `password` senza prima controllare che `candidate` esista | TODO 1, login passo 2 |
| `InvalidCharacterError: atob` al refresh | Manca il `try/catch` in `decode()`. Un utente curioso ha modificato `pc.token` in DevTools | TODO 1, `decode()` |
| Login funziona ma in `pc.token` finisce un oggetto JSON visibile (non base64) | Ti sei dimenticato il `btoa()` o hai salvato direttamente `JSON.stringify(payload)` | TODO 1, login passo 4-5 |
| Login OK con admin, `/admin` però redirige a `/login` (tornello al contrario) | `authGuard` ritorna `true` ma `roleGuard` legge `currentUser() === null` perché il login non ha aggiornato il signal | TODO 1, login passo 6 |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!

---

## Prossimo: [Lab 4b — Interceptors: Bearer + error handling + retry](../lab-04b-interceptors/README.md)
