# Lab 4a — Auth: AuthService + Login + Guards
## Guida per il Docente

---

## 1. Scopo Didattico

Primo dei due lab del Mod 4 (4a → 4b). Applica la **Scheda 05** (auth simulata + JWT-like + guards). L'angolazione è: "costruisci la biglietteria che gli interceptor del 4b consulteranno".

Tre messaggi chiave:

1. **Service come fonte di verità.** L'`AuthService` è l'unico posto dove si decodifica il token, si valida l'`exp`, si pulisce `localStorage` se invalido. Ogni altra parte dell'app (guard, interceptor, header) legge solo signal o chiama `getToken()`.
2. **Signal nel service, non Observable.** Lo stato user è un signal — `currentUser`, `isAuthenticated` come computed. È la stessa scelta che faremo per il `NotificationService` del Mod 1: dove non c'è bisogno di stream RxJS, signal vince per uniformità con il template.
3. **Autenticazione vs autorizzazione sono cose diverse.** `authGuard` chiede "chi sei?", `roleGuard` chiede "ti spetta entrare qui?". Componendoli in `canActivate: [authGuard, roleGuard('admin')]` separi le responsabilità — niente `if (user && user.role === 'admin')` annidato in una sola guard monolitica.

---

## 2. Timing Consigliato

**Slot orario: 15:45–16:20 (35 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo del risultato finale (login admin/user con behavior diverso) | 3 min |
| Setup | Seed `users` in `db.json` + sanity curl | 3 min |
| TODO 1 | `AuthService` (login + logout + getToken + restoreFromStorage + decode) | 15 min |
| TODO 2 | Login `onSubmit` + `auth-guard.ts` | 8 min |
| TODO 3 | `roleGuard` factory + composizione in `admin.routes.ts` | 5 min |
| Recap | Verifica visiva (login admin → admin; login user → /admin negato) | 1 min |
| **Totale** | | **~35 min** |

> Il TODO 1 è il file più grande del lab. Se la classe è in difficoltà, fai prima il `login()` insieme (live coding) e lascia che ognuno scriva `logout()`/`getToken()`/`restoreFromStorage()`/`decode()`. I `try/catch` sui `decode()` e `atob()` sono un'opportunità per parlare di "fault tolerance al confine col mondo esterno" (storage manipolato dall'utente).

---

## 3. Contesto nella Scaletta

- **Mod 4 teoria** (14:00–15:30): Schede 04 (interceptors + error + retry) e 05 (auth + JWT + refresh).
- **Lab 4a** (questo, 15:45–16:20): pacchetto AuthService + guards.
- **Lab 4b** (16:20–16:50): interceptors che consumano `AuthService.getToken()`.

Aggancio col resto del corso:

- Il `NotificationService` (M1) torna utile qui: il `roleGuard` lo usa per il toast "Accesso negato". Stesso pattern del Lab 2b.
- L'`admin.routes.ts` toccato dal Lab 3a (children + lazy) si arricchisce qui di `roleGuard('admin')`. Nessun re-write — composizione.
- La guard del Lab 3a (`authGuard` versione placeholder) viene "completata" qui: stessa interfaccia, ma legge da `AuthService` invece che da `localStorage` cruda.

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 Stato del service: signal, non Observable

```typescript
private _user = signal<User | null>(null);
readonly currentUser    = this._user.asReadonly();
readonly isAuthenticated = computed(() => this._user() !== null);
```

**Cosa dire:**
> "Lo stato user è un signal — niente `BehaviorSubject`. Perché? Tre motivi: (1) i consumer (header, guard) lo leggono nel template/closure come `user()`, uniforme col resto del seme; (2) `isAuthenticated` come `computed` è gratuito; (3) non ci sono stream HTTP da comporre — la login è una singola call. La regola: se non servono pipe RxJS (`combineLatest`, `switchMap`, ...), signal è la scelta giusta. Vedi Scheda 12 del Mod 1."

### 4.2 Token finto in `localStorage` — vs `sessionStorage` e cookie

```typescript
localStorage.setItem(STORAGE_KEY, token);
```

**Cosa dire:**
> "`localStorage` è semplice e funziona, ma in produzione un JWT non finisce in `localStorage` — finisce in un cookie HttpOnly Secure SameSite=Lax, perché localStorage è leggibile da qualsiasi script (XSS). Qui usiamo `localStorage` perché è auth **simulata** e ci serve un meccanismo di persistenza visibile in DevTools per la didattica. Per gli studenti più curiosi: in produzione il backend setta il cookie nella response del login, e il browser lo includes automaticamente nelle request future — Angular non vede mai il token in chiaro."

### 4.3 `restoreFromStorage` con HTTP al boot

```typescript
constructor() {
  this.restoreFromStorage();
}

private restoreFromStorage(): void {
  // legge token, valida exp, fa GET /users/<sub>, popola signal
}
```

**Cosa dire:**
> "Al boot, il signal parte a `null`. Se non chiamiamo `restoreFromStorage`, ogni F5 azzera la sessione anche se in `localStorage` c'è un token buono. Il pattern: leggi il token, valida `exp` lato client (così risparmiamo una request già condannata), poi GET dell'utente per popolare email+name nel signal. Alternativa progettuale (non richiesta dal lab): salvare anche l'oggetto user accanto al token in `localStorage`, zero request al boot. Tradeoff: dati staleable. La discutiamo nelle FAQ."

### 4.4 `try/catch` su `atob` — perché esiste

```typescript
private decode(raw: string): TokenPayload | null {
  try {
    return JSON.parse(atob(raw)) as TokenPayload;
  } catch {
    return null;
  }
}
```

**Cosa dire:**
> "Il `try/catch` non è cosmetico. Se l'utente apre DevTools → Application → Local Storage e sostituisce `pc.token` con `'ciao'`, al refresh `atob('ciao')` lancia `InvalidCharacterError`. Senza catch, l'app esplode prima del primo render. Con catch + return `null`, l'app si comporta come se il token non ci fosse: `restoreFromStorage` rimuove la chiave e lascia il signal a `null`. È il pattern 'fault tolerance al confine col mondo esterno' — il client storage è territorio nemico."

### 4.5 `auth-guard.ts` — `UrlTree`, non `router.navigate`

```typescript
export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isAuthenticated()) return true;

  return router.createUrlTree(['/login'], {
    queryParams: { returnUrl: state.url },
  });
};
```

**Cosa dire:**
> "Notate: ritorniamo un `UrlTree` invece di chiamare `router.navigate`. Una guard deve *ritornare* un valore (`true | false | UrlTree | Observable<...>`) — non innescare side effect. `router.navigate` dentro una guard funziona ma rompe il contratto e crea race condition con altri eventi di routing. `createUrlTree` lascia ad Angular il controllo di *quando* fare il redirect. È il pattern Angular 21 idiomatic."

### 4.6 `roleGuard` come factory

```typescript
export function roleGuard(required: User['role']): CanActivateFn {
  return (_route, _state) => {
    const auth   = inject(AuthService);
    const router = inject(Router);
    const notify = inject(NotificationService);

    const user = auth.currentUser();
    if (user?.role === required) return true;

    notify.error(`Accesso negato: serve il ruolo "${required}".`);
    return router.createUrlTree(['/']);
  };
}
```

**Cosa dire:**
> "Notate la firma: `roleGuard(...)` è una *funzione* (factory) che ritorna una `CanActivateFn`. Si chiama una volta a setup-time in `admin.routes.ts` (`roleGuard('admin')`); la `CanActivateFn` ritornata cattura `'admin'` nella closure e lo userà a ogni navigazione. Le tre `inject()` vivono DENTRO la closure ritornata perché lì c'è l'injection context al momento della navigazione — se chiamaste `inject()` nella body della factory (cioè *fuori* dalla closure), Angular lancerebbe `inject() can only be used within an injection context`. Errore tipico."

### 4.7 Composizione `[authGuard, roleGuard('admin')]` — perché quest'ordine

```typescript
canActivate: [authGuard, roleGuard('admin')],
```

**Cosa dire:**
> "Angular valuta le guard nell'ordine dell'array, in AND. `authGuard` per primo: se l'utente non è loggato, redirect a `/login` e `roleGuard` non viene mai interrogato. Importante per UX: invertendo l'ordine (`[roleGuard, authGuard]`), un utente non loggato vedrebbe il toast 'Accesso negato: serve il ruolo "admin"' un istante prima del redirect — confondente. La regola: prima autenticazione, poi autorizzazione."

---

## 5. Errori comuni degli studenti

### ❌ Errore 1: `inject()` nella body della factory invece che dentro la closure
**Sintomo:** `Error: inject() can only be used within an injection context`.
**Causa:** Lo studente scrive `inject(AuthService)` fuori dalla `CanActivateFn` ritornata.
**Fix:** Spostare le tre `inject()` *dentro* la `return (route, state) => { ... }`.

### ❌ Errore 2: `password` nel signal `_user`
**Sintomo:** funziona, ma `currentUser().password` espone la password.
**Causa:** Lo studente fa `this._user.set(candidate)` invece di rimuovere la password prima.
**Fix:** `const { password: _pwd, ...safeUser } = candidate; this._user.set(safeUser);`.

### ❌ Errore 3: Manca `restoreFromStorage()` nel costruttore
**Sintomo:** login OK, ma al primo F5 perdi l'utente loggato.
**Fix:** chiamare `this.restoreFromStorage()` nel costruttore.

### ❌ Errore 4: `try/catch` mancante su `atob`/`JSON.parse`
**Sintomo:** un'app che esplode quando l'utente manipola `pc.token` in DevTools (errore `InvalidCharacterError`).
**Fix:** wrap del decode in try/catch, return `null` sul fail.

### ❌ Errore 5: `roleGuard` legge `currentUser()` `null` quando dovrebbe vedere admin
**Sintomo:** login admin → `/admin` rifiuta con toast.
**Causa:** stai navigando a `/admin` *prima* che `restoreFromStorage` abbia popolato il signal (race al boot), oppure nel login non hai fatto `this._user.set(safeUser)` prima del navigate.
**Fix:** assicurarsi che `login()` aggiorni il signal *prima* di risolvere la Promise. Per il caso boot, alternativa è salvare l'utente intero in `localStorage` accanto al token.

### ❌ Errore 6: `router.navigate(...)` invece di `createUrlTree(...)` dentro la guard
**Sintomo:** funziona ma triggerano warning di "Navigation cancellation: redirect during navigation".
**Fix:** ritornare `router.createUrlTree([...], { queryParams })`.

### ❌ Errore 7: Confronto password senza check di esistenza
**Sintomo:** `TypeError: Cannot read properties of undefined (reading 'password')` quando si tenta login con email inesistente.
**Causa:** `if (candidate.password !== password)` senza prima `if (!candidate)`.
**Fix:** `if (!candidate || candidate.password !== password) throw new Error(...)`.

### ❌ Errore 8: Ordine `[roleGuard, authGuard]` in `canActivate`
**Sintomo:** utenti non loggati vedono per un istante il toast "Accesso negato" prima del redirect a `/login`.
**Fix:** `[authGuard, roleGuard('admin')]` — autenticazione prima.

### ❌ Errore 9: Login con `navigate([returnUrl])` invece di `navigateByUrl(returnUrl)`
**Sintomo:** `returnUrl=/admin/products?q=mac` → `navigate` lo interpreta come segmento e va a `/%2Fadmin%2Fproducts%3Fq%3Dmac`.
**Fix:** `router.navigateByUrl(returnUrl ?? '/admin')` — `navigateByUrl` accetta URL complete.

---

## 6. Domande frequenti

**Q: Perché auth simulata e non un vero JWT con firma?**
A: Perché il valore didattico del lab è il *pattern Angular* (service + signal + interceptor + guard), non la crittografia. Implementare la verifica della firma RSA lato client sarebbe didatticamente fuorviante: in produzione la firma la verifica il *server*, il client può solo leggere il payload. Il nostro `btoa(JSON.stringify(...))` è strutturalmente identico al payload di un JWT — header e firma omessi. Quando in produzione il backend diventa reale, il codice Angular qui scritto non cambia. Cambia solo `login()` che chiamerà `POST /api/login` invece di `GET /users?email=…`.

**Q: Se metto `pc.token` con un valore base64 valido ma con `exp` futura, posso falsificare un login?**
A: Sì — e questo è precisamente il motivo per cui in produzione il token va *firmato* e la firma va verificata dal server. Il nostro check di `exp` lato client è una "ottimizzazione" (evita request inutili), non una garanzia. La verità è il server. Per il lab, simuliamo: in `restoreFromStorage` facciamo `GET /users/<sub>` — se l'id non esiste, l'app si "scioglie" da sola. Imperfetto ma sufficiente per la didattica.

**Q: Posso evitare la GET in `restoreFromStorage` salvando l'oggetto utente in `localStorage`?**
A: Sì, e in tante app reali si fa così. Tradeoff: l'utente è "staleable" — se in altra tab cambi il nome/email, questa tab continuerebbe a vederlo vecchio fino al prossimo login. La GET è la scelta più conservativa per la verità dello stato, al costo di una request al boot. In produzione: dipende dal flusso.

**Q: `currentUser.asReadonly()` impedisce davvero le modifiche dall'esterno?**
A: A livello TypeScript, sì — `Signal<T>` (read-only) non ha `.set()` o `.update()`. A runtime, JS non ha veri private — `(authService as any).["_user"]` può aggirare tutto. Il `private` + `asReadonly` esprimono l'*intento*, e il `_` davanti al nome del signal privato è la convenzione visiva. Non è blindato, è chiaro.

**Q: Perché non gestiamo refresh token?**
A: Perché l'auth è simulata: non c'è un backend che possa rilasciare nuovi token. Il pattern refresh è coperto in teoria nella Scheda 05 (§"Refresh token: due richieste annidate") — concettualmente, l'`errorInterceptor` del 4b intercetta 401, chiama `POST /api/refresh` con il refresh token, riprova la request originale con il nuovo access token. È fattibile come bonus avanzato, ma per il timing dello slot resta teorico.

---

## 7. Adattamenti

### Classe veloce (resta tempo):
- TODO bonus: aggiungere un `<button>` "Logout" nell'header. Discutere se `(click)="auth.logout()"` da solo basta o se serve anche `router.navigate(['/home'])` dopo. Risposta: dipende — se la pagina corrente è `/admin`, dopo logout `authGuard` redirigerà automaticamente; se è `/home`, l'utente resta lì. Pulito.
- Mostrare in DevTools che cambiando il `role` di `admin@overnet.it` nel `db.json` da `admin` a `user` (richiede restart di json-server) e rifacendo login, `/admin` rifiuta. Aiuta a fissare la nozione "il role è server-driven anche nel nostro mock".

### Classe lenta:
- Saltare `restoreFromStorage`: accettare il bug "F5 perde sessione" come compromesso. Il TODO 1 si riduce a `login`+`logout`+`getToken`. Tempo risparmiato: 4 min. Costo: l'esperienza utente è meno realistica, ma il pattern guard+interceptor del 4b funziona comunque finché l'utente non ricarica.
- Saltare il `roleGuard` (TODO 3) — lasciare solo `authGuard`. Il messaggio "ruolo" lo si vede in teoria nella Scheda 05 ma non si tocca. Tempo risparmiato: 5 min. Costo: l'utente "user" può entrare in `/admin`.

### Cosa NON approfondire:
- Refresh token flow completo: copertura teorica nella Scheda 05.
- `inject(PLATFORM_ID, ...)` per SSR-safety di `localStorage`: lo affrontiamo nel Mod 6.
- `HttpInterceptor` per Bearer: è il 4b.
- OAuth/OIDC: fuori scope (corso non specialistico in auth).

---

## 8. Verifica NAP (binario A)

Stato di partenza: `product-catalog-finale/` con la solution di Lab 3c già applicata. Applicare i delta:

```bash
cp -r Corso/G2/lab-04a-auth-guards/solution/src/app/. Corso/progetto/product-catalog-finale/src/app/
cp Corso/G2/lab-04a-auth-guards/solution/db.json Corso/progetto/product-catalog-finale/db.json

cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test
```

**Verifica funzionale suggerita (manuale):**
- `npm start` (json-server + ng serve).
- Login `admin@overnet.it / demo123` → `/admin` accessibile, `pc.token` in `localStorage`.
- `atob('<token>')` da console → `{"sub":1,"role":"admin","exp":...}`.
- Logout → `pc.token` sparisce, `/admin` redirige a `/login?returnUrl=/admin`.
- Login `user@overnet.it / demo123` → entri, `/admin` → toast "Accesso negato" + redirect `/`.
- Manomettere `pc.token` con `'ciao'` → refresh → no errori, `pc.token` rimosso, header non mostra user.
- F5 con token buono → utente resta loggato.

> **Stato di partenza del Lab 4b:** la `solution/` di questo lab applicata a `product-catalog-finale/`. Lab 4b aggiungerà `authInterceptor` (Bearer) + `errorInterceptor` (401/retry/toast) + registrazione in `app.config.ts`.
