// services/auth.ts — SOLUTION Lab 4a G2
// "Biglietteria" che simula l'autenticazione su json-server.

import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface User {
  id: number;
  email: string;
  name: string;
  role: 'admin' | 'user';
}

interface TokenPayload {
  sub: number;
  role: User['role'];
  exp: number;
}

const API_HOST = 'http://localhost:3000';
const STORAGE_KEY = 'pc.token';
const ONE_HOUR_MS = 60 * 60 * 1000;

@Injectable({ providedIn: 'root' })
export class AuthService {

  private http = inject(HttpClient);

  // ✅ TODO 1 — Stato in signal: i consumer (header, guard, roleGuard) leggono reattivamente.
  private _user = signal<User | null>(null);
  readonly currentUser    = this._user.asReadonly();
  readonly isAuthenticated = computed(() => this._user() !== null);

  constructor() {
    // ✅ TODO 1 — al boot ripristina lo stato se in localStorage c'è un token ancora buono
    this.restoreFromStorage();
  }

  async login(email: string, password: string): Promise<User> {
    // ✅ TODO 1 — 1) Chiedo a json-server l'utente con quella email (filtro REST automatico)
    const found = await firstValueFrom(
      this.http.get<Array<User & { password: string }>>(`${API_HOST}/users`, { params: { email } }),
    );
    const candidate = found[0];

    // ✅ TODO 1 — 2) Confronto password LATO CLIENT (è la parte simulata; in prod lo fa il server)
    if (!candidate || candidate.password !== password) {
      throw new Error('Credenziali non valide');
    }

    // ✅ TODO 1 — 3) Costruisco il payload del token finto (forma JWT senza firma)
    const payload: TokenPayload = {
      sub: candidate.id,
      role: candidate.role,
      exp: Date.now() + ONE_HOUR_MS,
    };
    // ✅ TODO 1 — 4) Generazione token
    const token = btoa(JSON.stringify(payload));

    // ✅ TODO 1 — 5) Persistenza + 6) aggiorno il signal con l'utente PULITO (senza password)
    localStorage.setItem(STORAGE_KEY, token);
    const { password: _pwd, ...safeUser } = candidate;
    this._user.set(safeUser);
    return safeUser;
  }

  logout(): void {
    // ✅ TODO 1 — pulisce sia storage che signal. La navigazione la fa chi chiama logout().
    localStorage.removeItem(STORAGE_KEY);
    this._user.set(null);
  }

  /** Letto dall'authInterceptor (Lab 4b). Restituisce null se token assente, scaduto o malformato. */
  getToken(): string | null {
    // ✅ TODO 1
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const payload = this.decode(raw);
    if (!payload || payload.exp < Date.now()) {
      localStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return raw;
  }

  private restoreFromStorage(): void {
    // ✅ TODO 1
    const raw = localStorage.getItem(STORAGE_KEY);
    const payload = raw ? this.decode(raw) : null;
    if (!raw || !payload || payload.exp < Date.now()) {
      localStorage.removeItem(STORAGE_KEY);
      return;
    }
    // Il payload ha solo sub/role/exp: per popolare email/name pesco l'utente dal backend.
    this.http.get<User & { password: string }>(`${API_HOST}/users/${payload.sub}`).subscribe({
      next: user => {
        const { password: _pwd, ...safeUser } = user;
        this._user.set(safeUser);
      },
      error: () => {
        // Il backend è giù o l'utente non esiste più → svuoto lo stato per coerenza.
        localStorage.removeItem(STORAGE_KEY);
        this._user.set(null);
      },
    });
  }

  private decode(raw: string): TokenPayload | null {
    // ✅ TODO 1 — try/catch obbligatorio: chi manomette pc.token in DevTools non deve rompere l'app
    try {
      return JSON.parse(atob(raw)) as TokenPayload;
    } catch {
      // raw non è base64 valido
      return null;
    }
  }
}
