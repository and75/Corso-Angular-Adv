// auth-guard.ts — SOLUTION Lab 4a G2
// Legge AuthService.isAuthenticated() (signal-aware) e propaga la rotta richiesta come returnUrl.

import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
import { AuthService } from './services/auth';

export const authGuard: CanActivateFn = (_route, state) => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  // ✅ TODO 2
  if (auth.isAuthenticated()) return true;

  // Non autenticato → redirige a /login conservando la rotta richiesta come returnUrl,
  // così dopo il login l'utente atterra esattamente dove voleva andare.
  return router.createUrlTree(['/login'], {
    queryParams: { returnUrl: state.url },
  });
};
