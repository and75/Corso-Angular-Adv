// features/admin/admin.routes.ts — SOLUTION Lab 4a G2
// Composizione `[authGuard, roleGuard('admin')]` sul livello padre.

import { Routes } from '@angular/router';
import { AdminLayout } from './admin-layout/admin-layout';
import { Admin } from '../../pages/admin/admin.page';
import { AdminList } from './pages/admin-list/admin-list';
import { ProductFormPage } from '../../pages/product-form/product-form.page';
import { authGuard } from '../../auth-guard';
import { roleGuard } from '../../guards/role.guard';

const adminRoutes: Routes = [
  {
    path: '',
    component: AdminLayout,
    // ✅ TODO 3 — Ordine: authGuard prima (utente non loggato → /login),
    //    roleGuard dopo (utente loggato senza ruolo admin → toast + redirect a /).
    //    Angular valuta in AND.
    canActivate: [authGuard, roleGuard('admin')],
    children: [
      { path: '', pathMatch: 'full', component: Admin },
      { path: 'products', component: AdminList },
      { path: 'products/:id/edit', component: ProductFormPage },
    ],
  },
];

export default adminRoutes;
