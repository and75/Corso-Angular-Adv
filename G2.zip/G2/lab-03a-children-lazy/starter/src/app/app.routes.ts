// app.routes.ts — STARTER Lab 3a G2
//
// Stato di partenza: rotta `admin` flat con component diretto.
// Obiettivo: sostituirla con loadChildren su admin.routes.ts (feature area lazy).

import { Routes } from '@angular/router';
import { HomePage } from './pages/home/home.page';
import { authGuard } from './auth-guard';
import { Login } from './pages/login/login.page';
import { Admin } from './pages/admin/admin.page';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomePage },
  { path: 'login', component: Login },

  /*
   * TODO 1 — Sostituisci la rotta 'admin' flat con una rotta LAZY (loadChildren).
   *
   *   Stato attuale (la riga sotto, da SOSTITUIRE):
   *     { path: 'admin', canActivate: [authGuard], component: Admin },
   *
   *   Target:
   *    - path: 'admin' invariato
   *    - NIENTE canActivate qui (la guard si sposta dentro admin.routes.ts, sul padre della feature area)
   *    - NIENTE component (qui si delega: il padre del file di rotte ha il component AdminLayout)
   *    - loadChildren: funzione () => import('./features/admin/admin.routes').then(m => m.default)
   *
   *   ⚠️ Il `.then(m => m.default)` è OBBLIGATORIO: admin.routes.ts esporta come default export
   *      (e senza, il `.then` cattura `undefined` → crash a runtime).
   *
   *   Vedi Scheda 02 G2 §"loadChildren: la sintassi" e Lab 3a README §TODO 1.
   *
   *   Dopo aver fatto la sostituzione: l'import di `Admin` qui sopra NON serve più.
   *   Rimuovilo per evitare warning di "unused import".
   */
  { path: 'admin', canActivate: [authGuard], component: Admin },

  {
    path: 'checkout',
    loadComponent: () =>
      import('./pages/checkout/checkout.page').then(m => m.CheckoutPage),
  },
  // ✅ products/new PRIMA di products/:id — "new" non venga catturato come :id
  {
    path: 'products/new',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./pages/product-form/product-form.page').then(m => m.ProductFormPage),
  },
  {
    path: 'products/:id',
    loadComponent: () =>
      import('./pages/product-detail/product-detail.page').then(m => m.ProductDetailPage),
  },
];
