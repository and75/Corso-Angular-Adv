/**
 * features/admin/pages/admin-list/admin-list.ts — STARTER Lab 3a G2
 *
 * Lista prodotti area admin — versione BASE (TODO 2).
 * In questo lab si mostra solo l'elenco con un link "Modifica" per riga.
 * Filtro/paginazione via querystring arrivano nel Lab 3b — qui niente queryParams.
 *
 * Vedi Scheda 02 G2 §"Children routing" e Lab 3a README §TODO 2.
 */

import { Component, DestroyRef, inject, signal } from '@angular/core';

// TODO 2 — Import necessari (da aggiungere qui):
//   - RouterLink (da '@angular/router')        link "Modifica" relativo a /admin/products
//   - CurrencyPipe (da '@angular/common')      formattazione prezzo nel template
//   - takeUntilDestroyed (da '@angular/core/rxjs-interop')   auto-unsubscribe sul destroy
//   - ProductService (da '../../../../services/product')    servizio del seme
//   - Product (da '../../../../product.model')              tipo dei prodotti

/*
 * TODO 2 — Decoratore @Component standalone:
 *
 *   selector: 'app-admin-list'
 *   standalone: true
 *   imports: [ RouterLink, CurrencyPipe ]
 *   templateUrl: './admin-list.html'
 */

/*
 * TODO 2 — Classe AdminList con:
 *
 *  Campi privati iniettati:
 *    private svc        = inject(ProductService)
 *    private destroyRef = inject(DestroyRef)
 *
 *  Stato esposto al template:
 *    readonly products = signal<Product[]>([])
 *
 *  Nel constructor:
 *    this.svc.getProducts()
 *      .pipe( takeUntilDestroyed(this.destroyRef) )
 *      .subscribe(list => this.products.set(list));
 *
 *  Pattern: signal + Observable. Il signal `products` è ciò che il template legge
 *  (signal-friendly), l'Observable di getProducts() è la sorgente HTTP.
 *  Il takeUntilDestroyed evita memory leak se l'utente naviga via durante la GET.
 */
