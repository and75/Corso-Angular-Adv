/**
 * features/admin/admin-layout/admin-layout.ts — STARTER Lab 3a G2
 *
 * Layout component dell'area admin (TODO 2). Stateless: delega tutto al router.
 *
 * Vedi Scheda 02 G2 §"Children routing — il layout con outlet interno"
 * e Lab 3a README §TODO 2.
 */

import { Component } from '@angular/core';

// TODO 2 — Import necessari dal '@angular/router':
//   - RouterLink         per i link della sidebar (Dashboard, Prodotti, Aggiungi)
//   - RouterLinkActive   per evidenziare il link della rotta corrente
//   - RouterOutlet       per il <router-outlet /> interno (dove montano i children)

/*
 * TODO 2 — Decoratore @Component standalone:
 *
 *   selector: 'app-admin-layout'
 *   standalone: true
 *   imports: [ RouterLink, RouterLinkActive, RouterOutlet ]
 *   templateUrl: './admin-layout.html'
 *
 *   La classe è VUOTA: AdminLayout non ha logica. Tutta la struttura è nel template.
 *
 *     export class AdminLayout {}
 */
