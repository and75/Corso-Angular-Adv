/**
 * features/admin/admin.routes.ts — STARTER Lab 3a G2
 *
 * Nuovo file: contiene le rotte della feature area admin. Verrà caricato lazy dal
 * router padre (app.routes.ts TODO 1) tramite loadChildren.
 *
 * Vedi Scheda 02 G2 §"admin.routes.ts — il file di rotte della feature".
 */

import { Routes } from '@angular/router';

// TODO 1 + TODO 2 — Import necessari (da aggiungere qui sopra):
//   - AdminLayout: il layout component (TODO 2, lo creerai in admin-layout/).
//     Import da './admin-layout/admin-layout'.
//   - authGuard: la functional guard del seme.
//     Import da '../../auth-guard'.
//   - Admin: la pagina admin esistente del seme (children landing).
//     Import da '../../pages/admin/admin.page'.
//   - AdminList: il nuovo componente di lista admin (TODO 2, lo creerai in pages/admin-list/).
//     Import da './pages/admin-list/admin-list'.
//   - ProductFormPage: la pagina di form esistente del seme (children edit).
//     Import da '../../pages/product-form/product-form.page'.

/*
 * TODO 1 + TODO 2 + TODO 3 — Costruisci l'array di rotte della feature.
 *
 *   Una sola rotta PADRE con N children:
 *
 *    Rotta padre:
 *      - path: ''                    matcha esattamente '/admin' (path RELATIVO al prefisso del loadChildren)
 *      - component: AdminLayout      layout con sidebar + <router-outlet /> interno (TODO 2)
 *      - canActivate: [authGuard]    guard a livello di AREA: vale per TUTTI i children (TODO 1)
 *      - children: [ ... ]           array di 3 children (TODO 2 + TODO 3)
 *
 *    Children (in questo ordine):
 *      1. path '' + pathMatch: 'full' + component: Admin       ← landing del seme (TODO 3, pathMatch full)
 *      2. path 'products' + component: AdminList               ← lista admin nuova (TODO 2)
 *      3. path 'products/:id/edit' + component: ProductFormPage ← riuso del seme (TODO 2)
 *
 *   Note:
 *    - I path dei children sono RELATIVI al padre (es. 'products' → /admin/products).
 *    - pathMatch: 'full' sul children '' evita di fare match accidentale su /admin/qualcosa.
 *    - Admin e ProductFormPage sono componenti ESISTENTI del seme — non li ricrei.
 *
 *   Dichiara la costante:
 *     const adminRoutes: Routes = [ ... ];
 */

/*
 * TODO 1 — [CRUCIALE] Default export delle rotte:
 *
 *     export default adminRoutes;
 *
 *   loadChildren cerca `.default` sul modulo dinamico. Senza questa riga, il
 *   `.then(m => m.default)` in app.routes.ts riceve `undefined` → crash a runtime
 *   navigando '/admin'. TypeScript NON lo segnala (loadChildren accetta qualsiasi
 *   callback che ritorni Promise<Routes>).
 *
 *   Vedi Scheda 02 G2 §"Errori comuni — 1. loadChildren senza default export".
 */
