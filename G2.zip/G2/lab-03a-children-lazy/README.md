# Lab 3a — Children routing + lazy area `features/admin/`
### Giorno 2 · Lab guidato (~20 min) · Slot 12:15–12:35

---

## Obiettivo

Applicare il pattern della [Scheda 02 — Feature areas, children, `loadChildren`](../didattica/02-children-loadchildren.md) ristrutturando l'area `/admin` del Product Catalog. Si passa da una rotta **flat** (oggi `{ path: 'admin', component: Admin }` nel seme) a una **feature area lazy** con:

1. `features/admin/admin.routes.ts` con **default export** caricato da `loadChildren`.
2. Un `AdminLayout` con sidebar + `<router-outlet />` interno.
3. **Tre children**: landing (riuso `Admin` del seme), lista admin (`AdminList` nuovo — versione base senza filtri), edit prodotto (riuso `ProductFormPage` del seme).
4. `canActivate: [authGuard]` sul padre della feature area: una sola riga di guard per tutto.

Risultato visivo:

- `/admin` → AdminLayout con sidebar a sinistra e landing del seme nel main.
- `/admin/products` → lista prodotti admin con pulsante "Modifica" per riga.
- `/admin/products/3/edit` → `ProductFormPage` esistente in modalità edit, montato dentro AdminLayout.
- DevTools → Network: navigando per la prima volta su `/admin` si scarica un chunk lazy dedicato (`admin-…js`).

> **Cosa non si fa qui:** filtro/paginazione via querystring (Lab 3b) e pannello laterale con named outlet (Lab 3c). Lo stato di partenza del Lab 3b è esattamente la `solution/` di questo lab.

---

## Gerarchia rotte target

```
ROOT (app.routes.ts)                                  app.html
├── '' → 'home'                                       <router-outlet />              ← OUTLET ROOT (primary)
├── 'home'        → HomePage                                  │
├── 'login'       → Login                                     │
├── 'admin'       → loadChildren(admin.routes)               │ /admin → AdminLayout
│                                                             │
├── 'checkout'    → loadComponent                            ▼ admin-layout.html
├── 'products/new'                                       AdminLayout (sidebar + )
└── 'products/:id'                                            <router-outlet />      ← OUTLET INTERNO
                                                                   │
                                                                   │  '' → Admin (landing)
                                                                   │  'products' → AdminList
                                                                   │  'products/:id/edit' → ProductFormPage
```

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/app.routes.ts` | Sostituire rotta `admin` flat con `loadChildren` | modificato |
| `src/app/features/admin/admin.routes.ts` | Default export `Routes` con `AdminLayout` + children | **nuovo** |
| `src/app/features/admin/admin-layout/admin-layout.ts` + `.html` | Layout con sidebar + `<router-outlet />` interno | **nuovo** |
| `src/app/features/admin/pages/admin-list/admin-list.ts` + `.html` | Lista prodotti admin (versione base, senza filtri) | **nuovo** |

> La pagina `pages/admin/admin.page.ts` esistente **non viene modificata** — diventa il children `''` di `/admin` (landing). Il `pages/product-form/` esistente **non viene modificato** — diventa il children `products/:id/edit` di `/admin`.

---

## Scaffolding — comandi Angular CLI

Tre artefatti nuovi: due componenti standalone e un file di rotte. Solo i componenti hanno uno schematic dedicato; `admin.routes.ts` lo crei a mano.

```bash
cd Corso/progetto/product-catalog

# AdminLayout
ng generate component features/admin/admin-layout --skip-tests
# alias breve:
ng g c features/admin/admin-layout --skip-tests

# AdminList
ng generate component features/admin/pages/admin-list --skip-tests
# alias breve:
ng g c features/admin/pages/admin-list --skip-tests
```

Note Angular 21:
- `ng g c` genera componenti `standalone: true` di default — niente `NgModule` da toccare.
- Il file si chiama `admin-layout.ts` (non `admin-layout.component.ts`): in Angular 20+ il suffisso `.component.ts` non è più obbligatorio. La classe però resta `AdminLayout` (PascalCase).
- `--skip-tests` evita di generare `*.spec.ts` (test della solution sono curati a parte).

`admin.routes.ts` non ha schematic: crea il file vuoto a mano dentro `src/app/features/admin/`.

> `ng` diretto perché in aula la CLI è installata globalmente. I comandi di verifica restano con `npx` (`npx ng build`/`npx ng test`).

---

## TODO 1 — FACILE: feature area + `loadChildren` (~7 min)

### `src/app/features/admin/admin.routes.ts` — nuovo

Crea il file e dichiara un array `Routes` con una **sola rotta padre**:

- `path: ''` — matcha esattamente `/admin` (è relativo al prefisso del `loadChildren`).
- `component: AdminLayout` — il layout che creerai nel TODO 2.
- `canActivate: [authGuard]` — la guard `authGuard` esistente nel seme. Importala da `'../../auth-guard'`. Mettendola qui copre **tutta** la feature area: ogni children eredita il check.
- `children: []` — array vuoto per ora; lo popoli nel TODO 2.

Alla fine del file aggiungi `export default adminRoutes` (dove `adminRoutes` è il nome della costante che hai dichiarato). Il **default export è obbligatorio**: `loadChildren` cerca `.default` sul modulo dinamico.

### `src/app/app.routes.ts` — modificato

Sostituisci la rotta `{ path: 'admin', canActivate: [authGuard], component: Admin }` con una rotta che usa **`loadChildren`** invece di `component`. La funzione di `loadChildren` fa `import('./features/admin/admin.routes')` e ritorna `m.default`. Il `canActivate` non serve più qui — lo gestisce il padre interno della feature area.

Rimuovi anche l'import di `Admin` da `app.routes.ts` (non serve più qui — verrà importato dentro `admin.routes.ts`).

Riferimento: [Scheda 02 §"admin.routes.ts — il file di rotte della feature"](../didattica/02-children-loadchildren.md).

---

## TODO 2 — MEDIO: `AdminLayout` + 3 children (~10 min)

### `features/admin/admin-layout/admin-layout.ts`

Componente standalone con selector `app-admin-layout` e templateUrl `./admin-layout.html`. Negli `imports` servono `RouterLink`, `RouterLinkActive`, `RouterOutlet`. La classe non ha logica — `export class AdminLayout {}`.

### `features/admin/admin-layout/admin-layout.html`

Layout a due colonne con Tailwind: sidebar a sinistra (200px), main a destra. Schema:

```
<div class="grid grid-cols-[200px_1fr] ...">
  <aside>
    <nav> tre <a routerLink="..."> ... </a> </nav>
  </aside>
  <main>
    <router-outlet />          ← OUTLET INTERNO
  </main>
</div>
```

I tre link della sidebar — attenzione alle differenze di routing:

| Etichetta | `routerLink` | Note |
|---|---|---|
| Dashboard | `""` (vuoto) | **Relativo**, matcha esattamente `/admin`. Aggiungi `[routerLinkActiveOptions]="{ exact: true }"` altrimenti resta attivo su qualsiasi rotta admin. |
| Prodotti | `"products"` (senza `/`) | **Relativo** → `/admin/products`. |
| + Aggiungi prodotto | `"/products/new"` (con `/`) | **Assoluto** — punta alla rotta top-level del seme, fuori dall'area admin. |

Per la classe attiva: `routerLinkActive="bg-teal-100 font-semibold"` (o equivalente).

### `features/admin/pages/admin-list/admin-list.ts` + `.html`

Versione **base** della lista admin — niente querystring qui (è il topic del Lab 3b). Il componente:

- inietta `ProductService` (da `'../../../../services/product'`) e `DestroyRef`;
- ha un `signal<Product[]>([])` chiamato `products`;
- nel costruttore sottoscrive `svc.getProducts().pipe(takeUntilDestroyed(destroyRef))` e fa `this.products.set(list)`.

Template: header con titolo, poi un `@for (p of products(); track p.id)` che mostra ogni prodotto in una riga con nome, categoria, prezzo formattato (`{{ p.price | currency:'EUR':'symbol':'1.0-0' }}`), e un link **relativo** `[routerLink]="[p.id, 'edit']"` con etichetta "Modifica". Usa `@empty` per il caso lista vuota.

Imports necessari del componente: `RouterLink`, `CurrencyPipe` (da `@angular/common`), `Product` (da `'../../../../product.model'`).

### Popolare i children in `admin.routes.ts` (TODO 2 chiude qui)

Torna in `admin.routes.ts` (TODO 1) e popola l'array `children` della rotta padre con **tre rotte**:

| path | component | Note |
|---|---|---|
| `''` | `Admin` | Landing del seme. Aggiungi `pathMatch: 'full'` — è il punto del TODO 3, evita match accidentali. |
| `'products'` | `AdminList` | Nuovo componente di questo lab. |
| `'products/:id/edit'` | `ProductFormPage` | Riuso del seme — il form di edit prodotto esistente. |

Import necessari nell'`admin.routes.ts`: `Admin` (`'../../pages/admin/admin.page'`), `AdminList` (`'./pages/admin-list/admin-list'`), `ProductFormPage` (`'../../pages/product-form/product-form.page'`), `authGuard` (`'../../auth-guard'`), `AdminLayout` (`'./admin-layout/admin-layout'`).

Riferimento: [Scheda 02 §"Children routing — il layout con outlet interno"](../didattica/02-children-loadchildren.md).

---

## TODO 3 — FACILE: navigazione e redirect (~3 min)

Il `pathMatch: 'full'` sul children `''` (landing) è già stato impostato nel TODO 2 sopra. Resta da **testare a mano** le navigazioni nel browser:

- [ ] `/admin` → vedi sidebar e landing.
- [ ] `/admin/products` → sidebar + lista prodotti con "Modifica" per riga.
- [ ] `/admin/products/3/edit` → sidebar + `ProductFormPage` in modalità edit.
- [ ] Clic su "Dashboard" nella sidebar da `/admin/products` → torni alla landing.
- [ ] `/admin/qualcosa-che-non-esiste` → cosa succede? Decidi se vuoi un fallback `{ path: '**', redirectTo: '' }` come ultimo children, oppure lasciare il 404 nativo.

Riferimento: [Scheda 02 §"Rotte relative e redirect nel contesto children"](../didattica/02-children-loadchildren.md).

---

## Criteri di verifica

- [ ] `/admin` mostra AdminLayout con sidebar + landing del seme dentro al main.
- [ ] La sidebar permette di navigare a `/admin/products` senza ricaricare la pagina.
- [ ] `/admin/products` mostra l'elenco dei prodotti del catalogo (nome, categoria, prezzo).
- [ ] Cliccando "Modifica" su un prodotto si naviga a `/admin/products/3/edit` e si vede `ProductFormPage` montato dentro AdminLayout.
- [ ] Senza login (svuota `localStorage.token`) il navigate a `/admin` redirige a `/login` (la guard sull'area funziona).
- [ ] DevTools → Network → la prima visita a `/admin` scarica un chunk lazy dedicato (`admin-…js` o simile).
- [ ] `ng serve` senza errori, console del browser pulita.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| `Cannot read properties of undefined (reading '...')` su `/admin` | Manca `export default adminRoutes;` in `admin.routes.ts` | TODO 1 |
| `/admin` mostra l'AdminLayout ma il main è vuoto | Dimenticato `<router-outlet />` interno in `admin-layout.html`, oppure manca un children con `path: ''` | TODO 2 |
| Cliccando sulla sidebar "Prodotti" si naviga fuori dall'area admin | `routerLink` assoluto (`/products`) invece che relativo (`products`) — punta alla rotta top-level del seme | TODO 2 |
| "Dashboard" nella sidebar resta sempre attivo, anche su `/admin/products` | Manca `[routerLinkActiveOptions]="{ exact: true }"` sul link Dashboard | TODO 2 |
| `Cannot find module './pages/admin-list/admin-list'` | Nome file errato (Angular 21 → `admin-list.ts`, non `admin-list.component.ts`) | TODO 2, scaffolding |
| `RouterOutlet`/`RouterLink`/`RouterLinkActive` non riconosciuti nel template | Mancano negli `imports` del component standalone corrispondente | TODO 2 |
| `/admin/products/3/edit` mostra il form ma fuori dall'AdminLayout | Hai messo `products/:id/edit` come rotta top-level in `app.routes.ts` invece che come children di `admin.routes.ts` | TODO 2 |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!

---

## Prossimo: [Lab 3b — Querystring filter + paginazione](../lab-03b-querystring/README.md)
