# Lab 3a — Children routing + lazy area
## Guida per il Docente

---

## 1. Scopo Didattico

Primo dei tre lab del Mod 3 (3a → 3b → 3c). Applica la **prima metà** della Scheda 02 (feature areas + `loadChildren` + children + layout component). Lascia querystring e named outlet ai lab successivi per non saturare la classe.

Tre messaggi chiave:

1. **Le pagine esistenti si riusano, non si riscrivono.** `Admin` (landing) e `ProductFormPage` diventano children di `/admin` senza modifiche al loro codice. Il routing è un layer di "composizione" sopra ai componenti, non un layer che li tocca.
2. **`loadChildren` cambia la granularità del code-splitting**, non la sintassi di Angular. Non è "più magico" — è solo un modo di organizzare meglio.
3. **Una guard sul padre vale per tutti i children.** Aggiungere children domani non richiede di ricordarsi della guard.

---

## 2. Timing Consigliato

**Slot orario: 12:15–12:35 (20 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo del risultato finale (sidebar + lazy chunk in DevTools) | 2 min |
| TODO 1 | Feature area + loadChildren | 7 min |
| TODO 2 | AdminLayout + 3 children + AdminList base | 8 min |
| TODO 3 | Test navigazione/redirect | 2 min |
| Recap | Verifica visiva + ponte al 3b | 1 min |
| **Totale** | | **~20 min** |

> Se la classe è in difficoltà sul TODO 2 (molti file da toccare in poco tempo), fai il `ng g c` insieme proiettando lo schermo. Il TODO 1 è il vero "perché" del lab — il TODO 2 è scrittura.

---

## 3. Contesto nella Scaletta

Lab 3a apre il blocco lab del Mod 3 (12:15–13:00) ed è il fondamento dei due successivi:

- **Lab 3b — Querystring** (12:35–12:50): parte dalla solution del 3a e arricchisce `AdminList` con `queryParams`.
- **Lab 3c — Named outlet** (12:50–13:00): parte dalla solution del 3b e aggiunge il pannello laterale cart.

Aggancio col resto del corso:

- Riusa il `ProductFormPage` modificato nel mini-lab-form (M2) — i validator cross-field e async sopravvivono al move sotto area admin lazy.
- Anticipa **Mod 4** (interceptor): la guard `authGuard` di oggi controlla solo `localStorage`. In M4 vedrete come un `authInterceptor` aggancia il token JWT a ogni richiesta HTTP dell'area protetta.

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 Default export di `admin.routes.ts`

```typescript
const adminRoutes: Routes = [ /* ... */ ];
export default adminRoutes;
```

**Cosa dire:**
> "Notate `export default`. `loadChildren` carica il modulo dinamico e cerca `.default`. Se esportate solo `adminRoutes` (named export) e fate `.then(m => m.default)`, ricevete `undefined`. Errore subdolo: TypeScript non si lamenta perché la firma di `loadChildren` accetta qualsiasi callback che ritorni `Promise<Routes>`. Vedete il crash solo a runtime navigando `/admin`."

### 4.2 Riuso di componenti esistenti come children

```typescript
import { Admin } from '../../pages/admin/admin.page';
import { ProductFormPage } from '../../pages/product-form/product-form.page';

children: [
  { path: '',                  pathMatch: 'full', component: Admin },
  { path: 'products',          component: AdminList },
  { path: 'products/:id/edit', component: ProductFormPage },
]
```

**Cosa dire:**
> "`Admin` e `ProductFormPage` sono i componenti del seme — non li tocchiamo. Il routing è solo un layer di composizione: dice 'in questo punto monta quel componente'. Lo stesso componente può vivere a `/products/new` (rotta top-level) e a `/admin/products/:id/edit` (children dell'area admin) senza modifiche. È esattamente il valore del decoupling `loadComponent`/`component`."

### 4.3 Guard sul padre eredita ai children

```typescript
{
  path: '',
  component: AdminLayout,
  canActivate: [authGuard],     // ← vale per TUTTI i children
  children: [ /* landing, lista, edit */ ],
}
```

**Cosa dire:**
> "Una sola riga di guard per tutta l'area. Aggiungere children domani non richiede di ricordarsi della guard — è automatica. Questo è il motivo per cui le feature area sono pulite anche quando crescono."

### 4.4 RouterLink relativi vs assoluti nella sidebar

```html
<a routerLink=""        ...> Dashboard           </a>    <!-- relativo, vuoto → /admin -->
<a routerLink="products" ...> Prodotti           </a>    <!-- relativo → /admin/products -->
<a routerLink="/products/new" ...> + Aggiungi    </a>    <!-- ASSOLUTO → /products/new (top-level) -->
```

**Cosa dire:**
> "Il `/` iniziale conta. Senza `/`, `routerLink` è relativo al padre — qui `/admin`. Con `/`, è assoluto. La sidebar deve usare i relativi per i link interni all'area (Dashboard, Prodotti) e l'assoluto per i link che escono dall'area (Aggiungi prodotto, che è una rotta top-level del catalogo). Se domani il prefisso cambia da `/admin` a `/dashboard/admin`, **non dovete toccare nessun link relativo**. È hard-codare il prefisso che vi mette nei guai dopo un refactor."

### 4.5 `pathMatch: 'full'` sul children `''`

```typescript
{ path: '', pathMatch: 'full', component: Admin }
```

**Cosa dire:**
> "Senza `pathMatch: 'full'`, Angular matcha il path vuoto anche su `/admin/qualcosa`, e fa apparire `Admin` insieme alla rotta che cercavate. Su un layout così semplice spesso non si vede, ma se aggiungete redirect o configurazioni più complesse il match parziale crea ambiguità. Mettete `full` ogni volta che dichiarate un children vuoto come landing."

### 4.6 AdminList versione base — niente querystring (ancora)

```typescript
export class AdminList {
  private svc        = inject(ProductService);
  private destroyRef = inject(DestroyRef);

  readonly products = signal<Product[]>([]);

  constructor() {
    this.svc.getProducts()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(list => this.products.set(list));
  }
}
```

**Cosa dire:**
> "Questa è la versione semplice: lista piatta, niente filtri, niente paginazione. Volutamente. Nel Lab 3b la arricchiamo con `q` e `page` dalla querystring. Il pattern `signal + subscribe con takeUntilDestroyed` ve lo presento qui per non doverlo introdurre insieme alle nuove cose del 3b."

---

## 5. Errori comuni degli studenti

### ❌ Errore 1: `loadChildren` senza `.then(m => m.default)`
**Sintomo:** crash a runtime navigando `/admin`.
**Causa:** dimenticato il `.then` oppure usato il named export del file di rotte.
**Fix:** `loadChildren: () => import('./features/admin/admin.routes').then(m => m.default)` + `export default adminRoutes` nel file di rotte.

### ❌ Errore 2: `<router-outlet />` interno dimenticato nel layout
**Sintomo:** sidebar appare, contenuto dei children non si vede.
**Fix:** controllare `admin-layout.html` — deve avere `<router-outlet />` dentro al `<main>`.

### ❌ Errore 3: RouterLink assoluto nei link interni della sidebar
**Sintomo:** cliccando "Prodotti" si naviga a `/products` (top-level del catalogo) invece che `/admin/products`.
**Fix:** rimuovere lo `/` iniziale.

### ❌ Errore 4: `[routerLinkActiveOptions]="{ exact: true }"` dimenticato sul link Dashboard
**Sintomo:** "Dashboard" resta evidenziato anche su `/admin/products`.
**Causa:** senza `exact: true`, il match `routerLinkActive` su `""` matcha qualsiasi sotto-rotta di `/admin`.
**Fix:** aggiungere `[routerLinkActiveOptions]="{ exact: true }"` al solo link Dashboard.

### ❌ Errore 5: `canActivate` dimenticato sul padre
**Sintomo:** senza login si entra in `/admin`.
**Fix:** `canActivate: [authGuard]` sulla rotta padre `path: ''` di `admin.routes.ts`. Non sui children — il padre eredita.

### ❌ Errore 6: Lasciato il `canActivate` su `app.routes.ts` invece di rimuoverlo
**Sintomo:** funziona ma la guard viene chiamata due volte (visibile nei log se aggiungete un `console.log` nella guard).
**Fix:** rimuovere il `canActivate` da `app.routes.ts` — sta dentro `admin.routes.ts` ora.

### ❌ Errore 7: File generato come `admin-list.component.ts` invece di `admin-list.ts`
**Sintomo:** import path errato → `Cannot find module ...`.
**Causa:** lo studente ha aggiunto `--type=component` o usa una vecchia CLI.
**Fix:** Angular 21 → `admin-list.ts` (senza suffisso). Cancellare il file e rigenerare con `ng g c features/admin/pages/admin-list --skip-tests`.

---

## 6. Domande frequenti

**Q: Perché non spostiamo anche `/products/:id` (detail prodotto) sotto `/admin`?**
A: Perché il detail prodotto NON è admin-only — anche utenti non loggati lo vedono dalla home (`HomePage → routerLink="/products/:id"`). Le rotte vanno organizzate per **dominio funzionale**, non per percorso URL. Il detail prodotto resta top-level.

**Q: Posso usare `loadComponent` invece di `component` per i children?**
A: Sì — anche i children possono essere lazy individualmente. Però in pratica, dato che l'intera `admin.routes.ts` è già lazy (caricata insieme dal `loadChildren`), avrebbe poco senso splittare ulteriormente. Useresti `loadComponent` dentro i children solo per pagine particolarmente pesanti che pochissimi utenti raggiungono.

**Q: Cosa succede se ho `canActivate` sul padre E sui children?**
A: Si sommano: la guard del padre viene eseguita prima, poi quella del children. Se una delle due fa redirect, l'altra non viene chiamata. Pattern utile: `canActivate: [isLoggedIn]` sul padre + `canActivate: [isAdmin]` sui children che richiedono permessi extra.

**Q: Cosa significa che il `loadChildren` "scarica un chunk lazy"?**
A: Angular CLI vede il `import('./features/admin/admin.routes')` e produce un bundle separato per quel sotto-grafo. Quando l'utente naviga su `/admin` per la prima volta, il browser scarica quel chunk in più. Lo vedete in DevTools → Network → filtra "js" → cercate un file con "admin" nel nome.

---

## 7. Adattamenti

### Classe veloce (resta tempo):
- TODO bonus a voce: "come fareste in modo che la voce 'Aggiungi prodotto' nella sidebar sia visibile **solo agli admin**?" → discussione su `*ngIf` (no — è deprecated) vs `@if` (Angular 21) + signal dal servizio di auth.
- Verificare in DevTools → Network il chunk lazy `admin-…js` che NON si scarica visitando `/home` ma si scarica entrando in `/admin`. Discutere quando vale la pena lazy (chunk > 50 kB, rotta non sempre visitata).

### Classe lenta:
- Tagliare la nota in TODO 3 sul fallback `path: '**'` (è opzionale).
- Far fare i 3 file dei componenti (`AdminLayout`, `AdminList`) con `ng g c` proiettato dal docente, e lasciare allo studente solo il riempimento.

### Cosa NON approfondire:
- Lazy preloading strategies (`PreloadAllModules`, `QuicklinkStrategy`): micro-ottimizzazione, esce dallo slot.
- `RouterStateSnapshot`/`UrlTree` avanzati.

---

## 8. Verifica NAP (binario A)

A fine lab, applicare i file di `solution/` sopra a `product-catalog-finale/`:

```bash
cp -r Corso/G2/lab-03a-children-lazy/solution/src/app/. Corso/progetto/product-catalog-finale/src/app/

cd Corso/progetto/product-catalog-finale
npx ng build           # atteso: Application bundle generation complete con nuovo chunk lazy "admin-…"
npx ng test            # atteso: tutti i Test Files passed
```

**Verifica funzionale suggerita (manuale):**
- `ng serve` → login → `/admin` → vedi sidebar + landing.
- Sidebar "Prodotti" → `/admin/products` → vedi lista con "Modifica" per riga.
- Clicca "Modifica" su un prodotto → `/admin/products/3/edit` → ProductFormPage in modalità edit dentro AdminLayout.
- DevTools → Network → conferma il chunk `admin-…js` scaricato al primo accesso a `/admin`.
- `localStorage.removeItem('token')` → naviga `/admin` → redirect a `/login`.

Il seme `Corso/progetto/product-catalog/` resta intatto.

> **Stato di partenza del Lab 3b:** la `solution/` di questo lab applicata a `product-catalog-finale/`. Lab 3b modificherà `AdminList` aggiungendo querystring + paginazione.
