// app.routes.ts — SOLUTION Lab 3a G2
// Delta rispetto al seme:
//  ✅ TODO 1 — rotta 'admin' eager sostituita da loadChildren su admin.routes.ts
//  ✅ TODO 1 — rimosso import di Admin (non serve più qui, è dentro admin.routes.ts)
//  ✅ TODO 1 — rimosso canActivate dalla rotta admin (è sul padre della feature area)

import { Routes } from '@angular/router';
import { HomePage } from './pages/home/home.page';
import { authGuard } from './auth-guard';
import { Login } from './pages/login/login.page';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomePage },
  { path: 'login', component: Login },

  // ✅ TODO 1 — feature area admin lazy (loadChildren con default export)
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then(m => m.default),
  },

  {
    path: 'checkout',
    loadComponent: () =>
      import('./pages/checkout/checkout.page').then(m => m.CheckoutPage),
  },
  // ✅ products/new PRIMA di products/:id — "new" non venga catturato come :id
  {
    path: 'products/new',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./pages/product-form/product-form.page').then(m => m.ProductFormPage),
  },
  {
    path: 'products/:id',
    loadComponent: () =>
      import('./pages/product-detail/product-detail.page').then(m => m.ProductDetailPage),
  },
];
