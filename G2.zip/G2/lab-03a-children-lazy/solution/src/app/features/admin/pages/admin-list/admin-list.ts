// features/admin/pages/admin-list/admin-list.ts — SOLUTION Lab 3a G2
// Lista prodotti admin — versione base, senza querystring.
// Pattern: signal locale alimentato da Observable, takeUntilDestroyed per cleanup.
// Lab 3b arricchirà questo componente con queryParams (q + page).

import { Component, DestroyRef, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CurrencyPipe } from '@angular/common';
import { ProductService } from '../../../../services/product';
import { Product } from '../../../../product.model';

@Component({
  selector: 'app-admin-list',
  standalone: true,
  imports: [RouterLink, CurrencyPipe],
  templateUrl: './admin-list.html',
})
export class AdminList {

  private svc        = inject(ProductService);
  private destroyRef = inject(DestroyRef);

  // ✅ TODO 2 — stato esposto al template
  readonly products = signal<Product[]>([]);

  constructor() {
    // ✅ TODO 2 — carico i prodotti dal service una sola volta
    // takeUntilDestroyed: chiude la subscription se l'utente naviga via prima della response
    this.svc.getProducts()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(list => this.products.set(list));
  }
}
