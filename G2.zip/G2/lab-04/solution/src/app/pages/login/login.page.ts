// login.page.ts — SOLUZIONE Lab 4 G2
// Form template-driven invariato; cambia solo onSubmit, che ora chiama AuthService.login.

import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AuthService } from '../../services/auth';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './login.page.html',
})
export class Login {

  private router        = inject(Router);
  private route         = inject(ActivatedRoute);
  private auth          = inject(AuthService);
  private notifications = inject(NotificationService);

  loginData = { email: '', password: '' };

  async onSubmit(isValid: boolean | null): Promise<void> {
    if (!isValid) return;

    try {
      await this.auth.login(this.loginData.email, this.loginData.password);

      // snapshot: la login page si visita una volta, niente subscribe utile qui.
      const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
      this.router.navigateByUrl(returnUrl ?? '/admin');

    } catch {
      // L'errore "Credenziali non valide" è atteso, non eccezionale: toast e basta.
      this.notifications.error('Credenziali non valide');
    }
  }
}
