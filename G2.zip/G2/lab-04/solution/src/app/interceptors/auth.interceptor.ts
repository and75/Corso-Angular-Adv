// auth.interceptor.ts — SOLUZIONE Lab 4 G2
// Aggiunge `Authorization: Bearer <token>` alle chiamate al backend, escludendo la GET di login.

import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from '../services/auth';

const API_HOST   = 'http://localhost:3000';
const LOGIN_PATH = '/users';   // la GET di login va a /users?email=... — niente Bearer per lei.

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth  = inject(AuthService);
  const token = auth.getToken();

  // Filtri: se uno blocca, la req passa intatta.
  const isOurApi    = req.url.startsWith(API_HOST);
  const isLoginCall = req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET';

  if (!token || !isOurApi || isLoginCall) {
    return next(req);
  }

  // Clone immutabile con il Bearer aggiunto.
  const cloned = req.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
  });
  return next(cloned);
};
