// app.config.ts — SOLUZIONE Lab 4 G2
// Registrazione interceptor con `withInterceptors([authInterceptor, errorInterceptor])`.

import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

import { routes } from './app.routes';
import { authInterceptor }  from './interceptors/auth.interceptor';
import { errorInterceptor } from './interceptors/error.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    // ⚠️ Ordine: auth PRIMA di error. In andata l'array si percorre dall'alto in basso
    //    (auth aggiunge il Bearer prima che error veda la richiesta); in ritorno il pipe
    //    si srotola dall'interno, quindi il retry di errorInterceptor è in coda — corretto.
    provideHttpClient(
      withInterceptors([
        authInterceptor,
        errorInterceptor,
      ]),
    ),
  ]
};
