// guards/role.guard.ts — SOLUZIONE Lab 4 G2
// Factory che restituisce una CanActivateFn per ruolo richiesto.

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService, type User } from '../services/auth';
import { NotificationService } from '../services/notification.service';

export function roleGuard(required: User['role']): CanActivateFn {
  return (_route, _state) => {
    const auth   = inject(AuthService);
    const router = inject(Router);
    const notify = inject(NotificationService);

    const user = auth.currentUser();
    if (user?.role === required) return true;

    // Utente autenticato ma senza il ruolo richiesto: toast + redirect a home.
    // (Se non fosse nemmeno autenticato, authGuard avrebbe già redirezionato a /login
    //  PRIMA che questo roleGuard fosse interrogato — vedi composizione in admin.routes.ts.)
    notify.error(`Accesso negato: serve il ruolo "${required}".`);
    return router.createUrlTree(['/']);
  };
}
