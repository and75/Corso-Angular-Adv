/**
 * features/admin/admin.routes.ts — STARTER Lab 4 G2
 *
 * Modifica del file del Lab 3: componi `roleGuard('admin')` accanto a `authGuard`
 * sul livello padre.
 *
 *   Risultato: per entrare in /admin l'utente deve essere autenticato (authGuard)
 *   E avere ruolo `admin` (roleGuard('admin')). Un `user` autenticato vede un
 *   toast "Accesso negato" e viene rimandato a /.
 *
 * Vedi Scheda 05 G2 §"Autenticazione vs autorizzazione: il roleGuard".
 */

import { Routes } from '@angular/router';
import { AdminLayout } from './admin-layout/admin-layout';
import { Admin } from '../../pages/admin/admin.page';
import { AdminList } from './pages/admin-list/admin-list';
import { ProductFormPage } from '../../pages/product-form/product-form.page';
import { authGuard } from '../../auth-guard';

/*
 * TODO 5 — Importa la factory roleGuard:
 *
 *     import { roleGuard } from '../../guards/role.guard';
 */

const adminRoutes: Routes = [
  {
    path: '',
    component: AdminLayout,

    /*
     * TODO 5 — Componi la guard per ruolo:
     *
     *     canActivate: [authGuard, roleGuard('admin')],
     *
     *   Note:
     *     - Ordine `[authGuard, roleGuard]`: Angular valuta in AND, prima a sinistra.
     *       Se l'utente non è loggato, authGuard redirige a /login PRIMA che
     *       roleGuard sia interrogato. Senza questo ordine, l'utente non loggato
     *       vedrebbe il toast "Accesso negato" un istante prima del redirect.
     *
     *     - `roleGuard('admin')` viene chiamata UNA volta a setup-time (qui),
     *       e ritorna una `CanActivateFn` che cattura `'admin'` nella closure.
     *       Funziona perché le factory di guard sono di prim'ordine in JS/TS.
     *
     *   Vedi Scheda 05 §"Autenticazione vs autorizzazione" — 3 perché motivati.
     */
    canActivate: [authGuard],   // ⚠️ era così nel Lab 3 — espandi con roleGuard('admin')

    children: [
      { path: '', pathMatch: 'full', component: Admin },
      { path: 'products', component: AdminList },
      { path: 'products/:id/edit', component: ProductFormPage },
    ],
  },
];

export default adminRoutes;
