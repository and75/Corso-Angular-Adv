/**
 * login.page.ts — STARTER Lab 4 G2
 *
 * Modifica del componente esistente: il form (template-driven, in login.page.html)
 * resta com'è — cambia solo `onSubmit`, che diventa una vera login asincrona
 * verso AuthService.
 *
 *   Lo starter NON cambia login.page.html: il template ha già email + password +
 *   validazione + submit. Tutto il delta è qui.
 *
 * Vedi Scheda 05 G2 §"La biglietteria — AuthService" (per il `login()` che chiami)
 * e §"Lo stand chiuso — il 401" (per `returnUrl`).
 */

import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';

/*
 * TODO 4 — Aggiungi gli import:
 *
 *     import { AuthService } from '../../services/auth';
 *     import { NotificationService } from '../../services/notification.service';
 */

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './login.page.html',
})
export class Login {

  private router = inject(Router);

  /*
   * TODO 4 — Inietta le 3 nuove dipendenze:
   *
   *     private route         = inject(ActivatedRoute);
   *     private auth          = inject(AuthService);
   *     private notifications = inject(NotificationService);
   *
   *   `ActivatedRoute` ti serve per leggere `returnUrl` dalla query string;
   *   `AuthService` per fare il login vero;
   *   `NotificationService` per il toast in caso di credenziali sbagliate.
   */

  loginData = { email: '', password: '' };

  /*
   * TODO 4 — Sostituisci l'`onSubmit` placeholder con la versione async:
   *
   *     async onSubmit(isValid: boolean | null): Promise<void> {
   *       if (!isValid) return;
   *
   *       try {
   *         await this.auth.login(this.loginData.email, this.loginData.password);
   *
   *         const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
   *         this.router.navigateByUrl(returnUrl ?? '/admin');
   *
   *       } catch {
   *         this.notifications.error('Credenziali non valide');
   *       }
   *     }
   *
   *   Note:
   *     - `route.snapshot.queryParamMap` invece di sottoscrivere `route.queryParamMap`:
   *       la login page si visita una volta sola, lo snapshot basta. La subscription
   *       sarebbe overhead inutile.
   *
   *     - `navigateByUrl` invece di `navigate([returnUrl])`: il `returnUrl` è già una
   *       URL completa (es. `/admin/products?q=mac`), va passata come stringa.
   *
   *     - Sul catch NON facciamo `console.error`: l'errore (`new Error('Credenziali non valide')`
   *       lanciato dal service) è atteso, non eccezionale. Il toast è la UX corretta.
   */

  // ⚠️ Placeholder del seme — da rimuovere nel TODO 4
  onSubmit(isValid: boolean | null): void {
    if (!isValid) return;
    localStorage.setItem('token', 'demo-token');
    this.router.navigate(['/admin']);
  }
}
