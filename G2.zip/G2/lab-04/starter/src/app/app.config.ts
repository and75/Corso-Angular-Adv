/**
 * app.config.ts — STARTER Lab 4 G2
 *
 * Modifica: registrare gli interceptor funzionali nel provideHttpClient.
 *
 * Vedi Scheda 04 G2 §"Registrarli: la fila dei caselli".
 */

import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';

import { routes } from './app.routes';

/*
 * TODO 4 — Aggiungi gli import per la registrazione interceptor:
 *
 *     import { provideHttpClient, withInterceptors } from '@angular/common/http';
 *     import { authInterceptor }  from './interceptors/auth.interceptor';
 *     import { errorInterceptor } from './interceptors/error.interceptor';
 */

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),

    /*
     * TODO 4 — Sostituisci il `provideHttpClient()` nudo qui sotto con la versione
     *           che registra gli interceptor in catena:
     *
     *     provideHttpClient(
     *       withInterceptors([
     *         authInterceptor,    ← ① aggiunge il Bearer in andata
     *         errorInterceptor,   ← ② vede la risposta — retry + 401/logout + toast
     *       ]),
     *     ),
     *
     *   ⚠️ L'ordine NON è simmetrico: in andata l'array si percorre dall'alto in basso
     *      (logging → auth → error → rete), in ritorno il `pipe` si srotola dall'interno
     *      verso l'esterno. Conseguenza pratica: il `retry` di errorInterceptor parte
     *      DOPO che authInterceptor ha aggiunto il Bearer in andata — quindi il retry
     *      include il token. Invertendo l'ordine, il retry partirebbe senza Bearer.
     *
     *   Vedi Scheda 04 §"Errori comuni — 5. Cambiare l'ordine in withInterceptors".
     */
    provideHttpClient()
  ]
};
