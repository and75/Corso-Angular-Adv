/**
 * auth-guard.ts — STARTER Lab 4 G2
 *
 * Modifica: sostituire la lettura "nuda" da localStorage con `AuthService.isAuthenticated()`.
 *
 * Vedi Scheda 05 G2 §"Il flusso end-to-end" (l'authGuard è il "tornello d'ingresso";
 * il roleGuard del TODO 5 è il "tornello del backstage").
 */

import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';

/*
 * TODO 4 — Importa AuthService:
 *
 *     import { AuthService } from './services/auth';
 */

export const authGuard: CanActivateFn = (_route, state) => {
  const router = inject(Router);

  /*
   * TODO 4 — Sostituisci la lettura placeholder qui sotto con:
   *
   *     const auth = inject(AuthService);
   *     if (auth.isAuthenticated()) return true;
   *     return router.createUrlTree(['/login'], {
   *       queryParams: { returnUrl: state.url },
   *     });
   *
   *   Note:
   *     - `state.url` è l'URL completo che l'utente stava cercando di raggiungere.
   *       Lo passiamo come `returnUrl` per riportarcelo dopo il login.
   *
   *     - `isAuthenticated()` legge un signal: la guard reagisce sempre allo stato
   *       corrente, non a un valore stantio cachato.
   *
   *     - `createUrlTree([...], { queryParams })` aggiunge le query alla rotta target.
   *       NON usare `router.navigate(...)` qui: una guard deve RITORNARE un valore
   *       (true | UrlTree | Observable<...>), non innescare un side effect.
   */

  // ⚠️ Placeholder del seme — da rimuovere nel TODO 4
  const token = localStorage.getItem('token');
  if (token) return true;
  return router.createUrlTree(['/login']);
};
