/**
 * interceptors/auth.interceptor.ts — STARTER Lab 4 G2
 *
 * Functional HTTP interceptor (Angular 21): aggiunge l'header
 * `Authorization: Bearer <token>` alle richieste dirette al nostro backend,
 * escludendo la GET di login (che parte SENZA token per design).
 *
 * Vedi Scheda 05 G2 §"Il buttafuori dello stand — authInterceptor".
 * Vedi Scheda 04 G2 §"Pattern 1 — clonare la richiesta" per `req.clone`.
 */

import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from '../services/auth';

/*
 * TODO 2 — Costanti per riconoscere "le nostre" chiamate.
 *
 *   Definisci due costanti a livello di modulo (fuori dalla function):
 *     - API_HOST   = 'http://localhost:3000'
 *     - LOGIN_PATH = '/users'   ← la GET di login va a /users?email=...
 *
 *   Usarle come stringhe magiche dentro l'if rende il codice più rumoroso.
 */

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  /*
   * TODO 2 — Recupera il token tramite AuthService.
   *
   *   Forma:
   *     const auth = inject(AuthService);
   *     const token = auth.getToken();
   *
   *   ⚠️ `inject()` qui in cima funziona perché l'interceptor è invocato in un
   *      injection context da HttpClient. NON spostarlo dentro pipe/catchError.
   */

  /*
   * TODO 2 — Tre filtri che, se TUTTI insieme bloccano, fanno passare la req intatta:
   *
   *     1) `!token`           — non siamo loggati, niente Bearer da aggiungere.
   *     2) `!isOurApi`        — la richiesta va a un servizio terzo (CDN, mappe, …).
   *                              Non vogliamo regalare il nostro token a chi non lo richiede.
   *        Espressione: `req.url.startsWith(API_HOST)`.
   *     3) `isLoginCall`      — la chiamata di login non deve portare il Bearer.
   *        Espressione: `req.url.startsWith(API_HOST + LOGIN_PATH) && req.method === 'GET'`.
   *
   *   Se almeno una blocca: `return next(req);`
   */

  /*
   * TODO 2 — Clona la richiesta aggiungendo il Bearer.
   *
   *   Forma:
   *     const cloned = req.clone({
   *       setHeaders: { Authorization: `Bearer ${token}` },
   *     });
   *     return next(cloned);
   *
   *   ⚠️ Errore numero uno: clonare e poi passare `req` (originale) a `next`.
   *      Il clone è un nuovo oggetto: se non lo usi, è come non averlo fatto.
   *
   *   Vedi Scheda 04 G2 §"Errori comuni — 2. Clonare ma non passare il clone".
   */

  /* eslint-disable-next-line @typescript-eslint/no-unused-expressions */
  null;   // placeholder per il compilatore — sostituire con la logica sopra
  throw new Error('TODO 2 — authInterceptor non implementato');
};
