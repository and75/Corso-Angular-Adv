/**
 * interceptors/error.interceptor.ts — STARTER Lab 4 G2
 *
 * Functional HTTP interceptor (Angular 21): gestisce centralmente gli errori HTTP.
 *
 *   Responsabilità:
 *     1) Retry MIRATO sui GET ritentabili (status 0 o 5xx).
 *     2) 401 → logout + redirect a /login?returnUrl=...
 *     3) Altri errori → toast via NotificationService.
 *     4) Sempre `throwError(() => err)` finale: l'errore deve risalire al componente.
 *
 * Vedi Scheda 04 G2 §"Pattern 2 — error interceptor" e §"Pattern 3 — retry mirato".
 * Vedi Scheda 05 G2 §"Lo stand chiuso — il 401" per il flusso logout/redirect.
 */

import { inject } from '@angular/core';
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, retry, throwError, timer } from 'rxjs';
import { AuthService } from '../services/auth';
import { NotificationService } from '../services/notification.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  /*
   * TODO 3 — Inietta le tre dipendenze in cima al body.
   *
   *     const auth          = inject(AuthService);
   *     const router        = inject(Router);
   *     const notifications = inject(NotificationService);
   *
   *   ⚠️ `inject()` NON va chiamato dentro `catchError`/`retry`: lì non c'è injection context.
   *      Le tre const restano catturate nella closure degli operatori.
   *
   *   Vedi Scheda 04 §"Pattern 2" — il "perché" del `inject()` qui dentro.
   */

  /*
   * TODO 3 — Applica gli operatori a `next(req)` in QUESTO ordine:
   *
   *     return next(req).pipe(
   *       retry({ ... }),
   *       catchError((err: HttpErrorResponse) => { ... }),
   *     );
   *
   *   L'ordine conta: `retry` deve venire PRIMA di `catchError`. Altrimenti
   *   il `catchError` cattura il primo errore, lo "gestisce", e `retry` non
   *   vede mai nulla da ritentare.
   */

  /*
   * TODO 3 — `retry({ count: 2, delay: (err) => Observable })`.
   *
   *   Il `delay` è una FUNZIONE che riceve l'errore e decide:
   *     - ritentare → ritorna `timer(500)` (o un Observable simile).
   *     - arrendersi → ritorna `throwError(() => err)` (interrompe il retry).
   *
   *   Filtro "ritentabile":
   *     const isRetriable =
   *       req.method === 'GET' &&
   *       (err.status === 0 || err.status >= 500);
   *
   *   Solo GET (idempotente, safe) e solo errori di rete/server (0 = browser non ci ha parlato,
   *   5xx = server momentaneamente in difficoltà). 4xx no — il retry non cambierà il fatto
   *   che la risorsa non esiste (404) o che non sei autorizzato (401/403).
   *
   *   Vedi Scheda 04 §"Pattern 3 — retry mirato": 3 regole (idempotente, status ritentabili, mai infinito).
   */

  /*
   * TODO 3 — `catchError((err: HttpErrorResponse) => ...)`.
   *
   *   if (err.status === 401) {
   *     auth.logout();                              ← ⚠️ PRIMA del navigate, altrimenti loop
   *     router.navigate(['/login'], {
   *       queryParams: { returnUrl: location.pathname }
   *     });
   *   } else {
   *     notifications.error(mapStatusToMessage(err));
   *   }
   *   return throwError(() => err);                  ← ⚠️ SEMPRE rilanciare
   *
   *   ⚠️ Errore più sottile del lab: dimenticare `auth.logout()` prima del navigate
   *      → la guard del prossimo refresh rivede il token in localStorage, rientri in
   *      /admin, la chiamata ritenta, 401 di nuovo, loop. Vedi README docente §3.
   *
   *   ⚠️ Errore numero due: sostituire `throwError(() => err)` con `return EMPTY`.
   *      Il componente che attendeva la risposta non riceve né next né error,
   *      il suo `isLoading` resta a true per sempre. Vedi Scheda 04 §"Errori comuni — 3".
   */

  /*
   * TODO 3 — `mapStatusToMessage(err: HttpErrorResponse): string`.
   *
   *   Helper privato al file (o inline nel catchError, a piacere). Mappa:
   *     - err.status === 0   → 'Server non raggiungibile. Controlla la connessione.'
   *     - err.status === 404 → 'Risorsa non trovata.'
   *     - err.status === 409 → 'Conflitto: la risorsa è già stata modificata.'
   *     - err.status >= 500  → 'Errore del server. Riprova tra qualche istante.'
   *     - default            → 'Si è verificato un errore. Riprova.'
   */

  /* eslint-disable-next-line @typescript-eslint/no-unused-expressions */
  null;   // placeholder per il compilatore — sostituire con la pipe sopra
  throw new Error('TODO 3 — errorInterceptor non implementato');
};
