/**
 * guards/role.guard.ts — STARTER Lab 4 G2
 *
 * Factory `roleGuard(required): CanActivateFn`.
 *
 *   Non è una guard semplice: è una FUNZIONE che restituisce una guard.
 *   Si chiama una volta a setup-time (in `admin.routes.ts`) con il ruolo
 *   richiesto come argomento; la `CanActivateFn` restituita lo cattura
 *   nella closure e lo userà a ogni navigazione.
 *
 *   Pattern canonico per "guard parametriche". Vedi Scheda 05 G2
 *   §"Autenticazione vs autorizzazione: il roleGuard".
 */

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService, type User } from '../services/auth';
import { NotificationService } from '../services/notification.service';

/*
 * TODO 5 — Firma della factory:
 *
 *     export function roleGuard(required: User['role']): CanActivateFn {
 *       return (route, state) => {
 *         ...
 *       };
 *     }
 *
 *   Tutta la logica vive DENTRO la `CanActivateFn` ritornata (perché è lì che
 *   c'è l'injection context al momento della navigazione).
 *
 *   Logica:
 *     1) const auth = inject(AuthService);
 *        const router = inject(Router);
 *        const notify = inject(NotificationService);
 *
 *     2) const user = auth.currentUser();
 *        if (user?.role === required) return true;
 *
 *     3) Altrimenti:
 *          notify.error(`Accesso negato: serve il ruolo "${required}".`);
 *          return router.createUrlTree(['/']);
 *
 *   Note progettuali:
 *     - Leggi il signal `currentUser()`, NON decodificare il token qui.
 *       Una sola fonte di verità (l'AuthService), un solo decoder.
 *
 *     - Ritorna `UrlTree` invece di `false`: `false` lascia l'utente sulla
 *       rotta corrente "senza che succeda niente"; `UrlTree` lo riporta a una
 *       pagina sensata, e il toast spiega il rifiuto.
 *
 *     - Il toast esce SOLO se l'utente è autenticato ma con ruolo sbagliato.
 *       Se non è autenticato affatto, è `authGuard` (che mettiamo PRIMA nella
 *       composizione `canActivate`) a redirigere su /login. Vedi Scheda 05
 *       §"Autenticazione vs autorizzazione" per il "perché" dell'ordine.
 */

export function roleGuard(_required: User['role']): CanActivateFn {
  return (_route, _state) => {
    throw new Error('TODO 5 — roleGuard non implementato');
  };
}
