/**
 * services/auth.ts — STARTER Lab 4 G2
 *
 * Nuovo service: "biglietteria" che simula l'autenticazione contro json-server.
 * Vive con `providedIn: 'root'` (singleton globale). Lo stato corrente è un signal,
 * la persistenza è in localStorage, il token è finto ma con la stessa forma di un JWT
 * (header omesso, payload + scadenza, niente firma).
 *
 * Vedi Scheda 05 G2 §"La biglietteria — AuthService".
 */

import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

/*
 * TODO 1 — Tipi del dominio.
 *
 *   1) `User`: shape dell'utente in `db.json` SENZA la password.
 *      Campi: id (number), email (string), name (string), role ('admin' | 'user').
 *
 *   2) `TokenPayload`: shape del payload del nostro token finto.
 *      Campi: sub (number, ovvero l'id utente), role (User['role']), exp (number, ms epoch).
 *
 *   3) Costante `STORAGE_KEY = 'pc.token'`: chiave usata in localStorage.
 *
 *   Note: la password è in chiaro in `db.json` perché simuliamo l'auth lato Angular —
 *   nei tipi pubblici NON deve apparire (vedi `currentUser` più avanti).
 */

@Injectable({ providedIn: 'root' })
export class AuthService {

  private http = inject(HttpClient);

  /*
   * TODO 1 — Stato interno.
   *
   *   Crea un signal privato:
   *
   *     private _user = signal<User | null>(null);
   *
   *   Esponi pubblicamente:
   *     - `currentUser`  : versione read-only (`asReadonly()`) per i consumer.
   *     - `isAuthenticated`: computed booleano derivato da `_user()`.
   */

  constructor() {
    /*
     * TODO 1 — Chiama qui `restoreFromStorage()` (definito sotto).
     *   Al boot dell'app il signal `_user` parte a null: questa chiamata lo ripopola
     *   se in localStorage c'è un token ancora valido. Senza, ogni F5 azzera la sessione.
     */
  }

  /*
   * TODO 1 — `login(email: string, password: string): Promise<User>`
   *
   *   Passi:
   *     1) Chiama il backend: `GET http://localhost:3000/users?email=<email>`.
   *        Suggerimento: `firstValueFrom(this.http.get<...>(...))` ti permette di
   *        scrivere il resto in async/await (più lineare di `subscribe` qui).
   *
   *     2) Il risultato è un array (json-server filtra in `?email=` ma ritorna `User[]`).
   *        Prendi `[0]`. Se manca, o se la password non coincide → throw `new Error('Credenziali non valide')`.
   *
   *     3) Costruisci il payload del token finto:
   *          { sub: candidate.id, role: candidate.role, exp: Date.now() + 60*60*1000 }
   *
   *     4) Genera il token: `btoa(JSON.stringify(payload))`.
   *
   *     5) Persisti in localStorage: `localStorage.setItem(STORAGE_KEY, token)`.
   *
   *     6) Aggiorna il signal: rimuovi `password` dall'utente e fai `this._user.set(senzaPwd)`.
   *
   *     7) Ritorna l'utente senza password.
   *
   *   ⚠️ Errori tipici:
   *     - Confrontare la password senza prima aver controllato che l'utente esista (NPE).
   *     - Salvare l'utente intero (con password) nel signal: la password non deve mai
   *       transitare oltre questo metodo.
   */

  /*
   * TODO 1 — `logout(): void`
   *
   *   Due righe:
   *     - `localStorage.removeItem(STORAGE_KEY)`
   *     - `this._user.set(null)`
   *
   *   Non chiamare router.navigate qui: il logout è un'azione di stato, la navigazione
   *   è responsabilità di chi lo chiama (LoginPage, errorInterceptor sul 401).
   */

  /*
   * TODO 1 — `getToken(): string | null`
   *
   *   Usato dall'authInterceptor a ogni request. Logica:
   *     1) raw = localStorage.getItem(STORAGE_KEY); se null → return null.
   *     2) Prova a decodificare: usa il metodo privato `decode(raw)` (definito sotto).
   *        Se il decode fallisce (token manomesso) o `payload.exp < Date.now()`:
   *        rimuovi la chiave e ritorna null.
   *     3) Altrimenti ritorna la stringa raw (l'interceptor non ha bisogno del payload).
   *
   *   ⚠️ Perché qui valido invece di "tanto risponderà 401 lato server"?
   *      - Risparmio una request già condannata.
   *      - Con auth simulata, json-server non risponde 401 mai. Senza la validazione
   *        client-side, un token scaduto resterebbe attivo indefinitamente.
   */

  /*
   * TODO 1 — `private restoreFromStorage(): void`
   *
   *   Chiamato dal costruttore. Logica:
   *     1) raw = localStorage.getItem(STORAGE_KEY); se null → return.
   *     2) payload = decode(raw). Se null o `exp < Date.now()`: rimuovi la chiave e return.
   *     3) Chiama `GET http://localhost:3000/users/<payload.sub>` e `subscribe` →
   *        `this._user.set(user senza password)`.
   *
   *   Nota: i `password` campi non vanno mai nel signal. In TS:
   *     `const { password: _, ...safe } = user as User & { password: string }; this._user.set(safe);`
   *
   *   Alternativa progettuale (NON richiesta dal lab):
   *     Salvare l'oggetto utente completo in localStorage accanto al token, e
   *     ripristinare senza chiamata HTTP. Vantaggio: zero request al boot.
   *     Svantaggio: dati staleable. Discusso nel README docente.
   */

  /*
   * TODO 1 — `private decode(raw: string): TokenPayload | null`
   *
   *   Decodifica del token finto. Forma idiomatica:
   *
   *     try {
   *       return JSON.parse(atob(raw)) as TokenPayload;
   *     } catch {
   *       return null;
   *     }
   *
   *   Il `try/catch` non è cosmetico: se l'utente sostituisce `pc.token` in DevTools
   *   con una stringa non base64, `atob` lancia `InvalidCharacterError` e senza
   *   catch il primo render dopo F5 esplode.
   */
}
