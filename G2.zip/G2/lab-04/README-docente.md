# Lab 4 — Note docente

> Pendant del [README.md](./README.md) per studenti — qui timing in aula, "perché" non scritti
> nello starter, errori tipici visti, e i punti dove vale la pena fermarsi a discutere.

---

## Timing (65 min totali)

| Tempo | Attività | Note |
|---|---|---|
| 0–5' | Brief del lab + setup db.json (seed users + sanity `curl`) | Va fatto prima del lab dal docente o messo nel piano dello STEP 00 NAP — se l'aula deve farlo, prevedere 5 minuti reali |
| 5–25' | **TODO 1** — `AuthService` | È il TODO più sostanzioso. Vale la pena fare una pausa a metà per ricapitolare cosa è il signal `_user` e perché c'è `restoreFromStorage` |
| 25–35' | **TODO 2** — `authInterceptor` | Veloce. Il punto di discussione è l'esclusione della GET di login (perché senza fa loop in alcuni backend reali) |
| 35–50' | **TODO 3** — `errorInterceptor` | Il `delay` come funzione confonde sempre — disegnare alla lavagna il flusso "retry → catchError → throwError" |
| 50–60' | **TODO 4** — login + auth-guard | Veloce, è soprattutto cablaggio. Mostrare la `returnUrl` come query string in barra |
| 60–65' | **TODO 5** — roleGuard factory + composizione | Mostrare la `roleGuard('admin')` come funzione di prim'ordine: si chiama una volta a setup-time, restituisce la `CanActivateFn` |

> Se sforate, il TODO 3 è il candidato a essere ridotto: si può lasciare solo `catchError` (niente `retry`) e raccontare il retry alla lavagna. Il TODO 5 invece è breve e va fatto: porta a casa il concetto autz-vs-auth.

---

## Demo live consigliata (5 minuti, prima di iniziare)

1. Apri il seme `product-catalog/` e mostra la versione attuale di `auth-guard.ts`: `localStorage.getItem('token')`.
2. Aprire DevTools → Application → Local Storage. `localStorage.setItem('token', 'anything')`, ricaricare, navigare a `/admin`. L'aula vede che "chiunque è admin".
3. Aprire `pages/login/login.page.ts`: mostra che `onSubmit` fa solo `localStorage.setItem('token', 'demo-token')`.
4. Dichiarare l'obiettivo: alla fine del lab, lo stesso esperimento non funzionerà più — il token sarà *validato* (scadenza + payload ben formato), e l'area `/admin` chiederà *anche* il ruolo.

Questa demo serve a far vedere quanto è giocattolo il setup base e perché vale la pena scrivere `AuthService` per davvero.

---

## Soluzione commentata — i "perché" che lo starter non dice

### TODO 1 — `services/auth.ts`

Punti che lo starter accenna ma vale la pena ripetere in aula:

- **Perché `signal` e non `BehaviorSubject`.** La coerenza con il `ProductService` del seme (che ha `cartItems = signal`) è il motivo pratico, ma c'è un motivo strutturale: `isAuthenticated = computed(() => !!user())` resta reattivo *senza pipe RxJS*. L'header in alto a destra può fare `@if (auth.isAuthenticated())` direttamente — niente `async pipe`, niente subscribe, niente `takeUntilDestroyed`.
- **Perché `restoreFromStorage` fa una GET.** Tre alternative possibili: (a) decodificare il token, fidarsi del payload (`sub`, `role`) e popolare un `_user` con solo quei campi; (b) salvare l'oggetto utente intero in `localStorage` accanto al token; (c) chiamare `GET /users/<sub>`. La scelta (c) è la più "vera" — i dati arrivano dal backend, eventuali modifiche al profilo sono riflesse — ma costa una request al boot. In aula vale la pena nominare tutte e tre e dire "in produzione spesso si fa (b) per ridurre il time-to-interactive".
- **Perché `getToken()` valida ogni volta.** Lo studente è tentato di scrivere `getToken() { return localStorage.getItem(STORAGE_KEY); }` perché "tanto se il token è scaduto il server risponderà 401". Vero ma due problemi: 1) consuma una request a sapere già che il token è morto; 2) con auth simulata, il server non risponderà 401 mai. Il `getToken()` validante è il punto in cui simuliamo la verifica della firma — *prima* dell'invio.
- **Perché `try/catch` sul `JSON.parse(atob(raw))`.** Se l'utente manomette `pc.token` da DevTools con `"ciao"`, `atob` lancia `InvalidCharacterError`. Senza `try/catch`, il primo render dopo F5 esplode. Con `try/catch` + rimozione della chiave, il sistema torna in stato pulito al primo accesso successivo.

### TODO 2 — `authInterceptor`

- **Perché `isOurApi` con `startsWith`.** Lo studente avanzato può chiedere "ma se l'URL contiene query string?" — `startsWith` continua a funzionare perché controlliamo il prefisso. Più rigoroso: usare `new URL(req.url).origin === API_ORIGIN`. Equivalente per il nostro lab.
- **Perché `isLoginCall` e non `req.url === API_HOST + '/users'`.** La chiamata di login è `GET /users?email=admin@overnet.it`: l'URL include la query string. `startsWith` la copre. Se metti `===` la chiamata di login non viene riconosciuta e il Bearer ci viene aggiunto. In `json-server` non succede nulla, ma in un IdP reale può rifiutarla.

### TODO 3 — `errorInterceptor`

- **Il `delay` come funzione di errore è il punto che confonde di più.** Disegnare alla lavagna:
  ```
  next(req) ──► (errore HTTP) ──► retry({delay: fn(err) → Observable})
                                            │
                                            ├─ fn ritorna timer(500) ► riprovi
                                            │
                                            └─ fn ritorna throwError(() => err) ► retry si arrende
                                                                                    │
                                                                                    ▼
                                                                              catchError
  ```
  Il `throwError` dentro il `delay` non è un `throw`: è un Observable che emette un errore, e questa è la convenzione di `retry` per "non ritentare". Spiegare la differenza fra `throw` (sincrono, scoppia subito) e `throwError(() => err)` (un Observable che emette un errore) è già metà della lezione su RxJS in questo contesto.
- **`return throwError(() => err)` nel `catchError` finale.** Lo studente è tentato di mettere `return EMPTY` perché "ho già notificato, non serve fare altro". È *l'errore più subdolo del lab*. Il componente che aveva sottoscritto la chiamata `http.get(...).subscribe({ next, error })` aspetta una risposta: senza rethrow non riceve né `next` né `error`, e il suo `isLoading` resta a `true` per sempre. Mostrare il bug in vivo: rimuovi `throwError` dal `catchError`, fai una request che fallisce con 500, e lo spinner non si spegne mai.
- **Perché `location.pathname` e non `Router.url`.** `Router.url` è stato già aggiornato all'inizio della navigazione, quindi se il 401 arriva dopo un click su `/admin`, `Router.url` è `/admin` (atteso) — funziona. Però in alcune race il 401 arriva *durante* il `resolve` di una guard e `Router.url` ancora punta alla pagina precedente. `location.pathname` è quello che il browser sta mostrando, sempre. Scorciatoia robusta.

### TODO 4 — login + auth-guard

- **Form template-driven mantenuto.** Lo starter non riscrive il form perché non è il punto del lab. Se in aula chiedono "ma le schede di Mod 2 dicono Reactive Forms": rispondere che entrambi gli stili convivono — il valore qui è l'auth, non la migrazione del form. In un progetto reale il form sarebbe stato già migrato in Mod 2.
- **`returnUrl` letto da `queryParamMap`.** Nello starter c'è una nota: usare `route.snapshot.queryParamMap.get('returnUrl')` *non* `route.queryParamMap.subscribe(...)`. La login page si naviga una sola volta, lo snapshot è sufficiente. Subscriversi è eccesso.

### TODO 5 — `roleGuard` + composizione

- **Factory vs guard semplice.** Mostrare lato lavagna che `roleGuard` è una funzione che ritorna `CanActivateFn`. Si chiama una volta a setup-time (`roleGuard('admin')` viene valutata mentre Angular istanzia `admin.routes.ts`), e il `CanActivateFn` restituito ha catturato `'admin'` nella closure. È l'esempio canonico di closure in JS / TS — vale la pena nominarlo.
- **Ordine `[authGuard, roleGuard('admin')]`.** Spiegare che Angular valuta le guard in sequenza, ma con semantica AND: la prima che restituisce `false` (o `UrlTree`) interrompe la catena. Metterle nell'ordine sbagliato funziona ma è confuso: utente non loggato → `authGuard` redirige, `roleGuard` non viene chiamato. Invertito: `roleGuard` legge `currentUser() === null`, mostra "Accesso negato", e *poi* `authGuard` redirige a `/login`. L'utente vede il toast prima del redirect: poco elegante. Da qui la regola "auth prima, autz dopo".

---

## Errori tipici visti in aula

### 1. Bearer aggiunto alla chiamata di login

```typescript
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = inject(AuthService).getToken();
  if (!token) return next(req);
  const cloned = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  return next(cloned);   // ❌ manca l'esclusione di /users?email=...
};
```

Caso silente: il login da sloggato (`token === null`) salta il clone. Bug visibile: il login da loggato (cambio account) fa partire la GET con `Bearer <vecchio token>`. Su `json-server` non si vede; su backend reali sì.

Fix: aggiungere il check `isLoginCall` come da scheda 05.

### 2. `inject()` dentro `catchError`

```typescript
catchError((err) => {
  const router = inject(Router);   // ❌ "inject() can only be used within an injection context"
  ...
})
```

Stack trace abbastanza esplicito ma confonde. Va spostato in cima al body dell'interceptor (l'interceptor *funzione* viene invocato in injection context da HttpClient; il `catchError` è dentro una `pipe` che vive in un altro tick e non eredita il contesto).

### 3. Loop di redirect dopo 401

```typescript
catchError((err) => {
  if (err.status === 401) {
    inject(Router).navigate(['/login']);   // ❌ manca auth.logout() prima
  }
  return throwError(() => err);
})
```

Risultato: navigate a `/login`, dove `auth.isAuthenticated()` legge il vecchio token ancora in `localStorage` (perché non è scaduto, è solo invalidato server-side). La guard non c'è su `/login` ma c'è `restoreFromStorage` che ha popolato `_user`. L'utente vede il form di login *e* l'header come se fosse loggato, finché non fa logout esplicito o riloggandosi sovrascrive il token. Sintomo: "sembra che il login non funzioni, devo cliccare 'Accedi' due volte".

Fix: `auth.logout()` *prima* di `router.navigate`.

### 4. `roleGuard` cerca `route.data['role']`

```typescript
const required = route.data['role'];   // ❌ aspetta il role come data della rotta
if (auth.currentUser()?.role === required) return true;
```

Approccio valido in altri pattern (`{ path: 'admin', data: { role: 'admin' } }`) ma non è la consegna del lab. La factory `roleGuard('admin')` è più esplicita perché il ruolo richiesto si vede leggendo la `canActivate` riga di `admin.routes.ts`, senza dover andare a leggere `data`. Va spinto verso la factory.

### 5. `restoreFromStorage` chiamato fuori dal costruttore

```typescript
ngOnInit() { this.restoreFromStorage(); }   // ❌ AuthService è un service, non ha ngOnInit
```

Servizio `providedIn: 'root'` non ha hook di lifecycle: il restore va nel costruttore. Lo studente che viene dal mondo React/Vue spesso dimentica questa asimmetria.

### 6. Storage che esplode al primo F5

```typescript
restoreFromStorage() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return;
  const payload = JSON.parse(atob(raw));   // ❌ niente try/catch
  ...
}
```

Aula utente curioso che ha messo `pc.token = "ciao"` in DevTools (perché glielo abbiamo detto nei criteri di verifica!). Al refresh `atob` esplode. La whole app si blocca sul boot dello `AuthService`. Insistere sul `try/catch` come pattern *sempre necessario* quando si decodifica input non controllato.

### 7. Retry su POST e su 4xx

```typescript
retry({ count: 2, delay: 500 })   // ❌ ritenta tutto, sempre, ovunque
```

Sintomo classico in aula con `npm run start:api`: scrivere un prodotto sbagliato → 3 POST in DB invece di 1 (json-server è permissivo). Più: errori 401/404/409 che impiegano 1.5s a comparire come toast. Fix: `delay` come funzione che filtra su `req.method === 'GET'` e su `err.status` ritentabile.

### 8. Pulsante "Logout" che non c'è

Il seme non ha un pulsante di logout (il login del corso base era one-way). Lo studente attento ne aggiungerà uno nell'header; quello distratto chiamerà `auth.logout()` da DevTools. Entrambi vanno bene per la verifica del lab — segnalarlo nel debrief come "in produzione il logout va sull'header".

---

## Note sul testing

Il `npx ng test` di `product-catalog-finale/` non testa specificatamente gli interceptor del Lab 4 (non si pretende che lo studente li copra). Il `auth-guard.spec.ts` esistente nel seme è uno smoke test minimale (`expect(executeGuard).toBeTruthy()`) che non invoca mai la guard: continua a passare anche con la nuova implementazione signal-based, quindi non va modificato.

> Estensione opzionale (10' in più): scrivere un vero test del `roleGuard` con `TestBed.runInInjectionContext` e mock di `AuthService.currentUser()` su due scenari (admin → true, user → UrlTree). Esempio canonico di testing delle functional guards Angular 21.

---

## Variazioni possibili

- **Logout button in header (5' in più).** Aggiungere un `<button (click)="auth.logout()">Logout</button>` nell'`HeaderComponent` con `@if (auth.isAuthenticated())`. Mostra `currentUser()?.name` di fianco.
- **Test del roleGuard (10' in più).** Test unit del `roleGuard('admin')` con `TestBed` e mock di `AuthService` — è un buon esempio di testing delle functional guards in Angular 21.
- **Refresh token reale (intera lezione separata).** Sostituire il token finto con un access+refresh, scrivere un piccolo middleware Express per `/auth/refresh`, gestire la coda durante il refresh. Non c'è tempo nel modulo; vale come extra-corso.
