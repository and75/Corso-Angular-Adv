# Lab 4 — Auth + Error Interceptor + roleGuard
### Giorno 2 · Lab guidato (65 min)

---

## Obiettivo

Mettere in sicurezza il Product Catalog applicando i pattern delle Schede 04–05 del Mod 4:

1. **`AuthService`** che simula l'autenticazione su `json-server`: `GET /users?email=...`, confronto password lato client, generazione di un **token finto** (`btoa({sub, role, exp})`) e persistenza in `localStorage`.
2. **`authInterceptor`** che aggiunge `Authorization: Bearer <token>` a tutte le chiamate dirette al nostro backend — *escludendo* la GET di login.
3. **`errorInterceptor`** che gestisce centralmente gli errori HTTP: 401 → logout + redirect a `/login?returnUrl=...`, altri errori → toast via `NotificationService`, `retry` mirato sui GET.
4. **`auth-guard`** che valuta `AuthService.isAuthenticated()` invece del placeholder del seme, e **`roleGuard('admin')`** come factory che restituisce una `CanActivateFn`.
5. Composizione `canActivate: [authGuard, roleGuard('admin')]` sull'area `/admin` ereditata dal Lab 3.

Risultato visibile:
- `admin@overnet.it / demo123` → entra in `/admin`, Bearer visibile in DevTools → Network.
- `user@overnet.it / demo123` → entra nell'app ma `/admin` viene negato dal `roleGuard` con un toast.
- Logout → la chiave `pc.token` sparisce da `localStorage` e il prossimo accesso a `/admin` redirige a `/login`.
- Manomettendo il token in DevTools (sostituirlo con una stringa qualsiasi) → al refresh, `AuthService` lo scarta silenziosamente e resetta lo stato.

> **Avvertenza didattica.** L'auth di questo lab è **simulata interamente lato Angular**:
> password in chiaro nel `db.json`, token finto opaco senza firma, niente IdP. È uno strumento per
> studiare il pattern Angular (interceptor + guard + storage), non un design di sicurezza. Tutto
> il codice Angular qui scritto, però, **non cambia** quando in produzione il backend diventa reale
> (HTTPS + JWT firmati + cookie HttpOnly). Per il "perché di questa scelta", vedi Scheda 05 §"Perché qui un token finto e non un JWT vero".

---

## Cosa cambia rispetto al Lab 3

```
ROOT (app.routes.ts)                                  app.config.ts
├── 'admin' → loadChildren(admin.routes)              providers: [
│                                                       provideHttpClient(
│        features/admin/admin.routes.ts                   withInterceptors([
│        canActivate: [                                     authInterceptor,   ← TODO 2
│          authGuard,         ← legge AuthService           errorInterceptor,  ← TODO 3
│          roleGuard('admin') ← TODO 5                    ]),
│        ]                                               ),
│                                                         ...
└── auth-guard.ts (TODO 4)                              ]
    return inject(AuthService).isAuthenticated()
        ? true
        : router.createUrlTree(['/login']);

services/auth.ts (TODO 1)                            pages/login/login.page.ts (TODO 4)
─────────────────────────                            ──────────────────────────────────
signal<User|null> _user                              inject(AuthService).login(email, pwd)
GET /users?email=…  → check pwd → btoa token         → setItem('pc.token', token)
restoreFromStorage al boot                           → router.navigate(returnUrl ?? '/admin')
getToken() validante                                 → su errore: notifications.error('credenziali')
```

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/services/auth.ts` | Biglietteria: login GET /users + token finto + signal currentUser + restoreFromStorage | **nuovo** |
| `src/app/interceptors/auth.interceptor.ts` | Aggiunge `Authorization: Bearer <token>` | **nuovo** |
| `src/app/interceptors/error.interceptor.ts` | 401 → logout+redirect, altri → toast, retry sui GET | **nuovo** |
| `src/app/guards/role.guard.ts` | Factory `roleGuard(role): CanActivateFn` | **nuovo** |
| `src/app/app.config.ts` | Registrazione interceptor con `withInterceptors([auth, error])` | modificato |
| `src/app/auth-guard.ts` | Usa `AuthService.isAuthenticated()` invece del placeholder localStorage | modificato |
| `src/app/pages/login/login.page.ts` | Form esistente collegato al nuovo `AuthService.login()` | modificato |
| `src/app/features/admin/admin.routes.ts` | `canActivate: [authGuard, roleGuard('admin')]` | modificato |
| `db.json` | Aggiungere collection `users` con 2 utenti seed (admin + user) | modificato |

> Il **template** `login.page.html` *non* viene modificato: il form template-driven del seme funziona già com'è. Cambia solo cosa fa `onSubmit` lato TypeScript. Lo stesso vale per `app.html` e tutti gli altri componenti già toccati dal Lab 3.

---

## Setup

### 1. Aggiungi gli utenti al `db.json`

Apri `Corso/progetto/product-catalog/db.json` (o il tuo working copy) e **sostituisci** la collection `users` con:

```json
"users": [
  { "id": 1, "email": "admin@overnet.it", "password": "demo123", "name": "Admin Demo", "role": "admin" },
  { "id": 2, "email": "user@overnet.it",  "password": "demo123", "name": "User Demo",  "role": "user"  }
]
```

> Password in chiaro: è dev. In produzione mai — verrebbero hashate con bcrypt/argon2 lato server e mai esposte via REST.

### 2. Avvia API + dev server

```bash
cd Corso/progetto/product-catalog
npm start         # avvia json-server (porta 3000) + ng serve (porta 4200) insieme
```

### 3. Sanity check dell'API

```bash
curl "http://localhost:3000/users?email=admin@overnet.it"
# atteso: [{ "id": 1, "email": "admin@overnet.it", "password": "demo123", "name": "Admin Demo", "role": "admin" }]
```

Se vedi un array vuoto, il seed non è stato applicato. Riapri `db.json` e ricontrolla.

---

## TODO 1 — FACILE: `services/auth.ts`

Crea **`src/app/services/auth.ts`**. È il file più grande del lab ma è anche il più lineare: una classe `@Injectable({ providedIn: 'root' })` che incapsula login, logout, stato corrente, e ripristino da `localStorage` al boot.

Struttura attesa:

- Interfacce `User` (`id`, `email`, `name`, `role: 'admin' | 'user'`) e `TokenPayload` (`sub`, `role`, `exp`).
- Costante `STORAGE_KEY = 'pc.token'`.
- Stato interno: `private _user = signal<User | null>(null)`.
- API pubblica:
  - `readonly currentUser = this._user.asReadonly()` — signal di sola lettura per i consumer.
  - `readonly isAuthenticated = computed(() => this._user() !== null)`.
  - `login(email, password): Promise<User>` — chiama `GET /users?email=...`, prende `[0]`, confronta `password` lato client, costruisce il payload (`exp = Date.now() + 60*60*1000`), genera `btoa(JSON.stringify(payload))`, lo salva in `localStorage[STORAGE_KEY]`, fa `this._user.set({...candidate without password})`. Se la password non combacia o nessun utente esiste, lancia `Error('Credenziali non valide')`.
  - `logout(): void` — `localStorage.removeItem(STORAGE_KEY)` + `this._user.set(null)`.
  - `getToken(): string | null` — usato dall'interceptor. Legge la chiave, prova a decodificare con `atob` + `JSON.parse` dentro un `try/catch`. Se è malformato o `exp < Date.now()`, rimuove la chiave e ritorna `null`. Altrimenti ritorna la stringa raw.
- Boot: nel costruttore chiama `restoreFromStorage()`, che decodifica il token, valida `exp`, e fa una `GET /users/<sub>` per popolare `_user` (così l'header dell'app può leggere `name` e `email`).

Suggerimenti:
- `firstValueFrom(this.http.get<User[]>(...))` per scrivere `login` in `async/await` senza farsi del male con `subscribe`.
- Il costruttore non può essere `async`: chiama `restoreFromStorage()` (non `await`), che a sua volta fa `.subscribe(...)` dentro.

Riferimento: **Scheda 05 §"La biglietteria — AuthService"** (codice completo + 4 perché).

---

## TODO 2 — MEDIO: `interceptors/auth.interceptor.ts`

Crea **`src/app/interceptors/auth.interceptor.ts`**. È il file più corto del lab e quello con la densità di "perché" più alta.

L'interceptor è una `HttpInterceptorFn` che riceve `(req, next)`. La logica:

1. `inject(AuthService).getToken()`.
2. Se il token è `null`, oppure la richiesta **non va al nostro backend** (`http://localhost:3000`), oppure è la **GET di login** (`http://localhost:3000/users?email=...`), passa la richiesta intatta a `next(req)`.
3. Altrimenti clona la richiesta con `req.clone({ setHeaders: { Authorization: 'Bearer ' + token } })` e passa il clone a `next(cloned)`.

I tre filtri sono motivati uno per uno nella scheda 05 §"Il buttafuori dello stand — authInterceptor"; il più subdolo è il check sulla GET di login (senza, in un backend reale, riceveresti 409 al cambio account). La logica `isLoginCall` può essere espressa come `req.url.startsWith('http://localhost:3000/users') && req.method === 'GET'` — basta. Se vuoi essere più rigoroso, controlla anche `req.params.has('email')`, ma non è strettamente necessario.

Riferimento: **Scheda 05 §"Il buttafuori dello stand — authInterceptor"**.

---

## TODO 3 — MEDIO: `interceptors/error.interceptor.ts`

Crea **`src/app/interceptors/error.interceptor.ts`**. Tre responsabilità in un solo file: gestire 401, notificare gli altri errori, ritentare i GET ritentabili.

Struttura attesa (in `pipe`, sopra a `next(req)`):

1. `retry({ count: 2, delay: (err) => ... })` — il `delay` come **funzione**. La funzione controlla se l'errore è ritentabile (`req.method === 'GET'` *e* `err.status === 0 || err.status >= 500`). Se sì, restituisce `timer(500)`. Se no, restituisce `throwError(() => err)` — questo *interrompe* il retry e propaga l'errore al `catchError` a valle.
2. `catchError((err: HttpErrorResponse) => { ... })`:
   - se `err.status === 401`: `inject(AuthService).logout()` + `inject(Router).navigate(['/login'], { queryParams: { returnUrl: location.pathname } })`;
   - altrimenti: `inject(NotificationService).error(mapStatusToMessage(err))`;
   - sempre: `return throwError(() => err)` (rilanciare è obbligatorio — vedi Scheda 04).

Suggerimenti:
- `inject()` si chiama in cima al body dell'interceptor, **non** dentro `catchError`. Le tre dipendenze (`AuthService`, `Router`, `NotificationService`) sono catturate nella closure.
- Mappa status → messaggio: 0 → "server non raggiungibile", 404 → "non trovato", 409 → "conflitto", `>= 500` → "errore del server", default → "errore generico".
- `location.pathname` invece di iniettare `Router.url` è una scorciatoia pragmatica: il `Router.url` si aggiorna *dopo* la navigate, e in mezzo al `catchError` non sempre coincide con la rotta corrente.

> **Importante per la registrazione**: in `app.config.ts` (TODO 4), l'ordine è `[authInterceptor, errorInterceptor]`. Invertirlo significa che il retry parte senza Bearer. Vedi Scheda 04 §"Errori comuni — 5. Cambiare l'ordine in withInterceptors".

Riferimento: **Scheda 04 §"Pattern 2 — error interceptor"** + **§"Pattern 3 — retry mirato"**.

---

## TODO 4 — MEDIO: collegare login + auth-guard

Due file da modificare:

### `src/app/pages/login/login.page.ts`

Il form **template-driven** del seme (`#f="ngForm"`, `[(ngModel)]`) resta com'è. Cambia solo `onSubmit`:

- inietta `AuthService` e `NotificationService` (oltre a `Router` e `ActivatedRoute`);
- in `onSubmit(isValid)` chiama `await this.auth.login(email, password)`;
- al successo: legge `queryParamMap.get('returnUrl')` e fa `router.navigateByUrl(returnUrl ?? '/admin')`;
- al fallimento (catch): `notifications.error('Credenziali non valide')` e basta — il form resta visibile, l'utente può ritentare.

Imports nuovi necessari: `AuthService`, `NotificationService`, `ActivatedRoute`. Lascia `FormsModule` e `RouterLink` come stanno.

### `src/app/auth-guard.ts`

Il placeholder del seme legge `localStorage.getItem('token')`. Sostituisci la logica con:

- inject di `AuthService` e `Router`;
- se `auth.isAuthenticated()` è `true` → ritorna `true`;
- altrimenti → ritorna `router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } })`. L'oggetto `UrlTree` è preferibile a `router.navigate()` dentro una guard: lascia ad Angular il controllo della navigazione e dell'ordine relativo agli altri eventi di routing.

Due cose da non scordare: usare `state.url` per `returnUrl` (è quello che la guard riceve come secondo argomento), e tipizzare la guard come `CanActivateFn` (Angular 21 idiomatic).

Riferimento: **Scheda 05 §"Lo stand chiuso — il 401"** (per `returnUrl`) e **§"Il flusso end-to-end"** (per il giro completo).

---

## TODO 5 — MEDIO: `guards/role.guard.ts` + composizione

Crea **`src/app/guards/role.guard.ts`** come **factory** — una funzione che riceve il ruolo richiesto e **ritorna** una `CanActivateFn`. La firma è `export function roleGuard(required: 'admin' | 'user'): CanActivateFn`.

La `CanActivateFn` ritornata, una volta invocata da Angular:

- inietta `AuthService`, `NotificationService`, `Router`;
- legge `auth.currentUser()` (il signal letto come funzione);
- se l'utente esiste e il suo `role` è uguale a `required` → ritorna `true`;
- altrimenti → chiama `notifications.error('Accesso negato: serve il ruolo X')` e ritorna `router.createUrlTree(['/'])` per dirottare alla home.

Non scrivere `export const roleGuard: CanActivateFn = ...` come si farebbe per una guard semplice: qui serve la **factory** perché vogliamo poter scrivere `roleGuard('admin')` con argomenti diversi sulle stesse routes.

Poi in **`src/app/features/admin/admin.routes.ts`** componi le due guard sulla rotta padre:

```typescript
canActivate: [authGuard, roleGuard('admin')]   // era: [authGuard]
```

L'ordine `[authGuard, roleGuard]` è motivato nella Scheda 05 §"Autenticazione vs autorizzazione": Angular valuta in AND, e se l'utente non è loggato non vogliamo nemmeno mostrargli il toast "accesso negato" — vogliamo mandarlo a `/login`.

---

## Criteri di verifica

### Funzionali (manuali, in DevTools)

- [ ] Login `admin@overnet.it / demo123` → atterri su `/admin`, Network mostra `Authorization: Bearer eyJ...` su `GET /products`.
- [ ] In `localStorage` c'è la chiave `pc.token` con un valore base64. `atob(...)` ti dà `{"sub":1,"role":"admin","exp":...}`.
- [ ] Click su "Logout" (o `auth.logout()` da console) → la chiave sparisce, refresh di `/admin` ti porta su `/login?returnUrl=/admin`. Dopo nuovo login, atterri di nuovo su `/admin`.
- [ ] Login `user@overnet.it / demo123` → entri ma `/admin` mostra un toast "Accesso negato" e ti porta su `/`.
- [ ] In DevTools → Application → Local Storage → modifica `pc.token` con `"ciao"` e ricarica. L'header non mostra più l'utente, niente errori in console, `pc.token` sparisce dallo storage.
- [ ] Credenziali sbagliate al login → toast "Credenziali non valide", resti sulla pagina di login.

### Formali (binario A — solution applicata a `product-catalog-finale/`)

```bash
cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test --watch=false
```

Zero errori, tutti i test verdi.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| Login OK ma `Authorization` non compare in Network | Manca `withInterceptors([authInterceptor, ...])` in app.config.ts, oppure stai cercando l'header sulla chiamata di login (che è esclusa dal Bearer per design) | TODO 2 + TODO 4 (`app.config.ts`) |
| `/admin` non parte mai, redirect immediato a `/login` | `auth-guard.ts` non sta leggendo `AuthService.isAuthenticated()`, o il signal è ancora `null` perché `restoreFromStorage` non è stato chiamato | TODO 1 (costruttore) + TODO 4 (`auth-guard`) |
| Login OK, ma al primo F5 perdi l'utente loggato | `restoreFromStorage` non c'è oppure non popola il signal | TODO 1 |
| Loop di redirect tra `/login` e `/admin` | Nel 401 dell'errorInterceptor stai facendo solo `router.navigate(['/login'])` senza `auth.logout()` prima | TODO 3 |
| Il `roleGuard` vede `currentUser()` `null` quando dovrebbe vedere admin | Stai navigando a `/admin` *prima* che `restoreFromStorage` abbia popolato il signal (race al boot) — la GET è ancora in volo. Alternativa: salvare l'utente intero in `localStorage`, non solo il token | TODO 1 / TODO 5 |
| Toast "Accesso negato" anche per l'admin | `roleGuard` confronta `role` con la stringa hardcoded sbagliata, oppure il payload del token non ha `role` (rileggi `login()`) | TODO 1 / TODO 5 |
| Retry su POST: ordine duplicato | Il `delay` del `retry` non filtra `req.method` | TODO 3 |
| Tutti i 4xx tornano dopo 1.5 s (3 tentativi inutili) | Il `delay` del retry sta ritentando anche per status 4xx — devi restituire `throwError(() => err)` per non-5xx | TODO 3 |
| `inject() can only be used within an injection context` nell'interceptor | Stai chiamando `inject()` *dentro* il `catchError`, non in cima al body | TODO 2 / TODO 3 |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!
