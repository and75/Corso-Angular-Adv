# Lab 3c — Named outlet cart preview
## Guida per il Docente

---

## 1. Scopo Didattico

Terzo e ultimo lab del Mod 3 (3a → 3b → **3c**). Chiude la teoria della Scheda 03 — outlet annidati e named outlet — con un esempio applicato: cart preview panel.

Tre messaggi chiave:

1. **Named outlet è uno strumento di nicchia.** Usatelo quando volete che lo stato del pannello sia nell'URL (bookmark, share, back/forward). Per UI pura, restate sui signal.
2. **Sintassi `routerLink` con named outlet è verbosa ma logica.** `[routerLink]="[{ outlets: { panel: ['cart'] } }]"` — array di segmenti che contiene un oggetto outlets, oggetto outlets con chiavi per ogni outlet da controllare, valore = array di segmenti del singolo outlet.
3. **`null` per chiudere, non `undefined`.** Il classico bug "il pannello si chiude ma al refresh torna" — `undefined` lascia la `(panel:cart)` nell'URL, `null` la rimuove.

---

## 2. Timing Consigliato

**Slot orario: 12:50–13:00 (10 minuti)**

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo del risultato (apertura/chiusura pannello, URL che cambia, refresh persiste) | 1 min |
| TODO 1 | Rotta `cart` con `outlet: 'panel'` in `app.routes.ts` | 2 min |
| TODO 2 | `<aside>` con `<router-outlet name="panel" />` in `app.html` | 2 min |
| TODO 3 | `CartPreviewPanel` wrapper di `CartSummary` | 4 min |
| TODO 4 | Link 👁️ nell'header | 1 min |
| **Totale** | | **~10 min** |

> Slot stretto: 10 minuti reali sono giusti per quattro modifiche piccole **ma indipendenti**. Lo studente non può confondersi su uno step e bloccare gli altri. Se il TODO 3 lo blocca (`CartPreviewPanel` da scrivere), può saltarlo e fare 1+2+4 prima — il pannello apparirà "vuoto" finché non scrive il TODO 3, e quello dà già un riscontro visivo sui named outlet.

---

## 3. Contesto nella Scaletta

- **Lab 3a** (12:15–12:35): feature area lazy + AdminLayout + children.
- **Lab 3b** (12:35–12:50): querystring filter + paginazione.
- **Lab 3c** (questo, 12:50–13:00): named outlet.

Aggancio col resto del corso:

- Il `CartSummary` riusato esiste dal corso base (M2 lab carrello). Anche se la metafora "il routing compone, non riscrive" l'abbiamo già vista nel 3a (riuso di `Admin` e `ProductFormPage`), qui torna su un componente di UI puro. Diverso dal 3a perché là si componevano *pagine*, qui un *frammento di UI*.
- Anticipa **Mod 4** (interceptor): in M4 vedremo come l'`authInterceptor` aggiunge il JWT alle chiamate del `ProductService`. Il pannello cart non vede il JWT: vede solo il signal `cartItems()` esposto dal service. Esempio concreto di "service come boundary".

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 La rotta con `outlet: 'panel'`

```typescript
{
  path: 'cart',
  outlet: 'panel',
  component: CartPreviewPanel,
}
```

**Cosa dire:**
> "`outlet: 'panel'` è la dichiarazione che cambia tutto: senza, la rotta finisce nel primary outlet — cliccando 👁️ la pagina principale viene sostituita dal carrello. Con `outlet: 'panel'`, la rotta vive in parallelo a quella primary. Notate che `outlet` non sta nel `path` — è una sorella di `component`/`canActivate`. Errore subdolo perché TypeScript non si lamenta in nessun caso."

### 4.2 Trucco `hidden has-[*]:block`

```html
<aside class="fixed right-4 top-20 w-80 bg-white border rounded-xl shadow-xl z-30 hidden has-[*]:block">
  <router-outlet name="panel" />
</aside>
```

**Cosa dire:**
> "L'alternativa naive è gestire la visibilità via `*ngIf`/`@if` legato a un signal — ma significa duplicare lo stato del router in un signal locale, e doverlo aggiornare ad ogni `NavigationEnd`. Tedioso. La utility Tailwind `has-[*]:block` usa il selector CSS `:has()` per chiedere 'l'aside ha figli? se sì, block; se no, hidden'. Quando il named outlet è inattivo, non emette markup (nessun figlio) → l'aside resta `hidden`. Quando emette `CartPreviewPanel` → l'aside diventa `block`. Zero JavaScript."

### 4.3 `inject(ProductService)` pubblico nel template

```typescript
export class CartPreviewPanel {
  productService = inject(ProductService);   // ✅ NIENTE `private`
  private router = inject(Router);
  // ...
}
```

**Cosa dire:**
> "Notate che `productService` non ha `private`. È volutamente pubblico, perché il template lo legge direttamente: `productService.cartItems()`, `productService.clearCart()`. È un'ottima pratica quando il componente è un wrapper — evita di scrivere getter intermedi e mantiene il legame esplicito. Solo `router` resta `private` perché lo usa il metodo `close()` interno."

### 4.4 `close()` — `null` non `undefined`

```typescript
close(): void {
  this.router.navigate([{ outlets: { panel: null } }]);
}
```

**Cosa dire:**
> "L'argomento è un array che contiene un oggetto outlets. Dentro outlets, una chiave per ogni outlet che voglio controllare — `null` per smontarlo. Errore tipico: usare `undefined` invece di `null`. `undefined` non rimuove l'outlet — l'URL conserva `(panel:cart)` e ricaricando la pagina il pannello si riapre da solo. Il bug 'il pannello si chiude visualmente ma torna al refresh' nove volte su dieci è questo."

### 4.5 Sintassi `[routerLink]` per aprire

```html
<a [routerLink]="[{ outlets: { panel: ['cart'] } }]"
   queryParamsHandling="preserve"
   ...>👁️</a>
```

**Cosa dire:**
> "Tre parentesi quadre annidate, una sintassi che disorienta la prima volta. Lette dall'esterno: array di segmenti di rotta (vuoto per restare sulla rotta corrente)... che contiene un oggetto outlets... che ha una chiave per ogni outlet da controllare... con valore un array di segmenti per quel singolo outlet. Per `panel: ['cart']`, il segmento è solo `'cart'`. Se la rotta del panel avesse parametri, sarebbe `panel: ['cart', userId]`. Il `queryParamsHandling="preserve"` è critico: senza, navigando dal `/admin/products?q=mac&page=2` perdi i filtri."

---

## 5. Errori comuni degli studenti

### ❌ Errore 1: Rotta senza `outlet: 'panel'`
**Sintomo:** cliccando 👁️ la pagina principale si svuota e appare il cart al suo posto.
**Causa:** la rotta `{ path: 'cart', component: CartPreviewPanel }` finisce nel primary outlet.
**Fix:** aggiungere `outlet: 'panel'`.

### ❌ Errore 2: Sintassi `routerLink` sbagliata
**Sintomo:** click non fa nulla, oppure errore di tipi.
**Causa:** dimenticato l'array esterno: `[routerLink]="{ outlets: { panel: ['cart'] } }"` invece di `[routerLink]="[{ outlets: { panel: ['cart'] } }]"`.
**Fix:** array che contiene l'oggetto outlets.

### ❌ Errore 3: `close()` con `undefined` invece di `null`
**Sintomo:** chiudere il pannello "funziona" a video ma l'URL conserva `(panel:cart)`; refresh riapre il pannello.
**Fix:** `panel: null`.

### ❌ Errore 4: `hidden has-[*]:block` dimenticato
**Sintomo:** un rettangolo bianco resta sempre visibile in alto a destra, anche con pannello chiuso.
**Fix:** aggiungere `hidden has-[*]:block` all'aside.

### ❌ Errore 5: `queryParamsHandling="preserve"` dimenticato sul link 👁️
**Sintomo:** aprire il pannello da `/admin/products?q=mac&page=2` lascia l'utente su `/admin/products(panel:cart)` — `q` e `page` spariti.
**Fix:** aggiungere `queryParamsHandling="preserve"`.

### ❌ Errore 6: `CartSummary` non importato negli imports del decoratore
**Sintomo:** `'app-cart-summary' is not a known element` nel template di `CartPreviewPanel`.
**Fix:** aggiungere `CartSummary` agli `imports` del decoratore `@Component`.

### ❌ Errore 7: `productService` dichiarato `private`
**Sintomo:** errore Angular template compilation `Property 'productService' is private and only accessible within class`.
**Fix:** rimuovere il `private` davanti all'inject (il template lo legge direttamente).

### ❌ Errore 8: Import di `CartPreviewPanel` dimenticato in `app.routes.ts`
**Sintomo:** errore TypeScript `Cannot find name 'CartPreviewPanel'`.
**Fix:** aggiungere `import { CartPreviewPanel } from './components/cart-preview-panel/cart-preview-panel';` in cima.

---

## 6. Domande frequenti

**Q: Si possono avere più named outlet allo stesso livello?**
A: Sì. Per esempio `<router-outlet name="panel" />` + `<router-outlet name="aside" />` con due rotte distinte. L'URL sarebbe `/admin/products(panel:cart//aside:filters)` (il `//` separa gli outlet named). Raro ma valido.

**Q: Perché non gestire il pannello con un signal locale invece del named outlet?**
A: Si potrebbe — `cartPanelOpen = signal(false)`, `@if (cartPanelOpen()) { <app-cart-preview-panel /> }`. Più semplice. Ma allora **non avete più lo stato del pannello nell'URL**: niente bookmark, niente share, niente refresh-resistente. La regola: named outlet solo se l'URL deve riflettere lo stato del pannello.

**Q: Perché lo `<aside>` è in `app.html` e non in `admin-layout.html`?**
A: Per scelta del progetto: il pannello cart deve essere accessibile da ovunque (anche home, login, checkout), non solo dall'area admin. Se fosse admin-only, lo metteremmo dentro `admin-layout.html`. L'`<aside>` in `app.html` è il livello giusto perché è "fratello" del primary outlet root.

**Q: `[{ outlets: { panel: ['cart'] } }]` — perché l'array esterno se voglio aprire solo un outlet?**
A: Perché `routerLink` accetta sempre un array di "segmenti di rotta". I segmenti possono essere stringhe (`'admin'`, `'products'`) o oggetti come `{ outlets: ... }`. Anche se passi un solo segmento, l'array esterno è obbligatorio dalla firma del Router.

---

## 7. Adattamenti

### Classe veloce (resta tempo):
- TODO bonus a voce: "come fareste in modo che il pulsante 👁️ sia **disabled** quando il carrello è vuoto?" → soluzione: legare `[disabled]="productService.cartItems().length === 0"`. Vale solo se usate `<button>` invece di `<a routerLink>` — discutete la differenza accessibilità/comportamento.
- TODO bonus avanzato: aggiungere un `confirm` quando l'utente sta per chiudere il pannello con elementi nel carrello.

### Classe lenta:
- Saltare il `hidden has-[*]:block` — accettare il rettangolo bianco visibile come compromesso.
- Saltare `queryParamsHandling="preserve"` — accettare la perdita dei filtri all'apertura del pannello. Discutere a voce perché è un bug.

### Cosa NON approfondire:
- Animazioni di apertura del named outlet (Angular Animations): UX, non Angular routing.
- `secondaryOutletName` per evitare hard-coding di `'panel'`: micro-ottimizzazione.
- Lazy loading del `CartPreviewPanel` con `loadComponent` sulla rotta `cart`: per un componente di 30 righe non ha senso.

---

## 8. Verifica NAP (binario A)

Stato di partenza: `product-catalog-finale/` con la solution di Lab 3a + 3b già applicate. Applicare i delta:

```bash
cp -r Corso/G2/lab-03c-named-outlet/solution/src/app/. Corso/progetto/product-catalog-finale/src/app/

cd Corso/progetto/product-catalog-finale
npx ng build
npx ng test
```

**Verifica funzionale suggerita (manuale):**
- `/admin/products` → vedi lista admin (eredità del 3b).
- Aggiungi prodotti al carrello dalla home.
- Torna su `/admin/products?q=mac&page=2`.
- Clicca 👁️ nell'header → URL diventa `…(panel:cart)`, pannello in alto a destra.
- Clicca ✕ → URL ritorna pulito (filtri preservati), pannello sparisce.
- Refresh con `(panel:cart)` nell'URL → pannello si riapre.

> **Fine modulo 3.** Il prossimo blocco di lab (Mod 4) ristruttura `AuthService`/interceptor/guard sopra a questa base.
