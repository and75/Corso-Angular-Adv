# Lab 3c — Named outlet: cart preview panel
### Giorno 2 · Lab guidato (~10 min) · Slot 12:50–13:00

---

## Obiettivo

Applicare il pattern della [Scheda 03 — Outlet annidati + named outlet](../didattica/03-outlet-annidati-named.md) aggiungendo un **pannello laterale** che mostra l'anteprima del carrello, controllato da un **named outlet** `panel`. Il pannello si apre cliccando 👁️ nell'header, si chiude con ✕, e il suo stato è **nell'URL** (`/admin/products(panel:cart)`): bookmarkabile, condivisibile, sopravvive al refresh.

Quattro modifiche piccole, indipendenti:

1. Una rotta `cart` con `outlet: 'panel'` in `app.routes.ts` (live in parallelo al primary outlet).
2. Un `<router-outlet name="panel" />` in un `<aside>` di `app.html`.
3. Un nuovo `CartPreviewPanel` standalone che fa da wrapper attorno a `CartSummary` esistente.
4. Un link `👁️` nell'header che apre il pannello con la sintassi `[routerLink]="[{ outlets: { panel: ['cart'] } }]"`.

Risultato visivo:

- `/admin/products?q=mac&page=2` → lista filtrata (eredità del Lab 3b).
- Clic su 👁️ nell'header → URL diventa `/admin/products(panel:cart)?q=mac&page=2` e in alto a destra appare un pannello con il riepilogo carrello.
- Clic su ✕ → URL torna `/admin/products?q=mac&page=2`, pannello sparisce. Il filtro/pagina restano grazie a `queryParamsHandling="preserve"` sul link.
- Refresh con `(panel:cart)` nell'URL → il pannello si riapre da solo.

> **Stato di partenza:** hai completato il [Lab 3b](../lab-03b-querystring/README.md) — nel tuo `product-catalog/` `AdminList` ha già filtro e paginazione via querystring. In questo lab si tocca solo l'infrastruttura di routing/UI top-level.

---

## Gerarchia rotte target

```
ROOT (app.routes.ts)                                  app.html
├── '' → 'home'                                       <router-outlet />          ← OUTLET ROOT (primary)
├── 'home'        → HomePage                                  │                         (mostra la rotta principale)
├── 'login'       → Login                                     │
├── 'admin'       → loadChildren(admin.routes)               │ /admin → AdminLayout
│                                                             │
├── 'checkout'    → loadComponent                            ▼ admin-layout.html
├── 'products/new'                                       AdminLayout (sidebar + )
├── 'products/:id'                                            <router-outlet />      ← OUTLET INTERNO (primary)
│                                                                                       (mostra il children)
└── 'cart'  outlet:'panel' → CartPreviewPanel    ← in PARALLELO al primary
                                                       │
                                                       ▼ <aside> in app.html
                                                  <router-outlet name="panel" />   ← OUTLET NAMED "panel"
                                                       │                              (mostra CartPreviewPanel
                                                       ▼                               quando attivo)
                                                  CartPreviewPanel → riusa <app-cart-summary>
```

URL composto: `/admin/products(panel:cart)?q=mac&page=2` — il `(panel:cart)` è la sintassi per i named outlet attivi e va **prima** della querystring (l'ordine canonico di `DefaultUrlSerializer`: segmenti+outlet, poi `?queryParams`).

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/app.routes.ts` | Aggiunge rotta `cart` con `outlet: 'panel'` | modificato |
| `src/app/app.html` | Aggiunge `<aside>` con `<router-outlet name="panel" />` | modificato |
| `src/app/components/cart-preview-panel/cart-preview-panel.ts` | Wrapper di `CartSummary`, header + close button | **nuovo** |
| `src/app/components/header/header.html` | Aggiunge `<a>` 👁️ che apre il named outlet | modificato |

`components/header/header.ts` **non viene modificato** (`RouterLink` è già negli imports dal seme).
`components/cart-summary/` **non viene modificato** — si riusa così com'è.

---

## Scaffolding — comandi Angular CLI

Un componente nuovo: `CartPreviewPanel`.

```bash
cd Corso/progetto/product-catalog

# Componente CartPreviewPanel
ng generate component components/cart-preview-panel --skip-tests
# alias breve:
ng g c components/cart-preview-panel --skip-tests
```

Note Angular 21:
- `ng g c` genera componente `standalone: true` di default.
- Il file è `cart-preview-panel.ts` (no suffisso `.component.ts`). Classe `CartPreviewPanel` (PascalCase).
- `--skip-tests` evita di generare `*.spec.ts`.
- In questo lab uso un **template inline** dentro il decoratore `@Component` (è breve, e tenerlo accanto al codice del componente rende più leggibile il rapporto template/handler). Quindi puoi eliminare il `.html` generato dallo schematic, oppure lasciarlo e usare `templateUrl`. Entrambe le scelte vanno bene.

> `ng` diretto perché in aula la CLI è installata globalmente.

---

## TODO 1 — FACILE: rotta `cart` con `outlet: 'panel'` (~2 min)

Apri `src/app/app.routes.ts` e aggiungi una rotta in fondo all'array `routes`:

- `path: 'cart'` — il path che andrà tra parentesi nell'URL (`(panel:cart)`).
- `outlet: 'panel'` — **dichiarazione critica**: senza, la rotta finisce nel primary outlet e cliccando 👁️ la home si svuota e appare il carrello al suo posto.
- `component: CartPreviewPanel` — il componente che crei nel TODO 3.

Aggiungi anche l'import in cima al file: `import { CartPreviewPanel } from './components/cart-preview-panel/cart-preview-panel';`.

Riferimento: [Scheda 03 §"Definire la rotta del named outlet"](../didattica/03-outlet-annidati-named.md).

---

## TODO 2 — FACILE: `<router-outlet name="panel" />` in `app.html` (~2 min)

Apri `src/app/app.html` e, **prima** del `</div>` finale (subito dopo `<app-toast />`), aggiungi un `<aside>` posizionato `fixed` a destra che contenga `<router-outlet name="panel" />`.

Classi Tailwind suggerite per l'aside:
- `fixed right-4 top-20 w-80` — posizione e dimensione.
- `bg-white border rounded-xl shadow-xl z-30` — aspetto a "card flottante".
- `hidden has-[*]:block` — l'aside resta `hidden` quando l'outlet è vuoto, diventa `block` quando ha un figlio. `has-[*]:block` è una utility Tailwind moderna che fa il check via `:has` CSS.

> Senza il trucco `hidden has-[*]:block`, l'aside lascia un rettangolo bianco vuoto in alto a destra anche quando il pannello non è aperto. Soluzione alternativa: gestirlo via `*ngIf`/`@if` legato a un signal — ma significa replicare lo stato del router in un signal, e diventa scomodo.

Riferimento: [Scheda 03 §"Dichiarare il named outlet nel template"](../didattica/03-outlet-annidati-named.md).

---

## TODO 3 — MEDIO: `CartPreviewPanel` wrapper di `CartSummary` (~4 min)

Crea `src/app/components/cart-preview-panel/cart-preview-panel.ts` (vedi sezione Scaffolding sopra).

**Cosa deve esporre la classe:**

- inject di `ProductService` (path `'../../services/product'`) — **lascialo `public`** (senza modificatore `private`), perché il template lo legge direttamente con `productService.cartItems()`, `productService.clearCart()`, ecc.
- inject di `Router` come **privato** — serve solo per il metodo `close()`.
- Metodo `close(): void` che chiama `this.router.navigate([{ outlets: { panel: null } }])`. Nota:
  - L'argomento è un **array** che contiene un oggetto con la chiave `outlets`.
  - `panel: null` smonta il named outlet (non usare `undefined` — non funziona).

**Imports del decoratore:** `[CartSummary]` (dal seme, path `'../cart-summary/cart-summary'`).

**Template (inline nel decoratore — è breve):**

- Un `<header>` con titolo "Anteprima carrello" e un `<button (click)="close()">✕</button>` a destra.
- Un body con `<app-cart-summary>` che riceve in input `[cartItems]="productService.cartItems()"` e ha due output `(clearCart)="productService.clearCart()"` e `(removeItem)="productService.removeFromCart($event)"`. Non riscrivere la UI del carrello — `CartSummary` esiste già, riusalo.

Riferimento: [Scheda 03 §"Esempio guida: cart preview"](../didattica/03-outlet-annidati-named.md).

---

## TODO 4 — FACILE: link 👁️ nell'header (~2 min)

Apri `src/app/components/header/header.html` e aggiungi un `<a>` nella `<nav>` (dopo il link "Carrello"). Attributi importanti:

- `[routerLink]="[{ outlets: { panel: ['cart'] } }]"` — sintassi name outlet. **Nota le tre parentesi quadre**: array esterno (segmenti di rotta), oggetto `outlets`, array interno (segmenti del named outlet).
- `queryParamsHandling="preserve"` — preserva `?q=...&page=...` dell'utente. Senza, navigando dal `/admin/products?q=mac&page=2` perdi i filtri.
- `title="Apri anteprima carrello"` — accessibilità.
- Classi Tailwind a tono con gli altri link della nav (suggerito: `text-sm font-medium px-3 py-1.5 rounded-full border border-teal-400 hover:bg-teal-600 transition-colors`).

Contenuto del link: l'emoji 👁️.

> `header.ts` non va toccato: ha già `RouterLink` negli `imports` (lo usa per gli altri link della nav).

Riferimento: [Scheda 03 §"Aprire un named outlet con routerLink"](../didattica/03-outlet-annidati-named.md).

---

## Criteri di verifica

- [ ] Cliccando 👁️ nell'header, l'URL passa da `/admin/products?q=mac&page=2` a `/admin/products(panel:cart)?q=mac&page=2`.
- [ ] Appare un pannello in alto a destra con il riepilogo del carrello, identico a quello del checkout (riuso di `CartSummary`).
- [ ] Cliccando ✕ nel pannello, l'URL ritorna `/admin/products?q=mac&page=2` (filtri preservati) e il pannello sparisce.
- [ ] Refresh dell'URL `/admin/products(panel:cart)?q=mac&page=2` → il pannello si riapre da solo.
- [ ] Aggiungere prodotti al carrello dalla home, poi aprire 👁️ → il pannello mostra i nuovi prodotti.
- [ ] Cliccando "Rimuovi" su un item dentro il pannello → l'item sparisce dal pannello E dal contatore "Carrello" nell'header (è lo stesso `ProductService`).
- [ ] L'aside in `app.html` **non lascia un rettangolo bianco** quando il pannello è chiuso (controlla con outlet vuoto: niente bordo bianco in alto a destra).
- [ ] `ng serve` senza errori, console del browser pulita.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| Cliccando 👁️ la pagina principale si svuota e appare il carrello al suo posto | La rotta `cart` manca di `outlet: 'panel'` — finisce nel primary outlet | TODO 1 |
| Cliccando 👁️ non succede nulla | Sintassi `routerLink` errata: `[routerLink]="{ outlets: { panel: ['cart'] } }"` (manca l'array esterno) | TODO 4 |
| Il pannello appare ma c'è un rettangolo bianco visibile anche da chiuso | Manca la utility `hidden has-[*]:block` sull'aside | TODO 2 |
| Cliccando ✕ il pannello "sparisce" ma l'URL conserva `(panel:cart)` e al refresh torna | `close()` passa `undefined` invece di `null` | TODO 3, `close()` |
| Cliccando 👁️ da `/admin/products?q=mac` si perdono `q` e `page` | Manca `queryParamsHandling="preserve"` sul link 👁️ | TODO 4 |
| Errore di template: `'app-cart-preview-panel' is not a known element` | Manca l'import di `CartPreviewPanel` in `app.routes.ts` (TODO 1) | TODO 1, import |
| Errore di template: `'app-cart-summary' is not a known element` dentro al pannello | Manca `CartSummary` negli `imports` del decoratore di `CartPreviewPanel` | TODO 3, decoratore |
| `ProductService is private — only accessible from within class` | Hai aggiunto `private` davanti all'inject di `ProductService`, ma il template lo legge | TODO 3, classe |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!

---

## Fine del Mod 3

Il Lab 3c chiude il blocco Mod 3 (Routing avanzato). Hai trasformato il routing del catalogo da una struttura flat a un'architettura enterprise: feature area lazy, children con guard sul padre, stato della vista nell'URL via querystring, pannello laterale con named outlet. **Prossimo passo:** Mod 4 — HttpClient avanzato (interceptors), dove la guard `authGuard` di oggi viene affiancata da un `authInterceptor` che aggancia il token JWT a ogni richiesta dell'area protetta.
