/**
 * components/cart-preview-panel/cart-preview-panel.ts — STARTER Lab 3c G2
 *
 * Wrapper attorno a CartSummary esistente, montato nel named outlet "panel".
 * È il contenuto della rotta { path: 'cart', outlet: 'panel', component: CartPreviewPanel }
 * (TODO 1 in app.routes.ts).
 *
 * Pattern:
 *  - usa il singleton ProductService già esistente nel seme (cartItems signal);
 *  - il close si auto-gestisce: chiama router.navigate con outlets.panel = null;
 *  - riusa CartSummary del seme senza modificarlo.
 *
 * Vedi Scheda 03 G2 §"Esempio guida — Cart preview" e Lab 3c README §TODO 3.
 */

import { Component } from '@angular/core';

// TODO 3 — Import necessari da aggiungere:
//   - inject da '@angular/core'.
//   - Router da '@angular/router'.
//   - ProductService da '../../services/product'.
//   - CartSummary da '../cart-summary/cart-summary'.

@Component({
  selector: 'app-cart-preview-panel',
  standalone: true,
  /*
   * TODO 3 — Aggiungi CartSummary a questo imports:
   *   imports: [ CartSummary ]
   */
  imports: [],
  template: `
    <!--
      TODO 3 — Struttura del template inline:

        <header class="flex justify-between items-center p-4 border-b">
          <h2 class="font-bold text-teal-700">Anteprima carrello</h2>
          <button (click)="close()" class="text-gray-400 hover:text-gray-700 text-lg leading-none">
            ✕
          </button>
        </header>
        <div class="p-4">
          <app-cart-summary
            [cartItems]="productService.cartItems()"
            (clearCart)="productService.clearCart()"
            (removeItem)="productService.removeFromCart($event)"
          />
        </div>

      Note:
       - productService va dichiarato come PUBBLICO (no "private") perché il template
         lo legge direttamente (productService.cartItems()).
       - close() naviga al named outlet con valore null per smontarsi.
    -->
  `,
})
export class CartPreviewPanel {

  /*
   * TODO 3 — Dichiara i due inject:
   *
   *   productService = inject(ProductService);    ← PUBBLICO, il template lo legge
   *   private router = inject(Router);            ← privato, usato solo dal close()
   *
   *  ⚠️ Niente "private" su productService.
   *  ⚠️ "private" su router (non c'è motivo di esporlo al template).
   */

  /*
   * TODO 3 — Metodo close():
   *
   *   close(): void {
   *     // Smonta il named outlet.
   *     // ⚠️ usare null, NON undefined: undefined non rimuove (panel:cart) dall'URL.
   *     this.router.navigate([{ outlets: { panel: null } }]);
   *   }
   *
   * Vedi Scheda 03 G2 §"Errori comuni — 3. close() con undefined".
   */
}
