// app.routes.ts — STARTER Lab 3c G2
//
// Stato di partenza: SOLUTION del Lab 3a (rotta 'admin' lazy via loadChildren).
// Il Lab 3b non tocca questo file.
// Obiettivo: aggiungere una rotta 'cart' su outlet:'panel' per il named outlet (TODO 1).

import { Routes } from '@angular/router';
import { HomePage } from './pages/home/home.page';
import { authGuard } from './auth-guard';
import { Login } from './pages/login/login.page';

// TODO 1 — Aggiungi qui sopra l'import del nuovo componente:
//   import { CartPreviewPanel } from './components/cart-preview-panel/cart-preview-panel';
//   (lo crei nel TODO 3)

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomePage },
  { path: 'login', component: Login },

  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then(m => m.default),
  },

  {
    path: 'checkout',
    loadComponent: () =>
      import('./pages/checkout/checkout.page').then(m => m.CheckoutPage),
  },
  {
    path: 'products/new',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./pages/product-form/product-form.page').then(m => m.ProductFormPage),
  },
  {
    path: 'products/:id',
    loadComponent: () =>
      import('./pages/product-detail/product-detail.page').then(m => m.ProductDetailPage),
  },

  /*
   * TODO 1 — Aggiungi qui in fondo una rotta per il named outlet "panel":
   *
   *   - path: 'cart'                  ← il segmento che apparirà tra parentesi nell'URL: (panel:cart)
   *   - outlet: 'panel'               ← OBBLIGATORIO: senza, la rotta finisce nel primary outlet e
   *                                     cliccando 👁️ la pagina principale viene sostituita dal carrello
   *   - component: CartPreviewPanel   ← il nuovo componente (TODO 3)
   *
   *   ⚠️ outlet è una sorella di component/canActivate, NON sta dentro path.
   *
   *   Vedi Scheda 03 G2 §"Definire la rotta del named outlet" e Lab 3c README §TODO 1.
   */
];
