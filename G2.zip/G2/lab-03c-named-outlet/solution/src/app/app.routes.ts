// app.routes.ts — SOLUTION Lab 3c G2
// Delta rispetto al Lab 3a (= 3b non tocca questo file):
//  ✅ TODO 1 — aggiunta rotta named outlet 'cart' con outlet: 'panel'

import { Routes } from '@angular/router';
import { HomePage } from './pages/home/home.page';
import { authGuard } from './auth-guard';
import { Login } from './pages/login/login.page';
import { CartPreviewPanel } from './components/cart-preview-panel/cart-preview-panel';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomePage },
  { path: 'login', component: Login },

  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then(m => m.default),
  },

  {
    path: 'checkout',
    loadComponent: () =>
      import('./pages/checkout/checkout.page').then(m => m.CheckoutPage),
  },
  {
    path: 'products/new',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./pages/product-form/product-form.page').then(m => m.ProductFormPage),
  },
  {
    path: 'products/:id',
    loadComponent: () =>
      import('./pages/product-detail/product-detail.page').then(m => m.ProductDetailPage),
  },

  // ✅ TODO 1 — rotta named outlet 'panel' per il cart preview.
  // outlet:'panel' è OBBLIGATORIO: senza, la rotta finisce nel primary outlet.
  {
    path: 'cart',
    outlet: 'panel',
    component: CartPreviewPanel,
  },
];
