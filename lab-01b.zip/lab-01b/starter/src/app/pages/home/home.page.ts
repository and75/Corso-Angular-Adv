/**
 * STARTER lab-01b — home.page.ts
 *
 * ┌─ TODO 4 — DIFFICILE ──────────────────────────────────────────────────
 * │ Una volta creato `ProductBody`:
 * │  - cambia l'import da `ProductCard` a `ProductBody`
 * │  - aggiorna l'array `imports:` del @Component
 * │  - elimina il metodo `getVariant(product)` (sotto): la variant ora si
 * │    legge direttamente da `product.variant` nel template
 * │
 * │ NB: l'esercizio di TODO 5 (nel template) userà
 * │     `[variant]="product.variant ?? 'default'"` quindi qui in TS non
 * │     serve più alcun mapping calcolato.
 * └───────────────────────────────────────────────────────────────────────
 */

import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Product, ProductCategory } from '../../product.model';
import { FilterProductsPipe } from '../../pipes/filter-products-pipe';
import { ProductService } from '../../services/product';
import { CartSummary } from '../../components/cart-summary/cart-summary';
import { ProductCard } from '../../components/product-card/product-card';
import { CardContainer } from '../../components/card-container/card-container';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, FormsModule, FilterProductsPipe, CartSummary, ProductCard, CardContainer],
  templateUrl: './home.page.html'
})
export class HomePage {

  selectedCategory = 'Tutti';
  searchTerm = '';
  categories: string[] = ['Tutti', ...Object.values(ProductCategory)];

  products: Product[] = [];
  isLoading = true;
  error: string | null = null;

  productService = inject(ProductService);

  ngOnInit(): void { this.loadProducts(); }

  loadProducts(): void {
    this.isLoading = true;
    this.error = null;
    this.productService.getProducts().subscribe({
      next: data  => { this.products = data; this.isLoading = false; },
      error: err  => { this.error = err.message || 'Errore sconosciuto'; this.isLoading = false; }
    });
  }

  retry(): void { this.loadProducts(); }

  onSelectCategory(category: string): void { this.selectedCategory = category; }

  get filteredProducts(): Product[] {
    const sorted = [...this.products].sort((a, b) => b.price - a.price);
    return this.selectedCategory === 'Tutti'
      ? sorted
      : sorted.filter(p => p.category === this.selectedCategory);
  }

  /**
   * TODO 4 — DA RIMUOVERE.
   * Mapping calcolato della variant: con il campo opzionale `variant` sul
   * Product (TODO 1) questo metodo non serve più — la variante viaggia
   * dato per dato, non si deriva.
   */
  getVariant(product: Product): 'default' | 'success' | 'warning' | 'info' {
    if (!product.available) return 'warning';
    if (product.category === ProductCategory.Laptop) return 'info';
    if (product.price > 1000) return 'success';
    return 'default';
  }

  onAddToCart(product: Product): void   { this.productService.addToCart(product); }
  onRemoveItem(productId: number): void { this.productService.removeFromCart(productId); }
  onClearCart(): void                   { this.productService.clearCart(); }
}
