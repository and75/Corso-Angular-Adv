/**
 * STARTER lab-01b — product-card.ts (versione monolitica del seme)
 *
 * ┌─ TODO 3 — DIFFICILE ───────────────────────────────────────────────────
 * │ Lo scopo di questo TODO è SPACCARE il componente: la parte informativa
 * │ del corpo (immagine, descrizione, prezzo) viene estratta in un nuovo
 * │ componente `ProductBody`. Titolo, badge categoria e bottone "Aggiungi"
 * │ NON vivranno più qui: saranno proiettati negli slot del CardContainer
 * │ dal padre (home.page.html).
 * │
 * │ Passi:
 * │  1. Genera il nuovo componente:
 * │       ng generate component components/product-body --skip-tests
 * │     (alias breve: `ng g c components/product-body --skip-tests`)
 * │  2. Nel nuovo componente, ricrea:
 * │       - selector  'app-product-body'
 * │       - input.required<Product>() chiamato `product`
 * │       - computed formattedPrice (identico a quello sotto)
 * │       - goToDetail() (identico a quello sotto)
 * │     RIMUOVI:
 * │       - output<Product>() addToCart
 * │       - onAddToCartClick()
 * │     Il bottone viene gestito dal padre, non più dalla card.
 * │  3. Sposta il template (solo immagine + descrizione + prezzo) — vedi
 * │     TODO 3-bis nel file product-card.html.
 * │  4. Cancella l'intera cartella `product-card/` quando hai finito.
 * └────────────────────────────────────────────────────────────────────────
 */

import { Component, inject, input, output, computed } from '@angular/core';
import { NgClass } from '@angular/common';
import { Router } from '@angular/router';
import { Product } from '../../product.model';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [NgClass],
  templateUrl: './product-card.html',
})
export class ProductCard {

  private router = inject(Router);

  product = input.required<Product>();
  addToCart = output<Product>();

  formattedPrice = computed(() =>
    new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
    }).format(this.product().price)
  );

  goToDetail(): void {
    this.router.navigate(['/products', this.product().id]);
  }

  onAddToCartClick(): void {
    this.addToCart.emit(this.product());
  }
}
