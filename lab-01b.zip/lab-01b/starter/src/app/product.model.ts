/**
 * STARTER lab-01b — product.model.ts
 *
 * ┌─ TODO 1 — FACILE ──────────────────────────────────────────────────────
 * │ Aggiungere un type alias `CardVariant` con i 4 valori canonici del
 * │ CardContainer ('default' | 'success' | 'warning' | 'info') e un campo
 * │ opzionale `variant?` su Product, tipato come CardVariant.
 * │
 * │ Perché: il CardContainer ha già un @Input() variant tipato sugli stessi
 * │ 4 valori. Avere il type esportato qui evita di duplicarlo e permette ai
 * │ dati (db.json) di indicare la variante della card prodotto per prodotto.
 * │
 * │ Dove guardare: card-container.ts → @Input() variant: 'default' | ...
 * └────────────────────────────────────────────────────────────────────────
 */

export enum ProductCategory {
  Laptop     = 'Laptop',
  Smartphone = 'Smartphone',
  Tablet     = 'Tablet',
  Audio      = 'Audio',
  Accessori  = 'Accessori',
  Wearable   = 'Wearable',
  Desktop    = 'Desktop',
  Media      = 'Media'
}

export interface Product {
  id: number;
  name: string;
  price: number;
  category: ProductCategory;
  available: boolean;
  description?: string;
  imageUrl?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export function getFirst<T>(items: T[]): T | null {
  return items.length > 0 ? items[0] : null;
}
