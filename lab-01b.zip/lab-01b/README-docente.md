# Lab 1b — CardContainer multi-slot + ProductBody + variant
## Guida per il Docente

---

## 1. Scopo Didattico

Il Lab 1b chiude il cerchio della Scheda 06 (multi-slot projection) **vista dall'altro lato**: nel Lab 1 lo studente aggiungeva slot a un componente esistente; qui invece adotta un **wrapper component** (`CardContainer`) che ha già 3 slot e impara a **comporre** dal padre.

Tre concetti chiave consolidati:

1. **Inversione di responsabilità** — la card non sa chi mostra il suo titolo, il suo footer o il suo badge. Lo decide il padre. Il pattern di tutte le UI library (Material, Bootstrap, headless).
2. **Splitting di componenti** — `ProductCard` diventa `ProductBody`. Il refactor obbliga lo studente a chiedersi: cosa appartiene davvero al *body* e cosa no? Buona occasione per discutere il principio di "componente piccolo e focalizzato".
3. **Props tipati con type alias condivisi** — `CardVariant` è esportato dal `product.model.ts` e consumato sia dall'`@Input()` del container, sia come campo opzionale del modello dati. Evita drift fra UI e dato.

L'esercizio è **interamente visivo**: dopo ogni TODO il risultato si vede a video (header colorato, footer ricomposto, body sfoltito).

---

## 2. Timing Consigliato

**Slot orario: ~45 minuti** (modulo G1 pomeriggio, dopo le schede 05b/06).

| Fase | Attività | Durata |
|---|---|---|
| Intro | Demo "prima/dopo" della home: stesso risultato visivo, ma decomposizione diversa | 3 min |
| TODO 1 | `CardVariant` + `variant?` su Product | 3 min |
| TODO 2 | Wireup `[class]` su header → verifica visiva con `variant='success'` temporaneo | 5 min |
| TODO 3 | Splitting in `ProductBody` (CLI + copia + sfoltimento + cancellazione vecchia cartella) | 15 min |
| Recap di mezzo | A video: la home ancora rotta, ma il componente nuovo esiste; spiegare perché serve il TODO 5 prima di vedere risultato | 2 min |
| TODO 4 | Imports + rimozione `getVariant` | 5 min |
| TODO 5 | Ricomposizione `@for`: slot header + body + footer con categoria + bottone | 10 min |
| Verifica finale | Criteri visivi + binario A | 2 min |
| **Totale** | | **~45 min** |

> Se la classe è veloce, proponi a voce: "Come trasformeresti il `CardContainer` in un componente di una libreria UI riusabile? Cosa toglieresti del wireup di home per renderlo agnostico?" — risposta nella sezione 7.

---

## 3. Contesto nella Scaletta

Il Lab 1b arriva **dopo** il Lab 1 (componenti dinamici + QuickView) e **prima** del Lab 2a (Splide + NgZone). Il pacchetto Mod 1 procede:

- Lab 1 (~30 min ridotto, solo QuickView dinamico)
- Lab 1b (~45 min, questo lab)
- Lab 2a (~18 min, carousel)
- Lab 2b (~22 min, NotificationService + bonus signal)

Lo stato di partenza di Lab 1b è il `product-catalog/` dopo Lab 0 + Lab 1 ridotto. La solution di Lab 1b si cumula su `product-catalog-finale/`.

> Frase chiave da dire all'inizio: "Nel Lab 1 abbiamo visto come aggiungere slot a un componente che già esiste. Oggi invertiamo la prospettiva: il `CardContainer` esiste già con i suoi slot, e noi lo *adottiamo*. È il pattern delle UI library — il componente è un guscio, voi decidete cosa metterci dentro."

---

## 4. Soluzione Commentata — Punti chiave

### 4.1 Type alias condiviso `CardVariant` (TODO 1)

Punto sottile: il prop `variant` del container è già tipato su 4 stringhe letterali. Senza il type alias condiviso, ogni consumer riscriverebbe `'default' | 'success' | 'warning' | 'info'` localmente. Bug latente: aggiungere una variante in futuro richiede di toccare N file.

**Cosa dire:**
> "Il type alias `CardVariant` è la SST (Single Source of Truth) della UI delle card. È esportato dal model perché è anche un dato — un prodotto può portarsi dietro la sua variante. Se domani aggiungete `'danger'`, una sola riga cambia."

### 4.2 `[class]` vs `class` + `[ngClass]` (TODO 2)

Domanda ricorrente: "perché non usare `[ngClass]`?"

```html
<div [class]="headerClass + ' px-4 py-3'">
```

**Risposta:**
> "`[class]` con stringa è il binding base — diretto, niente directive. `[ngClass]` brilla quando devi attivare/disattivare *classi singole condizionali* (`{active: foo, error: bar}`). Qui abbiamo una sola stringa calcolata, `[class]` è più semplice. Attenzione: con `[class]="stringa"` una `class="..."` statica accanto verrebbe sovrascritta — non doppia dichiarazione."

### 4.3 Splitting di ProductCard → ProductBody (TODO 3)

Punti da sottolineare:

- Cancellare la cartella `product-card/` invece di rinominare il file. Aiuta a togliere il riflesso "tengo il vecchio commentato".
- L'output `addToCart` sparisce: in un componente "presentazionale" puro, anche gli output sono superflui quando l'azione vive nel padre. Pattern dumb component spinto.
- Niente più `$event.stopPropagation()`: c'era perché il bottone era *dentro* il div cliccabile della card. Ora il bottone vive nel footer del CardContainer, fuori dal body cliccabile. Meno righe, meno bug.

**Cosa dire:**
> "Quando spostate logica negli slot del padre, spesso scoprite che il figlio ha output e workaround che non gli servono più. Quel `stopPropagation` era un sintomo: la card si arrogava la responsabilità di un click di cui non era più la padrona. Levarlo è un piccolo refactor pulito."

### 4.4 `[variant]="product.variant ?? 'default'"` (TODO 5)

Pattern compatto col nullish coalescing nel template. Coerente con `input.required<T>()` lato container (richiede un valore).

**Cosa dire:**
> "Il campo `variant` è opzionale sul Product, ma il container lo vuole sempre. Il `??` materializza il default lì dove serve, senza dover decidere il default nel servizio o nel mock. Pattern leggero."

---

## 5. Confronto con Lab 1

Il Lab 1 lavora "dall'alto verso il basso": ho un componente esistente, gli aggiungo slot, lo adatto. Il Lab 1b lavora "dal basso verso l'alto": ho un wrapper con slot già fatti, ridisegno i componenti sopra per usarlo.

In aula vale la pena chiarire che **entrambi i pattern coesistono nei progetti reali**:

- Pattern 1 (slot retrofittati): rivisiti un componente vecchio quando ti serve maggior flessibilità. Frequente nei monoliti legacy.
- Pattern 2 (wrapper di libreria UI): adottato in greenfield o quando si introduce un design system. Frequente in progetti maturi.

> "Il Lab 1 è il pattern del refactor opportunistico. Il Lab 1b è il pattern del design system. Entrambi escono dalla stessa scheda di teoria, perché la primitiva `ng-content` è la stessa — cambia chi guida la composizione."

---

## 6. Errori comuni degli studenti

### ❌ Errore 1: rinomina manuale dei file invece di `ng g c`
**Sintomo:** import rotti, IDE confuso, niente schematic sotto la mano.
**Causa:** lo studente fa `mv product-card.ts product-body.ts` invece di generare il componente nuovo.
**Fix:** usare l'alias `ng g c components/product-body --skip-tests`. Lo schematic scrive selector, decoratore standalone, e crea anche `.html` vuoto.

### ❌ Errore 2: lasciare `product-card/` non cancellata
**Sintomo:** build passa ma "non vedo modifiche". Oppure dopo qualche minuto, errore TS "duplicate component".
**Causa:** il vecchio componente è ancora importato da qualche altra parte (es. tipicamente da product-list.ts).
**Fix:** grep `ProductCard` in tutto `src/` e ripulire.

### ❌ Errore 3: dimenticare `[variant]` nullish coalescing
**Sintomo:** `Type 'undefined' is not assignable to type "default" | "success" | …`.
**Causa:** `product.variant` è opzionale, il container lo vuole stretto.
**Fix:** `[variant]="product.variant ?? 'default'"`.

### ❌ Errore 4: `[class]="headerClass"` senza padding base
**Sintomo:** l'header diventa colorato ma con padding sballato (ammucchiato).
**Causa:** il vecchio `px-4 py-3` non è stato concatenato.
**Fix:** `[class]="headerClass + ' px-4 py-3'"`.

### ❌ Errore 5: rimuovere `(addToCart)` dal markup ma lasciare l'output sul ProductBody
**Sintomo:** nessun errore, ma il bottone Aggiungi non funziona perché il vero handler vive nel padre.
**Causa:** lo studente "sopravvive" copiando dal vecchio ProductCard senza pulizia.
**Fix:** in ProductBody **NON** dichiarare `addToCart = output<Product>()`. Verificare l'assenza con grep.

---

## 7. Domande frequenti

**Q: Perché non un `[title]` sul container invece di uno slot `[header]`?**
A: Il container ha entrambi (`[title]` come default rendering dell'header). Per il lab insistiamo su `[header]` perché vogliamo che lo slot sia il pattern principale. `[title]` è un comodo "shortcut" per casi semplici, ma lo slot scala (es. titolo + sottotitolo, badge accanto, etc.). In Lab 1b ignoriamo `[title]` di proposito.

**Q: Si poteva mantenere `ProductCard` e farne un "facade" che usa `CardContainer` dentro?**
A: Sì, e in molti design system è esattamente il pattern (componenti specializzati che wrappano il container generico). L'abbiamo evitato per timing: avrebbe aggiunto un'indirezione senza giovare al focus didattico. Spunto a casa: "trasformate ProductBody in un ProductCard che incapsula CardContainer + slot pre-cablati".

**Q: Si può rendere il container ancora più generico (es. slot dinamici)?**
A: Con `<ng-template>` + `ngTemplateOutlet` sì (Scheda 07). Per esempio, il consumer potrebbe passare il template del footer parametrizzato dal `Product`. Per ora con `ng-content` siamo coperti perché il padre ha già accesso al `product` nel `@for`.

**Q: Perché `output addToCart` di `ProductBody` scompare e in `ProductCard` invece c'era?**
A: Era una concessione del refactor precedente (signal output). Qui che la responsabilità del bottone si sposta nel footer del container — gestito dal padre — l'output non serve più. Esempio concreto di "interfaccia che si semplifica man mano che le responsabilità si spostano".

---

## 8. Adattamenti

### Se la classe è veloce (finiscono in 30 min):
Proponi a voce il bonus: estendere `CardVariant` con un quinto valore `'danger'`, aggiornare `headerClass` nel container, assegnare `'danger'` a un prodotto nel `db.json` e verificare a video. Mostra la SST: un type alias cambiato si riflette ovunque.

### Se la classe è lenta:
Tagliare il TODO 2 (wireup `headerClass`) e fornirlo pre-fatto nello starter, concentrandosi sullo splitting + ricomposizione che è il cuore didattico. Il colore dell'header diventa "magia di default" — accettabile per non perdere il filo.

### Cosa NON approfondire in aula:
- Pattern facade `ProductCard` su `CardContainer` (interessante ma fuori scope).
- Test di componente sugli slot (sono delicati con `ng-content`; meglio capitolo separato).
- Tematizzazione completa via CSS variables (slittiamo lì nei moduli successivi).

---

## 9. Verifica NAP (binario A)

A fine lab, applicare i 6 file di `solution/` sopra a `Corso/progetto/product-catalog-finale/`:

```bash
# (esegue l'utente, da fuori da questo lab)
cp -r Corso/G1/lab-01b/solution/src/app/* Corso/progetto/product-catalog-finale/src/app/

# cancella la vecchia cartella product-card nel finale
rm -rf Corso/progetto/product-catalog-finale/src/app/components/product-card

cd Corso/progetto/product-catalog-finale
npx ng build       # atteso: Application bundle generation complete
npx ng test        # atteso: tutti i Test Files passed
```

Il seme `Corso/progetto/product-catalog/` resta intatto.
