# Lab 1b — CardContainer multi-slot + ProductBody + variant
### Giorno 1 · Lab guidato (~45 min)

---

## Obiettivo

Applicare il pattern **wrapper component con slot multi** (Scheda 06): il `CardContainer` diventa il guscio riusabile della UI; `ProductCard` viene splittata in `ProductBody` (solo corpo informativo) e tutto il resto — titolo, badge categoria, bottone "Aggiungi" — viene **proiettato dal padre** negli slot del container.

Lungo la strada, il prop `variant` del `CardContainer` viene effettivamente cablato sull'header (oggi è ignorato) e diventa la chiave per colorare le card in base a un nuovo campo del `Product`.

Risultato visivo: stessa griglia di card di prima, ma **ricomposta**. L'header colorato cambia per i prodotti con `variant: 'success' | 'warning' | 'info'`; il footer ospita ora categoria + bottone Aggiungi affiancati.

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/product.model.ts` | aggiunge `CardVariant` + `variant?` su Product | modificato |
| `src/app/components/card-container/card-container.html` | wireup `[class]` su header per applicare `headerClass` | modificato |
| `src/app/components/product-body/product-body.ts` + `.html` | nuovo componente, solo corpo informativo | **nuovo** |
| `src/app/components/product-card/` | rimosso (sostituito da product-body) | **rimosso** |
| `src/app/pages/home/home.page.ts` | import `ProductBody`, rimuove `getVariant()` | modificato |
| `src/app/pages/home/home.page.html` | `@for` ricomposto con slot `[header]` + body + `[footer]` | modificato |

> Il resto del progetto è invariato.

---

## Scaffolding — comandi Angular CLI

Solo un componente nuovo da generare:

```bash
cd Corso/progetto/product-catalog
ng generate component components/product-body --skip-tests
# alias breve:
# ng g c components/product-body --skip-tests
```

> **Nota Angular 21**: lo schematic crea `product-body.ts` / `.html` (niente più suffisso `.component.ts`) e li marca `standalone: true` per default.

Dopo aver portato in `ProductBody` il codice che serve (TODO 3) e averlo agganciato in home (TODO 4–5), **cancella manualmente** la cartella `src/app/components/product-card/` — non c'è uno schematic `ng destroy`, va rimossa a mano.

---

## Setup veloce

Se non hai già `ng serve` + `json-server` attivi:

```bash
# Shell 1
cd Corso/progetto/product-catalog
npx json-server --watch db.json --port 3000

# Shell 2
cd Corso/progetto/product-catalog
ng serve
```

Apri `http://localhost:4200` → home con i prodotti.

---

## TODO graduati

### TODO 1 — FACILE: campo `variant?` su Product (~3 min)

Apri `src/app/product.model.ts`.

Aggiungi un type alias `CardVariant` con i 4 valori canonici del container (gli stessi che vedi in `card-container.ts` sull'`@Input() variant`). Poi aggiungi un campo opzionale `variant?: CardVariant` su `Product`.

> Perché export del type? Per evitare di duplicarlo. Domani, se ne serve un quinto, lo aggiungi in un solo posto.

### TODO 2 — MEDIO: wireup `headerClass` nel container (~5 min)

Apri `src/app/components/card-container/card-container.html`.

Il div dell'header oggi ha solo classi statiche, e il getter `headerClass` (in `card-container.ts`) non viene mai applicato. Sostituisci la `class="..."` del div header con un `[class]="..."` che compone in stringa:
- le classi base di padding;
- il valore di `headerClass`.

Pattern utile:

```html
[class]="propertyA + ' ' + 'class-statiche'"
```

Verifica: passa `[variant]="'success'"` temporaneamente su un container nella home → l'header diventa verde.

### TODO 3 — DIFFICILE: splittare ProductCard → ProductBody (~15 min)

1. Genera il componente (vedi sezione Scaffolding).
2. Nel nuovo `product-body.ts` ricrea il minimo indispensabile:
   - selector `app-product-body`
   - `product = input.required<Product>()`
   - `formattedPrice` come computed (formato `'it-IT'`, currency EUR)
   - `goToDetail()` con `Router.navigate(['/products', this.product().id])`
   - **non** ricreare `output addToCart` né `onAddToCartClick`.
3. Nel template `product-body.html` tieni solo:
   - immagine 📦
   - descrizione (`product().description`)
   - prezzo (`formattedPrice()`)
   - `(click)="goToDetail()"` sul div esterno
   - `[ngClass]` con `'bg-red-50 opacity-40'` quando `!product().available`
4. Cancella `src/app/components/product-card/`.

> Tip: non commentare il vecchio codice, cancellalo del tutto. Lascialo solo finché non hai validato a video che la nuova card si vede.

### TODO 4 — DIFFICILE: aggiornare imports e rimuovere `getVariant` (~5 min)

In `home.page.ts`:
- cambia l'import da `ProductCard` a `ProductBody`;
- aggiorna l'array `imports:` di `@Component`;
- elimina il metodo `getVariant(product)`.

> Se l'IDE non si lamenta dopo l'edit, sei a posto.

### TODO 5 — DIFFICILE: ricomporre il `@for` con slot (~15 min)

In `home.page.html`, dentro `@for (product of filteredProducts; ...)`:

- togli `[title]` dal `<app-card-container>`;
- cambia `[variant]` per leggere `product.variant ?? 'default'`;
- sostituisci `<app-product-card ... />` con `<app-product-body [product]="product" />`;
- nel `<div footer>` aggiungi a sinistra un badge `<span>` con `{{ product.category }}` e tieni il bottone "+ Aggiungi" / fallback "Non disponibile" a destra. Usa `flex items-center justify-between gap-2` sul div footer;
- sul bottone Aggiungi chiama `onAddToCart(product)` diretto (niente `$event.stopPropagation()`).

> Verifica visiva: niente più titolo nel corpo della card, header con sfondo grigio (= variant default), categoria + bottone allineati nel footer.

---

## Criteri di verifica

- [ ] Lo schermo mostra le card con: titolo nell'header (sfondo grigio), corpo informativo (immagine + descrizione + prezzo), footer con categoria + bottone "Aggiungi".
- [ ] Cliccando il corpo della card si naviga al dettaglio. Cliccando il bottone Aggiungi NON si naviga.
- [ ] Aggiungendo a un prodotto nel `db.json` un campo `"variant": "success"`, l'header di quella card diventa verde dopo `json-server` reload + ricarica pagina.
- [ ] `ng serve` non lancia errori; console del browser pulita.
- [ ] Cartella `components/product-card/` rimossa.
- [ ] **Verifica formale (binario A):** applicando la `solution/` a `Corso/progetto/product-catalog-finale/` ed eseguendo `npx ng build` + `npx ng test`, tutto passa.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| `'app-product-body' is not a known element` | Manca l'import in `home.page.ts` o nel `imports[]` di `@Component` | TODO 4 |
| Il bottone "Aggiungi" naviga al dettaglio | Non più necessario `stopPropagation`: il bottone vive nel footer, non sopra il body cliccabile. Se accade, il bottone è ancora dentro il vecchio `<app-product-card>` | TODO 5 |
| L'header resta sempre grigio | TODO 2 non applicato: il binding `[class]` non c'è | TODO 2 |
| `Cannot find name 'CardVariant'` | Manca l'export in `product.model.ts` | TODO 1 |
| Errore TS sulla rimozione di `getVariant` | C'è ancora un riferimento al metodo nel template | TODO 4 + TODO 5 |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!
