/**
 * SOLUZIONE lab-01b
 * Delta rispetto al seme:
 *   - aggiunto type `CardVariant` (4 valori canonici per il container)
 *   - aggiunto campo opzionale `variant?: CardVariant` su Product
 * Il resto (CartItem, getFirst, ProductCategory) è invariato.
 */

export enum ProductCategory {
  Laptop     = 'Laptop',
  Smartphone = 'Smartphone',
  Tablet     = 'Tablet',
  Audio      = 'Audio',
  Accessori  = 'Accessori',
  Wearable   = 'Wearable',
  Desktop    = 'Desktop',
  Media      = 'Media'
}

export type CardVariant = 'default' | 'success' | 'warning' | 'info';

export interface Product {
  id: number;
  name: string;
  price: number;
  category: ProductCategory;
  available: boolean;
  description?: string;
  imageUrl?: string;
  variant?: CardVariant;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export function getFirst<T>(items: T[]): T | null {
  return items.length > 0 ? items[0] : null;
}
