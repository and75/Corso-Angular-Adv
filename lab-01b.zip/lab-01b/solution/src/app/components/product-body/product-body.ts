/**
 * SOLUZIONE lab-01b — product-body.ts
 *
 * Cosa è cambiato rispetto alla vecchia ProductCard:
 *  - selector:  app-product-card  →  app-product-body
 *  - classe:    ProductCard       →  ProductBody
 *  - rimosso:   output<Product>() addToCart  (il bottone vive nello slot footer dell'host)
 *  - rimosso:   onAddToCartClick()           (insieme all'output)
 *
 * Restano:
 *  - product = input.required<Product>()
 *  - formattedPrice computed
 *  - goToDetail() per il click sul body
 */

import { Component, inject, input, computed } from '@angular/core';
import { NgClass } from '@angular/common';
import { Router } from '@angular/router';
import { Product } from '../../product.model';

@Component({
  selector: 'app-product-body',
  standalone: true,
  imports: [NgClass],
  templateUrl: './product-body.html',
})
export class ProductBody {

  private router = inject(Router);

  product = input.required<Product>();

  formattedPrice = computed(() =>
    new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
    }).format(this.product().price)
  );

  goToDetail(): void {
    this.router.navigate(['/products', this.product().id]);
  }
}
