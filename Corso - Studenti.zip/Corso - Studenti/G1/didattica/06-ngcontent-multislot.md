# 06 — ng-content multi-slot

> **Tempo:** ~30 min · **Slide:** TBD · **Blocco:** G1 Sessione 3 · 11:30–12:00 (Mod 1a)

---

## Il problema

Nella [Scheda 05b](./05b-ngcontent.md) abbiamo richiamato `<ng-content>` con un solo foro: il `CardContainer` del seme accetta `title` come `@Input()` e proietta tutto il markup del padre in un unico slot. Funziona per i componenti con **una sola area variabile**, ma cade non appena un componente di design system ne richiede di più: una `ProductCard` con **badge** opzionale + **body** + **footer** con pulsante, un accordion con **intestazione** cliccabile + **pannello**, un dialog con **titolo** + **corpo** + **azioni**.

Servono più `<ng-content>` nello stesso componente, ciascuno destinato a ricevere un pezzo specifico del DOM proiettato. La scheda risponde a tre domande:

1. Come si dichiarano più `<ng-content>` nello stesso componente senza che si sovrappongano nel match dei nodi.
2. Cosa succede se uno slot resta vuoto, e come si specifica il **fallback content**.
3. Quando preferire la content projection e quando un `@Input()`.

Per agganciarci al lessico di Angular: ogni `<ng-content>` è uno **slot di proiezione**, e l'attributo `select` è un **selettore CSS** (attribute, class o type selector) che decide quali "projected nodes" del padre vanno in quale slot.

---

## Lo smistapacchi: una metafora per tutta la scheda

La 05b ha introdotto lo "sportello unico". Qui la metafora si estende naturalmente: il padre **spedisce pacchetti** (i suoi nodi DOM annidati) etichettandoli con attributi/classi/tag. Il componente espone più **sportelli**, ciascuno con un **selettore CSS** che dice "io accetto pacchetti che matchano `[header]`", "io quelli che matchano `[footer]`", e così via. Uno sportello senza `select` fa da **default slot**: cattura tutti i pacchetti che nessun altro selettore ha matchato. Angular esegue lo smistamento una sola volta, al momento del bootstrap della view.

Tutta la scheda gira intorno a questa immagine. Quando vi confondete sui selettori, sull'ordine degli slot o sul fallback content, tornate qui: chi è il mittente, qual è l'etichetta, dov'è lo sportello, cosa succede se manca il pacchetto.

---

## Multi-slot: ogni `<ng-content>` con il suo `select`

```html
<!-- Versione "evoluta" del card-container, didattica — non riscriviamo il seme,
     ma è il modello che applicheremo nel Lab 1 alla ProductCard -->
<div class="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">

  <!-- SLOT 1: attribute selector [header] -->
  <div class="px-4 py-3 bg-gray-50 border-b">
    <ng-content select="[header]">
      <!-- fallback content se nessun nodo [header] viene proiettato -->
      <h3 class="font-semibold text-sm text-gray-400">Card</h3>
    </ng-content>
  </div>

  <!-- SLOT 2: default slot (nessun select) -->
  <div class="p-4">
    <ng-content></ng-content>
  </div>

  <!-- SLOT 3: attribute selector [footer] -->
  <div class="px-4 py-3 bg-gray-50 border-t">
    <ng-content select="[footer]"></ng-content>
  </div>

</div>
```

Lato host, gli attributi `header` e `footer` vanno scritti come **attributi HTML nudi** (senza valore): è quello che il selettore di attributo `[header]` matcha — la presenza dell'attributo, non un valore specifico.

```html
<app-card-container>
  <h3 header>Catalogo prodotti</h3>     <!-- → SLOT 1 ([header]) -->

  <p>Lista dei 9 prodotti.</p>
  <ul>…</ul>                              <!-- → SLOT 2 (default) -->

  <button footer>Aggiorna</button>      <!-- → SLOT 3 ([footer]) -->
</app-card-container>
```

Tre regole formali da memorizzare:

| Aspetto | Regola |
|---|---|
| **Sintassi del selettore** | Qualsiasi selettore CSS supportato: `[attr]`, `.class`, `tag-name`, e relative combinazioni |
| **Algoritmo di matching** | Ogni projected node viene assegnato al **primo** `<ng-content select="...">` che lo matcha; lo slot senza `select` cattura il resto |
| **Fallback content** | Il markup **dentro** a `<ng-content>...</ng-content>` viene renderizzato solo se nessun projected node viene assegnato a quello slot |

Importante: il match avviene **una sola volta** sui nodi diretti dell'host, non ricorsivamente sui discendenti. Se l'host annida un `<div><h3 header>...</h3></div>`, il `<div>` esterno (senza attributo `header`) finisce nel default slot; l'`<h3 header>` interno non viene "estratto" dal padre `<div>` per essere proiettato nello slot 1.

---

## Tipi di selettore: attribute, class, type

Lo slot si etichetta in tre stili. Funzionano tutti, ma per coerenza del design system **uno solo** in tutta la libreria.

```html
<!-- (a) Attribute selector — la scelta del corso -->
<ng-content select="[header]"></ng-content>

<!-- (b) Class selector — utile se la classe ha anche valore stilistico -->
<ng-content select=".card-header"></ng-content>

<!-- (c) Type selector — quando il pezzo è già un componente Angular dedicato -->
<ng-content select="app-card-actions"></ng-content>
```

Andiamo con (a) per due motivi pratici: l'attributo nudo è leggibile nel template del consumer (`<div badge>` dice subito cosa è) e non si confonde con i selettori CSS reali del file `.css`/`.scss`. L'opzione (c) ha senso quando il pezzo proiettato è già un componente dedicato (es. `<app-card-actions>` con la sua API), e tipicamente compare nelle librerie di Mod 5.

---

## Fallback content (`<ng-content>...</ng-content>` con default)

Il markup scritto fra il tag di apertura e quello di chiusura del `<ng-content>` è il **fallback content**: viene renderizzato **solo se** lo slot non riceve projected nodes. Se l'host fornisce anche un solo nodo che matcha, il fallback sparisce completamente — non c'è sovrapposizione né duplicazione.

```html
<ng-content select="[header]">
  <h3 class="font-semibold text-sm text-gray-400">Card</h3>
</ng-content>
```

Casi d'uso tipici nei design system: empty state di liste/tabelle, pulsanti di azione predefiniti in un dialog, segnaposto di avatar/thumbnail. Il fallback abbassa il rumore dei consumer base — chi usa il componente nel caso semplice non scrive nulla, chi ha esigenze particolari sovrascrive solo gli slot che gli interessano.

---

## Projection vs `@Input()`

| Cosa passi dal padre al figlio | Strumento |
|---|---|
| Testo / numero / oggetto immutabile (titolo, variante, flag) | `@Input()` |
| Flag che decide se mostrare qualcosa | `@Input() boolean` + `@if` nel template del figlio |
| Porzione di markup statica decisa dal padre | `<ng-content>` (con o senza `select`) |
| Markup parametrizzato da dati interni del figlio (es. ogni riga di una tabella) | `<ng-template>` + `ngTemplateOutlet` ([Scheda 07](./07-ngtemplate-outlet.md)) |

Il `CardContainer` del seme è il caso misto: `title` viaggia come `@Input()` (è un dato testuale), il corpo viaggia come `<ng-content>` (è markup arbitrario). Per il motivo per cui **non** si passa il markup come stringa via `@Input() html` + `[innerHTML]` (perdita di binding, XSS, niente type checking), rimando alla [Scheda 05b](./05b-ngcontent.md#perché-ng-content-e-non-input-html-string).

---

## Errori comuni

### 1. Selettore che non matcha → projected node nel default slot

```html
<!-- componente -->
<ng-content select="[header]"></ng-content>
<ng-content></ng-content>

<!-- host -->
<app-card-container>
  <h3 class="header">Titolo</h3>   <!-- ❌ class="header" non matcha [header] -->
</app-card-container>
```

L'`<h3>` ha la classe CSS `header`, non l'attributo `header`. Il selettore `[header]` (attribute selector) non lo matcha, e il nodo finisce nel default slot. Nessun errore in console, nessun warning del compilatore: ve ne accorgete solo a video, vedendo l'header vuoto e il titolo che spunta nel corpo. **Fix:** allineate la sintassi — `<h3 header>` con `select="[header]"`, oppure `<h3 class="card-header">` con `select=".card-header"`.

### 2. Default slot dichiarato prima dei selettori specifici

```html
<!-- componente — ❌ -->
<ng-content></ng-content>
<ng-content select="[footer]"></ng-content>
```

L'algoritmo di matching scansiona gli `<ng-content>` nell'ordine del template e assegna ogni projected node al **primo** slot compatibile. Il default slot (senza `select`) è compatibile con qualunque nodo, quindi assorbe tutto — footer incluso. **Fix:** il default slot va sempre **per ultimo**, dopo tutti quelli con `select`.

### 3. Più `<ng-content>` con lo stesso selettore

```html
<ng-content select="[footer]"></ng-content>
<!-- ... -->
<ng-content select="[footer]"></ng-content>   <!-- ❌ duplicato -->
```

Un projected node non si duplica fra slot: viene assegnato al **primo** match e basta. Il secondo `<ng-content select="[footer]">` resta vuoto. Se vi serve renderizzare lo stesso markup in più punti del componente, lo strumento è `<ng-template>` + `ngTemplateOutlet` ([Scheda 07](./07-ngtemplate-outlet.md)), che permette di istanziare la stessa view in posizioni distinte.

### 4. Type selector troppo generico

```html
<ng-content select="div"></ng-content>
```

Cattura **qualsiasi** `<div>` proiettato, incluso markup che voleva andare nel default slot o in un altro slot. Preferire sempre selettori intenzionali: attribute selector dedicati (`[badge]`, `[footer]`), oppure type selector di componenti specifici (`app-card-actions`). Mai type selector di tag HTML generici (`div`, `p`, `span`).

---

## Il flusso, raccontato

Esempio reale dal Lab 1, lato consumer:

```html
<app-product-card>
  <span badge>In offerta</span>
  <p>Pasta artigianale 100% grano italiano.</p>
  <button footer (click)="aggiungi(prodotto)">Aggiungi al carrello</button>
</app-product-card>
```

Cosa fa Angular:

1. Compila il template di `ProductCard` e individua tre `<ng-content>`: `select="[badge]"`, default, `select="[footer]"`.
2. Sui projected nodes del consumer applica l'algoritmo di matching: `<span badge>` → slot badge, `<p>` → default slot, `<button footer>` → slot footer.
3. I projected nodes vengono inseriti negli slot **mantenendo lo scope dell'host**: il binding `(click)="aggiungi(prodotto)"` resta legato al componente padre, non a `ProductCard`. È il consumer a gestire il click — il componente è solo il contenitore strutturato.
4. La view si compone: `ProductCard` decide layout, classi Tailwind, dove vanno gli slot; il consumer decide il contenuto di ciascuno.

Questa divisione del lavoro — il componente offre lo scheletro stilato, l'host lo riempie con il proprio markup mantenendo i propri binding — è il motivo per cui `<ng-content>` è lo strumento di base dei design system Angular.

---

## Schema riassuntivo

```
HOST (consumer)
┌─────────────────────────────────────┐
│ <app-card-container>                │
│   <h3 header>Titolo</h3>            │ ──┐ projected node [header]
│   <p>Body…</p>                      │ ──┤ projected node senza match → default
│   <button footer>OK</button>        │ ──┘ projected node [footer]
│ </app-card-container>               │
└─────────────────────────────────────┘
              │
              ▼ algoritmo di matching (primo `select` compatibile)
COMPONENTE (CardContainer)
┌─────────────────────────────────────────────────────┐
│ <ng-content select="[header]">     ← <h3 header>   │
│ <ng-content>                       ← <p> (default) │
│ <ng-content select="[footer]">     ← <button>      │
└─────────────────────────────────────────────────────┘
```

| Voce | Sintassi chiave |
|---|---|
| Slot singolo (corso base, [Scheda 05b](./05b-ngcontent.md)) | `<ng-content></ng-content>` |
| Slot con selettore | `<ng-content select="[attr]"></ng-content>` |
| Default slot | `<ng-content></ng-content>` — sempre **per ultimo** nel template |
| Fallback content | markup **dentro** a `<ng-content>...</ng-content>` |
| Preferire `@Input()` | se passi un dato (non DOM) |
| Passare a `<ng-template>` + `ngTemplateOutlet` | se serve un template parametrizzato o renderizzato in più punti ([Scheda 07](./07-ngtemplate-outlet.md)) |
| Riferimento ai projected nodes dal TypeScript del figlio | `@ContentChild` / `@ContentChildren` (Mod 1c) |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/components/card-container/card-container.ts`](../../progetto/product-catalog/src/app/components/card-container/card-container.ts) | Slot singolo + `@Input() title`/`variant` come punto di partenza |
| [`src/app/components/card-container/card-container.html`](../../progetto/product-catalog/src/app/components/card-container/card-container.html) | `<ng-content>` singolo da evolvere a multi-slot nel Lab 1 |

---

## Prossimo: [07 — ng-template + ngTemplateOutlet](./07-ngtemplate-outlet.md)
