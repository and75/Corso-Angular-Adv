# 11 — Subject / BehaviorSubject per la comunicazione tra componenti

> **Tempo:** ~15 min · **Slide:** TBD · **Blocco:** G1 Sessione 5 · 16:00–16:15 (Mod 1d)
> **Prerequisito:** ripasso Observable e operatori → [Scheda 02](./02-observable-rxjs.md).

---

## Il problema

Nel seme c'è già un `ProductService` che usa `signal()` per il carrello: `cartItems = signal<CartItem[]>([])`, i componenti lo consumano direttamente nel template e tutto funziona. Per lo *stato locale* di un servizio consumato in modo dichiarativo, è la scelta giusta — non c'è motivo di cambiarla.

Quello che il seme **non** copre, e che incontreremo nel Lab 2b, sono due scenari diversi:

- Un **bus di eventi** che attraversa l'app: una `NotificationService` su cui qualunque pezzo dell'app può fare `error("Errore di rete")`, e dei toast in alto a destra che appaiono e scompaiono. Chi emette e chi ascolta non si conoscono fra loro — un interceptor HTTP (Mod 4) deve poter pubblicare un errore senza sapere chi ha la UI.
- Uno **stato condiviso tra componenti scollegati** che si compone con altri stream RxJS. L'`AuthService` espone l'utente loggato, il `CartService` deve resettarsi al logout e ricaricarsi al login. Vorremmo che il `CartService` si "metta in ascolto" dell'auth una sola volta, e che il `BehaviorSubject` faccia da motore di sincronizzazione — senza che il `CartService` chieda mai esplicitamente "chi è loggato adesso?".

Per entrambi i casi lo strumento idiomatico è **Subject / BehaviorSubject** di RxJS. Vediamoli con calma, partendo dalla metafora che li accompagnerà.

---

## La lavagnetta del piatto del giorno

Il `BehaviorSubject` è uno strumento di RxJS, la libreria che Angular usa per gestire i flussi di dati nel tempo. Immaginatelo come la **lavagnetta del "piatto del giorno"** appesa all'ingresso di un ristorante. Ha tre proprietà che lo rendono speciale:

1. Ha **sempre** un valore scritto sopra, e parte già con qualcosa scritto (il valore iniziale è obbligatorio). Non esiste mai "vuota".
2. Chiunque entra **legge subito** cosa c'è scritto adesso, anche se è appena arrivato. Non deve aspettare il prossimo cambio.
3. Quando cambi quello che è scritto, **tutti quelli che stanno guardando** la lavagnetta vengono avvisati all'istante del nuovo valore.

```typescript
import { BehaviorSubject } from 'rxjs';

// la lavagnetta parte già con un valore
const piattoDelGiorno = new BehaviorSubject<string>('Carbonara');

// A entra e legge subito quello che c'è: "Carbonara"
piattoDelGiorno.subscribe(v => console.log('A:', v));

// cambio il piatto -> A viene avvisato: "Amatriciana"
piattoDelGiorno.next('Amatriciana');

// B entra in ritardo, ma legge comunque l'ULTIMO valore: "Amatriciana"
piattoDelGiorno.subscribe(v => console.log('B:', v));

// posso anche leggere il valore corrente al volo, senza subscribe
console.log(piattoDelGiorno.value); // 'Amatriciana'
```

Il nome inglese vale una nota etimologica. *"Subject"* perché è un oggetto che fa sia da sorgente sia da ascoltatore di valori (può sia emettere con `next()` sia essere sottoscritto come un Observable normale). *"Behavior"* nel senso matematico — una grandezza che ha sempre un valore attuale in ogni istante (la lavagnetta non è mai vuota), contrapposta a un semplice "evento" che accade e poi sparisce. In aula, comunque, anche fra italiani si dice sempre `BehaviorSubject` — non si traduce mai.

---

## I cugini: Observable, Subject, BehaviorSubject

Tre strumenti che sembrano simili e si confondono facilmente. La differenza è esattamente questa:

| | Comportamento |
|---|---|
| **Observable normale** | Un cameriere che racconta i piatti solo da quando ti siedi in poi. Quello che è successo prima te lo sei perso. È *unicast*: ogni nuovo `.subscribe()` ripete il flusso da capo per quel singolo iscritto. |
| **`Subject`** | Stesso cameriere, ma parla a più tavoli contemporaneamente. È *multicast*: tutti gli iscritti ricevono lo stesso evento nel momento in cui viene emesso. Però non ha memoria — chi arriva dopo l'emissione, non sente nulla finché non arriva il prossimo `next()`. |
| **`BehaviorSubject`** | Il `Subject` con in più la lavagnetta. Conserva l'ultimo valore emesso e lo dà immediatamente a chi si sottoscrive in ritardo. È *multicast* + *con stato corrente*. |

Per lo stato condiviso (utente loggato, tema corrente, contenuto del carrello), la lavagnetta è ciò che serve: ti garantisce che chi nasce dopo non si trovi senza informazione. Per gli eventi puri ("l'utente ha cliccato logout", "è arrivato un errore HTTP"), il `Subject` senza memoria va benissimo — il significato è proprio "qualcosa è successo ora", non "questo è lo stato attuale".

---

## L'esempio canonico: due servizi che si parlano via lavagnetta

Lo scenario più classico — e quello che useremo come modello per il Lab 2b — è due servizi dove uno **tiene lo stato** e l'altro **reagisce** ai suoi cambiamenti. Un `AuthService` che sa chi è l'utente loggato, e un `CartService` (il carrello) che deve svuotarsi al logout e ricaricare i dati giusti al cambio utente.

### Servizio 1 — AuthService (tiene lo stato)

```typescript
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface User { id: string; nome: string; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  // la "lavagnetta": parte vuota (nessun utente loggato)
  private _utente = new BehaviorSubject<User | null>(null);

  // i SOLI a essere esposti all'esterno: in sola lettura
  utente$ = this._utente.asObservable();

  // comodo per leggere il valore corrente al volo, senza subscribe
  get utenteCorrente(): User | null {
    return this._utente.value;
  }

  login(user: User) {
    this._utente.next(user);   // scrivo sulla lavagnetta → tutti avvisati
  }

  logout() {
    this._utente.next(null);   // azzero → tutti avvisati
  }
}
```

Il punto chiave da fissare: solo `AuthService` può chiamare `.next()` (perché `_utente` è privato). Tutti gli altri vedono soltanto `utente$` — un Observable in sola lettura ottenuto con `asObservable()`. Chi tiene lo stato controlla chi può modificarlo. È lo stesso pattern di incapsulamento che applichereste a qualsiasi proprietà privata di una classe, solo che qui passa per la separazione fra il Subject (canale di scrittura interno) e l'Observable (canale di lettura pubblico).

### Servizio 2 — CartService (reagisce)

```typescript
import { Injectable, inject } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';

export interface Articolo { id: string; nome: string; }

@Injectable({ providedIn: 'root' })
export class CartService {
  private auth = inject(AuthService);

  private _articoli = new BehaviorSubject<Articolo[]>([]); // carrello vuoto
  articoli$ = this._articoli.asObservable();

  constructor() {
    // mi metto in ascolto della lavagnetta dell'AuthService
    this.auth.utente$.subscribe(utente => {
      if (utente) {
        this.caricaCarrelloPerUtente(utente.id); // login → carico i suoi articoli
      } else {
        this._articoli.next([]);                 // logout → svuoto
      }
    });
  }

  aggiungi(articolo: Articolo) {
    this._articoli.next([...this._articoli.value, articolo]);
  }

  private caricaCarrelloPerUtente(userId: string) {
    // in pratica una chiamata HTTP; semplifico con dati finti
    this._articoli.next([{ id: 'a1', nome: 'Pasta artigianale' }]);
  }
}
```

Notate la cosa importante: `CartService` non chiama mai direttamente `AuthService` per chiedere *"chi c'è adesso?"*. Si limita a iscriversi a `utente$` una volta sola, nel costruttore. Da quel momento è il `BehaviorSubject` a **spingere** gli aggiornamenti verso il carrello — un meccanismo *push*, non *pull*. I due servizi sono disaccoppiati: `AuthService` non sa nemmeno che il carrello esiste, e se domani un terzo servizio (cronologia ordini, preferiti, sessione) volesse anche lui reagire al login, gli basterebbe iscriversi alla stessa lavagnetta senza che `AuthService` cambi di una virgola.

### Come lo usa un componente

```typescript
@Component({
  selector: 'app-header',
  template: `
    <span *ngIf="auth.utente$ | async as u">Ciao {{ u.nome }}</span>
    <span>Articoli: {{ (cart.articoli$ | async)?.length }}</span>
  `,
})
export class HeaderComponent {
  auth = inject(AuthService);
  cart = inject(CartService);
}
```

Il pipe `async` fa due cose preziose: si sottoscrive automaticamente quando il template viene creato, si disiscrive quando viene distrutto — niente memory leak, niente boilerplate. Per i casi semplici, in cui il dato finisce direttamente nel template, è quasi sempre la scelta giusta.

---

## Perché BehaviorSubject e non Subject normale

C'è un dettaglio cruciale di tempistica nello scenario sopra. `CartService` viene creato la prima volta che qualcuno lo usa — che può essere **dopo** che l'utente ha già fatto login. Con un `Subject` semplice, quando `CartService` si iscrive nel suo costruttore, si perderebbe il valore già emesso e non saprebbe chi è loggato. Con il `BehaviorSubject`, invece, riceve subito l'ultimo valore al momento dell'iscrizione (la lavagnetta porta il piatto di oggi, anche se non sei stato presente quando l'hanno scritto). Il carrello si sincronizza correttamente anche se nasce in ritardo.

Questa è la regola pratica: **se chi può iscriversi in ritardo deve trovare lo stato corrente, BehaviorSubject. Se chi è in ritardo deve solo aspettare il prossimo evento, Subject.**

---

## Perché BehaviorSubject e non un signal

È la domanda che esce in aula ogni volta. Dal momento che Angular 17 ha introdotto `signal()`, e che il seme stesso usa già `cartItems = signal<CartItem[]>([])` nel `ProductService`, viene naturale chiedersi se `BehaviorSubject` non sia ormai legacy.

Risposta onesta: in parte sì, in parte no. I `signal` e i `BehaviorSubject` risolvono problemi che si sovrappongono molto — entrambi tengono un valore corrente, entrambi notificano chi ascolta — ma vivono in due ecosistemi diversi, e la scelta dipende da come quel valore si compone col resto.

I **signal** sono nativi del nuovo change detection di Angular: sincroni, leggibili nel template come funzioni (`{{ count() }}`), si combinano con `computed()` per stati derivati ed `effect()` per side effect. Per lo stato locale di un componente o di un servizio consumato direttamente nel template — il caso del `cartItems` del seme — sono la scelta più diretta e idiomatica.

I **BehaviorSubject** sono Observable: vivono nell'ecosistema RxJS, si compongono con tutti gli operatori (`debounceTime`, `switchMap`, `combineLatest`, `distinctUntilChanged`), si integrano nativamente con tutto ciò che già emette Observable (`HttpClient`, `valueChanges` dei form reattivi, eventi del router). Per uno *stato condiviso che deve interagire con stream esistenti* — il caso classico di un `NotificationService` che riceve emissioni da interceptor HTTP, da form di ricerca, da chiamate asincrone — sono molto più naturali.

La regola pratica del corso, in tabella:

| Caso d'uso | Strumento |
|---|---|
| Stato di un componente consumato dal suo template | `signal` |
| Stato derivato da altri signal | `computed` |
| Side effect quando uno stato cambia | `effect` |
| Bus di eventi (toast, "user logged out", click globali) | `Subject` (multicast, niente storico) |
| Stato condiviso fra componenti scollegati, con replay del valore corrente | `BehaviorSubject` |
| Wrap di codice RxJS-based (interceptor, gateway HTTP, libreria che emette stream) | `BehaviorSubject` / `Subject` |

E c'è una via che concilia i due mondi: `toSignal(observable$)` (Angular 16+, in `@angular/core/rxjs-interop`). Permette di tenere un `BehaviorSubject` lato servizio — per la componibilità con altri stream — e di consumarlo come signal nel componente, con la sintassi `notifications = toSignal(notifService.notifications$)`. È il pattern che useremo nel Mod 4 quando l'`errorInterceptor` chiamerà la notifica: il servizio espone l'`Observable`, ogni componente decide se consumarlo come `Observable` (col pipe `async`) o come signal (con `toSignal`).

Il prossimo Angular spingerà probabilmente sempre di più verso i signal anche nei servizi, ed esisterà un giorno in cui il `BehaviorSubject` sarà un'eccezione. Oggi (Angular 21) le due API convivono, e si scelgono per quale ecosistema vi conviene di più — non per moda.

---

## Il pattern del NotificationService (modello del Lab 2b)

Mettendo insieme tutto: stato interno privato, esposizione read-only, scritture immutabili, API pubblica per chi emette.

```typescript
// services/notification.service.ts — anteprima Lab 2b
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}

@Injectable({ providedIn: 'root' })
export class NotificationService {
  // la lavagnetta: array dei toast attivi, parte vuota
  private list$ = new BehaviorSubject<Notification[]>([]);
  private nextId = 1;

  // esposizione read-only: i consumer leggono ma non scrivono
  readonly notifications$: Observable<Notification[]> = this.list$.asObservable();

  success(message: string): void { this.push('success', message); }
  error(message: string)   : void { this.push('error',   message); }

  dismiss(id: number): void {
    this.list$.next(this.list$.value.filter(n => n.id !== id));
  }

  private push(type: Notification['type'], message: string) {
    const n: Notification = { id: this.nextId++, type, message };
    this.list$.next([...this.list$.value, n]);
  }
}
```

Due dettagli importanti, oltre a quelli già visti per `AuthService`. Primo: `list$.value` permette l'accesso sincrono al valore corrente, necessario per calcolare il **prossimo** stato (aggiungere un elemento all'array, filtrare quello da rimuovere) senza dover sottoscriversi una tantum. Secondo: ogni `next()` riceve **un nuovo array** (`[...this.list$.value, n]`), non l'array mutato in place. Se mutate, il riferimento resta lo stesso e i subscriber che fanno equality check non vedono il cambiamento — più di un debug doloroso parte da qui.

---

## Cleanup: takeUntilDestroyed

Le sottoscrizioni a `Subject` / `BehaviorSubject` **non terminano da sole**. Una `HttpClient.get()` emette il valore e completa, e la subscription si chiude pulita; una lavagnetta resta appesa al muro per sempre — finché qualcuno non la stacca. Se un componente si sottoscrive senza disiscriversi, alla sua distruzione la callback resta in piedi e tiene in memoria tutto quello che cattura (incluso `this`). Memory leak silenzioso.

In Angular 16+ il modo idiomatico è `takeUntilDestroyed` da `@angular/core/rxjs-interop`:

```typescript
import { Component, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

export class Toast {
  private notifications = inject(NotificationService);
  private destroyRef    = inject(DestroyRef);

  list: Notification[] = [];

  ngOnInit(): void {
    this.notifications.notifications$
      .pipe(takeUntilDestroyed(this.destroyRef))   // auto-unsubscribe al destroy
      .subscribe(list => this.list = list);
  }
}
```

Una nota pratica: `takeUntilDestroyed()` senza argomento funziona **solo dentro un injection context** — il body di una classe come inizializzatore di proprietà, o il costruttore. Fuori da lì (per esempio dentro a `ngOnInit`) va passato esplicitamente `this.destroyRef`. In alternativa potete fare:

```typescript
list$ = this.notifications.notifications$.pipe(takeUntilDestroyed());   // dichiarata come proprietà
```

e nel template usare `@if (list$ | async; as list) { ... }`. Spesso è la forma più pulita, perché evita del tutto il `subscribe()` manuale.

---

## Errori comuni

### 1. Esporre il Subject pubblicamente

```typescript
notifications$ = new BehaviorSubject<Notification[]>([]);
// ❌ qualsiasi componente può fare notifications$.next(...) → chi modifica cosa? mistero
```

Senza incapsulamento il pattern collassa: ogni componente può scrivere sulla lavagnetta e nessuno sa chi ha emesso cosa. **Fix:** `private list$ = new BehaviorSubject(...)` + `readonly notifications$ = list$.asObservable()`.

### 2. Mutare l'array invece di sostituirlo

```typescript
this.list$.value.push(n);
this.list$.next(this.list$.value);   // ❌ stesso riferimento — i subscriber non "vedono" il cambiamento
```

I subscriber con equality check (anche solo `distinctUntilChanged()` nella pipe, o un `computed` collegato via `toSignal`) saltano l'emissione perché il riferimento non è cambiato. **Fix:** `this.list$.next([...this.list$.value, n])` — nuovo array, nuovo riferimento.

### 3. Sottoscriversi senza unsubscribe

```typescript
ngOnInit() {
  this.notifications.notifications$.subscribe(list => this.list = list);
  // ❌ memory leak: il subject non completa, il componente sì
}
```

**Fix:** `takeUntilDestroyed(this.destroyRef)` oppure pipe `async` direttamente nel template.

### 4. BehaviorSubject senza valore iniziale

```typescript
private list$ = new BehaviorSubject<Notification[]>();   // ❌ TS: Argument expected
```

`BehaviorSubject<T>(initial)` richiede l'`initial`: la lavagnetta non può essere vuota. Se non avete un valore di default ragionevole, probabilmente quello che volete è un `Subject<T>()` (niente replay) o, per casi avanzati, un `ReplaySubject<T>(1)` (replay dell'ultimo valore solo se è stato emesso almeno una volta).

---

## Il flusso, raccontato

L'utente apre la home del catalogo. `AuthService` è un singleton (`providedIn: 'root'`): nasce al primo `inject(AuthService)` e tiene la sua lavagnetta `_utente` ancora con `null`. Il `CartService`, anch'esso singleton, nasce poco dopo, e nel suo costruttore si iscrive a `auth.utente$`. La lavagnetta è ancora vuota: il subscribe riceve subito `null` (è la garanzia del `BehaviorSubject`), il carrello rimane `[]`. Tutto normale.

L'utente compila il form di login e preme submit. `AuthService.login(user)` chiama `_utente.next(user)`: il valore della lavagnetta cambia da `null` a `{ id, nome }`, e tutti gli iscritti vengono avvisati nello stesso istante. Il `CartService`, in ascolto, riceve la nuova emissione, entra nel ramo `if (utente)` e chiama `caricaCarrelloPerUtente(utente.id)` — che a sua volta scrive sulla *sua* lavagnetta `_articoli`. L'`HeaderComponent` ha due `| async` nel template: uno su `auth.utente$`, uno su `cart.articoli$`. Entrambi ricevono il nuovo valore, il template si ridisegna da solo, e l'header passa da "guest" a "Ciao Mario · Articoli: 1".

L'utente preme logout. `AuthService.logout()` riazzera la sua lavagnetta a `null`, il `CartService` riceve l'emissione, va nel ramo `else` e azzera la propria. L'header torna allo stato iniziale. Nessuno ha "chiesto" attivamente — tutto a catena, spinto dalle due lavagnette, con il template che si aggiorna da solo grazie al pipe `async`.

È il pattern che ritroverete in tutto il corso, ogni volta che due servizi devono coordinarsi senza accoppiarsi: il `Mod 4` aggiungerà l'`errorInterceptor` che chiama `notification.error(...)`, il `Mod 5` esporrà servizi di libreria con la stessa forma, e tutto si comporrà perché la fonte e i consumer parlano la stessa lingua RxJS.

---

## Schema riassuntivo

```
   AuthService                        CartService                      HeaderComponent
   (publisher)                        (publisher + subscriber)         (subscriber)
   ───────────                        ────────────────────────         ─────────────────
                                                                      template:
   private _utente$ ─────► utente$ ──► subscribe ┐                     {{ auth.utente$ | async }}
                              ▲                  │                     {{ cart.articoli$ | async }}
                              │ asObservable     │
                              │ (read-only)      │                              ▲
   login(u) → _utente.next(u)                    ▼                              │
   logout() → _utente.next(null)         private _articoli$ ──► articoli$ ─────┘
                                            (BehaviorSubject)
                                            ▲
                                            │ next([...value, n])
                                            │ next([])
                                            │
                                       caricaCarrello / aggiungi / svuota
```

| Voce | Sintassi chiave |
|---|---|
| Subject puro | `new Subject<T>()` |
| BehaviorSubject con stato | `new BehaviorSubject<T>(initial)` |
| Esposizione read-only | `subject.asObservable()` |
| Valore corrente sincrono | `subject.value` (o `subject.getValue()`) |
| Emettere un valore | `subject.next(value)` |
| Auto-unsubscribe | `pipe(takeUntilDestroyed(destroyRef))` |
| Pipe async nel template | `{{ obs$ \| async }}` o `@if (obs$ \| async; as x) { ... }` |
| Ponte verso signal | `toSignal(obs$)` da `@angular/core/rxjs-interop` |

### File reali nel seme da citare in aula

| File | Cosa mostra | Note |
|---|---|---|
| [`src/app/services/product.ts`](../../progetto/product-catalog/src/app/services/product.ts) | `cartItems = signal<CartItem[]>([])` + `computed`/`effect` | Esempio di "stato locale → signal". Confronto col `NotificationService` del Lab 2b |
| — | Nessun uso di `Subject` / `BehaviorSubject` nel seme | Novità del Mod 1d: arrivano col Lab 2b (`NotificationService`) |

---

## Prossimo: [12 — Signal: lo stato reattivo nativo di Angular](./12-signal.md)
