# 10 — Integrare una libreria legacy con NgZone

> **Tempo:** ~15 min · **Slide:** TBD · **Blocco:** G1 Sessione 5 · 15:45–16:00 (Mod 1c)

---

## Il problema

Prima o poi, in qualsiasi progetto Angular reale, capita di dover integrare una libreria JavaScript "vanilla" che non sa nulla del framework: un carousel come Splide, un editor di testo come Quill, una mappa Leaflet, un grafico Chart.js, un drag-and-drop scritto a mano. Queste librerie vivono direttamente sul DOM, registrano i propri event listener, si gestiscono i propri animation loop con `requestAnimationFrame` 60 volte al secondo. Sono fatte per girare *da sole*, e funzionano benissimo finché restano sole.

Il guaio comincia quando le metti in un componente Angular. Il framework, di suo, ha un meccanismo che intercetta ogni evento asincrono — click, timer, callback HTTP, microtask, `requestAnimationFrame` — e dopo ognuno chiede *"qualcuno ha cambiato qualcosa? devo ridipingere lo schermo?"*. Per il codice scritto in stile Angular questo è perfetto: cambi un signal, il framework se ne accorge, il template si aggiorna. Ma per Splide, che muove le slide a 60fps e ascolta `mousemove`, ogni singolo tick diventa un ciclo di change detection inutile. L'app si pianta in modo silenzioso e difficile da diagnosticare.

Nel Lab 2a questo è esattamente lo scenario: avvolgere Splide in un `Carousel` Angular per la homepage del catalogo. Vediamo come si fa senza paralizzare la pagina.

---

## La stanza insonorizzata: la metafora che useremo

Pensate a Zone.js come a un **microfono onnipresente** appeso nel salotto principale dell'app. Capta ogni rumore — ogni evento asincrono che succede dentro l'app — e ad ogni captazione tira giù dal soffitto il pannello del change detection: *"controllate se c'è qualcosa di nuovo da mostrare a video"*. Per i rumori normali (l'utente clicca un bottone, arriva una risposta HTTP) è perfetto, ed è il motivo per cui in Angular base non vi siete mai dovuti preoccupare di "quando" il template si aggiorna.

Il problema è che le librerie DOM legacy sono **ospiti chiassosi**: animation loop a 60Hz, listener `mousemove`, `requestAnimationFrame` ininterrotti. Lasciate libere nel salotto, fanno scattare il microfono 60 volte al secondo. La soluzione si chiama `NgZone.runOutsideAngular`: prendete la libreria e la mettete in una **stanza insonorizzata**, separata dal salotto. Lì dentro può urlare quanto vuole — il microfono non sente niente, change detection non si attiva. Solo quando la libreria ha qualcosa di davvero importante da dire all'app Angular (un evento utente che deve aggiornare lo stato), apre la porta, si affaccia in salotto con `zone.run` e annuncia. Detto l'annuncio, richiude e torna in stanza.

Tutta la scheda gira intorno a questa immagine. La libreria sta dentro (`runOutsideAngular`), parla fuori solo quando deve (`zone.run`), e quando il componente muore si porta via tutto (`destroyRef.onDestroy`).

---

## Il pattern del wrapper

Lo schema vale per qualsiasi libreria DOM legacy. Lo applicheremo nel Lab 2a con Splide, ma sostituite mentalmente con Leaflet, Chart.js o qualunque cosa abbiate sul tavolo.

```typescript
// estratto del componente Carousel del Lab 2a
import {
  Component, ElementRef, NgZone, DestroyRef, inject,
  afterNextRender, viewChild,
} from '@angular/core';
import Splide from '@splidejs/splide';

@Component({
  selector: 'app-carousel',
  standalone: true,
  template: `
    <section #host class="splide">
      <div class="splide__track">
        <ul class="splide__list">
          @for (s of slides; track s) {
            <li class="splide__slide">{{ s }}</li>
          }
        </ul>
      </div>
    </section>
  `,
})
export class Carousel {
  private zone       = inject(NgZone);       // chi apre/chiude la porta della stanza
  private destroyRef = inject(DestroyRef);   // chi smonta tutto quando il componente muore

  private host = viewChild<ElementRef<HTMLElement>>('host');
  slides = ['A', 'B', 'C', 'D'];
  private splide?: Splide;

  constructor() {
    // afterNextRender: garantisce che la view sia montata prima di toccarne il DOM.
    // È SSR-safe (sul server non parte) — torna utile nel Mod 6.
    afterNextRender(() => {
      const el = this.host()?.nativeElement;
      if (!el) return;

      // Splide nasce e vive nella stanza insonorizzata:
      // tutti i suoi listener e i suoi animation loop sono fuori zone.
      this.zone.runOutsideAngular(() => {
        this.splide = new Splide(el, { type: 'loop', perPage: 1 });
        this.splide.mount();
      });
    });

    // quando il componente viene distrutto, Splide viene distrutto con lui
    this.destroyRef.onDestroy(() => this.splide?.destroy());
  }
}
```

Tre dettagli che vale la pena fissare. Primo: `afterNextRender` è il successore moderno di `ngAfterViewInit` per *"fai questa cosa dopo il primo render"*. Ha il pregio di essere SSR-safe — sul server non viene chiamato, quindi non rischiate di chiedere a Splide di misurare l'elemento DOM in un ambiente Node dove `window` non esiste (lo riprenderemo nel Mod 6). Secondo: `runOutsideAngular` non è una pillola che disattiva CD globalmente, è uno **scope**. Tutto quello che dichiarate dentro la callback eredita lo stato "fuori zone": l'`on('move', ...)` registrato lì sopra, il setInterval, il requestAnimationFrame — tutto. Terzo: `destroyRef.onDestroy` ha preso il posto del vecchio `ngOnDestroy()`. Più leggibile, meno metodo "fantasma" sulla classe, e si scrive nel costruttore vicino al codice che istanzia la risorsa. Dimenticare questa riga è il modo più rapido per accumulare istanze morte di Splide nel DOM ogni volta che il componente viene smontato e rimontato.

---

## Rientrare per parlare in salotto

Finché Splide si limita a muovere le sue slide, può restare in stanza isolata per sempre — nessuno in Angular ha bisogno di saperlo. Ma se la libreria emette un evento che *deve* aggiornare lo stato del componente (un `currentIndex` da mostrare nel template, un signal da aggiornare, un'emissione su un `BehaviorSubject`), allora va aperta la porta:

```typescript
this.zone.runOutsideAngular(() => {
  this.splide!.on('move', (newIndex: number) => {
    // siamo ancora fuori zone — un signal.set() qui non scatena CD
    this.zone.run(() => {
      this.currentIndex.set(newIndex);   // dentro zone → il template si aggiorna
    });
  });
});
```

La regola pratica si memorizza in una riga: la **registrazione del listener** sta fuori zone (è infrastruttura della libreria), la **scrittura sullo stato Angular** sta dentro `zone.run` (è informazione per il salotto). Il sandwich è il pattern: stanza isolata → uscita momentanea per annunciare → ritorno in stanza.

---

## Perché tutto questo e non semplicemente "disabilitare il CD"

Domanda legittima. Se il problema è che Zone.js fa scattare troppi cicli di change detection, perché non passare a `ChangeDetectionStrategy.OnPush` su tutto il componente, o usare `provideExperimentalZonelessChangeDetection()` su tutta l'app? Entrambe sono strade percorribili, ma rispondono a problemi diversi.

`OnPush` cambia *quando* il componente reagisce ai cicli di CD (solo se i suoi `@Input` cambiano riferimento, o se è il bersaglio diretto di un evento), ma i cicli di CD continuano comunque a scattare in tutta l'app. Risparmiate sul costo del *check* di quel componente, ma non sull'innesco del giro. Per Splide, dove il problema è proprio l'innesco continuo di Zone.js, `OnPush` aiuta poco.

Il *zoneless* (Angular 18+) è la direzione del futuro: niente Zone.js, niente intercettazione globale, signal-based change detection. Il giorno in cui userete `provideExperimentalZonelessChangeDetection()` su un progetto greenfield, gran parte di questa scheda diventerà meno rilevante. Oggi (Angular 21) lo zoneless è ancora `experimental` e implica avere tutto il codice — vostro e delle librerie che usate — pronto a non contare su Zone. Per integrare una libreria legacy in un'app classica con Zone, `runOutsideAngular` resta il modo idiomatico.

In pratica, la regola del corso è: finché vivete con Zone.js, le librerie DOM legacy vanno avvolte. Il giorno in cui passate a zoneless, riguarderete il wrapper e probabilmente potrete togliere il `runOutsideAngular` — ma a quel punto avrete altri problemi più interessanti da risolvere (es. come Splide notifica un signal senza Zone che fa da intermediario).

---

## Errori comuni

### 1. Inizializzare in `ngOnInit`

```typescript
ngOnInit() {
  this.splide = new Splide(this.host()!.nativeElement, {...}).mount();   // ❌
}
```

`ngOnInit` parte prima che la view sia completamente costruita: il nodo `#host` potrebbe esistere ma non avere ancora dimensioni misurate dal browser. Sintomo: Splide calcola `width = 0`, le slide si sovrappongono, il layout sembra impazzito. **Fix:** `afterNextRender` (preferito) o, se proprio dovete restare al vecchio stile, `ngAfterViewInit`.

### 2. Dimenticare `runOutsideAngular`

```typescript
afterNextRender(() => {
  this.splide = new Splide(el, opts).mount();   // ❌ tutto in zone
});
```

Sintomo: l'app sembra "lenta" appena scrollate la slide o trascinate. Profilando con i DevTools vedete CD scattare ogni 16 millisecondi. **Fix:** incapsulare l'init e tutti i listener della libreria in `runOutsideAngular`.

### 3. Niente `destroy()` al cleanup

Se il componente viene smontato (l'utente naviga via) e poi rimontato (torna sulla home), le istanze precedenti di Splide restano agganciate al DOM via internals della libreria — Angular ha tolto il template ma Splide ha già preso i suoi riferimenti. Memory leak silenzioso, contatore degli event listener nei DevTools che cresce monotonamente. **Fix:** `destroyRef.onDestroy(() => this.splide?.destroy())` accanto all'inizializzazione.

### 4. `zone.run` su tutta la callback

```typescript
this.splide!.on('move', (i) => this.zone.run(() => { /* tutto */ }));   // ❌
```

Funziona, ma rientra in zone per *tutta* la durata della callback — incluso il codice della libreria che potrebbe a sua volta chiamare altri callback dentro la stessa esecuzione. State pagando il costo che volevate evitare, solo in modo più subdolo. **Fix:** restate in `runOutsideAngular` per la registrazione, e usate `zone.run` solo per le righe che toccano lo stato Angular (`signal.set`, `subject.next`, scritture su proprietà osservate dal template).

---

## Il flusso, raccontato

L'utente apre la home del catalogo. Angular costruisce il `Carousel`, ma non lancia subito Splide: aspetta che il primo render finisca (`afterNextRender`), così l'elemento `#host` ha già dimensioni reali. A questo punto entra in scena la stanza insonorizzata: dentro `runOutsideAngular`, Splide viene istanziato, monta la sua struttura DOM nel `#host`, registra i suoi listener su `mousemove` e i suoi `requestAnimationFrame` per le animazioni. Da quel momento Splide gira a 60fps — il microfono di Zone.js non lo sente, change detection di Angular non si sveglia.

L'utente trascina una slide. Splide calcola, anima, aggiorna il proprio DOM interno. Niente CD, niente costi per Angular. Quando l'animazione finisce, Splide emette l'evento `move` con il nuovo indice. Il nostro listener era stato registrato fuori zone, quindi la callback parte fuori zone — apriamo brevemente la porta con `zone.run`, dentro c'è una sola riga (`this.currentIndex.set(newIndex)`), il signal cambia, Angular se ne accorge, il template che mostra "Slide 2 di 4" si ridisegna. Richiusa la porta, torniamo in stanza.

L'utente naviga via dalla home. Angular distrugge `Carousel`, il `destroyRef.onDestroy` registrato in costruttore scatta, `splide.destroy()` smonta tutti i listener della libreria e libera il suo DOM interno. Nessun memory leak. La prossima volta che l'utente torna sulla home, tutto il ciclo riparte da capo, pulito.

È lo stesso scheletro che useremo per qualunque libreria DOM avrete in mano nei vostri progetti: identificare gli eventi che devono propagarsi ad Angular (di solito sono pochi), tenere tutto il resto fuori zone, smontare al destroy.

---

## Schema riassuntivo

```
        SALOTTO ANGULAR (in zone)
        ┌──────────────────────────────────────────┐
        │  microfono Zone.js: capta ogni evento    │
        │  ──> change detection                    │
        │                                          │
        │           ┌───────────────────────────┐  │
        │           │  STANZA INSONORIZZATA     │  │
        │  zone.run │  (runOutsideAngular)      │  │
        │ ────────▶ │                           │  │
        │           │  Splide                   │  │
        │  signal   │   ├ mount + DOM           │  │
        │  .set     │   ├ listener mousemove    │  │
        │ ◀──────── │   ├ requestAnimationFrame │  │
        │  zone.run │   └ on('move', ...) ──────┼──┼─▶ apre porta
        │           │                           │  │   con zone.run
        │           └───────────────────────────┘  │   solo per signal.set
        │                                          │
        │  destroyRef.onDestroy ──▶ splide.destroy │
        └──────────────────────────────────────────┘
```

| Voce | Sintassi chiave |
|---|---|
| Iniettare la zone | `inject(NgZone)` |
| Iniettare il DestroyRef | `inject(DestroyRef)` |
| Aspettare il primo render | `afterNextRender(() => { ... })` |
| Stanza insonorizzata | `zone.runOutsideAngular(() => { ... })` |
| Apertura porta per annunciare | `zone.run(() => signal.set(...))` |
| Cleanup garantito | `destroyRef.onDestroy(() => lib?.destroy())` |
| Riferimento al nodo host | `viewChild<ElementRef<HTMLElement>>('host')` |

### File reali nel seme da citare in aula

| File | Cosa mostra | Note |
|---|---|---|
| — | Nessun uso di `NgZone` o di Splide nel seme | Sono novità del Mod 1c: arriveranno nel Lab 2a |

---

## Prossimo: [11 — Subject / BehaviorSubject per la comunicazione tra componenti](./11-subject-behaviorsubject.md)
