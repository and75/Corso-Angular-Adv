# 12 — Signal: lo stato reattivo nativo di Angular

> **Tempo:** ~20 min · **Slide:** TBD · **Blocco:** G1 Sessione 5 · 16:15–16:35 (completamento Mod 1d)
> **Prerequisito:** [Scheda 11 — Subject / BehaviorSubject](./11-subject-behaviorsubject.md). Questa scheda riscrive lo stesso scenario con i signal e confronta i due mondi.

---

## Il problema

Nella [Scheda 11](./11-subject-behaviorsubject.md) abbiamo costruito `AuthService` + `CartService` con `BehaviorSubject`: una lavagnetta che tiene l'utente loggato, un servizio carrello che reagisce ai cambi via `subscribe` nel costruttore, due `| async` nel template del componente. Funziona, è il pattern storico di Angular, ed è quello che troverete in qualunque codebase di qualche anno.

Da Angular 16 c'è una primitiva nativa che fa lo stesso lavoro con molto meno cerimoniale: i **signal**. Da Angular 19 sono trattati come il modo *predefinito* per modellare lo stato locale, e nei progetti nuovi del 2026 sono la scelta naturale per lo stato sincrono condiviso fra servizi e componenti. La domanda canonica del corso — *quando signal, quando BehaviorSubject?* — l'abbiamo aperta nella 11. Qui la chiudiamo dal lato opposto: riscriviamo `AuthService` + `CartService` riga per riga, vediamo cosa sparisce e cosa cambia, e arriviamo a una linea pratica per il 2026 — che non è "buttate via RxJS" ma "dividetevi i compiti".

---

## Dalla lavagnetta al foglio di calcolo

Nella 11 abbiamo usato la metafora della **lavagnetta**: un valore appeso al muro, con tre proprietà — c'è sempre, chi entra lo legge subito, ogni cambiamento avvisa tutti. È esattamente quello che fa un `BehaviorSubject`.

I signal sono la stessa idea portata un passo in là. Pensateli come le **celle di un foglio di calcolo** — Excel, Google Sheets, quello che volete. Le celle base in cui scrivete valori a mano (`A1 = 10`) sono i `signal`. Le celle con formula (`C1 = A1 + B1`) sono i `computed`: derivate da altre celle, si ricalcolano da sole quando le sorgenti cambiano. Le macro VBA che scattano al cambio di una cella sono gli `effect`: side effect dichiarativi.

Tre differenze rispetto alla lavagnetta cambiano tutto:

1. La cella è **sincrona pull-based**: la leggete quando volete con `signal()`, senza sottoscrizione. Nel foglio di calcolo non vi "iscrivete" a `A1` — la guardate e basta.
2. Le formule sono **native**: `computed()` vi dà gratis quello che con RxJS ottenete con `.pipe(map(...))`, e in più memoizza e si ricalcola solo quando serve.
3. Le **macro non si sganciano da sole**: `effect()` si pulisce automaticamente al destroy del componente che lo possiede. Niente `takeUntilDestroyed`, niente `Subscription` da tenere d'occhio.

Quando vi chiederete *"qui signal o BehaviorSubject?"*, tornate alla differenza tra una lavagnetta e una cella di foglio di calcolo. La lavagnetta funziona benissimo, ma la cella si compone meglio col resto del foglio — e in Angular moderno il foglio è il modello di riferimento.

---

## signal(): la cella base

```typescript
import { signal } from '@angular/core';

const count = signal(0);          // creazione + valore iniziale (obbligatorio, come BehaviorSubject)
console.log(count());             // 0 — leggere chiamando come funzione

count.set(5);                     // sostituire il valore
count.update(c => c + 1);         // aggiornare in funzione del precedente
console.log(count());             // 6
```

Tre dettagli da fissare. Primo: si **legge** chiamando il signal come funzione (`count()`), non come property. Sembra una micro-eccentricità, ma è quello che permette al sistema di tracciare *chi* sta leggendo cosa, senza decoratori né proxy. Vi servirà fra poco per capire `computed` ed `effect`. Secondo: per **scrivere** ci sono `set(v)` e `update(fn)`. Il vecchio `mutate()` è stato rimosso in Angular 18 — se lo vedete in tutorial vecchi, sostituite con `update`. Terzo: per **esporre un signal in sola lettura** all'esterno esiste `asReadonly()`, l'equivalente di `asObservable()` nel mondo RxJS:

```typescript
private _items = signal<CartItem[]>([]);
readonly items = this._items.asReadonly();   // i consumer leggono ma non scrivono
```

È lo stesso pattern di incapsulamento della scheda 11 — chi tiene lo stato controlla chi può modificarlo. La forma cambia, la sostanza no.

---

## AuthService, versione signal

Riscriviamo il primo dei due servizi. Stesso scenario, stessa API esterna, internals diversi.

```typescript
import { Injectable, signal, computed } from '@angular/core';

export interface User { id: string; nome: string; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  // la "lavagnetta" diventa una cella del foglio di calcolo
  private _utente = signal<User | null>(null);

  // versione in sola lettura esposta all'esterno
  readonly utente = this._utente.asReadonly();

  // stato derivato: si ricalcola da solo quando _utente cambia
  readonly isLoggato = computed(() => this._utente() !== null);

  login(user: User) { this._utente.set(user); }
  logout()          { this._utente.set(null); }
}
```

Confrontate riga per riga con la versione `BehaviorSubject` della 11. Tre cose sono cambiate. La **lavagnetta** è diventata una cella: lettura sincrona (`this._utente()`), nessuna sottoscrizione necessaria, nessuna `.value` da chiamare separatamente. L'**esposizione read-only** passa da `asObservable()` a `asReadonly()` — stesso significato, sintassi più snella, e il consumer riceve un signal da chiamare come funzione (`auth.utente()`) invece di un Observable da sottoscrivere. Il `isLoggato` è la novità che vale la pena assaporare: con `BehaviorSubject` avreste scritto `isLoggato$ = this.utente$.pipe(map(u => u !== null))`. Con i signal è una sola riga di `computed`, senza pipe, senza operatori importati, senza subscriptions da gestire. Ed è **lazy + memoizzato**: la formula gira solo quando qualcuno legge `isLoggato()`, e finché `_utente` non cambia, il valore resta in cache.

---

## CartService, versione signal: da subscribe a effect

Qui sta la differenza più interessante. Nella 11 il `CartService` si iscriveva a `auth.utente$` nel costruttore. Nella versione signal usiamo `effect()` — che ri-esegue automaticamente quando un signal letto al suo interno cambia.

```typescript
import { Injectable, inject, signal, effect } from '@angular/core';
import { AuthService } from './auth.service';

export interface Articolo { id: string; nome: string; }

@Injectable({ providedIn: 'root' })
export class CartService {
  private auth = inject(AuthService);

  private _articoli = signal<Articolo[]>([]);
  readonly articoli = this._articoli.asReadonly();

  constructor() {
    // reagisce ai cambi di auth.utente() senza subscribe né unsubscribe
    effect(() => {
      const utente = this.auth.utente();
      if (utente) this.caricaCarrelloPerUtente(utente.id);
      else        this._articoli.set([]);
    });
  }

  aggiungi(articolo: Articolo) {
    // update riceve il valore corrente e ne restituisce uno nuovo
    this._articoli.update(lista => [...lista, articolo]);
  }

  private caricaCarrelloPerUtente(userId: string) {
    this._articoli.set([{ id: 'a1', nome: 'Pasta artigianale' }]);
  }
}
```

Quattro cose sono sparite dalla versione con `BehaviorSubject`: l'`import { Subject } from 'rxjs'`, il `subscribe` nel costruttore, il dover ricordarsi del `takeUntilDestroyed`, il dover tenere il riferimento alla `Subscription`. Quello che resta è un `effect(() => ...)` che **dichiara una relazione**: *"il carrello dipende dall'utente; quando l'utente cambia, ricalcola il carrello"*. Niente più *quando* — Angular sa quando lavorare, perché vede la lettura di `this.auth.utente()` dentro al body dell'effect e si "abbona" automaticamente.

Notate anche il dettaglio dell'`update`: nella 11 scrivevamo `this._articoli.next([...this._articoli.value, articolo])` — accesso esplicito al valore corrente più nuovo array. Qui è `this._articoli.update(lista => [...lista, articolo])` — la callback riceve il valore corrente, restituisce il nuovo, l'API è auto-esplicativa.

---

## Il componente: niente più pipe async

```typescript
@Component({
  selector: 'app-header',
  template: `
    @if (auth.utente(); as u) { <span>Ciao {{ u.nome }}</span> }
    <span>Articoli: {{ cart.articoli().length }}</span>
  `,
})
export class HeaderComponent {
  auth = inject(AuthService);
  cart = inject(CartService);
}
```

Nella 11 il template aveva due `| async`. Qui non c'è. Un signal nel template si legge direttamente come funzione — il sistema di change detection di Angular sa che il template dipende da quei signal e ridipinge automaticamente quando cambiano. Il pattern `@if (... ; as ...)` per il narrowing del tipo funziona identico a quello con `async`. Tre righe di template, zero subscriptions implicite, zero gestione del lifecycle.

Per chi viene dal mondo RxJS, vale la pena sottolinearlo: in passato anche con `async` si scriveva un template pulito. La differenza qui non è "meno codice nel template" — è che dietro non c'è più una Subscription, neanche implicita. Il signal è letto e basta, e Angular tiene traccia della dipendenza nel suo grafo interno.

---

## Il vantaggio "nascosto" che risolve un problema della 11

Vi ricordate il motivo per cui nella 11 serviva proprio un `BehaviorSubject` e non un `Subject` normale? Era una questione di tempistica: il `CartService` poteva nascere *dopo* che `AuthService.login()` era già stato chiamato, e con un `Subject` semplice si sarebbe perso l'emissione. La lavagnetta del `BehaviorSubject` risolveva esattamente questo — il subscribe in ritardo trovava comunque l'ultimo valore.

Con i signal questo problema **sparisce per costruzione**. Un signal *è* sempre il suo valore corrente, non c'è il concetto di "essermi perso l'emissione precedente": quando l'`effect` di `CartService` viene creato, legge `this.auth.utente()` e ottiene l'istantanea sincrona — fosse `null` (nessuno loggato) o un `User` già autenticato. Il problema di tempistica non si pone proprio. Quel motivo specifico per scegliere `BehaviorSubject` non esiste più.

È un esempio del pattern generale: alcuni dei problemi su cui RxJS aveva la risposta corretta (replay dell'ultimo valore, sincronizzazione del subscribe ritardato) non sono problemi nel mondo signal — sono concetti che non hanno traduzione perché il modello è diverso.

---

## Quando però terresti comunque RxJS (e BehaviorSubject)

La risposta onesta non è *"i signal rimpiazzano tutto"*. È una **divisione dei compiti**, ed è il consenso attuale della community Angular nel 2026:

- I **signal** sono fatti per lo **stato**. Valori sincroni, stato della UI, derivati, rendering performante. Sono pull-based, tracciati automaticamente, senza subscribe né cleanup.
- **RxJS** (e con lui `BehaviorSubject` / `Subject`) resta giusto per i **flussi asincroni nel tempo**: risposte HTTP, dati WebSocket, polling, trasformazioni async complesse (`debounceTime` per un campo di ricerca, `switchMap` per cancellare la chiamata precedente, `retry` per ritentare, `combineLatest` per derivare da più sorgenti async).

Detto altrimenti — in tabella concreta:

| Caso | Strumento |
|---|---|
| Stato sincrono di un componente, leggibile nel template | `signal` |
| Stato derivato sincrono | `computed` |
| Side effect quando uno stato cambia (storage, log, navigazione) | `effect` |
| Stato sincrono condiviso fra servizi (utente loggato, tema, carrello) | `signal` (qui i signal hanno sostituito `BehaviorSubject`) |
| Risposta HTTP, evento WebSocket, polling, click "globali" che attraversano l'app | `Observable` / `Subject` |
| Pipeline async con `debounceTime`, `switchMap`, `combineLatest`, `retry` | RxJS — i signal non hanno equivalente naturale |
| Bus eventi senza storia (toast, "user logged out") | `Subject` (multicast, niente replay) |
| Codebase esistente piena di Observable | RxJS — non si rifà tutto, si fa da ponte con `toSignal` dove serve |

Tre casi in cui terreste `BehaviorSubject` anche oggi, in un progetto nuovo:

1. **Lo stato nasce da un flusso asincrono vero** — una WebSocket che emette aggiornamenti, un polling HTTP, eventi che arrivano nel tempo. Lì RxJS con i suoi operatori è ancora insostituibile, perché modella esattamente *quel tipo* di realtà.
2. **Vi serve la composizione temporale**, non solo "l'ultimo valore". `combineLatest` di tre stream, `withLatestFrom`, `bufferTime`, `merge` di sorgenti diverse — sono pattern che con i signal non hanno traduzione naturale.
3. **State lavorando su una codebase esistente** già piena di Observable. La migrazione tipica non è *"butto via tutto"*, è *"lo stato sincrono condiviso passa ai signal, l'async resta in RxJS, e `toSignal` fa da cerniera al confine con i componenti"*.

---

## Il caso ibrido: HTTP/WebSocket + toSignal

Il pattern reale del 2026 è quello in cui un servizio riceve dati da una fonte asincrona (HTTP, WebSocket, RxJS-based legacy) e li espone alla UI come signal. La cerniera è `toSignal()` da `@angular/core/rxjs-interop`.

```typescript
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { toSignal } from '@angular/core/rxjs-interop';
import { interval, switchMap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PricesService {
  private http = inject(HttpClient);

  // RxJS dove serve davvero: polling ogni 10 secondi
  private prices$ = interval(10_000).pipe(
    switchMap(() => this.http.get<Record<string, number>>('/api/prices'))
  );

  // toSignal: il template legge come un signal qualsiasi
  readonly prices = toSignal(this.prices$, { initialValue: {} });
}
```

Cosa fa `toSignal` esattamente: sottoscrive l'Observable internamente, espone un signal che vale sempre l'ultima emissione, e si pulisce automaticamente al destroy dell'injection context in cui è stato creato. Nel componente:

```typescript
@Component({
  template: `
    <p>Prezzo Bitcoin: {{ prices()['BTC'] }}</p>
  `,
})
export class PriceWidget {
  prices = inject(PricesService).prices;   // è un signal, non un Observable
}
```

Niente `| async`, niente `subscribe`, niente cleanup. Il polling vive in RxJS (è il suo mestiere), la UI vive nei signal (è il suo mestiere), e il confine fra i due mondi passa per quella riga di `toSignal()`. È il pattern che vedrete in qualsiasi codice Angular moderno con backend reattivo — adottatelo come default ogni volta che lo stream RxJS che producete è destinato a diventare stato della UI.

Esiste anche la direzione opposta: `toObservable(signal)` esporta un signal verso il mondo RxJS, utile quando lo stato di un componente deve alimentare una pipeline async (es. un input di ricerca che diventa `debounceTime` + `switchMap`). Useremo questo pattern nel Mod 3 con i query parameter del router e nel Mod 4 con gli interceptor.

---

## input() e output(): la nuova API dei componenti

I signal hanno cambiato anche il modo di dichiarare input e output dei componenti. `@Input()` / `@Output()` con `EventEmitter` funzionano ancora, ma le API signal-based (Angular 17.1+, stabilizzate in 19) sono più tipizzate:

```typescript
import { Component, input, output, computed } from '@angular/core';

@Component({
  selector: 'app-product-card',
  template: `
    <h3>{{ product().nome }} — {{ product().prezzo | currency }}</h3>
    @if (isPremium()) { <span class="badge">Premium</span> }
  `,
})
export class ProductCard {
  product = input.required<Product>();           // input obbligatorio (TS lo controlla)
  variant = input<'default' | 'compact'>('default');   // input opzionale con default

  addToCart = output<Product>();                 // output: emette eventi al padre

  // si compone naturalmente con computed — niente ngOnChanges
  isPremium = computed(() => this.product().prezzo > 50);
}
```

`input.required<T>()` dichiara un input obbligatorio controllato a compile-time — niente più `@Input() product!: Product` con l'`!` di assertion. Gli input sono signal di sola lettura: leggete con `product()`, non potete scriverci sopra (il componente è il consumer, non il proprietario). Il `computed` su `product()` è ciò che con `@Input()` avreste dovuto fare con `ngOnChanges` e una property derivata aggiornata a mano. Per il **two-way binding** c'è `model<T>()`, che è input + output combinati — utile per stepper, slider, controlli custom dove il componente legge *e* scrive lo stesso valore.

---

## Errori comuni

### 1. Lettura senza parentesi nel template

```html
<div>{{ count }}</div>      <!-- ❌ stampa la funzione -->
<div>{{ count() }}</div>    <!-- ✅ -->
```

Niente errore di compilazione, output strano a video. È l'errore numero uno di chi inizia.

### 2. computed con side effect

```typescript
const totale = computed(() => {
  const sum = articoli().reduce((s, i) => s + i.prezzo, 0);
  localStorage.setItem('lastTotal', String(sum));   // ❌ side effect in computed
  return sum;
});
```

Il `computed` è lazy: se nessuno lo legge, lo storage non si aggiorna. Se più consumer lo leggono, lo storage si aggiorna più volte. **Fix:** la derivazione resta in `computed`, il side effect va in un `effect` separato.

### 3. effect che scrive lo stesso signal che legge

```typescript
effect(() => {
  count.set(count() + 1);   // ❌ NG0600 — Angular blocca esplicitamente
});
```

Loop infinito intercettato dal framework. Se vi serve davvero scrivere dentro un effect senza essere "abbonati" alla propria scrittura, usate `untracked(() => count.set(...))` — segnala chiaramente "so cosa sto facendo".

### 4. effect fuori da un injection context

```typescript
ngOnInit() {
  effect(() => console.log(this.count()));   // ❌ NG0203 senza injector esplicito
}
```

L'`effect` ha bisogno di sapere quale injector lo possiede per pulirsi al destroy. **Fix:** dichiararlo come property della classe (idiomatico) o passare un `injector` esplicito.

### 5. effect usato dove bastava computed

```typescript
let isPremium = false;
effect(() => { isPremium = product().prezzo > 50; });   // ❌

isPremium = computed(() => this.product().prezzo > 50);   // ✅
```

Se l'obiettivo è "ottenere un valore derivato", la risposta è `computed`. L'`effect` è per le azioni — DOM, storage, log, navigazione — non per produrre stato.

---

## Schema riassuntivo

```
    11 — BehaviorSubject (lavagnetta)         12 — signal (foglio di calcolo)
    ──────────────────────────────────         ─────────────────────────────────
    private _utente = new                      private _utente = signal<User|null>(null);
      BehaviorSubject<User|null>(null);

    utente$ = _utente.asObservable();          readonly utente = _utente.asReadonly();

    isLoggato$ = utente$.pipe(                 readonly isLoggato =
      map(u => u !== null));                     computed(() => _utente() !== null);

    login(u) { _utente.next(u); }              login(u) { _utente.set(u); }

    // CartService
    this.auth.utente$.subscribe(u => {         effect(() => {
      if (u) carica(u.id);                       const u = this.auth.utente();
      else _articoli.next([]);                   if (u) carica(u.id);
    });                                          else _articoli.set([]);
                                               });

    // componente
    <span>{{ (auth.utente$ | async)?.nome }}   <span>{{ auth.utente()?.nome }}</span>

    PONTE con il mondo opposto:
    Observable → signal:   toSignal(obs$, { initialValue })
    signal     → Observable: toObservable(sig)
```

| Voce | Sintassi chiave |
|---|---|
| Creare un signal | `signal<T>(initial)` |
| Leggere | `count()` |
| Scrivere | `count.set(v)` / `count.update(fn)` |
| Esporre read-only | `private _x = signal(...)` + `readonly x = _x.asReadonly()` |
| Cella con formula | `computed(() => deps() + altre())` |
| Side effect | `effect(() => { ... })` (in injection context) |
| Lettura non tracciata | `untracked(() => signal())` |
| Input signal-based | `input<T>()` / `input.required<T>()` |
| Output signal-based | `output<T>()` |
| Two-way binding | `model<T>(default)` |
| Observable → signal | `toSignal(obs$, { initialValue })` |
| Signal → Observable | `toObservable(sig)` |

### File reali nel seme da citare in aula

| File | Cosa mostra | Note |
|---|---|---|
| [`src/app/services/product.ts`](../../progetto/product-catalog/src/app/services/product.ts) | `cartItems = signal<CartItem[]>([])` + `computed` per totali | Esempio già nel seme: qui aggiungiamo `effect`, `input()`, `output()`, `toSignal` |
| [`src/app/components/product-card/product-card.ts`](../../progetto/product-catalog/src/app/components/product-card/product-card.ts) | Oggi usa `@Input()` classico | Candidato per la migrazione a `input.required<Product>()` (opzionale nel Lab 1) |

---

## Prossimo: [Lab 2a — Carousel Splide con NgZone](../lab-02a/README.md)
