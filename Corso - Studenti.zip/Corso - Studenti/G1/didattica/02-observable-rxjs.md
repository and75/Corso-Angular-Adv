# 02 — Observable e RxJS Base

> **Tempo:** ~18 min · **Slide:** TBD · **Blocco:** G1 Sessione 1 · 09:33–09:51 (ripasso)

---

## Il problema

Nel corso base avete scritto tante volte `.subscribe(...)` su una chiamata HTTP, e ha funzionato: l'array di prodotti arrivava, lo mettevate nella property del componente, il template lo mostrava. Bene. Solo che, se vi fermo qui e vi chiedo *"cos'è esattamente quella cosa che sta a sinistra del `.subscribe()`?"*, probabilmente la risposta sarà *"un Observable"* — e poi un silenzio.

In questo corso avanzato gli Observable smettono di essere "quella cosa di `HttpClient`" e diventano lo strumento di base per:

- **Mod 1d** — un `NotificationService` che usa `Subject` / `BehaviorSubject` per spingere notifiche a tutti i componenti che ascoltano.
- **Mod 3** — i parametri di rotta reattivi (`route.paramMap`, `route.queryParamMap`), che cambiano nel tempo a ogni navigazione.
- **Mod 4** — gli **interceptor**, dove `pipe()` con `catchError` e `retry` è il pane quotidiano per gestire errori HTTP e re-autenticazione.

Per arrivarci dobbiamo essere a posto su tre cose: *cos'è davvero un Observable*, *cosa succede quando ci si sottoscrive*, *come si trasformano i dati nel tragitto fra il server e il componente*. Questo è il ripasso.

---

## Il rubinetto: che cos'è un Observable

Pensate a un Observable come a un **rubinetto**. Il rubinetto esiste sul muro — qualcuno l'ha montato — ma da quel rubinetto non esce niente finché non lo aprite. Quando lo aprite, l'acqua inizia a scorrere. Quando lo chiudete, smette.

In RxJS:

- *montare il rubinetto* = creare l'Observable (chiamare `http.get(...)`, importare `interval(...)`, leggere un `valueChanges` di un form).
- *aprire il rubinetto* = `.subscribe(...)`.
- *l'acqua che esce* = i valori che arrivano alla vostra callback `next`.
- *chiudere il rubinetto* = annullare la sottoscrizione (`unsubscribe`, oppure operatori come `takeUntilDestroyed`).

```
http.get<Product[]>('/products')
─────────────────────────────────
   [montato]   il rubinetto è lì, ma è chiuso → nessuna chiamata HTTP

   .subscribe(...)                ← apro il rubinetto

   [parte la richiesta]
        │
        ├──── ~200 ms ────▶  next: [{ id:1 }, { id:2 }, ...]
        │
        └── [complete]              il serbatoio è finito (HTTP è one-shot)
```

Il punto da assimilare bene è questo: **finché nessuno chiama `.subscribe()`, non succede niente**. Non è come una funzione che, una volta scritta, "fa qualcosa". L'Observable è una *descrizione* di un flusso futuro — il flusso parte solo se qualcuno lo accende. È quello che in gergo si chiama **lazy**.

> **Il caso HTTP è particolare**: il rubinetto eroga *un solo* valore (la risposta del server) e poi si chiude da solo (`complete`). Non vale per tutti gli Observable: un `interval(1000)` continua a sgocciolare ogni secondo finché non lo chiudete voi, un `Subject` può emettere centinaia di valori finché vive, un `valueChanges` di un form emette a ogni tasto premuto. Tenete a mente questa distinzione — la riprendiamo nel Mod 1d quando parliamo dei `Subject`.

### Perché un Observable e non una Promise

Domanda legittima: per una chiamata HTTP che emette un valore e poi finisce, una `Promise` farebbe lo stesso lavoro. E in effetti `HttpClient` lo si potrebbe wrappare con `firstValueFrom(...)` e usarlo con `async/await`. Perché allora Angular usa Observable di default?

Tre motivi, in ordine di importanza pratica:

1. **L'Observable è lazy, la Promise è eager.** La Promise parte nel momento in cui la create. L'Observable parte solo quando lo sottoscrivete. Sembra una sottigliezza, finché non avete bisogno di costruire la richiesta una volta e farla partire due volte (retry), o di non farla partire affatto se nel frattempo l'utente ha già cambiato pagina.
2. **L'Observable è cancellabile, la Promise no.** Se l'utente naviga via prima che la risposta arrivi, voi *chiudete il rubinetto* e la richiesta HTTP viene cancellata. Con una Promise non avete questa leva.
3. **Gli operatori di `pipe()` sono parte del modello.** Un Observable può essere trasformato in volo (filtrato, mappato, combinato con un altro Observable) con un'API ricchissima e composabile. Una Promise non ha niente di simile nativamente.

Per una `getProducts()` che fa una chiamata HTTP e basta, la differenza non si vede. Ma il giorno in cui dovete fare *"ogni volta che l'utente cambia query nella ricerca, annulla la richiesta precedente e fanne una nuova con debounce di 300 ms"* — quello con le Promise è un piccolo incubo, con RxJS sono tre operatori in fila.

---

## subscribe(): i tre canali (next, error, complete)

Quando aprite il rubinetto con `.subscribe()`, gli dite *cosa fare* in tre situazioni possibili: arriva un valore (`next`), arriva un errore (`error`), il serbatoio è finito (`complete`). Per `HttpClient` ne servono praticamente solo due:

```typescript
// src/app/pages/home/home.page.ts — pattern reale del seme
loadProducts(): void {
  this.isLoading = true;
  this.error = null;

  this.productService.getProducts().subscribe({
    next: data => {
      this.products = data;
      this.isLoading = false;
    },
    error: err => {
      this.error = err.message || 'Errore sconosciuto';
      this.isLoading = false;
    },
    // complete: non serve per HttpClient — viene chiamato dopo next,
    //           ma a quel punto il dato è già a posto nel next.
  });
}
```

Notate una cosa importante: il componente **non delega ad Angular** la decisione su quando aprire il rubinetto. È `HomePage` che chiama `loadProducts()` dentro al suo `ngOnInit`, è `HomePage` che decide cosa fare quando arriva il dato (riempire `this.products`) e cosa fare quando arriva un errore (riempire `this.error`). Angular non sa nemmeno che esiste questa chiamata HTTP — lui si limita a montare il componente e a far girare il template. Tutto il resto è il vostro codice.

Il template poi guida la UI con la classica trilogia di stati:

```html
@if (isLoading) {
  <span>Caricamento...</span>
} @else if (error) {
  <div class="error">{{ error }}</div>
} @else {
  <!-- griglia di prodotti -->
}
```

Questo pattern *loading / error / data* è il pane quotidiano dei componenti che parlano col server. Vale la pena memorizzarlo perché tornerà — letteralmente — in ogni pagina dei vostri progetti.

---

## pipe(): cosa succede prima che l'acqua arrivi al lavandino

Il dato grezzo che arriva dal server quasi mai è esattamente quello che serve al componente. Magari `json-server` vi restituisce tutti i prodotti ma a voi servono solo quelli disponibili. Magari vi servono ordinati per prezzo. Magari volete loggare cos'è arrivato, per debug.

Tutte queste *trasformazioni* andrebbero fatte **nel servizio**, prima che il dato arrivi al componente. Tornando alla metafora del rubinetto: `pipe()` è il pezzo di tubatura dove montate i **filtri**. L'acqua entra grezza dalla rete idrica, passa attraverso una serie di filtri (uno depura, uno addolcisce, uno aggiunge minerali), ed esce dal vostro rubinetto già pronta da bere.

```
Observable<DatoGrezzo>
  .pipe(
    operatore1(),   ← filtro 1
    operatore2(),   ← filtro 2
    operatore3(),   ← filtro 3
  )
→ Observable<DatoTrasformato>
```

Il vantaggio non è solo estetico. Mettendo le trasformazioni nel servizio: (a) il componente riceve dati già pronti e resta semplice — fa solo da "vetrina"; (b) la trasformazione è riusabile, perché il servizio è iniettato in tante pagine; (c) la logica è facile da testare in isolamento.

### map() — trasforma ogni valore

`map()` di RxJS è analogo a `Array.map()`, ma agisce sui valori emessi dal flusso anziché sugli elementi di un array. Per `HttpClient` viene chiamato una sola volta (perché esce un solo valore), e voi lo usate per *rifinire* la risposta:

```typescript
import { map } from 'rxjs/operators';

getProductsAvailable(): Observable<Product[]> {
  return this.http.get<Product[]>(this.API_URL).pipe(
    map(products => products.filter(p => p.available)),
    // ↑ map RxJS                ↑ map Array — due cose diverse
  );
}
```

Attenzione al doppio `map` qui sopra: quello esterno è l'operatore RxJS (lavora sul valore che esce dal rubinetto, cioè l'intero array), quello interno è il `filter` di JavaScript (lavora sugli elementi dell'array). Confondere i due livelli è un errore comune all'inizio — quando vi capita un `Property 'map' does not exist on type 'Observable<...>'`, è quasi sempre questo.

### catchError() — la valvola di sicurezza

Se nel tragitto qualcosa va storto (server giù, 404, rete che cade), il rubinetto **emette un errore** invece di un valore — e poi si spegne. Il `catchError` è una valvola che intercetta l'errore prima che arrivi al `subscribe`, e decide cosa fare al posto suo. È un punto di scelta progettuale importante, e nel seme del corso base lo trovate fatto così:

```typescript
// src/app/services/product.ts — codice reale del seme
getProducts(): Observable<Product[]> {
  return this.http.get<Product[]>(this.API_URL).pipe(
    catchError(err => {
      console.error('Errore caricamento prodotti:', err);
      return throwError(() => new Error(
        'Impossibile caricare i prodotti. Assicurati che json-server sia in esecuzione.'
      ));
    }),
  );
}
```

Quel `catchError` non *sopprime* l'errore: lo intercetta, lo logga, e poi ne ri-lancia un altro più "umano" (con un messaggio adatto a essere mostrato all'utente). Il componente nel suo `subscribe.error` riceverà quell'errore pulito e potrà metterlo nel template senza far vedere lo stacktrace di Angular.

C'è anche la scelta opposta, che vi capiterà spesso. Invece di rilanciare, potete *ingoiare* l'errore e restituire un valore di fallback:

```typescript
catchError(err => {
  console.error('Errore:', err);
  return of([]); // ← Observable che emette array vuoto e completa
})
```

Con `return of([])` il componente non viene mai notificato dell'errore: riceve semplicemente un array vuoto, e la UI mostrerà "nessun risultato" invece di un alert rosso. È un comportamento utile quando "vuoto" è uno stato accettabile (catalogo senza filtri attivi, lista preferiti dell'utente nuovo), pessimo quando l'utente *deve* sapere che qualcosa non ha funzionato (pagamento, login). La regola spannometrica è: rilanciate se l'utente deve agire, ingoiate se l'utente non può/non deve farsene niente.

### of() — un valore già pronto, fatto Observable

`of(...)` crea un Observable che emette immediatamente il valore che gli passate, e poi completa:

```typescript
import { of } from 'rxjs';
of(42).subscribe(v => console.log(v)); // stampa 42, poi complete
```

È utilissimo come **fallback** in `catchError` (l'avete appena visto: `return of([])`), nei test (perché simula una risposta sincrona senza chiamare il server), o come placeholder mentre costruite un nuovo metodo del servizio.

### tap() — sbirciare senza toccare

`tap()` è l'operatore "fissa-il-flusso-senza-modificarlo": riceve ogni valore che passa, ci fa quello che gli dite (tipicamente un `console.log`), e poi lo lascia proseguire intatto. È il modo corretto per debuggare una pipeline RxJS:

```typescript
import { tap } from 'rxjs/operators';

return this.http.get<Product[]>(url).pipe(
  tap(products => console.log('Grezzo:', products.length)),
  map(products => products.filter(p => p.available)),
  tap(products => console.log('Filtrato:', products.length)),
);
```

I due `tap` sopra non alterano il flusso — l'output del `map` è lo stesso che sarebbe stato senza di loro. Vi servono solo per vedere, durante lo sviluppo, *cosa* sta passando in ogni punto della pipeline. In produzione potete lasciarli (se il logging serve davvero) o rimuoverli.

---

## Anticipazione: switchMap e debounceTime

Non li usiamo nel ripasso, ma vi capiterà di vederli citati spesso nei prossimi moduli, e vale la pena sapere a cosa servono:

- **`debounceTime(ms)`** — attende che il flusso si "calmi" prima di emettere. Tipico per un campo di ricerca: l'utente digita "p", "pi", "piz", "pizz", "pizza" — e voi volete fare una sola chiamata HTTP quando ha smesso di digitare, non cinque.
- **`switchMap(fn)`** — quando arriva un valore, lancia una nuova operazione asincrona **annullando** quella precedente. Stesso esempio della ricerca: se l'utente digita "pi" e poi cambia idea e digita "piz", lo `switchMap` cancella la richiesta `/search?q=pi` (chiude il rubinetto) e fa partire `/search?q=piz`. Senza switchMap rischiereste di mostrare i risultati di "pi" *dopo* quelli di "piz".

Li vedrete in azione nei lab di Mod 3 (parametri di rotta) e Mod 4 (interceptor con refresh token).

---

## Errori comuni

### 1. Dimenticare `.subscribe()`

```typescript
// ❌ Niente subscribe → il rubinetto resta chiuso, la chiamata HTTP non parte mai
ngOnInit() {
  this.productService.getProducts();
}

// ✅ Subscribe come nel seme
ngOnInit() {
  this.productService.getProducts().subscribe({ next: d => this.products = d });
}
```

L'errore è subdolo perché TypeScript non protesta — `getProducts()` ha un valore di ritorno valido (è un `Observable`), e ignorarlo è sintatticamente legale. Ma a runtime non succede niente, e la pagina resta vuota in silenzio. Se la chiamata HTTP non parte, controllate sempre per prima cosa che ci sia un `.subscribe()` da qualche parte.

### 2. `subscribe()` dentro al servizio

```typescript
// ❌ Stato dentro al servizio: difficile da testare, accoppia UI e dati
getProducts(): void {
  this.http.get<Product[]>(url).subscribe(d => this.products = d);
}

// ✅ Il servizio restituisce l'Observable — è il componente che decide
getProducts(): Observable<Product[]> {
  return this.http.get<Product[]>(url);
}
```

Questo è un errore di pulizia architetturale: se il servizio fa lui il `subscribe` e si tiene lo stato, ogni componente che vuole quei dati deve "chiedere" al servizio, e ogni test del componente deve mockare lo stato interno del servizio. Lasciare che il servizio restituisca l'Observable inverte la responsabilità: *il servizio descrive come ottenere i dati, il componente decide quando consumarli*. Lo vedete nel `ProductService` del seme: il metodo restituisce sempre un `Observable<Product[]>`.

### 3. `map()` di RxJS chiamato fuori da `pipe()`

```typescript
// ❌ TypeScript: "Property 'map' does not exist on type 'Observable<Product[]>'"
this.http.get<Product[]>(url).map(p => p.name);

// ✅ Gli operatori RxJS stanno SEMPRE dentro pipe()
this.http.get<Product[]>(url).pipe(
  map(products => products.map(p => p.name)),
);
```

Capita di confondere la sintassi di RxJS (operatori dentro `pipe()`) con la sintassi del `map` degli array (chiamato come metodo). Quando l'IDE dice *"Property 'map' does not exist"* su un Observable, è quasi sempre questo.

### 4. Cosa NON facciamo nel ripasso: i memory leak

Avrete sentito parlare di `takeUntilDestroyed()` per evitare memory leak nelle sottoscrizioni. Per le chiamate `HttpClient` non serve: il rubinetto si chiude da solo quando arriva la risposta (è quel `complete` dopo il `next`). Diventa invece rilevante per gli Observable *infiniti* — `Subject`, `valueChanges` di un form, `interval` — perché lì il rubinetto resta aperto finché qualcuno non lo chiude esplicitamente. Ne parliamo nel **Mod 1d** insieme a `Subject` e `BehaviorSubject`, che è dove rischiate davvero di lasciare aperto un rubinetto a vita.

---

## Il flusso completo, raccontato

Mettiamo insieme i pezzi. Quando l'utente apre la home del Product Catalog:

1. Angular monta `HomePage`, parte l'`ngOnInit`, che chiama `productService.getProducts()`.
2. `getProducts()` non fa partire nessuna richiesta — restituisce solo un Observable, ovvero un *rubinetto montato ma chiuso*. Su questo rubinetto c'è già una `pipe` con un `catchError` che farà da valvola di sicurezza se qualcosa va storto.
3. `HomePage` chiama `.subscribe({ next, error })` su quell'Observable: **adesso** il rubinetto si apre e parte la richiesta HTTP a `/products`.
4. Caso buono — il server risponde con l'array di prodotti: il valore esce dal rubinetto, passa attraverso la `pipe` indenne (non c'è errore da intercettare), arriva al `next` di `HomePage`, che fa `this.products = data` e `this.isLoading = false`. Dopo il valore il rubinetto si chiude da solo (`complete`), e la sottoscrizione termina.
5. Caso brutto — il server non risponde o restituisce 500: l'errore arriva al `catchError` del servizio, che lo logga e ri-lancia un errore "pulito"; quello arriva al `error` di `HomePage`, che fa `this.error = ...` e `this.isLoading = false`.
6. Il template, in entrambi i casi, vede cambiare le property `isLoading`/`error`/`products` e ridisegna lo stato giusto fra i tre rami del `@if/@else if/@else`.

Tutto a catena, senza che nessuno debba "chiedere" attivamente al servizio cosa sta succedendo. Una volta capito che il rubinetto si apre con `subscribe`, si modella con `pipe`, e si chiude da solo con `complete` o con un errore, il resto degli operatori che incontrerete (`switchMap`, `combineLatest`, `withLatestFrom`...) sono varianti dello stesso meccanismo. È quello che vediamo nei prossimi moduli.

---

## Dove l'avanzato lo estende

| Modulo | Cosa aggiunge | Operatori chiave |
|---|---|---|
| Mod 1d | `Subject` / `BehaviorSubject` per la comunicazione tra componenti (es. `NotificationService` con toast) | `next()`/`asObservable()`, `takeUntilDestroyed()` |
| Mod 3 | Lazy + parametri di rotta reattivi (`route.paramMap`, `route.queryParamMap`) | `switchMap`, `distinctUntilChanged` |
| Mod 4 | Interceptor funzionali per gestire errori HTTP e re-autenticazione | `catchError`, `retry`, `switchMap` |

---

## Schema riassuntivo

```
ProductService                                    HomePage
──────────────                                    ────────
http.get<Product[]>(API_URL)                      isLoading = true
  .pipe(                                          error = null
    catchError(err =>                             ┌─ next(data) → products = data
      throwError(() => new Error(...)))           │              isLoading = false
  )                                  subscribe ───┤
→ Observable<Product[]>                           └─ error(err) → error = err.message
                                                                 isLoading = false
```

| Operatore | Cosa fa |
|---|---|
| `map(fn)` | Trasforma ogni valore emesso |
| `tap(fn)` | Effetto collaterale (log) senza modificare il valore |
| `catchError(fn)` | Intercetta un errore: `of(...)` per nascondere, `throwError(...)` per rilanciare |
| `of(valore)` | Observable sincrono che emette `valore` e completa |
| `throwError(() => err)` | Observable che emette subito un errore |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/services/product.ts`](../../progetto/product-catalog/src/app/services/product.ts) | `Observable<Product[]>` con `pipe(catchError(...))` |
| [`src/app/pages/home/home.page.ts`](../../progetto/product-catalog/src/app/pages/home/home.page.ts) | `.subscribe({ next, error })` reale con pattern loading/error/data |

---

## Prossimo: [03 — HttpClient](./03-httpclient.md)
