# 05 — Reactive Forms base

> **Tempo:** ~12 min · **Slide:** TBD · **Blocco:** G1 Sessione 1 · 10:27–10:39 (ripasso)

---

## Il problema

Il Product Catalog usa Reactive Forms in due punti — il `CheckoutPage` e il `ProductFormPage` — con `Validators` built-in e una factory di `ValidatorFn` custom. Nel Mod 2 estenderemo proprio quel pattern con **validatori asincroni** (`AsyncValidatorFn` che ritorna `Observable<ValidationErrors | null>`) e **cross-field validation** applicata a livello di `FormGroup`. Tutto ciò vive **solo** nella famiglia reattiva: prima di metterci sopra cose nuove, mettiamo a fuoco le basi.

---

## Reactive vs Template-driven (perché reactive)

Angular offre due API per le form, con filosofie opposte. La forma corta:

| Aspetto | Template-driven (`FormsModule` + `ngModel`) | Reactive (`ReactiveFormsModule` + `FormBuilder`) |
|---|---|---|
| Dove vive lo schema della form | Template HTML | TypeScript (`FormGroup`/`FormControl`) |
| Direttive chiave | `[(ngModel)]`, `#ref="ngModel"` | `[formGroup]`, `formControlName` |
| Lettura/scrittura dello stato | Asincrona (passa dal DOM) | Sincrona (oggetto in memoria) |
| Validatori dinamici | Difficili (manipolazione del DOM) | Naturali (`addValidators`, `setValidators`, `removeValidators`) |
| Testabilità | Richiede fixture + change detection | Si testano come oggetti, senza render |
| Tipizzazione | Limitata (`any` di fatto) | **Typed Forms** da Angular 14+ (`FormGroup<{ email: FormControl<string> }>`) |

La regola del corso: quando la form ha più di 4-5 controlli, validatori che dipendono fra loro, o cambia struttura a runtime (campi aggiunti/rimossi), si usa reactive. È quello che fanno entrambe le pagine "form" del seme — e tutto Mod 2 darà per scontato che si parta da qui.

### Perché reactive e non template-driven, in pratica

Il vantaggio decisivo è la **separazione fra schema e presentazione**. Con il template-driven, lo schema della form *è* il template: per sapere quali campi esistono, di che tipo sono e quali validatori hanno, bisogna leggere l'HTML. Con il reactive, lo schema è un oggetto TypeScript in memoria — `this.checkoutForm.value` è un'istantanea sincrona del valore corrente, `this.checkoutForm.get('email')` restituisce l'`AbstractControl` con tutta la sua API, i validatori si sostituiscono a runtime con una riga. Per form non triviali, è il giusto livello di controllo.

C'è anche un effetto secondario non ovvio: i `valueChanges` di un `FormControl` / `FormGroup` sono `Observable` (lo stesso flusso lazy della [Scheda 02](./02-observable-rxjs.md)). Su quegli Observable potete mettere `debounceTime`, `switchMap`, `distinctUntilChanged` — e all'improvviso una form reattiva diventa il cardine di una ricerca live, di un autosave, di una validazione asincrona. Con il template-driven non avete questo cavo elettrico.

---

## Le 4 mosse

### 1. Importare `ReactiveFormsModule` nel componente standalone

`ReactiveFormsModule` va negli `imports` del componente che usa la form, non più in un `NgModule` globale:

```typescript
// src/app/pages/checkout/checkout.page.ts — codice reale del seme
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [CurrencyPipe, RouterLink, ReactiveFormsModule],  // ← qui
  templateUrl: './checkout.page.html',
})
```

Se lo dimenticate, in console comparirà `Can't bind to 'formGroup' since it isn't a known property of 'form'`. È l'errore più frequente in assoluto al primo setup di una form reattiva.

### 2. Costruire il `FormGroup` con `FormBuilder`

`FormBuilder` è zucchero sintattico: evita di scrivere `new FormControl('', [Validators.required])` riga per riga e accetta una sintassi a tupla `[valoreIniziale, validatori, validatoriAsincroni]`:

```typescript
// src/app/pages/checkout/checkout.page.ts — codice reale del seme
private fb = inject(FormBuilder);

checkoutForm!: FormGroup;

ngOnInit(): void {
  this.checkoutForm = this.fb.group({
    customerName: ['', Validators.required],
    email:        ['', [Validators.required, Validators.email]],
    address:      ['', [Validators.required, Validators.minLength(10)]],
    notes:        [''],   // opzionale: nessun validator
  });
}
```

Vale la pena distinguere: `Validators.required` è una `ValidatorFn` direttamente; `Validators.minLength(10)` è una **factory** che restituisce una `ValidatorFn`. È la stessa distinzione che useremo fra poco per i validatori custom.

I built-in che incontrate nel seme:

| `ValidatorFn` | Cosa controlla | `ValidationErrors` prodotto |
|---|---|---|
| `Validators.required` | Valore non vuoto/non null | `{ required: true }` |
| `Validators.email` | Stringa con formato email | `{ email: true }` |
| `Validators.minLength(n)` | Lunghezza ≥ n | `{ minlength: { requiredLength: n, actualLength } }` |
| `Validators.min(n)` | Numero ≥ n | `{ min: { min: n, actual } }` |

L'oggetto restituito non è solo un boolean: la chiave (`required`, `email`...) è il **nome dell'errore** che il template potrà rileggere, e il payload contiene le info per costruire un messaggio sensato.

### 3. Binding nel template: `[formGroup]` + `formControlName`

```html
<!-- estratto di src/app/pages/checkout/checkout.page.html -->
<form [formGroup]="checkoutForm" (ngSubmit)="onSubmit()">
  <label>
    Nome
    <input formControlName="customerName" />
  </label>

  <label>
    Email
    <input type="email" formControlName="email" />
  </label>

  @if (isInvalid('email')) {
    <small class="text-red-600">Email non valida.</small>
  }

  <button type="submit" [disabled]="checkoutForm.invalid">Invia ordine</button>
</form>
```

Tre direttive, una responsabilità ciascuna. `[formGroup]` aggancia il `FormGroup` TypeScript al `<form>` HTML. `formControlName` collega ogni `<input>` a una chiave del gruppo (`customerName`, `email`...) — il valore digitato finisce in `checkoutForm.value.customerName`, e i validatori partono in automatico. `(ngSubmit)` emette quando l'utente invia con Enter o con un `<button type="submit">`: è preferibile a `(click)` sul bottone perché copre anche il caso Enter da tastiera.

### 4. Stati del `FormControl` e visualizzazione errori

Ogni `AbstractControl` espone tre coppie di stati:

- `valid` / `invalid` — superato o meno tutti i `ValidatorFn`.
- `touched` / `untouched` — l'utente è entrato nel campo e poi ne è uscito (evento `blur`).
- `dirty` / `pristine` — l'utente ha modificato il valore almeno una volta.

Mostrare l'errore solo su `invalid && touched` è la convenzione del seme: evita di sparare "obbligatorio" appena la pagina si apre, perché in quel momento il campo è invalido (vuoto) ma l'utente non l'ha ancora toccato.

```typescript
// src/app/pages/checkout/checkout.page.ts — codice reale del seme
isInvalid(field: string): boolean {
  const ctrl = this.checkoutForm?.get(field);
  return !!(ctrl?.invalid && ctrl?.touched);
}
```

Per coprire il caso del primo invio (utente che preme submit senza essere mai entrato nei campi), si chiama `markAllAsTouched()` sul `FormGroup` prima di restituire:

```typescript
onSubmit(): void {
  if (this.checkoutForm.invalid) {
    this.checkoutForm.markAllAsTouched();   // tutti i controlli passano a touched
    return;                                  // gli errori diventano visibili
  }
  // ... costruisci e invia l'ordine
}
```

Senza `markAllAsTouched()`, l'utente preme "Invia", non succede niente di visibile, e si chiede perché.

---

## Validatori custom: factory che ritorna una `ValidatorFn`

Quando i built-in non bastano, si scrive una **factory function** che ritorna una `ValidatorFn`. La firma fissa è `(control: AbstractControl) => ValidationErrors | null`: `null` significa "controllo valido", un oggetto significa "invalido" e descrive l'errore.

```typescript
// src/app/validators/product.validators.ts — codice reale del seme
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function forbiddenWordsValidator(forbidden: string[]): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = (control.value ?? '').toLowerCase() as string;
    if (!value) return null;                 // delego a Validators.required l'assenza di valore

    const found = forbidden.find(word => value.includes(word.toLowerCase()));
    if (!found) return null;                 // valido

    return { forbiddenWord: { word: found } }; // invalido — chiave + payload
  };
}
```

Tre dettagli da notare. Primo: la funzione esterna è una **factory** che cattura la lista di parole vietate via closure, e ritorna il vero `ValidatorFn`. Questo permette di riusare lo stesso validatore con liste diverse (`forbiddenWordsValidator(['sconto', 'gratis'])` e `forbiddenWordsValidator(['spam'])`). Secondo: il valore null/empty viene restituito come `null` (valido) per **non duplicare** la responsabilità di `Validators.required` — i validatori vanno componibili, ognuno deve fare la sua parte e basta. Terzo: il payload (`{ word: found }`) si rilegge dal template con `control.getError('forbiddenWord').word`, e permette messaggi specifici tipo *"La parola 'sconto' non è ammessa"* invece di un generico "valore non valido".

Uso nel form prodotto:

```typescript
// src/app/pages/product-form/product-form.page.ts — codice reale del seme
description: ['', [
  Validators.required,
  Validators.minLength(10),
  forbiddenWordsValidator(['sconto', 'gratis', 'offerta', 'promo']),
]],
```

I tre validatori si compongono: tutti devono passare perché il controllo sia `valid`. Se più di uno fallisce, `control.errors` contiene la **prima** chiave che ha fallito secondo l'ordine.

> **Mod 2** estenderà questo pattern in due direzioni: validatori **asincroni** (`AsyncValidatorFn` con `Observable<ValidationErrors | null>` — tipico per check di unicità via HTTP) e **cross-field validation** (validatore registrato sul `FormGroup` invece che sul singolo `FormControl`, per regole tipo "password e conferma password devono coincidere").

---

## Errori comuni

### 1. `ReactiveFormsModule` dimenticato

```typescript
// ❌ Standalone component senza ReactiveFormsModule
@Component({ imports: [], ... })
// → "Can't bind to 'formGroup' since it isn't a known property of 'form'"
```

Va aggiunto in `imports: [ReactiveFormsModule]`. Nel seme è già fatto in `CheckoutPage` e `ProductFormPage` — copiate da lì se siete in dubbio.

### 2. Errore mostrato senza controllare `touched`

```html
<!-- ❌ Errore visibile appena la pagina apre, prima che l'utente faccia nulla -->
@if (form.get('email')?.invalid) {
  <small>Email obbligatoria.</small>
}

<!-- ✅ Solo dopo che il controllo è stato visitato -->
@if (isInvalid('email')) { <small>Email obbligatoria.</small> }
```

Vale anche con `dirty` se preferite "errore solo dopo che l'utente ha digitato qualcosa". `touched` è la scelta più comune perché si attiva anche se il campo viene visitato e lasciato vuoto.

### 3. `reset()` senza valori di default

```typescript
// ❌ reset() svuota tutto → in product-form perderemmo available=true
this.productForm.reset();

// ✅ reset(value) ripristina i default
this.productForm.reset({ available: true });
```

`reset()` non solo cancella i valori ma riporta tutti i controlli a `untouched` e `pristine` — è quello che vogliamo dopo un submit andato a buon fine, ma vanno passati i valori iniziali che NON sono `null`.

### 4. Leggere `value` di una form `invalid`

`checkoutForm.value` restituisce **comunque** un oggetto, anche quando `checkoutForm.invalid` è `true`. Se accidentalmente costruite il payload di submit prima del check di validità, finite per inviare dati incompleti al backend. La guardia in `onSubmit` deve essere sempre la prima istruzione: `if (this.checkoutForm.invalid) { this.checkoutForm.markAllAsTouched(); return; }`.

---

## Schema riassuntivo

```
TypeScript                                          Template
──────────                                          ────────
private fb = inject(FormBuilder);                   <form [formGroup]="checkoutForm"
this.checkoutForm = this.fb.group({                       (ngSubmit)="onSubmit()">
  email: ['', [Validators.required,                   <input formControlName="email" />
                Validators.email]],
  ...                                                 @if (isInvalid('email')) { ... }
});                                                 </form>
   │                                                       │
   │ schema sincrono in memoria                            │ binding bidirezionale
   └───────────────────────────────────────────────────────┘
```

| API | A cosa serve |
|---|---|
| `FormBuilder.group({...})` | Costruisce un `FormGroup` con sintassi compatta |
| `Validators.required / email / minLength` | `ValidatorFn` built-in |
| `(c: AbstractControl) => ValidationErrors \| null` | Firma di un `ValidatorFn` custom |
| `control.valid / invalid / touched / dirty` | Stati osservabili dal template |
| `form.markAllAsTouched()` | Forza il rendering degli errori al primo submit |
| `form.reset(defaults)` | Ripristina stato pulito mantenendo i default |
| `control.valueChanges` | `Observable` del valore — input per Mod 2 (async, debounce) |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/pages/checkout/checkout.page.ts`](../../progetto/product-catalog/src/app/pages/checkout/checkout.page.ts) | `FormBuilder.group(...)` + `Validators.required/email/minLength` + `markAllAsTouched` |
| [`src/app/pages/product-form/product-form.page.ts`](../../progetto/product-catalog/src/app/pages/product-form/product-form.page.ts) | `forbiddenWordsValidator` agganciato + `getFieldError` per messaggi mirati |
| [`src/app/validators/product.validators.ts`](../../progetto/product-catalog/src/app/validators/product.validators.ts) | Factory di `ValidatorFn` con chiave + payload |

---

## Prossimo: [05b — ng-content base](./05b-ngcontent.md)
