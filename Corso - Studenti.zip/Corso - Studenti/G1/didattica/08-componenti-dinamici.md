# 08 — Componenti dinamici (ViewContainerRef + createComponent)

> **Tempo:** ~30 min · **Slide:** TBD · **Blocco:** G1 Sessione 3 · 12:30–13:00 (Mod 1b)

---

## Il problema

Finora tutto quello che abbiamo composto è **statico**: il padre scrive `<app-product-quick-view [product]="p" />` nel suo template, Angular istanzia il componente quando renderizza la view, fine. Funziona perché il padre sa in anticipo *quale* componente serve, *quando* serve e *dove* metterlo.

Solo che in un'applicazione vera ci sono casi in cui questa premessa non regge. Un **overlay di quick-view** che si apre cliccando "Vedi" su una card del catalogo: scrivere `<app-product-quick-view>` nel template della home significa tenerlo lì sempre, anche quando nessuno l'ha aperto. Una **dashboard** che mostra widget diversi a seconda della configurazione dell'utente: il template non sa quale classe componente serve finché non legge la config. Un **plug-in** caricato da una libreria esterna: il componente nemmeno esiste al momento della compilazione.

In tutti e tre i casi l'host deve dire ad Angular *"a un certo punto, in questo posto, voglio montare quel componente"* — non a compile-time, ma a runtime, in risposta a un evento. Per farlo Angular offre due primitive: il `ViewContainerRef` (il *dove*) e il metodo `createComponent` (il *come*). Dal Lab 1 le useremo per la `ProductQuickView` del catalogo.

---

## L'attaccapanni: la metafora che useremo

Pensate al `ViewContainerRef` come a un **attaccapanni** appeso in un punto preciso della stanza (DOM). È fissato lì in modo permanente, fa parte dell'arredamento. Ma di per sé è vuoto: non ha cappotti addosso. I cappotti — i componenti dinamici — li **appendete voi** quando vi servono (`createComponent`), e li **togliete** quando non servono più (`destroy`). Se ne potete appendere uno solo o tanti dipende da come gestite l'attaccapanni: senza disciplina, dopo un mese ne avete venti sovrapposti e nessuno se ne accorge — è il memory leak classico di questo pattern.

Tutta la scheda gira intorno a questa immagine. L'attaccapanni si fissa al muro in due modi (con `inject` o agganciandolo a un `<ng-container>`); si carica con `createComponent`; gli si passano gli input con `setInput`; lo si ascolta con `instance.<output>.subscribe`; lo si svuota con `destroy()` o `clear()`. Tornate alla metafora ogni volta che vi confondete sul lifecycle.

---

## ViewContainerRef: dove pianta il chiodo

Due modi di ottenerlo, e si scelgono in base a *dove* vogliamo che il componente nasca nel DOM.

### (a) `inject(ViewContainerRef)` dentro l'host

```typescript
@Component({ /* ... */ })
export class HomePage {
  private vcr = inject(ViewContainerRef);
  // il componente verrà montato come "sibling" di HomePage nel DOM
}
```

L'attaccapanni nasce nello stesso punto dove vive l'host. Comodo per overlay, toast, notifiche che concettualmente "appartengono" a quella pagina ma non hanno un posto preciso nel suo template.

### (b) `viewChild` con `{ read: ViewContainerRef }` su un'ancora del template

```typescript
@Component({
  selector: 'app-home-page',
  standalone: true,
  template: `
    <div class="grid grid-cols-3 gap-4">
      @for (p of products(); track p.id) {
        <app-product-card [product]="p" (preview)="openQuickView(p)" />
      }
    </div>

    <!-- ancora invisibile: qui pianteremo l'attaccapanni -->
    <ng-container #quickViewAnchor></ng-container>
  `,
})
export class HomePage {
  anchor = viewChild('quickViewAnchor', { read: ViewContainerRef });
}
```

L'`<ng-container>` è una "scatola invisibile": non produce DOM proprio, ma serve da punto di aggancio identificabile. Il `{ read: ViewContainerRef }` è la richiesta esplicita ad Angular: *"non darmi l'`ElementRef`, dammi il container."* Senza quel `read`, ricevereste l'elemento HTML e non sapreste cosa farci.

Nel corso preferiamo questa seconda forma quando il punto di montaggio è significativo per chi legge: vedere `#quickViewAnchor` nel template dice subito *"qui nascerà qualcosa a runtime"*, mentre `inject(ViewContainerRef)` è invisibile finché non aprite il `.ts`.

---

## createComponent: appendere il cappotto

```typescript
import { ProductQuickView } from '../product-quick-view/product-quick-view';

openQuickView(p: Product): void {
  const vcr = this.anchor();
  if (!vcr) return;             // l'attaccapanni non è ancora pronto (è un signal)

  const ref = vcr.createComponent(ProductQuickView);   // appendo il cappotto
  ref.setInput('product', p);                          // gli infilo i dati nelle tasche
}
```

Il valore di ritorno (`ref`) è un `ComponentRef<ProductQuickView>`: è la *gruccia* del cappotto, il riferimento che vi serve per ritrovarlo dopo — per passargli dati, ascoltarlo, distruggerlo. Senza tenere `ref`, il cappotto resta appeso ma voi non sapete più dov'è.

Tre cose da fissare:

| Punto | Dettaglio |
|---|---|
| **Niente `ComponentFactoryResolver`** | Deprecato in Angular 14+. `createComponent(C)` accetta direttamente la classe |
| **Il componente target deve essere standalone** | Angular non saprebbe quale `NgModule` consultare. In Angular 21 standalone è il default, ma se integrate codice legacy controllate |
| **`ref.setInput(name, value)` per gli input** | È la via ufficiale per impostare gli `@Input()` di un componente dinamico: passa per il sistema di change detection di Angular, e funziona con i nuovi `input()` signal allo stesso modo |

Sul terzo punto vale la pena spendere una riga. La tentazione di scrivere `ref.instance.product = p` esiste — funziona, a volte. Il problema è che bypassa il binding di Angular: il componente non riceve la notifica di "input cambiato", il change detection può non scattare al momento giusto, e voi avete una bomba a tempo che esplode quando l'input diventa un oggetto invece di una primitiva. Usate sempre `setInput`.

---

## Ascoltare gli output

Gli `@Output()` (o `output()` signal) sono raggiungibili tramite `ref.instance`:

```typescript
ref.instance.close.subscribe(() => {
  ref.destroy();                              // chiudi → smonta il cappotto
  this.currentQuickView = undefined;
});
```

Notate il dettaglio importante: la subscription su `close` la fa **l'host**, non `ProductQuickView`. Il componente dinamico emette `close` e basta — non sa nemmeno chi lo sta ascoltando, né cosa succederà dopo. È l'host che decide la reazione: distruggere, navigare via, salvare lo stato, fare un'animazione. Stesso disaccoppiamento che vedete fra componente padre e figlio nel mondo statico, solo che qui il collegamento si fa a runtime.

Quando chiamate `ref.destroy()`, Angular completa anche tutti gli `EventEmitter` del componente, e la subscription si chiude da sola — *a patto che* `destroy()` venga chiamato. Se vi dimenticate, la subscription resta viva e tiene in piedi tutto il sottografo del componente in memoria.

---

## Il cleanup: la riga che gli studenti dimenticano

```typescript
ref.destroy();   // toglie quel cappotto (smonta componente + DOM + subscriptions)
// OPPURE
vcr.clear();     // svuota l'attaccapanni (smonta TUTTI i componenti che ci ho appeso)
```

La regola pratica del corso, in tre righe:

1. **Per ogni `createComponent` ci dev'essere un `destroy` o un `clear`**. Non è una raccomandazione: è la condizione perché non vi si accumulino componenti orfani nel DOM e in memoria.
2. Quando l'host viene distrutto, Angular smonta automaticamente tutto quello che era stato appeso al suo `ViewContainerRef` — ma è un paracadute, non una strategia. Se la pagina dell'host vive ore (dashboard, SPA single-page) e l'utente apre la quick-view 50 volte, vi portate dietro 50 componenti tutto il tempo.
3. Se l'attaccapanni ne tiene uno alla volta (è il caso di un modal singleton), chiamate `vcr.clear()` *prima* di `createComponent` e siete sicuri.

Pattern compatto del Lab 1:

```typescript
openQuickView(p: Product): void {
  const vcr = this.anchor();
  if (!vcr) return;
  vcr.clear();                                       // pulizia preventiva
  const ref = vcr.createComponent(ProductQuickView);
  ref.setInput('product', p);
  ref.instance.close.subscribe(() => vcr.clear());   // close → smontaggio
}
```

`vcr.clear()` qui fa doppio servizio: garantisce stato pulito all'apertura, e fa da meccanismo di chiusura senza dover tenere `ref` come property dell'host.

---

## Perché componenti dinamici e non `@if` con un flag boolean

È la domanda giusta. Per un singolo modal "apri/chiudi", in effetti `@if (showQuickView)` funziona — è meno codice, è dichiarativo, lo capisce chiunque.

I componenti dinamici diventano la scelta corretta quando si verifica almeno una di queste condizioni:

- **Il template del padre non sa quale classe componente servirà**. Una dashboard configurabile riceve un array `widgets: ComponentClass[]` e li monta uno a uno: con `@if` dovreste scrivere a mano un caso per ogni possibile widget.
- **Il componente vive "fuori scope"**. Un sistema di toast globale monta i singoli `ToastItem` da un servizio centralizzato (`ToastService`): nessun template di una pagina sa che esistono.
- **Volete pieno controllo sul lifecycle**, indipendente dal template. Un wizard multi-step può smontare il passo precedente nel momento esatto in cui costruisce il successivo, per liberare risorse senza aspettare il prossimo change detection.
- **Caricamento davvero pigro**. Il codice del componente non è nemmeno nel bundle iniziale: arriva con `import()` dinamico solo quando l'utente lo richiede. Con `@if` il componente è nel bundle anche se non viene mai mostrato.

Per la `ProductQuickView` del Lab 1 abbiamo scelto questa strada perché vogliamo l'esercizio sul pattern, e perché in seguito (Mod 5, librerie) lo stesso meccanismo verrà riusato per un sistema di notifiche. Ma — è bene dirlo — in un progetto reale piccolo, `@if` resta la prima scelta, e si passa a `ViewContainerRef` solo quando le condizioni sopra giustificano la complessità in più.

---

## Errori comuni

### 1. Componente target non standalone

```typescript
vcr.createComponent(LegacyComponent);
// Error: The component class is not standalone
```

Angular non sa in quale `NgModule` cercare le dipendenze del componente. **Fix:** aggiungere `standalone: true` (o lasciare il default di Angular 21) e dichiarare i propri `imports`.

### 2. Set diretto su `instance.foo` invece di `setInput`

```typescript
ref.instance.product = p;     // ❌ funziona a volte, bypassa il CD
ref.setInput('product', p);   // ✅ via ufficiale, sempre
```

Discusso sopra: funziona "per fortuna" su primitive, smette di funzionare in modo subdolo quando l'input diventa un oggetto o un signal.

### 3. Niente `destroy`, accumulo silenzioso

Sintomo: aprite la quick-view 30 volte, ogni `console.log` dell'`ngOnInit` continua a comparire a ogni nuovo apri, le chiamate HTTP si moltiplicano, la pagina rallenta. Aprite Performance nei DevTools: contatore dei componenti in salita monotona. **Fix:** `ref.destroy()` o `vcr.clear()` (pattern del Lab 1 sopra).

### 4. `viewChild()` chiamato troppo presto

```typescript
ngOnInit() {
  this.anchor()?.createComponent(...);   // ❌ undefined: la view non è ancora costruita
}
```

`viewChild` è un signal `Signal<T | undefined>` che diventa definito **dopo** la costruzione della view, non in `ngOnInit`. Chiamate `createComponent` dentro un handler utente (`(click)`) — di solito è proprio il caso degli overlay — oppure in `afterNextRender` se serve subito al primo ciclo.

### 5. `ComponentFactoryResolver` ancora in giro

```typescript
const factory = this.cfr.resolveComponentFactory(QuickView); // ❌ deprecated
const ref = this.vcr.createComponent(factory);
```

Funziona ancora, ma è marcato deprecated dal 2022 (Angular 14). Sostituire con `vcr.createComponent(QuickView)` e via.

---

## Il flusso, raccontato

L'utente è sulla home del catalogo. Vede la griglia di `ProductCard`, sotto è piantato un `<ng-container #quickViewAnchor>` invisibile — l'attaccapanni è già al muro, ma non ha cappotti. L'utente clicca "Vedi" su una card: parte l'`@Output() preview` della card, che il padre `HomePage` ha legato al metodo `openQuickView(p)`.

Dentro `openQuickView`, l'host recupera il `ViewContainerRef` dal signal `anchor()`, fa un `clear()` preventivo (l'attaccapanni torna pulito, anche se non c'era nulla), poi chiama `createComponent(ProductQuickView)`: nasce l'istanza, viene appesa al container, il DOM del modal compare. Subito dopo, `setInput('product', p)` passa il prodotto al modal — il template della quick-view si renderizza con i dati giusti. L'host si iscrive al `close` del modal: quando l'utente premerà la X, il `vcr.clear()` smonterà tutto e l'attaccapanni tornerà vuoto, pronto per la prossima apertura.

Quattro righe di codice di handler, una metafora chiara per ricordarsele, e zero `@if` nel template della home. È il pattern che riapplicheremo a notifiche, dialog e widget configurabili per il resto del corso.

---

## ngTemplateOutlet vs componente dinamico

Sembrano alternative, ma rispondono a domande diverse.

| Cosa stai montando? | Strumento |
|---|---|
| Un **template** del padre (parametrizzato sui dati del padre) | `<ng-template>` + `ngTemplateOutlet` ([Scheda 07](./07-ngtemplate-outlet.md)) |
| Un **componente** con la sua classe, il suo stato, i suoi servizi iniettati, il suo change detection | `ViewContainerRef.createComponent` (questa scheda) |

Nel Lab 1: il badge della `ProductCard` accetta un `<ng-template>` (parametrizzato sui dati della card), la quick-view è un **componente** dinamico (stato proprio, chiusura, eventuale lazy-load delle immagini). Strumenti diversi per esigenze diverse.

---

## Schema riassuntivo

```
                 HOST (HomePage)
                 ┌───────────────────────────────────────────────┐
                 │ anchor = viewChild('quickViewAnchor',         │
                 │                    { read: ViewContainerRef });│
                 │                                               │
                 │ openQuickView(p) {                            │
                 │   const vcr = this.anchor();                  │
                 │   if (!vcr) return;                           │
                 │   vcr.clear();                                │
                 │   const ref = vcr.createComponent(ProductQuickView);
                 │   ref.setInput('product', p);                 │
                 │   ref.instance.close.subscribe(               │
                 │     () => vcr.clear());                       │
                 │ }                                             │
                 └───────────────────────────────────────────────┘
                              │
                              ▼ <ng-container #quickViewAnchor>  (l'attaccapanni)
                       ┌─────────────────┐
                       │ ProductQuickView│  ← standalone, @Input product, @Output close
                       └─────────────────┘
```

| Voce | Sintassi chiave |
|---|---|
| Ancora nel template | `<ng-container #anchor></ng-container>` |
| Ottenere il `ViewContainerRef` | `viewChild('anchor', { read: ViewContainerRef })` o `inject(ViewContainerRef)` |
| Creare il componente | `vcr.createComponent(MyStandaloneComp)` |
| Impostare un input | `ref.setInput('nome', valore)` |
| Ascoltare un output | `ref.instance.eventName.subscribe(...)` |
| Distruggere un singolo componente | `ref.destroy()` |
| Svuotare l'attaccapanni | `vcr.clear()` |
| Requisito | il componente target è **standalone** |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| — | Nessun file del seme usa `ViewContainerRef.createComponent`: è la **novità** del Mod 1b. Verrà introdotta nel Lab 1 con `ProductQuickView`. |

---

## Prossimo: [09 — Host Directives](./09-host-directives.md)
