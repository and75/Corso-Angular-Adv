# 05b — ng-content (slot singolo)

> **Tempo:** ~10 min · **Slide:** TBD · **Blocco:** G1 Sessione 1 · 10:39–10:49 (ripasso)

---

## Il problema

Il seme ha un `CardContainer` riusabile: una scatola Tailwind con bordo, ombra, padding standard, e — opzionalmente — un'intestazione colorata. L'host (chi usa la card) decide il `title` come stringa (`@Input()`) e il **contenuto del corpo** come markup arbitrario. La domanda è: *come fa il componente ad accettare markup arbitrario dall'esterno?*

Risposta: **content projection** tramite `<ng-content>`. Oggi vediamo il caso più semplice — uno `<ng-content>` solo, "tutto o niente" — perché è quello che il seme usa e perché è il presupposto per il caso multi-slot del Mod 1a ([Scheda 06](./06-ngcontent-multislot.md)).

---

## Lo sportello unico

`<ng-content>` si comporta come uno **sportello** nel template del componente. Quando il padre annida del markup *dentro* il tag (`<app-card-container>...markup...</app-card-container>`), Angular prende tutto quel markup e lo recapita allo sportello — così com'è, mantenendo l'ordine, conservando il legame con il padre (binding ed event handler restano del consumer).

Per ora di sportelli ne abbiamo uno. Nel Mod 1a li moltiplicheremo, dando a ciascuno un'etichetta CSS via `select="..."`. Ma il meccanismo di fondo è lo stesso: lo sportello vive nel template del figlio, il padre vi spedisce DOM.

```typescript
// src/app/components/card-container/card-container.ts — codice reale del seme
@Component({
  selector: 'app-card-container',
  imports: [],
  templateUrl: './card-container.html',
})
export class CardContainer {
  @Input() title: string = '';
  @Input() variant: 'default' | 'success' | 'warning' | 'info' = 'default';
}
```

```html
<!-- src/app/components/card-container/card-container.html — codice reale del seme -->
<div class="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">

  @if (title) {
    <div [class]="'px-4 py-3 ' + headerClass">
      <h3 class="font-semibold text-sm">{{ title }}</h3>
    </div>
  }

  <div class="p-4">
    <ng-content></ng-content>      <!-- ← lo sportello: prende tutto il DOM proiettato -->
  </div>

</div>
```

Notate la convivenza fra due meccanismi distinti: `title` viaggia come `@Input()` (è un **dato** testuale, finisce in `this.title` e va via interpolazione), il corpo viaggia come `<ng-content>` (è **DOM** proiettato dall'host). Sono due canali diversi sullo stesso componente, ed è normale che si usino insieme.

---

## Uso dal padre

```html
<!-- estratto da HomePage — il consumer della CardContainer -->
<app-card-container title="Catalogo prodotti" variant="info">
  @for (p of filteredProducts; track p.id) {
    <app-product-card [product]="p" (addToCart)="onAddToCart(p)" />
  }
</app-card-container>
```

Cosa fa Angular qui:

| Cosa scrive il padre | Come arriva al figlio |
|---|---|
| `title="..."`, `variant="..."` sul tag | Binding `@Input()`: dati in `this.title` / `this.variant` |
| Il `@for` con le `<app-product-card>` annidate | **DOM proiettato**: Angular lo trasloca nel `<ng-content>` del figlio |

Il dettaglio cruciale, che vale la pena memorizzare subito: il markup proiettato resta "in casa" del padre per quanto riguarda binding ed event handler. L'espressione `[product]="p"` viene risolta nello scope di `HomePage`, e `(addToCart)="onAddToCart(p)"` invoca il metodo di `HomePage`, non di `CardContainer`. Il componente figlio fa da contenitore, non si appropria della logica. È la stessa proprietà che permette di proiettare dentro una card un componente che usa servizi, signals, qualunque cosa — senza che la card debba saperne nulla.

---

## Perché `<ng-content>` e non `@Input() html: string`

La tentazione, vedendo "proietta del markup dentro un componente", è di passare quel markup come stringa via `@Input()` e di iniettarlo con `[innerHTML]`. Si fa? Tecnicamente sì, in pratica **no**, per tre motivi:

1. Il markup non è "vivo": niente binding Angular, niente event handler, niente componenti figli istanziati al suo interno. È testo statico, punto.
2. È un vettore di **XSS** se la stringa proviene da una fonte non controllata. Angular si difende sanificando il contenuto, ma toglierà ciò che serve per il vostro caso (event handler, attributi rischiosi).
3. Perdete il type checking del template: l'IDE non vi avverte se la stringa è malformata, se contiene tag chiusi male, se include selettori inesistenti.

`<ng-content>` proietta **DOM vero**: gli `*ngFor`/`@for` continuano a girare, i `(click)` continuano a chiamare i metodi del padre, i componenti annidati continuano a essere istanziati con tutto il loro lifecycle. È la scelta corretta tutte le volte che il padre vuole comporre una porzione di interfaccia, non solo trasmettere un dato.

---

## Anteprima del Mod 1a

Lo `<ng-content>` singolo va bene finché il componente ha **una sola area variabile**. Per una card con header + body + footer separati, serve il caso **multi-slot**: più `<ng-content>`, ciascuno con un attributo `select="..."` che fa da etichetta CSS, e i nodi del padre vengono smistati allo sportello giusto.

```html
<!-- anteprima — non scriviamo questo oggi -->
<app-fancy-card>
  <h3 header>Catalogo prodotti</h3>     <!-- → <ng-content select="[header]"> -->
  <p>Lista dei 9 prodotti.</p>           <!-- → <ng-content> (default) -->
  <button footer>Aggiorna</button>      <!-- → <ng-content select="[footer]"> -->
</app-fancy-card>
```

Lo trattiamo a fondo nella [Scheda 06](./06-ngcontent-multislot.md), inclusi i fallback (contenuto di default quando lo slot resta vuoto) e l'alternativa `<ng-template>` + `ngTemplateOutlet` ([Scheda 07](./07-ngtemplate-outlet.md)) per i casi in cui il padre deve passare un *template* da renderizzare dentro al figlio, non solo DOM statico.

---

## Errori comuni

### 1. `<ng-content>` confuso con `<ng-template>`

`<ng-content>` si **renderizza sempre** (a parte i casi multi-slot non matchati). `<ng-template>` **non si renderizza** finché qualcuno non lo monta esplicitamente (con `*ngIf`, `ngTemplateOutlet`, una direttiva strutturale). Sono complementari: la card del seme usa `<ng-content>`, in Mod 1 li userete spesso insieme.

### 2. Aspettarsi che il figlio "veda" il markup proiettato

Il `CardContainer` non ha un riferimento al DOM proiettato dall'host — non può iterarlo, contarlo, modificarlo via TypeScript. Se vi serve, dovete usare `@ContentChild` / `@ContentChildren` (Mod 1c), che recupera istanze dei componenti proiettati. Ma è un caso più avanzato, non da scheda di ripasso.

### 3. Aspettarsi che il binding cambi scope

```html
<app-card-container>
  <button (click)="azione()">OK</button>   <!-- azione() è del PADRE, non del figlio -->
</app-card-container>
```

Domanda frequente: *"`azione()` non esiste nel `CardContainer`, devo dichiararla lì?"*. No. Il markup proiettato è del padre, l'evento `(click)` chiama il metodo `azione()` dello stesso componente che ha scritto il `<button>` — cioè il padre. Il figlio non c'entra nulla. Se non vi torna, ripensate al fatto che `<ng-content>` non *copia* il DOM, lo *trasloca* mantenendo il legame con lo scope di origine.

---

## Schema riassuntivo

```
HOST (consumer)                              FIGLIO (CardContainer)
───────────────                              ──────────────────────
<app-card-container title="Cat." variant="info">
  <h3>Body</h3>                              ─── proiezione ──▶  <ng-content/>
  <ul>...</ul>
</app-card-container>
                                             [title, variant: @Input()]
   (binding ed event handler                 [body: DOM proiettato dal padre]
    restano nello scope del padre)
```

| Sintassi | Quando si usa |
|---|---|
| `@Input() x: T` | Passi un **dato** atomico (testo, numero, oggetto immutabile, flag) |
| `<ng-content></ng-content>` | Il padre proietta **DOM/markup** arbitrario |
| `<ng-content select="...">` | Multi-slot — Mod 1a, [Scheda 06](./06-ngcontent-multislot.md) |
| `<ng-template>` + `ngTemplateOutlet` | Il padre passa un **template** renderizzato dal figlio — [Scheda 07](./07-ngtemplate-outlet.md) |
| `@ContentChild`, `@ContentChildren` | Il figlio accede a istanze proiettate via TypeScript (Mod 1c) |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/components/card-container/card-container.ts`](../../progetto/product-catalog/src/app/components/card-container/card-container.ts) | `@Input() title/variant` come dati, niente API di proiezione lato TS |
| [`src/app/components/card-container/card-container.html`](../../progetto/product-catalog/src/app/components/card-container/card-container.html) | `<ng-content>` singolo nel corpo della card |

---

## Prossimo: [Lab 0 — Setup + mini-esercizio](../lab-00/README.md)
