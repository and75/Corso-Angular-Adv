# 07 — ng-template + ngTemplateOutlet

> **Tempo:** ~30 min · **Slide:** TBD · **Blocco:** G1 Sessione 3 · 12:00–12:30 (completamento Mod 1a)

---

## Il problema

La Scheda 06 ci ha dato la projection multi-slot: il padre **spinge** del DOM nel figlio
e il figlio lo "smista" coi selettori. Funziona finché il padre conosce in anticipo *quale*
markup serve in *quale* posto.

Tre limiti rimangono:

- **Stesso markup, montato più volte.** Non si proietta lo stesso `<ng-content>` in due
  punti del template figlio: il nodo viene "consumato" dal primo slot (errore comune n.3
  della Scheda 06).
- **Markup che dipende dai dati interni del figlio.** Il padre vorrebbe scrivere "per
  ogni prodotto della lista del figlio, mostra X" — ma quei prodotti sono dentro al figlio,
  non al padre.
- **Markup parametrico.** Il padre vorrebbe un "ricettario" di template (header, body,
  footer) da richiamare al momento giusto, con parametri.

`<ng-template>` + `ngTemplateOutlet` rispondono a tutti e tre: il padre dichiara un
**frammento di template** con dei "buchi" (le variabili di contesto), il figlio lo
**monta** quando vuole e dove vuole, passandogli i dati che servono.

---

## `<ng-template>` — un frammento che non si renderizza da solo

```html
<!-- Da qualche parte nel template del padre -->
<ng-template #saluto>
  <p class="text-teal-700">Ciao a tutti!</p>
</ng-template>
```

Tre cose da notare:

1. **Non si vede a video.** `<ng-template>` è "spento" finché qualcuno non lo monta. È
   come una funzione: dichiararla non la esegue.
2. **`#saluto`** è una *reference variable* — l'etichetta per richiamarlo nel resto del
   template.
3. **Niente magia con `*ngIf`/`*ngFor` ecc.** Tutte le direttive strutturali in realtà
   creano un `<ng-template>` "implicito" sotto il cofano. `<ng-template>` esplicito è
   quello che ti serve quando vuoi controllo manuale.

---

## `ngTemplateOutlet` — monta il template dove vuoi

Per "accenderlo" si usa la direttiva `*ngTemplateOutlet`, di solito su un
`<ng-container>` (un elemento che non genera DOM proprio):

```html
<ng-template #saluto>
  <p class="text-teal-700">Ciao a tutti!</p>
</ng-template>

<!-- ↓ qui appare il saluto -->
<ng-container *ngTemplateOutlet="saluto"></ng-container>

<!-- ↓ e qui di nuovo — stesso template, montato due volte -->
<ng-container *ngTemplateOutlet="saluto"></ng-container>
```

Il template `#saluto` viene "stampato" in entrambi i punti. **Nessuna duplicazione di
codice**, due render reali. Questo da solo già risolve il primo limite del Mod 1a (stesso
markup, più posti).

---

## Context: passare dati al template

La parte più potente: ogni template può accettare un **oggetto di contesto** e dichiarare
delle variabili che leggono i campi di quel contesto.

```html
<ng-template #riga let-prodotto let-i="indice">
  <li>
    {{ i + 1 }}. <strong>{{ prodotto.name }}</strong> — {{ prodotto.price | currency }}
  </li>
</ng-template>

<ul>
  <ng-container
    *ngTemplateOutlet="riga; context: { $implicit: products[0], indice: 0 }">
  </ng-container>
  <ng-container
    *ngTemplateOutlet="riga; context: { $implicit: products[1], indice: 1 }">
  </ng-container>
</ul>
```

Tre cose da memorizzare:

| Sintassi | Significato |
|---|---|
| `let-prodotto` | dichiara una variabile `prodotto` che legge la chiave **`$implicit`** del contesto |
| `let-i="indice"` | dichiara `i` che legge la chiave **`indice`** del contesto |
| `context: { $implicit: …, indice: … }` | oggetto passato al template per il render |

`$implicit` è una **convenzione**: la chiave "principale" del contesto, quella per cui
basta scrivere `let-prodotto` senza specificare la chiave. Le altre vanno mappate
esplicitamente con `let-i="indice"`.

> Se conosci una direttiva strutturale come `*ngFor`, hai già visto questo pattern:
> `*ngFor="let p of products; let i = index"` è esattamente lo stesso meccanismo.
> `*ngTemplateOutlet` lo rende "manuale".

---

## Da TypeScript: ottenere il `TemplateRef`

Quando un componente deve maneggiare un template dal codice TypeScript, gli serve un
**riferimento tipizzato**: `TemplateRef<TContext>`. Qui c'è una distinzione che genera
confusione e che vale la pena fissare prima del codice — esistono **due scenari**, spesso
scambiati l'uno per l'altro:

| Scenario | Il template è dichiarato… | Strumento |
|---|---|---|
| **(A)** Il padre passa il template al figlio | nel template del **padre** | `@Input() tpl?: TemplateRef<T>` |
| **(B)** Il componente vuole il ref di un template proprio | nel template del **componente stesso** | `viewChild()` / `@ViewChild` |

Sono **complementari**, non alternativi: lo stesso componente può usare entrambi (un
default interno + un override esterno). Li vediamo uno alla volta con esempi padre→figlio
espliciti.

### Scenario A — il padre passa il template via `@Input()`

È il pattern che applicheremo nel **Lab 1** sulla `ProductCard`. Il **padre** dichiara il
template (lo "spegne" con `<ng-template>`) e lo passa al **figlio** come Input; il figlio
lo monta dove e quando vuole con `*ngTemplateOutlet`.

```html
<!-- PADRE — pages/products.html -->
<!-- 1) dichiara il template (dormiente) e gli dà la reference #badgeTpl -->
<ng-template #badgeTpl let-p>
  <span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800">
    ★ {{ p.name }}
  </span>
</ng-template>

<!-- 2) lo passa al figlio come @Input() — niente "viewChild" qui:
        la #badgeTpl è già visibile in tutto il template del padre,
        si binda direttamente con [badgeTemplate]="badgeTpl" -->
@for (p of products(); track p.id) {
  <app-product-card [product]="p" [badgeTemplate]="badgeTpl"></app-product-card>
}
```

```typescript
// FIGLIO — components/product-card/product-card.ts
@Component({
  selector: 'app-product-card',
  imports: [NgTemplateOutlet],
  template: `
    <div class="rounded-xl shadow border p-4">
      <!-- monta il template ricevuto dal padre, passando 'product' come $implicit -->
      <ng-container
        *ngTemplateOutlet="badgeTemplate; context: { $implicit: product }">
      </ng-container>
      <h3>{{ product.name }}</h3>
      <p>{{ product.price | currency }}</p>
    </div>
  `,
})
export class ProductCard {
  @Input({ required: true }) product!: Product;
  @Input() badgeTemplate?: TemplateRef<Product>;   // ← TemplateRef tipizzato
}
```

Tre cose da fissare:

1. La `#badgeTpl` è una **reference variable**: nel template del padre è già visibile
   ovunque, basta bindarla con `[badgeTemplate]="badgeTpl"`. **Non serve `viewChild` qui**
   — è un equivoco frequente.
2. Il figlio riceve un `TemplateRef<Product>` **tipizzato** (non `any`): dentro al
   template del padre, `let-p` viene inferito come `Product`.
3. Se l'host non passa nulla, `badgeTemplate` resta `undefined`. `*ngTemplateOutlet`
   con valore `undefined` semplicemente **non monta nulla**, senza errore. Per un
   fallback "vero" si combina con lo Scenario B (vedi sotto).

### Scenario B — `viewChild()`: il componente interroga il proprio template

`viewChild()` è una **query**: una funzione che il componente esegue **sul proprio
template** per ottenere un riferimento a qualcosa che ha dichiarato lì dentro. Non è
specifica dei template — restituisce, nella forma signal, uno qualsiasi tra:

- un **componente figlio**: `viewChild(Toolbar)` o `viewChild<Toolbar>('bar')`
- un **elemento DOM**: `viewChild<ElementRef>('myInput')`
- un **`<ng-template>` interno**: `viewChild<TemplateRef<…>>('tpl')`

#### Esempio "didascalico" padre→figlio: il padre chiama un metodo del figlio

Prima di applicarlo ai template, vediamo il caso più scolastico di `viewChild`. Un
componente padre vuole chiamare dal suo TypeScript un **metodo pubblico** di un componente
figlio:

```typescript
// PADRE — pages/products-page.ts
@Component({
  selector: 'app-products-page',
  imports: [Toolbar],
  template: `
    <!-- ↓ #bar è la reference variable: l'etichetta che viewChild andrà a cercare -->
    <app-toolbar #bar title="Catalogo"></app-toolbar>
    <button (click)="refresh()">Aggiorna</button>
  `,
})
export class ProductsPage {
  // ✅ riferimento all'istanza di <app-toolbar #bar> nel mio template
  bar = viewChild<Toolbar>('bar');

  refresh() {
    // posso chiamare un metodo pubblico del figlio dal codice del padre
    this.bar()?.showSpinner();
  }
}
```

Quattro cose da memorizzare su `viewChild()`:

| Aspetto | Come funziona |
|---|---|
| Cosa cerca | qualcosa nel **proprio template** del componente |
| Come lo cerca | per reference variable (`'bar'`) o per **tipo** (`Toolbar`, `ElementRef`, `TemplateRef`) |
| Cosa restituisce | un **signal**: prima del render → `undefined`; dopo → l'istanza/`ref`. Per questo lo si invoca con le parentesi: `this.bar()` |
| Quando NON usarlo | per ricevere qualcosa **dal padre** (lì serve `@Input()`); per ciò che il padre proietta con `<ng-content>` (lì serve `contentChild`, Mod 2) |

#### Applicato al `TemplateRef`: un default interno come fallback

Combinando A e B otteniamo una `ProductCard` con **template di default interno** + **override
esterno** dal padre — il pattern completo che useremo nel Lab 1:

```typescript
@Component({
  selector: 'app-product-card',
  imports: [NgTemplateOutlet],
  template: `
    <!-- ↓ template di default, dichiarato DENTRO al figlio -->
    <ng-template #defaultBadge let-p>
      <span class="px-2 py-0.5 rounded bg-gray-100 text-gray-500">
        {{ p.category }}
      </span>
    </ng-template>

    <div class="rounded-xl shadow border p-4">
      <!-- override del padre se c'è, altrimenti default interno -->
      <ng-container
        *ngTemplateOutlet="badgeTemplate ?? defaultBadge();
                           context: { $implicit: product }">
      </ng-container>
      <h3>{{ product.name }}</h3>
    </div>
  `,
})
export class ProductCard {
  @Input({ required: true }) product!: Product;
  @Input() badgeTemplate?: TemplateRef<Product>;                  // ← dal padre (Scenario A)
  defaultBadge = viewChild<TemplateRef<Product>>('defaultBadge'); // ← proprio template (Scenario B)
}
```

Il pattern `badgeTemplate ?? defaultBadge()` tenta prima l'override del padre (l'`@Input()`);
se è `undefined`, invoca il signal del default interno. Notare la differenza di sintassi:
`badgeTemplate` è un campo "normale" (decoratore), `defaultBadge()` è un signal — la
coppia parentesi non è opzionale.

### Variante con decoratore: `@ViewChild`

```typescript
@ViewChild('defaultBadge', { static: false })
defaultBadge!: TemplateRef<Product>;
```

Le due forme sono equivalenti per il caso d'uso del template ref. Nel corso preferiamo
`viewChild()` perché si integra con i signal e non richiede `static: true/false`
(domanda ricorrente in aula su `@ViewChild`).

---

## Stesso problema, due strumenti: `<ng-content>` vs `<ng-template>`

Quando si sovrappongono? Mai del tutto: hanno scopi diversi.

| Scenario | Soluzione |
|---|---|
| Il padre passa **DOM statico** che il figlio inserisce in punti predefiniti | `<ng-content select="...">` (Scheda 06) |
| Il padre passa **markup parametrico**, da renderizzare 0/1/N volte con dati che il figlio conosce | `<ng-template>` + `ngTemplateOutlet` |
| Il padre passa **dati semplici** (testo, numero, booleano) | `@Input()` |
| Il figlio dichiara un template e lo monta in più punti del suo stesso template | `<ng-template>` interno + `ngTemplateOutlet` |

Esempio concreto del corso (anteprima del **Lab 1**): la `ProductCard` accetta un
`@Input() badgeTemplate?: TemplateRef<Product>` opzionale. Se l'host glielo passa, la
card lo monta con il prodotto come `$implicit`; se non glielo passa, mostra un badge di
default. Il vantaggio: **lo stesso markup di badge** può essere usato dall'host in 30
schede prodotto, parametrizzato sui dati di ognuna.

---

## Errori comuni

### 1. Dimenticare `NgTemplateOutlet` negli `imports`

```typescript
// ❌ standalone component senza NgTemplateOutlet → "Can't bind to 'ngTemplateOutlet' since it isn't a known property of 'ng-container'"
@Component({ imports: [], template: '...' })
```

`*ngTemplateOutlet` non è control flow built-in (non è `@if`/`@for`): vive in
`@angular/common`. Aggiungilo:

```typescript
import { NgTemplateOutlet } from '@angular/common';
@Component({ imports: [NgTemplateOutlet], ... })
```

### 2. Dimenticare l'asterisco `*`

```html
<!-- ❌ non funziona: ngTemplateOutlet senza asterisco viene letto come "proprietà ngTemplateOutlet su un div" -->
<div ngTemplateOutlet="tpl"></div>

<!-- ✅ asterisco = direttiva strutturale -->
<ng-container *ngTemplateOutlet="tpl"></ng-container>
```

Forma alternativa esplicita (raramente usata): `<ng-template [ngTemplateOutlet]="tpl">`.

### 3. Context con chiavi sbagliate

```html
<ng-template #riga let-prodotto>...</ng-template>

<ng-container *ngTemplateOutlet="riga; context: { item: p }"></ng-container>
                                       <!-- ❌ chiave "item", ma let-prodotto cerca $implicit -->
```

A runtime: nessun errore, `prodotto` resta `undefined`. La griglia si mostra ma con
campi vuoti.

**Fix:** allinea le chiavi: `context: { $implicit: p }` per le variabili dichiarate con
`let-x` senza chiave, e nome esplicito per le altre (`context: { $implicit: p, indice: i }`).

### 4. Usare `<ng-template>` quando bastava `@if`

```html
<!-- ❌ Sovra-ingegneria: un placeholder banale -->
<ng-template #vuoto><p>Nessun prodotto.</p></ng-template>
<ng-container *ngTemplateOutlet="products.length === 0 ? vuoto : null"></ng-container>

<!-- ✅ Control flow built-in -->
@if (products.length === 0) {
  <p>Nessun prodotto.</p>
}
```

Lo strumento giusto per "mostra A oppure B in funzione di una condizione" è il control
flow integrato. `<ng-template>` + `ngTemplateOutlet` brillano quando lo **stesso**
template va montato in più punti o quando il template è **passato dall'esterno**.

---

## Schema riassuntivo

```
                  PADRE
                  ┌─────────────────────────────────────┐
                  │ <ng-template #riga                  │
                  │   let-p let-i="idx">                │  ← template "dormiente"
                  │   {{ i+1 }}. {{ p.name }}           │
                  │ </ng-template>                      │
                  │                                     │
                  │ <ng-container *ngTemplateOutlet=    │  ← monta + passa context
                  │   "riga;                            │
                  │    context: { $implicit: p, idx:i}" │
                  │ />                                  │
                  └─────────────────────────────────────┘
                                  │
                                  │ "stampa" il template
                                  ▼
                       1. Carrello — Tazza  €5
```

| Voce | Sintassi chiave |
|---|---|
| Dichiarare un template | `<ng-template #ref> ... </ng-template>` |
| Variabile di contesto principale | `let-p` (legge `$implicit`) |
| Variabile di contesto secondaria | `let-i="indice"` |
| Montare il template | `<ng-container *ngTemplateOutlet="ref">` |
| Montare con dati | `*ngTemplateOutlet="ref; context: { $implicit: p, indice: i }"` |
| Ottenere il TemplateRef da TS | `viewChild<TemplateRef<any>>('ref')` |
| Import necessario | `NgTemplateOutlet` da `@angular/common` |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/components/card-container/card-container.ts`](../../progetto/product-catalog/src/app/components/card-container/card-container.ts) | Il punto di partenza concettuale: un componente con `<ng-content>` singolo che, nel Lab 1, evolveremo aggiungendo anche un `<ng-template>` passato dall'host |

> Nessun altro file del seme usa `ngTemplateOutlet` direttamente: è la **novità** che
> introduciamo in Mod 1a e applicheremo nel Lab 1 alla `ProductCard`.

---

## Prossimo: [08 — Componenti dinamici (ViewContainerRef + createComponent)](./08-componenti-dinamici.md)
