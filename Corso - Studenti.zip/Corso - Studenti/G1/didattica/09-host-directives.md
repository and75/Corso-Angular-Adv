# 09 — Host Directives

> **Tempo:** ~30 min · **Slide:** TBD · **Blocco:** G1 Sessione 4 · 14:00–14:30 (completamento Mod 1b)

---

## Ripasso: cos'è una attribute directive

Prima di parlare di host directives serve avere ben chiaro cos'è una **direttiva**, perché è il mattone su cui costruisce tutto il resto. Una direttiva è una classe annotata con `@Directive` che — invece di portarsi dietro un proprio template come fa un componente — *aggiunge comportamento* a un elemento già esistente nel DOM. L'host che la scrive non vede nulla di nuovo a video; vede però l'elemento *reagire diversamente* (cambiare stile al passaggio del mouse, intercettare un click, applicare un focus ring, abilitare il drag, ecc.).

Nel seme del corso base c'è un esempio canonico: la `HighlightDirective`, che disegna un outline colorato attorno all'elemento al passaggio del mouse e lo rimuove all'uscita. È un attribute directive — perché la si applica come fosse un attributo HTML — ed è proprio il punto di partenza che useremo oggi per arrivare alle host directives.

```typescript
// src/app/directives/highlight.ts — codice reale del seme
import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighlight]',   // selettore di attributo: si attiva su [appHighlight]
  standalone: true,             // niente NgModule: si "importa" come un componente
})
export class HighlightDirective {
  @Input() highlightColor: string = 'teal';   // pomello regolabile del comportamento

  private originalOutline: string = '';        // memorizzo per ripristinare al mouseleave

  constructor(private el: ElementRef) {}       // ElementRef: il "manico" del nodo DOM

  @HostListener('mouseenter') onMouseEnter() {
    this.originalOutline = this.el.nativeElement.style.outline;
    this.el.nativeElement.style.outline = `0 0 0 2px ${this.highlightColor}`;
    this.el.nativeElement.style.transition = 'box-shadow 0.4s ease';
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.el.nativeElement.style.outline = this.originalOutline;
  }
}
```

Tre cose vale la pena fissare, perché torneranno per il resto della scheda. Primo: il **selettore** `[appHighlight]` è un attribute selector CSS — funziona esattamente come quelli che abbiamo visto per `<ng-content select="...">`, e si attiva su qualsiasi nodo che porta quell'attributo. Secondo: `ElementRef` iniettato nel costruttore è il "manico" che permette alla direttiva di parlare col nodo DOM su cui è stata applicata (`el.nativeElement` è l'elemento HTML vero). Terzo: `@HostListener` aggancia un metodo della direttiva a un evento DOM dell'elemento host — niente `addEventListener` a mano, niente cleanup da gestire (al `destroy` della direttiva Angular stacca il listener da solo).

Per usarla nel template, l'host la scrive come un attributo qualsiasi, eventualmente con il valore dell'input:

```html
<div appHighlight highlightColor="emerald">
  <h3>Pasta artigianale</h3>
  <p>100% grano italiano.</p>
</div>
```

Da fuori sembra un attributo HTML inventato. Sotto il cofano è una classe TypeScript istanziata da Angular per quel nodo, con il suo lifecycle (`ngOnInit`, `ngOnDestroy`), i suoi input, i suoi listener. È un componente "senza template" — ed è esattamente il blocco che le host directives di cui parliamo oggi vanno a riusare in modo più elegante.

---

## Il problema

La `HighlightDirective` del seme funziona perfettamente, ma per usarla il consumer deve attaccarla al tag, ogni volta:

```html
<div appHighlight highlightColor="teal">…</div>
<div appHighlight highlightColor="teal">…</div>
<div appHighlight highlightColor="teal">…</div>
```

Va benissimo finché l'evidenziazione è un effetto **occasionale**, che chi scrive il template decide caso per caso. Diventa un problema quando il comportamento è invece **parte dell'identità** di un componente: la `ProductCard` del catalogo deve *sempre* evidenziarsi al passaggio del mouse, *sempre* con lo stesso colore, *sempre* col focus-ring per l'accessibilità. Delegare al consumer questo dettaglio significa tre cose, tutte sgradevoli: l'API del componente si raddoppia (gli input della card più quelli della direttiva), basta una distrazione e una card "nuova" nasce senza highlight (regressione silenziosa), e il template del consumer si riempie di rumore che non racconta niente del dominio.

La soluzione storica era l'**ereditarietà**: `class HighlightingCard extends ProductCard implements Highlightable`. Funziona ma porta tutti i mali noti dell'ereditarietà — gerarchie rigide, override impliciti, costruttori incatenati, refactoring complicati. Da Angular 15 c'è un meccanismo migliore: le **host directives**. La card dichiara che ospita la `HighlightDirective` come parte di sé, e il consumer non se ne accorge nemmeno. È composizione, non ereditarietà.

---

## Di serie vs aftermarket: la metafora che useremo

Pensate alla `HighlightDirective` come a un **accessorio per auto**. Il consumer può comprare la card "base" e poi montarsi l'accessorio in officina (la attribute directive classica, attaccata al tag), oppure può comprare la card "premium" che ha già l'accessorio **di serie**, montato in fabbrica (la host directive). Per chi guida — il consumer del componente — la seconda è più comoda: si sale in macchina e tutto funziona, senza dover sapere niente di accessori. Il prezzo da pagare è la flessibilità: l'accessorio di serie c'è e basta, non lo togli scegliendo di non montarlo.

Tutta la scheda gira intorno a questa metafora. Esporre gli input = lasciare il pomello regolabile sul cruscotto, anche se la dotazione è di serie. Più host directives = il pacchetto "Premium" con più optional di fabbrica. Quando preferire l'attribute directive classica = quando l'accessorio serve solo a una piccola minoranza dei consumer.

---

## Sintassi base

```typescript
import { Component } from '@angular/core';
import { HighlightDirective } from '../../directives/highlight';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [/* ... */],
  hostDirectives: [HighlightDirective],   // ← di serie
  templateUrl: './product-card.html',
})
export class ProductCard { /* ... */ }
```

Da questo momento, ogni volta che un `<app-product-card>` compare in un template, Angular monta automaticamente anche una `HighlightDirective` sull'host del componente. Il consumer non scrive nulla:

```html
<!-- Quello che il consumer scrive: -->
<app-product-card [product]="p" />

<!-- Quello che Angular istanzia (invisibile al consumer): -->
<!-- <app-product-card [product]="p" appHighlight> -->
```

Vincolo formale, non negoziabile: la direttiva citata in `hostDirectives` deve essere `standalone: true`. Angular non saprebbe in quale `NgModule` cercare le sue dipendenze. Nel seme `HighlightDirective` lo è già — l'abbiamo vista nella [Scheda 01](./01-standalone-di-inject.md). In Angular 21 standalone è il default, ma se integrate codice legacy controllate.

---

## Esporre input e output

Spesso vogliamo che il consumer continui a controllare *qualcosa* della direttiva — il colore dell'outline, per esempio — senza dover sapere che lì sotto vive una host directive. Si dichiara la forma estesa con `inputs` e `outputs`:

```typescript
@Component({
  selector: 'app-product-card',
  standalone: true,
  hostDirectives: [{
    directive: HighlightDirective,
    inputs: ['highlightColor'],     // pomello regolabile esposto
    outputs: [],
  }],
})
export class ProductCard { /* ... */ }
```

```html
<app-product-card [product]="p" highlightColor="emerald" />
```

Per il consumer, `highlightColor` è indistinguibile da un `@Input()` del `ProductCard`. Tecnicamente è un **alias**: la card non gestisce l'input, lo gira così com'è alla direttiva ospitata. Il punto chiave da tenere a mente è la **direzione del controllo**: il consumer parla con la card, la card parla con la direttiva. La direttiva resta un dettaglio interno — il consumer non sa nemmeno che esiste, e va bene così.

### Rinominare in fase di esposizione

A volte il nome dell'input della direttiva è "tecnico" e non si sposa con l'API del componente. Si rinomina al volo:

```typescript
hostDirectives: [{
  directive: HighlightDirective,
  inputs: ['highlightColor: hoverColor'],   // direttiva.highlightColor → host.hoverColor
}]
```

```html
<app-product-card [product]="p" hoverColor="emerald" />
```

Stessa sintassi per `outputs`: `outputs: ['nameInternal: nameExposed']`. Il rename è quello che permette al componente di tenere un'API pulita e coerente anche quando le direttive che ospita arrivano da una libreria con nomenclatura diversa.

> **Cosa NON è esposto**: se non lo elencate in `inputs`/`outputs`, il consumer non vede l'input/output della direttiva. Per chi guarda il template è completamente invisibile — è una *feature* decisa dal componente, non un valore di default che si possa sovrascrivere. Il pomello, semplicemente, non c'è sul cruscotto.

---

## Perché host directive e non ereditarietà

È la domanda giusta. `class FancyCard extends ProductCard` funziona, è familiare a chiunque venga da Java o C#, e raggiunge un risultato simile: la `FancyCard` ha tutto quello che ha `ProductCard` più qualcosa in più. Perché non così?

Tre motivi pratici, in ordine di peso:

- **L'ereditarietà è verticale, le host directives sono orizzontali**. Con `extends` aggiungete *un solo* comportamento per livello, e se ne servono tre la gerarchia esplode (`PremiumFancyHighlightedCard extends FancyHighlightedCard extends HighlightedCard extends Card`). Con `hostDirectives: [A, B, C]` ne componete N in una riga.
- **Niente costruttori da incatenare**. Con `extends` ogni livello deve chiamare `super(...)` con gli argomenti giusti, e Angular ha le sue regole su quando un costruttore è "stabile". Con le host directives ogni direttiva ha il suo lifecycle indipendente — Angular le inizializza tutte come direttive separate sull'host.
- **Il refactoring è locale**. Spostare un comportamento da "di serie" a "aftermarket" significa cancellare una riga in `hostDirectives` e attaccare la direttiva nei template che ne hanno ancora bisogno. Con `extends` significa toccare la gerarchia, e in genere si trascina dietro modifiche in cascata.

Vale anche la nota generale che vale per OOP in Angular: il framework spinge su *composition over inheritance* in tutto il suo design (servizi iniettati, signals, content projection, host directives), e andare controcorrente significa scrivere codice che funziona ma legge male a chi è abituato al resto dell'ecosistema.

---

## DI condivisa

L'host directive condivide l'**injector** del componente che la ospita. Concretamente: la direttiva può iniettare qualsiasi cosa il componente sia in grado di vedere — i servizi `providedIn: 'root'`, ma anche gli eventuali `providers` locali del componente. E viceversa, il componente può iniettare l'istanza della direttiva con `inject(HighlightDirective)` se gli serve coordinarsi, anche se nella pratica è raro e di solito è meglio passare via input.

Caso concreto del corso: una `FocusRingDirective` che usa `inject(AccessibilityService)` per leggere la preferenza utente "ridotto movimento" e disattivare l'animazione del ring. La direttiva non sa nulla del componente che la ospita; il componente non sa nulla del servizio di accessibilità. È composizione pulita su tre livelli — esattamente lo stile che il pattern incoraggia.

---

## Più host directives

`hostDirectives` accetta un array. Esempio realistico per una `ProductCard` "premium":

```typescript
hostDirectives: [
  { directive: HighlightDirective, inputs: ['highlightColor: hoverColor'] },
  { directive: FocusRingDirective },
  { directive: AnalyticsClickDirective, outputs: ['fired: tracked'] },
]
```

L'ordine dell'array determina l'ordine di inizializzazione. Non è quasi mai un problema, ma vale la pena ricordarlo per quel caso raro in cui una direttiva legge lo stato lasciato da un'altra al `ngOnInit`. Tre direttive di serie, ognuna con la sua API, tutte invisibili al consumer salvo gli input/output esposti.

---

## Aftermarket vs di serie, lato consumer

Mettendole a confronto si vede meglio quando l'una vince sull'altra.

### (A) Attribute directive classica — il consumer la attacca

```html
<div appHighlight highlightColor="teal">
  <app-product-card [product]="p" />
</div>
```

Pro: granulare, applicabile a qualsiasi elemento, il consumer ha visibilità totale di cosa sta succedendo. Contro: ripetizione, regressioni silenziose, API duplicata.

### (B) Host directive — il componente la incorpora

```html
<app-product-card [product]="p" hoverColor="teal" />
```

Pro: il comportamento è incorporato, il consumer scrive meno, l'API esposta è una sola — quella del componente. Contro: il consumer non può **togliere** la direttiva, può solo (se l'input è esposto) neutralizzarla via valore (es. `hoverColor="transparent"`).

La regola del corso, da memorizzare: se la direttiva esprime un'**identità** del componente (focus ring di accessibilità, tracking delle interazioni, drag handle che è parte del componente), passate a host directive. Se è un effetto che il consumer applica selettivamente solo in certe pagine, lasciatela attribute directive classica.

---

## Errori comuni

### 1. Direttiva non standalone

```typescript
@Directive({ selector: '[appHighlight]' /* manca standalone: true */ })
export class HighlightDirective { /* ... */ }

@Component({ hostDirectives: [HighlightDirective] })  // ❌ NG3001
```

Errore esplicito: `Host directives must be standalone`. **Fix:** `standalone: true` sulla direttiva. In Angular 21 è il default — se vedete l'errore, di solito è codice legacy migrato.

### 2. Input non esposto, consumer ci scrive sopra

```typescript
hostDirectives: [{ directive: HighlightDirective /* niente inputs */ }]
```

```html
<app-product-card highlightColor="emerald" />  <!-- ❌ ignorato, niente warning -->
```

L'input esiste sulla direttiva ma non è esposto sul componente: Angular non lo riconosce come `@Input()` di `ProductCard`. Il binding sembra valido in TypeScript ma a runtime non passa nulla — il pomello sul cruscotto semplicemente non è cablato a niente. **Fix:** elencare l'input in `inputs: ['highlightColor']`.

### 3. Applicare host directive anche a una direttiva

```typescript
@Directive({
  selector: '[appDraggable]',
  standalone: true,
  hostDirectives: [HighlightDirective],   // ✅ valido
})
export class DraggableDirective { /* ... */ }
```

Non è un errore, è una cosa che molti studenti non sanno: `hostDirectives` è un metadato che funziona sia su `@Component` sia su `@Directive`. Permette composizione fra direttive (una direttiva "drag" che riusa una direttiva "highlight" per il feedback visivo). Composizione pura, nessuna gerarchia.

### 4. Selettori che si scontrano

Se la host directive ha un selettore che il consumer scrive anche a mano, si creano due istanze:

```html
<app-product-card [product]="p" appHighlight>
  <!-- ❌ una istanza dalla host directive, una dall'attributo: doppia attivazione -->
</app-product-card>
```

**Fix:** se la direttiva è ormai "di serie" sul componente, non scriverla a mano nei template. Se proprio serve l'overlap (caso raro), usare selettori distinti per i due ruoli.

### 5. Import della classe dimenticato

`hostDirectives: [HighlightDirective]` richiede comunque l'`import` della classe in TypeScript. Errore banale ma frequente quando l'auto-import dell'IDE non scatta — l'array diventa `[undefined]` e Angular si arrabbia in modo poco esplicito.

---

## Quando NON usare host directives

Tre casi in cui restare con l'attribute directive classica è la scelta giusta:

- **Il comportamento è opzionale per il consumer.** Se nove card su dieci non devono evidenziarsi, "esporre l'highlight di serie e lasciarlo spento per default" è sovra-ingegneria. Lasciate che chi vuole l'highlight attacchi la direttiva a mano.
- **La direttiva manipola la struttura del DOM** (è strutturale, o riscrive pesantemente il template). Le host directives sono pensate per comportamenti sull'elemento host, non per riscrivere il rendering.
- **Codice legacy che non potete rendere standalone.** Finché la direttiva sta dietro un `NgModule` non standalone, resta accessorio aftermarket — finché non la migrate.

---

## Il flusso, raccontato

L'utente apre la home del catalogo. Angular monta `HomePage`, e per ogni prodotto istanzia una `<app-product-card>`. Per ognuna, oltre alla classe `ProductCard`, Angular costruisce in automatico anche una `HighlightDirective` agganciata allo stesso nodo host — è quello che `hostDirectives: [HighlightDirective]` gli dice di fare. Le due istanze condividono lo stesso injector, lo stesso elemento DOM, lo stesso lifecycle: quando la card viene distrutta, la direttiva viene distrutta con lei.

L'utente passa il mouse su una card. La `HighlightDirective` ha registrato un listener `@HostListener('mouseenter')` (o l'equivalente con renderer): scatta il listener, disegna l'outline, aspetta il `mouseleave`. Il consumer ha scritto `hoverColor="emerald"` nel template: quel valore è arrivato — via alias — all'input `highlightColor` della direttiva, e l'outline esce verde smeraldo.

Nel template della home non c'è scritto nulla di tutto questo. Solo `<app-product-card [product]="p" hoverColor="emerald" />`. La card è venuta "di serie" con l'highlight, e da fuori sembra una sola cosa. Quando un domani la card "premium" del Lab 5 avrà anche focus ring di accessibilità e tracking delle interazioni, aggiungeremo due righe a `hostDirectives` e il template del consumer non cambierà di una virgola.

---

## Schema riassuntivo

```
  PRIMA (accessorio aftermarket)            DOPO (dotazione di serie)
  ─────────────────────────────             ─────────────────────────
  <app-product-card appHighlight            @Component({
    highlightColor="teal" />                  selector: 'app-product-card',
                                              hostDirectives: [{
  • Il consumer deve ricordarsi.              directive: HighlightDirective,
  • L'API si raddoppia.                       inputs: ['highlightColor: hoverColor'],
  • Regressioni silenziose se                }],
    si dimentica.                           })

                                            <app-product-card hoverColor="teal" />

                                             • Comportamento incorporato.
                                             • Una sola API (quella del componente).
                                             • Niente regressioni: c'è sempre.
```

| Voce | Sintassi chiave |
|---|---|
| Forma semplice | `hostDirectives: [HighlightDirective]` |
| Forma estesa | `hostDirectives: [{ directive, inputs: [...], outputs: [...] }]` |
| Esporre input col nome originale | `inputs: ['highlightColor']` |
| Esporre input col rename | `inputs: ['highlightColor: hoverColor']` |
| Vincolo | la direttiva deve essere `standalone: true` |
| DI condivisa | stesso injector → la direttiva vede i provider del componente |
| Errore tipico | `NG3001` — direttiva non standalone |

### File reali nel seme da citare in aula

| File | Cosa mostra |
|---|---|
| [`src/app/directives/highlight.ts`](../../progetto/product-catalog/src/app/directives/highlight.ts) | Attribute directive già `standalone: true` — candidata perfetta per essere "promossa" a host directive di `ProductCard` |
| [`src/app/components/product-card/product-card.ts`](../../progetto/product-catalog/src/app/components/product-card/product-card.ts) | Possibile host: oggi non usa `HighlightDirective` né direttamente né come host directive |

> Nessun componente del seme usa ancora `hostDirectives`: è il pattern nuovo che introduciamo qui. La promozione di `HighlightDirective` a host directive di `ProductCard` può essere uno degli step del Lab 1 (opzionale o **DIFFICILE**) se il tempo lo permette.

---

## Prossimo: [10 — Integrare una libreria legacy con NgZone](./10-legacy-ngzone.md)
