# Lab 2b — NotificationService con BehaviorSubject (+ bonus signal)
### Giorno 1 · Lab guidato (~22 min)

---

## Obiettivo

Applicare il pattern della [Scheda 11 — Subject / BehaviorSubject](../didattica/11-subject-behaviorsubject.md) costruendo un sistema di notifiche toast condiviso tra componenti scollegati. Poi, come bonus, riscriverlo con i signal — applicando la [Scheda 12](../didattica/12-signal.md) sullo stesso scenario, per *toccare con mano* il confronto.

Tre componenti:

1. **`NotificationService`** — servizio singleton che pubblica una lista di toast tramite `BehaviorSubject<Notification[]>`, esposta read-only come `Observable`.
2. **`Toast`** — componente standalone che consuma `notifications$` con `takeUntilDestroyed` e mostra i messaggi attivi.
3. **Auto-dismiss** — i toast spariscono da soli dopo N secondi, con `setTimeout` registrato fuori zone per non scatenare CD.

**Bonus DIFFICILE:** riscrittura del `NotificationService` + `Toast` con `signal()` / `effect()` / `computed()`. Niente `BehaviorSubject`, niente `subscribe`, niente `takeUntilDestroyed`. Vedi sezione finale.

Risultato visivo: in basso a destra appare uno stack di toast quando un componente chiama `notificationService.success(...)`, `error(...)`, `info(...)`. Cliccando ✕ scompaiono subito; senza interazione, scompaiono da soli dopo 4 secondi.

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/services/notification.service.ts` | Servizio toast con `BehaviorSubject` | **nuovo** |
| `src/app/components/toast/toast.ts` + `.html` | Consumer dei toast | **nuovo** |
| `src/app/app.html` | Aggiunge `<app-toast />` come root globale | modificato |
| `src/app/app.ts` | Aggiunge `Toast` agli `imports` | modificato |

Nessuna dipendenza npm nuova.

---

## TODO 1 — FACILE: servizio con BehaviorSubject (~5 min)

Crea `src/app/services/notification.service.ts` con `@Injectable({ providedIn: 'root' })`.

**Interfaccia da esportare:**

```typescript
export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}
```

**Stato interno del servizio (campi privati):**

- `list$` = un `BehaviorSubject<Notification[]>` inizializzato a `[]`. **Privato** — nessuno fuori deve poter fare `next()`.
- `nextId = 1` — contatore per assegnare id univoci.

**Esposizione pubblica read-only:**

- `notifications$: Observable<Notification[]>` ottenuto con `list$.asObservable()`. Dichiararla `readonly`.

**Metodi pubblici (3 + 1):**

- `success(message: string): void`, `error(message: string): void`, `info(message: string): void` — tutti delegano a un metodo privato `push(type, message)`.
- `dismiss(id: number): void` — rimuove dalla lista filtrando per id e chiama `list$.next(...)`.
- `private push(type, message): void` — crea un `Notification` con `nextId++`, e fa `list$.next([...list$.value, n])`.

### Due punti chiave (dalla Scheda 11)

- **`private list$` + `readonly notifications$ = list$.asObservable()`** = **incapsulamento**. È lo stesso pattern dell'`AuthService` della scheda — chi tiene lo stato controlla chi può modificarlo. Se i consumer potessero fare `next()`, perderesti il controllo del flusso di stato.
- **`[...list$.value, n]`** produce sempre un nuovo riferimento → i subscriber rilevano il cambiamento. `list$.value.push(n)` seguito da `list$.next(list$.value)` invece *non* funzionerebbe in modi sottili (immutabilità delle reference, comparazioni `===`).

---

## TODO 2 — MEDIO: componente Toast (~5 min)

Crea `src/app/components/toast/toast.ts` come componente standalone con selector `app-toast` e templateUrl `./toast.html`.

**Cosa deve esporre la classe:**

- Inject di `NotificationService` e `DestroyRef` come campi privati.
- Un signal locale `list = signal<Notification[]>([])` alimentato dall'Observable del servizio. Tienilo `readonly`.
- Un metodo `dismiss(id: number)` che delega a `notifications.dismiss(id)`.

**Cosa fa il `constructor()`:**

- Sottoscrivi `notifications.notifications$` usando `.pipe(takeUntilDestroyed(this.destroyRef))` prima della `.subscribe(...)`. Nel callback di subscribe: `this.list.set(list)`.

**Template `toast.html` (consigli):**

- Contenitore `<div class="fixed top-4 right-4 flex flex-col gap-2 z-30 max-w-xs">`.
- Loop con `@for (n of list(); track n.id) { ... }` — nota la `()` per leggere il signal.
- Ogni toast ha classi diverse per `n.type` (`success` verde, `error` rosso, `info` blu). Puoi usare un'espressione ternaria nella property binding `[class]`.
- Bottone `<button (click)="dismiss(n.id)">✕</button>` per la chiusura manuale.

### Perché signal locale invece di `async pipe`?

Perché `notifications$ | async` nel template funzionerebbe ma:
1. Il resto del seme usa già signal nei template — è più uniforme.
2. Avere `list` come signal permette derivazioni gratuite (es. `count = computed(() => list().length)`).
3. La `subscribe` esplicita lascia spazio per filtri/trasformazioni RxJS in `pipe` prima di alimentare il signal.

È il classico ponte RxJS → signal: lo stream di sorgente resta `Observable`, il consumo nel componente è un signal.

---

## TODO 3 — FACILE: mount in app.html (~3 min)

Apri `src/app/app.html` e, **prima** del `</div>` finale, aggiungi il tag `<app-toast />`.

Poi in `src/app/app.ts` aggiungi `Toast` all'array `imports` del decoratore (insieme a `RouterOutlet`, `Header`, `Footer`, `LiveTimer` già presenti) e l'import del simbolo da `./components/toast/toast`.

> **Test rapido**: nel costruttore di `HomePage` (temporaneamente) aggiungi `inject(NotificationService).success('Toast funzionante!');`. Dovresti vedere il toast verde in alto a destra. Cliccando ✕, sparisce. Poi rimuovi la riga di test.

---

## TODO 4 — MEDIO: auto-dismiss dei toast (~5 min)

I toast restano a video finché l'utente non clicca ✕. Più realistico: spariscono dopo 4 secondi. **Senza intasare la zone** — l'errore classico è mettere il `setTimeout` dentro a un `zone.run` che fa scattare CD a ogni tick.

**Modifiche al `NotificationService`:**

1. Inietta `NgZone` come campo privato (`private zone = inject(NgZone)`).
2. Aggiungi un parametro `ttlMs = 4000` ai metodi pubblici `success / error / info` e a `push`. È un default-value parameter — chi non passa il TTL ottiene 4 secondi.
3. Alla fine di `push`, dopo il `next(...)`, programma il dismiss automatico **con il pattern sandwich**:

```
zone.runOutsideAngular(() => {
  setTimeout(() => zone.run(() => this.dismiss(n.id)), ttlMs);
});
```

### Il pattern sandwich (Scheda 10)

- **Registrazione del timeout FUORI zone**: il timer non scatena CD ad ogni tick interno di Angular.
- **Esecuzione del cambio di stato DENTRO zone** (`zone.run(() => ...)`): la riga che modifica il `BehaviorSubject` rientra in zone e fa aggiornare la UI normalmente.

Se inverti (timeout dentro zone, dismiss fuori): perdi il vantaggio principale **e** il dismiss non aggiorna la UI. Memorizza la forma a sandwich.

---

## TODO 5 — DIFFICILE (BONUS, ~10 min): riscrivi tutto con i signal

Chiude l'arco delle schede 10→11→12. Riprende lo stesso scenario e lo riscrive in versione **signal puri** — niente più `BehaviorSubject`, niente `Observable`, niente `subscribe`, niente `takeUntilDestroyed`.

I file della soluzione bonus sono in `bonus-signal/`. Prova prima tu, poi confronta.

### `NotificationService` signal-based — cosa cambia

- Sostituisci `private list$ = new BehaviorSubject<Notification[]>([])` con `private _list = signal<Notification[]>([])`. La convenzione è anteporre l'underscore al signal scrivibile privato.
- Sostituisci `readonly notifications$ = list$.asObservable()` con `readonly list = this._list.asReadonly()`. È il pendant di `asObservable()` nel mondo signal.
- Dentro `push`: invece di `list$.next([...list$.value, n])`, usa `this._list.update(list => [...list, n])`. L'API `.update(fn)` ti dà il valore corrente come argomento.
- Dentro `dismiss`: invece di filtrare e fare `next()`, usa `this._list.update(list => list.filter(n => n.id !== id))`.
- **Bonus dei bonus** — aggiungi due `computed` gratuiti: `count = computed(() => this._list().length)` e `hasErrors = computed(() => this._list().some(n => n.type === 'error'))`. Con `BehaviorSubject` richiederebbero `pipe(map(...))` o un secondo subject.
- Il pattern sandwich del TODO 4 **resta identico**: `zone` è ortogonale alla scelta signal/RxJS.

### `Toast` signal-based — cosa scompare

- Non serve più `DestroyRef`, `takeUntilDestroyed`, l'import di `signal`, né l'intera subscribe nel constructor.
- L'unico campo della classe diventa `readonly list = this.notifications.list` — esponi direttamente il signal del servizio.
- Il template `toast.html` **non cambia**: leggeva già `list()` come signal nel TODO 2.

### Cosa è sparito, cosa si guadagna

Sparisce: l'intero import di `rxjs`, l'import di `takeUntilDestroyed`, l'`inject(DestroyRef)`, tutto il costruttore di `Toast`. In cambio guadagni: `count` e `hasErrors` come `computed` quasi gratis, niente subscription da gestire, accesso sincrono al valore corrente come *default* invece che come eccezione (`.value` su `BehaviorSubject` è un'API di ripiego, sui signal è normale).

### Cosa **non** si guadagna

I `computed` sono lazy + memoizzati — ottimi per costi alti. Per costi triviali (un `.length`) il vantaggio è marginale. La differenza importante non è la performance ma il **modello mentale**: dichiari la relazione (`count = computed(() => list().length)`), il sistema pensa al *quando*.

### Cosa terresti comunque in BehaviorSubject

Vai a rileggere la sezione "Quando però terresti comunque RxJS" della [Scheda 12](../didattica/12-signal.md). Per un `NotificationService` *isolato* come questo lab, signal è la scelta migliore nel 2026. Lo terresti `BehaviorSubject` se il servizio dovesse comporsi con stream RxJS (es. ricevere notifiche da un'interceptor HTTP, da un canale WebSocket, da `combineLatest` di più sorgenti async).

---

## Criteri di verifica

- [ ] (TODO 1-3) Un `inject(NotificationService).success('msg')` fa apparire il toast verde in alto a destra.
- [ ] Cliccando ✕ il toast sparisce subito; gli altri restano.
- [ ] (TODO 4) Senza interazione, il toast sparisce da solo dopo 4 secondi.
- [ ] (TODO 4) Il profiler dei DevTools **non** mostra CD a 60Hz dopo l'emissione del toast (`setTimeout` è fuori zone).
- [ ] Navigando via dalla home e tornando, niente memory leak: la subscription di `Toast` è chiusa (`takeUntilDestroyed`) — o, nella versione signal, semplicemente non esiste.
- [ ] (TODO 5 bonus) Sostituendo i due file con la versione signal-based, l'app si comporta in modo identico — tutto da fuori sembra uguale.
- [ ] **Verifica formale (binario A):** applicando la `solution/` a `product-catalog-finale/`, `npx ng build` + `npx ng test` passano.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| Template: `'app-toast' is not a known element` | Manca `Toast` negli `imports` di `App` | TODO 3, app.ts |
| Toast non appare quando il servizio fa `success(...)` | Manca `<app-toast />` in `app.html` | TODO 3, app.html |
| Toast appaiono ma sono tutti dello stesso colore | Hai usato `[ngClass]` senza importare `NgClass`, o l'espressione condizionale è errata | TODO 2, toast.html |
| Memory leak (Toast resta sub-scritto dopo navigate) | Manca `takeUntilDestroyed(this.destroyRef)` nel `pipe()` | TODO 2, toast.ts |
| Toast non sparisce mai (TODO 4) | `setTimeout` chiamato dentro a `zone.run` invece che fuori | TODO 4 |
| Toast sparisce ma la UI non si aggiorna | `dismiss` chiamato fuori zone — manca il `zone.run` interno | TODO 4 |
| (Bonus) Signal letto senza parentesi nel template | `{{ list }}` invece di `{{ list() }}` | TODO 5 |

Soluzione BehaviorSubject in `solution/`, soluzione signal in `bonus-signal/`.

---

## Prossimo: fine Mod 1 · recap Giorno 1
