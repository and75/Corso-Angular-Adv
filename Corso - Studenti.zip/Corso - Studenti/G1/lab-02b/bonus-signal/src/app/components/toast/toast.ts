/**
 * LAB 2b — BONUS SIGNAL (TODO 5)
 * ─────────────────────────────────────────────────────────────────────────────
 * File: src/app/components/toast/toast.ts
 *
 * Versione signal del Toast — riscrittura della solution/ con la sola
 * differenza che il `list` esposto al template è ora il signal del servizio,
 * letto direttamente.
 *
 * Cosa sparisce rispetto alla solution/:
 *   ❌ import { DestroyRef, signal } from '@angular/core'
 *   ❌ import { takeUntilDestroyed } from '@angular/core/rxjs-interop'
 *   ❌ private destroyRef = inject(DestroyRef)
 *   ❌ readonly list = signal<Notification[]>([])  ← signal locale
 *   ❌ constructor() { ... pipe(takeUntilDestroyed) ... subscribe(...) }
 *
 * Cosa resta:
 *   ✅ inject(NotificationService)
 *   ✅ dismiss(id) — delega al servizio
 *   ✅ il template toast.html invariato (leggeva già list() come signal)
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Component, inject } from '@angular/core';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  templateUrl: './toast.html',
})
export class Toast {
  private notifications = inject(NotificationService);

  // espongo direttamente il signal del servizio — niente subscribe, niente cleanup
  readonly list = this.notifications.list;

  dismiss(id: number): void {
    this.notifications.dismiss(id);
  }
}
