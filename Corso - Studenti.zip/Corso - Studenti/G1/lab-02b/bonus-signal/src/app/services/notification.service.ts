/**
 * LAB 2b — BONUS SIGNAL (TODO 5)
 * ─────────────────────────────────────────────────────────────────────────────
 * File: src/app/services/notification.service.ts
 *
 * Stesso scenario della solution/, riscritto con signal/computed (Scheda 12).
 *
 * Differenze dalla versione BehaviorSubject:
 *   ✅ niente import RxJS — solo @angular/core
 *   ✅ private _list = signal<Notification[]>([])  invece di BehaviorSubject
 *   ✅ readonly list = _list.asReadonly()           invece di asObservable()
 *   ✅ readonly count / hasErrors = computed(...)   derivati gratuiti
 *   ✅ _list.update(list => [...list, n])           invece di list$.next([...list$.value, n])
 *   ✅ il sandwich runOutsideAngular + zone.run resta identico
 *
 * Per il consumer:
 *   ✅ il Toast NON ha più constructor + subscribe + signal locale
 *   ✅ legge direttamente il signal del servizio: readonly list = this.notifications.list
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Injectable, inject, NgZone, signal, computed } from '@angular/core';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}

@Injectable({ providedIn: 'root' })
export class NotificationService {

  private zone = inject(NgZone);

  // la "cella del foglio di calcolo": signal scrivibile privato
  private _list = signal<Notification[]>([]);
  private nextId = 1;

  // esposizione read-only — pendant di asObservable() nel mondo signal
  readonly list = this._list.asReadonly();

  // computed gratis — con BehaviorSubject avresti scritto pipe(map(l => l.length))
  readonly count = computed(() => this._list().length);
  readonly hasErrors = computed(() => this._list().some(n => n.type === 'error'));

  success(message: string, ttlMs = 4000): void { this.push('success', message, ttlMs); }
  error(message: string,   ttlMs = 4000): void { this.push('error',   message, ttlMs); }
  info(message: string,    ttlMs = 4000): void { this.push('info',    message, ttlMs); }

  dismiss(id: number): void {
    this._list.update(list => list.filter(n => n.id !== id));
  }

  private push(type: Notification['type'], message: string, ttlMs: number): void {
    const n: Notification = { id: this.nextId++, type, message };
    this._list.update(list => [...list, n]);

    // sandwich identico a quello della solution/: la zone gestisce il timer,
    // signal non c'entra. La "lavagnetta" è cambiata, il timer no.
    this.zone.runOutsideAngular(() => {
      setTimeout(() => this.zone.run(() => this.dismiss(n.id)), ttlMs);
    });
  }
}
