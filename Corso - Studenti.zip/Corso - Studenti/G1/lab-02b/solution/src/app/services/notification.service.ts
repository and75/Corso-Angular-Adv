/**
 * LAB 2b — SOLUTION
 * ─────────────────────────────────────────────────────────────────────────────
 * File: src/app/services/notification.service.ts
 *
 * Servizio singleton (providedIn: 'root') che pubblica una lista di toast
 * tramite BehaviorSubject, esposta read-only come Observable.
 *
 * Punti chiave (Scheda 11):
 *   ✅ private list$ + readonly notifications$ → incapsulamento
 *   ✅ push immutabile con [...list$.value, n] → CD/subscriber rilevano la modifica
 *   ✅ id auto-generato per dismiss puntuale
 *   ✅ TODO 4: auto-dismiss con setTimeout fuori zone + zone.run dentro
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Injectable, inject, NgZone } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}

@Injectable({ providedIn: 'root' })
export class NotificationService {

  private zone = inject(NgZone);

  // Stato interno (immutabile): nessuno fuori può fare next()
  private list$ = new BehaviorSubject<Notification[]>([]);
  private nextId = 1;

  // API pubblica read-only
  readonly notifications$: Observable<Notification[]> = this.list$.asObservable();

  success(message: string, ttlMs = 4000): void { this.push('success', message, ttlMs); }
  error(message: string,   ttlMs = 4000): void { this.push('error',   message, ttlMs); }
  info(message: string,    ttlMs = 4000): void { this.push('info',    message, ttlMs); }

  dismiss(id: number): void {
    this.list$.next(this.list$.value.filter(n => n.id !== id));
  }

  private push(type: Notification['type'], message: string, ttlMs: number): void {
    const n: Notification = { id: this.nextId++, type, message };
    this.list$.next([...this.list$.value, n]);   // ✅ nuovo riferimento sempre

    // ✅ TODO 4: sandwich runOutsideAngular + zone.run
    // - setTimeout FUORI zone (non scatena CD ad ogni tick del timer)
    // - dismiss DENTRO zone (deve aggiornare il BehaviorSubject + propagare al template)
    this.zone.runOutsideAngular(() => {
      setTimeout(() => this.zone.run(() => this.dismiss(n.id)), ttlMs);
    });
  }
}
