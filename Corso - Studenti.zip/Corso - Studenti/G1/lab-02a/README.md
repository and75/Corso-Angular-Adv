# Lab 2a — Carousel Splide con NgZone
### Giorno 1 · Lab guidato (~18 min)

---

## Obiettivo

Applicare il pattern della [Scheda 10 — Libreria legacy + NgZone](../didattica/10-legacy-ngzone.md) integrando **Splide.js** nella home del catalogo. Si scrive un componente standalone `Carousel` che avvolge la libreria DOM legacy senza intasare il change detection di Angular.

Risultato visivo: sopra alla griglia dei prodotti scorre un carousel di slide promozionali in autoplay ogni 3 secondi.

---

## File creati / modificati

| File | Ruolo | Stato |
|---|---|---|
| `src/app/components/carousel/carousel.ts` + `.html` | Wrapper Splide standalone | **nuovo** |
| `src/app/pages/home/home.page.ts` | Aggiunge `Carousel` agli `imports` | modificato |
| `src/app/pages/home/home.page.html` | Aggiunge `<app-carousel [slides]="..." />` sopra al filtro | modificato |
| `package.json` | Aggiunge `@splidejs/splide` | dipendenza |

---

## Setup — installa Splide (3 min)

Solo per il progetto di verifica `product-catalog-finale/` (il seme resta intatto):

```bash
cd Corso/progetto/product-catalog-finale
npm install @splidejs/splide
```

> Splide.js è una libreria carousel vanilla JS (~25 kB, zero dipendenze). La useremo come esempio "libreria che lavora sul DOM e si gestisce da sola" — esattamente il caso d'uso del pattern `runOutsideAngular`.

Nel componente non dimenticare l'import degli stili: `import '@splidejs/splide/css';`. Senza questa riga le slide si impilano verticalmente con larghezza 0.

---

## TODO 1 — MEDIO: componente Carousel (~10 min)

Crea `src/app/components/carousel/carousel.ts` come componente standalone con selector `app-carousel` e templateUrl `./carousel.html`.

**Cosa deve esporre la classe:**

- Un **signal input richiesto** `slides` di tipo `string[]` (vedi [Scheda 06 — Signal](../didattica/06-signal.md) sui `input.required<T>()`).
- Una **viewChild required** che punta alla `<section>` ospite del template, tipizzata `ElementRef<HTMLElement>`, usando la template variable `#host`.
- Un campo privato `splide?: Splide` per tenere il riferimento all'istanza, così possiamo distruggerla al destroy.

**Cosa deve fare il `constructor()` (tre passaggi, tutti commentati nello starter):**

1. **Iniettare** `NgZone` e `DestroyRef` con `inject()` come campi privati.
2. Dentro `afterNextRender(() => { ... })`: chiamare `zone.runOutsideAngular(() => { ... })` e qui dentro istanziare Splide passando `host().nativeElement` come primo argomento e l'oggetto opzioni come secondo. Subito dopo: `this.splide.mount()`. Salvare il risultato in `this.splide`.
3. **Fuori** dall'`afterNextRender`, ma sempre nel costruttore: `destroyRef.onDestroy(() => this.splide?.destroy())`.

**Opzioni Splide richieste** (oggetto da passare al costruttore):
- `type: 'loop'`
- `perPage: 1`
- `autoplay: true`
- `interval: 3000`

**Template `carousel.html`** — la struttura HTML è imposta dalla libreria (`section.splide > div.splide__track > ul.splide__list > li.splide__slide`). Sulla `<section>` mettere la template variable `#host` e l'attributo `aria-label="Promozioni"`. Dentro l'`<ul>` ciclare le slide con il nuovo control flow `@for (s of slides(); track s) { ... }` — ogni `<li>` mostra `{{ s }}` con classi Tailwind a piacere (`bg-teal-50 text-teal-800 text-center py-6 font-semibold` come default).

### Tre punti chiave del pattern (Scheda 10)

- **`afterNextRender`** parte dopo il primo render lato browser, **non** sul server. Renderà il componente SSR-safe (torna utile nel Mod 6). Non usare `ngOnInit`: la view non esiste ancora e Splide misurerebbe 0 px.
- **Tutta la mount è in `runOutsideAngular`**: gli event-listener e l'animation loop di Splide non scatenano change detection. Senza questa riga vedrai un picco di CD ogni 16 ms nel profiler.
- **`destroyRef.onDestroy(() => splide?.destroy())`** evita il memory leak quando l'utente naviga via dalla home e torna. È il pendant moderno di `ngOnDestroy`.

---

## TODO 2 — FACILE: mount in home.page.html (~5 min)

Apri `src/app/pages/home/home.page.html` e **sopra** alla riga del filtro (l'`<input type="text" [(ngModel)]="searchTerm" ...>`) inserisci il tag `<app-carousel>` passandogli un array di 3 stringhe promozionali come signal input `[slides]`. Aggiungi una classe `class="block mb-6"` per dargli margine inferiore.

Esempi di stringhe (sostituiscile a piacere):

- 🚀 Spedizione gratuita oltre 50€
- 🎁 Reso entro 30 giorni
- 🛡️ Garanzia 2 anni

Poi in `src/app/pages/home/home.page.ts` aggiungi `Carousel` all'array `imports` del decoratore `@Component` (insieme a `CommonModule`, `FormsModule`, `FilterProductsPipe`, `CartSummary`, `ProductCard`, `CardContainer` già presenti) e l'import del simbolo dal path relativo `../../components/carousel/carousel`.

> A questo punto la home mostra il carousel con autoplay ogni 3 secondi. **Apri il Performance tab dei DevTools**: niente change detection scatenato dai tick di Splide. Se vuoi confrontare, commenta temporaneamente `zone.runOutsideAngular(...)` e tieni la mount diretta — vedrai un picco di chiamate di CD ogni 16 ms.

---

## Criteri di verifica

- [ ] Il carousel parte all'avvio della home, autoplay ogni 3 secondi.
- [ ] Le slide hanno larghezza coerente (no `width: 0`, no sovrapposizione) — vuol dire che `afterNextRender` ha aspettato il DOM correttamente.
- [ ] Niente errori console (`Cannot read properties of undefined` su `host.nativeElement` = init prima della view).
- [ ] Navigando via dalla home e tornando, il carousel si re-istanzia senza errori — il vecchio `splide?.destroy()` parte al `destroyRef.onDestroy`.
- [ ] **Verifica formale (binario A):** applicando la `solution/` a `product-catalog-finale/` (dopo `npm install @splidejs/splide`), `npx ng build` + `npx ng test` passano.

---

## Se ti blocchi

| Sintomo | Probabile causa | Dove guardare |
|---|---|---|
| `Cannot find module '@splidejs/splide'` | Manca `npm install @splidejs/splide` | Setup |
| Splide misura 0 px / slide impilate verticalmente | Manca `import '@splidejs/splide/css'` | TODO 1, riga import |
| Splide misura 0 px / layout sbagliato | Init in `ngOnInit` invece di `afterNextRender` (la view non è ancora costruita) | TODO 1, constructor |
| App scattante in CD continuo (60 FPS sprecati) | Manca `runOutsideAngular` attorno a `splide.mount()` | TODO 1, constructor |
| `splide.destroy is not a function` quando navighi via | Non hai salvato `this.splide = ...` dentro al callback di `runOutsideAngular`, oppure manca `destroyRef.onDestroy` | TODO 1, constructor |
| Template: `'app-carousel' is not a known element` | Manca `Carousel` negli `imports` di `HomePage` | TODO 2, home.page.ts |

Soluzione completa in `solution/` — aprila solo dopo aver tentato!

---

## Prossimo: [Lab 2b — NotificationService con BehaviorSubject](../lab-02b/README.md)
